# Playwright Documentation Research - Getting Started with VS Code

**Page:** Getting started - VS Code  
**URL:** https://playwright.dev/docs/getting-started-vscode  
**Research Date:** December 13, 2025

## Overview

The Playwright VS Code extension brings the full power of Playwright Test directly into the editor, enabling developers to run, debug, and generate tests with a seamless UI-driven experience. This integration transforms VS Code into a comprehensive testing environment.

## Prerequisites

Before using the extension, ensure the following are installed:
- Node.js (LTS version recommended)
- Visual Studio Code

## Installation Process

The installation follows a three-step process:

**Step 1: Install the Extension** - Open the Extensions view in VS Code using `Ctrl+Shift+X` (Windows/Linux) or `Cmd+Shift+X` (Mac), search for "Playwright", and install the official extension from Microsoft.

**Step 2: Install Playwright** - Open the Command Palette using `Ctrl+Shift+P` (Windows/Linux) or `Cmd+Shift+P` (Mac) and run the **Test: Install Playwright** command.

**Step 3: Select Browsers** - Choose browsers for testing (Chromium, Firefox, WebKit). The setup wizard also offers to add a GitHub Actions workflow for CI. All settings can be modified later in the `playwright.config.ts` file.

## Test Explorer Interface

The Test Explorer is accessed by clicking the **Testing icon** in the VS Code Activity Bar. This interface provides:
- Complete test tree view
- Playwright sidebar for managing projects, tools, and settings
- Visual representation of test hierarchy
- Quick access to all testing features

## Running Tests

### Single Test Execution

Click the green "play" icon next to any test to execute it. The icon changes to:
- **Green checkmark** - Test passed
- **Red X** - Test failed

Test execution time displays next to the test name. The Test Results panel automatically opens at the bottom of VS Code, showing:
- Number of tests run
- Pass/fail/skip counts
- Total execution time
- Detailed summary

### Running Multiple Tests

Tests can be executed at different levels:
- **File level** - Click the play icon next to a test file to run all tests in that file
- **Project level** - Click the play icon at the top of Test Explorer to run all tests across the entire project

### Multi-Browser Testing

The Playwright sidebar includes checkboxes for projects (browser configurations). Each project represents a specific browser with its own settings:
- Browser type (Chromium, Firefox, WebKit)
- Viewport size
- Device emulation
- Browser-specific options

When a test runs, it executes across all selected projects, verifying consistent behavior across different browsers and configurations.

### Browser Visibility Control

The **Show Browser** option in the sidebar controls browser visibility:
- **Enabled** - Tests execute in a live browser window (headed mode)
- **Disabled** - Tests run in headless mode (background execution without visible browser)

## Debugging Capabilities

The VS Code extension provides comprehensive debugging tools for identifying and fixing test issues.

### Breakpoint Debugging

Set breakpoints by clicking in the gutter next to line numbers. Right-click the test and select **Debug Test**. The test pauses at breakpoints, allowing:
- Variable inspection
- Step-through execution
- Call stack examination
- Expression evaluation

### Live Debugging

With **Show Browsers** enabled, clicking on a locator in code causes Playwright to highlight the corresponding element in the browser. This feature:
- Verifies locator accuracy
- Identifies element selection issues
- Provides visual feedback
- Simplifies locator refinement

### Error Message Display

When tests fail, the extension displays detailed error information directly in the editor:
- Expected vs. received values
- Full call log
- Stack traces
- Contextual error details

### AI-Powered Fix Suggestions

The **Fix with AI** feature provides intelligent error resolution:
- Click the sparkle icon next to errors
- Copilot analyzes the failure
- Suggests code changes to resolve issues
- Accelerates debugging workflow

### Trace Viewer Integration

Enable **Show Trace Viewer** in the Playwright sidebar for comprehensive debugging. When tests finish, a detailed trace automatically opens, providing:

**Step-by-step analysis** - Navigate through each action with precise timestamps to understand test execution flow.

**DOM inspection** - View DOM snapshots at any point during test execution to see exactly what the page looked like at each moment.

**Network monitoring** - Examine all network requests and responses that occurred during the test, including headers, payloads, and timing information.

**Console logs** - Access all console messages and errors from the browser to identify JavaScript issues.

**Source mapping** - Jump directly to the source code that executed each action for quick navigation.

**Visual debugging** - See screenshots and understand what the user would have seen at each step of the test.

The trace viewer is especially valuable for:
- Debugging flaky tests
- Understanding complex user interactions
- Post-mortem analysis of failures
- Sharing debugging context with team members

## Test Generation with CodeGen

CodeGen is Playwright's powerful test generation tool that automatically creates test code by recording interactions with web pages. Instead of writing tests from scratch, developers can navigate through applications while CodeGen captures actions and converts them into reliable test code with proper locators and assertions.

### Recording New Tests

Click **Record new** in the sidebar to open a browser window. As you interact with the page:
- Playwright automatically generates test code
- Actions are captured in real-time
- Proper locators are selected
- Assertions can be generated from the recording toolbar

### Recording at Cursor Position

Place the cursor inside an existing test and click **Record at cursor** to add new actions at that specific point. This enables:
- Extending existing tests
- Inserting additional steps
- Modifying test flows
- Building tests incrementally

### Pick Locator Tool

The **Pick locator** tool allows clicking on any element in the opened browser. Playwright:
- Determines the best locator for the element
- Copies the locator to clipboard
- Makes it ready to paste into code
- Follows locator best practices

## Advanced Features

### Project Dependencies

Project dependencies define setup tests that run before other tests. For example, a login test can run first, then the authenticated state is reused across multiple tests without repeating login for each test.

**VS Code Integration:**
- Setup tests appear in Test Explorer
- Can be run independently when needed
- Visual dependency representation
- Simplified test organization

### Global Setup and Teardown

For tasks that need to run only once before all tests (like seeding a database), use **Global Setup**. The Playwright sidebar provides manual triggers for:
- Global setup execution
- Global teardown execution
- One-time initialization tasks
- Environment preparation

### Multiple Configuration Files

If multiple `playwright.config.ts` files exist, switch between them using the gear icon in the Playwright sidebar. This enables:
- Working with different test suites
- Managing multiple environments
- Project-specific configurations
- Flexible test organization

## Quick Reference Table

| Action | How to do it in VS Code |
|--------|------------------------|
| Install Playwright | Command Palette → `Test: Install Playwright` |
| Run a Test | Click the "play" icon next to the test |
| Debug a Test | Set a breakpoint, right-click the test → `Debug Test` |
| Show Live Browser | Enable `Show Browsers` in the Playwright sidebar |
| Record a New Test | Click `Record new` in the Playwright sidebar |
| Pick a Locator | Click `Pick locator` in the Playwright sidebar |
| View Test Trace | Enable `Show Trace Viewer` in the Playwright sidebar |

## Key Benefits

The VS Code extension provides numerous advantages for Playwright test development:

**Integrated Workflow** - All testing activities occur within the familiar VS Code environment without context switching.

**Visual Feedback** - Immediate visual representation of test execution, results, and browser interactions.

**Debugging Power** - Comprehensive debugging tools including breakpoints, variable inspection, and trace viewer integration.

**Test Generation** - CodeGen integration enables rapid test creation through recording rather than manual coding.

**Multi-Browser Support** - Easy configuration and execution across multiple browsers and configurations.

**AI Assistance** - Copilot integration provides intelligent error resolution suggestions.

**Project Management** - Support for complex project structures with multiple configurations and dependencies.

## Best Practices Identified

1. **Use Show Browser During Development** - Visual feedback helps verify test behavior and debug issues
2. **Leverage Trace Viewer for Complex Failures** - Comprehensive debugging information aids in understanding failures
3. **Generate Tests with CodeGen** - Accelerate test creation and learn proper locator patterns
4. **Set Breakpoints Strategically** - Focus debugging efforts on problematic test sections
5. **Use Pick Locator Tool** - Verify and refine locators interactively
6. **Enable AI Fix Suggestions** - Leverage Copilot for faster error resolution
7. **Organize with Project Dependencies** - Structure tests efficiently with setup/teardown patterns
8. **Switch Configurations as Needed** - Use multiple config files for different testing scenarios

## Related Topics to Explore

- Trace Viewer detailed guide
- CodeGen comprehensive documentation
- Project Dependencies guide
- Web-first assertions
- Page fixtures
- Locators guide
- CI integration from VS Code
- Test organization patterns
