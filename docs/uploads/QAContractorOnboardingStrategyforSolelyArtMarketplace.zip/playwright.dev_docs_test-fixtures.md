import { test } from '@playwright/test';

// Completely unset baseURL for this file.
test.use({
  baseURL: [async ({}, use) => use(undefined), { scope: 'test' }],
});

test('no base url', async ({ page }) => {
  // This test will not have a base url.
});

Execution order​

Each fixture has a setup and teardown phase before and after the await use() call in the fixture. Setup is executed before the test/hook requiring it is run, and teardown is executed when the fixture is no longer being used by the test/hook.

Fixtures follow these rules to determine the execution order:

When fixture A depends on fixture B: B is always set up before A and torn down after A.
Non-automatic fixtures are executed lazily, only when the test/hook needs them.
Test-scoped fixtures are torn down after each test, while worker-scoped fixtures are only torn down when the worker process executing tests is torn down.

Consider the following example:

import { test as base } from '@playwright/test';

const test = base.extend<{
  testFixture: string,
  autoTestFixture: string,
  unusedFixture: string,
}, {
  workerFixture: string,
  autoWorkerFixture: string,
}>({
  workerFixture: [async ({ browser }) => {
    // workerFixture setup...
    await use('workerFixture');
    // workerFixture teardown...
  }, { scope: 'worker' }],

  autoWorkerFixture: [async ({ browser }) => {
    // autoWorkerFixture setup...
    await use('autoWorkerFixture');
    // autoWorkerFixture teardown...
  }, { scope: 'worker', auto: true }],

  testFixture: [async ({ page, workerFixture }) => {
    // testFixture setup...
    await use('testFixture');
    // testFixture teardown...
  }, { scope: 'test' }],

  autoTestFixture: [async () => {
    // autoTestFixture setup...
    await use('autoTestFixture');
    // autoTestFixture teardown...
  }, { scope: 'test', auto: true }],

  unusedFixture: [async ({ page }) => {
    // unusedFixture setup...
    await use('unusedFixture');
    // unusedFixture teardown...
  }, { scope: 'test' }],
});

test.beforeAll(async () => { /* ... */ });
test.beforeEach(async ({ page }) => { /* ... */ });
test('first test', async ({ page }) => { /* ... */ });
test('second test', async ({ testFixture }) => { /* ... */ });
test.afterEach(async () => { /* ... */ });
test.afterAll(async () => { /* ... */ });


Normally, if all tests pass and no errors are thrown, the order of execution is as following.

worker setup and beforeAll section:
browser setup because it is required by autoWorkerFixture.
autoWorkerFixture setup because automatic worker fixtures are always set up before anything else.
beforeAll runs.
first test section:
autoTestFixture setup because automatic test fixtures are always set up before test and beforeEach hooks.
page setup because it is required in beforeEach hook.
beforeEach runs.
first test runs.
afterEach runs.
page teardown because it is a test-scoped fixture and should be torn down after the test finishes.
autoTestFixture teardown because it is a test-scoped fixture and should be torn down after the test finishes.
second test section:
autoTestFixture setup because automatic test fixtures are always set up before test and beforeEach hooks.
page setup because it is required in beforeEach hook.
beforeEach runs.
workerFixture setup because it is required by testFixture that is required by the second test.
testFixture setup because it is required by the second test.
second test runs.
afterEach runs.
testFixture teardown because it is a test-scoped fixture and should be torn down after the test finishes.
page teardown because it is a test-scoped fixture and should be torn down after the test finishes.
autoTestFixture teardown because it is a test-scoped fixture and should be torn down after the test finishes.
afterAll and worker teardown section:
afterAll runs.
workerFixture teardown because it is a workers-scoped fixture and should be torn down once at the end.
autoWorkerFixture teardown because it is a workers-scoped fixture and should be torn down once at the end.
browser teardown because it is a workers-scoped fixture and should be torn down once at the end.

A few observations:

page and autoTestFixture are set up and torn down for each test, as test-scoped fixtures.
unusedFixture is never set up because it is not used by any tests/hooks.
testFixture depends on workerFixture and triggers its setup.
workerFixture is lazily set up before the second test, but torn down once during worker shutdown, as a worker-scoped fixture.
autoWorkerFixture is set up for beforeAll hook, but autoTestFixture is not.
Combine custom fixtures from multiple modules​

You can merge test fixtures from multiple files or modules:

fixtures.ts
import { mergeTests } from '@playwright/test';
import { test as dbTest } from 'database-test-utils';
import { test as a11yTest } from 'a11y-test-utils';

export const test = mergeTests(dbTest, a11yTest);

test.spec.ts
import { test } from './fixtures';

test('passes', async ({ database, page, a11y }) => {
  // use database and a11y fixtures.
});

Box fixtures​

Usually, custom fixtures are reported as separate steps in the UI mode, Trace Viewer and various test reports. They also appear in error messages from the test runner. For frequently used fixtures, this can mean lots of noise. You can stop the fixtures steps from being shown in the UI by "boxing" it.

import { test as base } from '@playwright/test';

export const test = base.extend({
  helperFixture: [async ({}, use, testInfo) => {
    // ...
  }, { box: true }],
});


This is useful for non-interesting helper fixtures. For example, an automatic fixture that sets up some common data can be safely hidden from a test report.

You can also mark the fixture as box: 'self' to only hide that particular fixture, but include all the steps inside the fixture in the test report.

Custom fixture title​

Instead of the usual fixture name, you can give fixtures a custom title that will be shown in test reports and error messages.

import { test as base } from '@playwright/test';

export const test = base.extend({
  innerFixture: [async ({}, use, testInfo) => {
    // ...
  }, { title: 'my fixture' }],
});

Adding global beforeEach/afterEach hooks​

test.beforeEach() and test.afterEach() hooks run before/after each test declared in the same file and same test.describe() block (if any). If you want to declare hooks that run before/after each test globally, you can declare them as auto fixtures like this:

fixtures.ts
import { test as base } from '@playwright/test';

export const test = base.extend<{ forEachTest: void }>({
  forEachTest: [async ({ page }, use) => {
    // This code runs before every test.
    await page.goto('http://localhost:8000');
    await use();
    // This code runs after every test.
    console.log('Last URL:', page.url());
  }, { auto: true }],  // automatically starts for every test.
});


And then import the fixtures in all your tests:

mytest.spec.ts
import { test } from './fixtures';
import { expect } from '@playwright/test';

test('basic', async ({ page }) => {
  expect(page).toHaveURL('http://localhost:8000');
  await page.goto('https://playwright.dev');
});

Adding global beforeAll/afterAll hooks​

test.beforeAll() and test.afterAll() hooks run before/after all tests declared in the same file and same test.describe() block (if any), once per worker process. If you want to declare hooks that run before/after all tests in every file, you can declare them as auto fixtures with scope: 'worker' as follows:

fixtures.ts
import { test as base } from '@playwright/test';

export const test = base.extend<{}, { forEachWorker: void }>({
  forEachWorker: [async ({}, use) => {
    // This code runs before all the tests in the worker process.
    console.log(`Starting test worker ${test.info().workerIndex}`);
    await use();
    // This code runs after all the tests in the worker process.
    console.log(`Stopping test worker ${test.info().workerIndex}`);
  }, { scope: 'worker', auto: true }],  // automatically starts for every worker.
});


And then import the fixtures in all your tests:

mytest.spec.ts
import { test } from './fixtures';
import { expect } from '@playwright/test';

test('basic', async ({ }) => {
  // ...
});


Note that the fixtures will still run once per worker process, but you don't need to redeclare them in every file.

Previous
Emulation
Next
Global setup and teardown
Introduction
Built-in fixtures
Without fixtures
With fixtures
Creating a fixture
Using a fixture
Overriding fixtures
Worker-scoped fixtures
Automatic fixtures
Fixture timeout
Fixtures-options
Execution order
Combine custom fixtures from multiple modules
Box fixtures
Custom fixture title
Adding global beforeEach/afterEach hooks
Adding global beforeAll/afterAll hooks
Learn
Getting started
Playwright Training
Learn Videos
Feature Videos
Community
Stack Overflow
Discord
Twitter
LinkedIn
More
GitHub
YouTube
Blog
Ambassadors
Copyright © 2025 Microsoft