# Monday.com Board Design for Solely Art Platform QA

This document outlines the design for the Monday.com board that will be used to manage the Quality Assurance (QA) process for the Solely Art Platform. The board is structured to provide a clear and efficient workflow for QA contractors, enabling them to track tasks, report bugs, and communicate progress effectively.

## Board Structure

The board will be named "Solely Art Platform - QA" and will be divided into two main groups:

### 1. QA Tasks

This group will house all the QA tasks that need to be executed. Each task will represent a specific test scenario or feature to be tested.

### 2. Bugs & Issues

This group will be used to log and track all the bugs and issues discovered during the testing process. Creating a separate group for bugs allows for a clear distinction between the initial QA tasks and the resulting bug reports, which helps in tracking the bug lifecycle independently.

## Columns

The following columns will be used in both groups to capture and organize the necessary information:

| Column Name | Column Type | Description |
|---|---|---|
| **Task Name** | Text | The name of the QA task or a concise summary of the bug. |
| **Assignee** | Person | The QA contractor assigned to the task or the developer assigned to fix the bug. |
| **Status** | Status | The current status of the task or bug. The status labels and their workflow are described in the next section. |
| **Priority** | Priority | The priority of the task or bug (e.g., High, Medium, Low). |
| **Epic** | Text | The high-level feature or user story that the task or bug relates to (e.g., Booking Engine, Payment Integration). |
| **Steps to Reproduce** | Long Text | (For Bugs & Issues group only) A detailed, step-by-step description of how to reproduce the bug. |
| **Expected Result** | Long Text | (For Bugs & Issues group only) A clear description of the expected behavior. |
| **Actual Result** | Long Text | (For Bugs & Issues group only) A clear description of the actual behavior observed. |
| **Attachments** | File | For uploading screenshots, videos, or logs that provide additional context to the task or bug. |
| **Linked Items** | Connect Boards | To create a relationship between a QA task and the bugs that were found during its execution. This is crucial for traceability. |

## Workflow and Statuses

The `Status` column will be the primary driver of the workflow. The following statuses will be used to track the progress of tasks and bugs:

| Status | Description | Workflow Action |
|---|---|---|
| **To Do** | The task or bug has been created but has not yet been started. | When a new task is created, it starts with this status. |
| **In Progress** | The QA contractor has started working on the task or the developer has started working on the bug fix. | The assignee changes the status to "In Progress" when they begin working. |
| **Blocked** | The task or bug cannot be progressed due to a dependency or an issue. | If a QA task is blocked by a bug, its status is changed to "Blocked" and it is linked to the bug item. |
| **Passed QA** | The QA task has been completed, and all test cases have passed. | The QA contractor changes the status to "Passed QA" after successful testing. |
| **Ready for Retest** | The bug has been fixed by the development team and is ready to be retested by the QA contractor. | The developer changes the status to "Ready for Retest" after deploying the fix. |
| **Closed** | The bug has been retested and verified as fixed, or the QA task is complete and all related bugs are closed. | The QA contractor changes the status to "Closed" after verifying the fix. |

This workflow provides a clear and delegated system for managing QA. When a QA contractor finds a bug, they create a new item in the "Bugs & Issues" group and link it to the original QA task. This action of creating a bug report and linking it serves as the notification to the development team that a fix is needed. The developer can then pick up the bug, fix it, and move it to "Ready for Retest," which in turn notifies the QA contractor to verify the fix. This process ensures a clear separation of concerns and a smooth handover between the QA and development teams.
