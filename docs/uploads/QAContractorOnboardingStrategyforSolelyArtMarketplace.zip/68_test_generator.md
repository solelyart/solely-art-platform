# Playwright Documentation Research - Test Generator

**Page:** Test Generator
**URL:** https://playwright.dev/docs/codegen
**Research Date:** December 14, 2025

## Overview

Playwright provides a test generator (Codegen) to record user interactions and generate test code.

### Key Features

- **Record user interactions:** Clicks, typing, and other actions.
- **Generate test code:** In JavaScript, Python, Java, or C#.
- **Speed up test authoring:** By automating the process of writing test code.

## Usage

```bash
npx playwright codegen wikipedia.org
```

## Summary

### Key Takeaways

- **`npx playwright codegen`:** To start the test generator.
- **Record and generate:** To quickly create test code.

### Related Topics

- Writing Tests
- Locators
