# Playwright Documentation Research - Network

**Page:** Network  
**URL:** https://playwright.dev/docs/network  
**Research Date:** December 13, 2025

## Introduction

**Overview:** Playwright provides APIs to **monitor** and **modify** browser network traffic, both HTTP and HTTPS.

**Capabilities:**
- Track requests (XHRs and fetch)
- Modify requests
- Handle requests
- Monitor network events

## Mock APIs

**Reference:** See API mocking guide for detailed information on:
- Mock API requests and never hit the API
- Perform API request and modify response
- Use HAR files to mock network requests

## Network Mocking

### Context-Level Mocking

**No configuration needed:** Just define custom Route that mocks network for browser context.

**Example:**
```typescript
import { test, expect } from '@playwright/test';

test.beforeEach(async ({ context }) => {
  // Block any css requests for each test in this file
  await context.route(/.css$/, route => route.abort());
});

test('loads page without css', async ({ page }) => {
  await page.goto('https://playwright.dev');
  // ... test goes here
});
```

**Benefit:** Applies to all pages in context.

### Page-Level Mocking

**Alternative:** Use `page.route()` to mock network in single page.

**Example:**
```typescript
import { test, expect } from '@playwright/test';

test('loads page without images', async ({ page }) => {
  // Block png and jpeg images
  await page.route(/(png|jpeg)$/, route => route.abort());

  await page.goto('https://playwright.dev');
  // ... test goes here
});
```

**Benefit:** Scoped to single page only.

## HTTP Authentication

**Configuration:** Set HTTP credentials globally in config.

**Example:**
```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    httpCredentials: {
      username: 'bill',
      password: 'pa55w0rd',
    }
  }
});
```

**Use case:** Test pages requiring HTTP authentication.

## HTTP Proxy

### Overview

**Support:** Configure pages to load over HTTP(S) proxy or SOCKSv5.

**Scope options:**
- Global for entire browser
- Per browser context

**Optional settings:**
- Username and password for HTTP(S) proxy
- Hosts to bypass proxy

### Global Proxy Configuration

**Example:**
```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    proxy: {
      server: 'http://myproxy.com:3128',
      username: 'usr',
      password: 'pwd'
    }
  }
});
```

### Per-Context Proxy Configuration

**Example:**
```typescript
import { test, expect } from '@playwright/test';

test('should use custom proxy on a new context', async ({ browser }) => {
  const context = await browser.newContext({
    proxy: {
      server: 'http://myproxy.com:3128',
    }
  });
  const page = await context.newPage();

  await context.close();
});
```

## Network Events

### Monitor Requests and Responses

**Event listeners:** Subscribe to 'request' and 'response' events.

**Example:**
```typescript
// Subscribe to 'request' and 'response' events
page.on('request', request => console.log('>>', request.method(), request.url()));
page.on('response', response => console.log('<<', response.status(), response.url()));

await page.goto('https://example.com');
```

**Use case:** Monitor all network traffic for debugging or logging.

### Wait for Network Response

**Method:** `page.waitForResponse()`

**Pattern:** Create promise before action, await after action.

**Example with glob pattern:**
```typescript
// Use a glob URL pattern. Note no await.
const responsePromise = page.waitForResponse('**/api/fetch_data');
await page.getByText('Update').click();
const response = await responsePromise;
```

**Example with RegExp:**
```typescript
// Use a RegExp. Note no await.
const responsePromise = page.waitForResponse(/\.jpeg$/);
await page.getByText('Update').click();
const response = await responsePromise;
```

**Example with predicate:**
```typescript
// Use a predicate taking a Response object. Note no await.
const responsePromise = page.waitForResponse(response => response.url().includes(token));
await page.getByText('Update').click();
const response = await responsePromise;
```

## Handle Requests

### Basic Request Handling

**Method:** `page.route()` with `route.fulfill()`

**Example:**
```typescript
await page.route('**/api/fetch_data', route => route.fulfill({
  status: 200,
  body: testData,
}));
await page.goto('https://example.com');
```

**Purpose:** Mock API endpoints via handling network requests.

### Context-Level vs Page-Level

**Context-level routing:**
```typescript
await browserContext.route('**/api/login', route => route.fulfill({
  status: 200,
  body: 'accept',
}));
await page.goto('https://example.com');
```

**Benefit:** Applies to popup windows and opened links.

## Modify Requests

### Modify Headers

**Example - Delete header:**
```typescript
// Delete header
await page.route('**/*', async route => {
  const headers = route.request().headers();
  delete headers['X-Secret'];
  await route.continue({ headers });
});
```

### Modify Method

**Example - Change to POST:**
```typescript
// Continue requests as POST
await page.route('**/*', route => route.continue({ method: 'POST' }));
```

**Purpose:** Continue requests with modifications.

## Abort Requests

### Basic Abort

**Method:** `page.route()` with `route.abort()`

**Example - Abort by pattern:**
```typescript
await page.route('**/*.{png,jpg,jpeg}', route => route.abort());
```

### Conditional Abort

**Example - Abort by resource type:**
```typescript
// Abort based on the request type
await page.route('**/*', route => {
  return route.request().resourceType() === 'image' ? route.abort() : route.continue();
});
```

**Use case:** Block specific resource types to speed up tests.

## Modify Responses

### Fetch-Modify-Fulfill Pattern

**Method:** Use `APIRequestContext` to get original response, then pass to `route.fulfill()`.

**Example:**
```typescript
await page.route('**/title.html', async route => {
  // Fetch original response
  const response = await route.fetch();
  
  // Add a prefix to the title
  let body = await response.text();
  body = body.replace('<title>', '<title>My prefix:');
  
  await route.fulfill({
    // Pass all fields from the response
    response,
    // Override response body
    body,
    // Force content type to be html
    headers: {
      ...response.headers(),
      'content-type': 'text/html'
    }
  });
});
```

**Capability:** Override individual fields on response via options.

## Glob URL Patterns

### Overview

**Purpose:** Simplified glob patterns for URL matching in network interception methods.

### Pattern Rules

**1. Asterisks:**
- Single `*` matches any characters except `/`
- Double `**` matches any characters including `/`

**2. Question mark:**
- `?` matches only question mark `?`
- To match any character, use `*` instead

**3. Curly braces:**
- `{}` can match list of options separated by commas `,`

**4. Backslash:**
- `\` can escape special characters
- Escape backslash itself as `\\`

### Examples

**Pattern:** `https://example.com/*.js`
- **Matches:** `https://example.com/file.js`
- **Does NOT match:** `https://example.com/path/file.js`

**Pattern:** `https://example.com/?page=1`
- **Matches:** `https://example.com/?page=1`
- **Does NOT match:** `https://example.com`

**Pattern:** `**/*.js`
- **Matches:** Both `https://example.com/file.js` and `https://example.com/path/file.js`

**Pattern:** `**/*.{png,jpg,jpeg}`
- **Matches:** All image requests

### Important Notes

1. **Full URL matching:** Glob pattern must match entire URL, not just part of it
2. **Consider full structure:** Include protocol and path separators
3. **Complex matching:** Use RegExp instead of glob patterns for complex requirements

## WebSockets

### Overview

**Support:** Playwright supports WebSockets inspection, mocking, and modifying out of the box.

**Reference:** See API mocking guide for WebSocket mocking details.

### WebSocket Events

**Event:** `page.on('websocket')` fired every time WebSocket is created.

**Example:**
```typescript
page.on('websocket', ws => {
  console.log(`WebSocket opened: ${ws.url()}>`);
  ws.on('framesent', event => console.log(event.payload));
  ws.on('framereceived', event => console.log(event.payload));
  ws.on('close', () => console.log('WebSocket closed'));
});
```

**Capabilities:**
- Monitor WebSocket URL
- Inspect sent frames
- Inspect received frames
- Track connection close

## Missing Network Events and Service Workers

### Issue

**Problem:** Network events may be missing when using Service Workers.

### Solution

**Disable Service Workers:** Set `serviceWorkers` to `'block'`.

### Mock Service Worker (MSW) Compatibility

**Issue:** MSW adds its own Service Worker that takes over network requests, making them invisible to `browserContext.route()` and `page.route()`.

**Recommendation:** If interested in both network testing and mocking, use built-in `browserContext.route()` and `page.route()` for response mocking instead of MSW.

**Alternative:** If need to route and listen for requests made by Service Workers themselves, see specific guide for that use case.

## Best Practices

### 1. Choose Right Scope

**Context-level:** For mocking that applies to all pages, popups, and links
```typescript
await context.route('**/*.css', route => route.abort());
```

**Page-level:** For mocking specific to single page
```typescript
await page.route('**/*.css', route => route.abort());
```

### 2. Set Up Routes Before Navigation

```typescript
// ✅ Good
await page.route('**/api/**', route => route.fulfill({ json: mockData }));
await page.goto('https://example.com');

// ❌ Bad - route set after navigation
await page.goto('https://example.com');
await page.route('**/api/**', route => route.fulfill({ json: mockData }));
```

### 3. Use Appropriate Pattern Type

**Glob patterns:** For simple URL matching
```typescript
await page.route('**/*.{png,jpg,jpeg}', route => route.abort());
```

**RegExp:** For complex matching
```typescript
await page.route(/\.(png|jpg|jpeg)$/i, route => route.abort());
```

**Predicate function:** For conditional logic
```typescript
await page.route('**/*', route => {
  if (route.request().resourceType() === 'image') {
    return route.abort();
  }
  return route.continue();
});
```

### 4. Monitor Network for Debugging

```typescript
test('debug network', async ({ page }) => {
  page.on('request', request => 
    console.log('>>', request.method(), request.url())
  );
  page.on('response', response => 
    console.log('<<', response.status(), response.url())
  );
  
  await page.goto('https://example.com');
});
```

### 5. Wait for Specific Responses

```typescript
// Create promise before action
const responsePromise = page.waitForResponse('**/api/data');
await page.getByRole('button', { name: 'Load' }).click();
const response = await responsePromise;

// Verify response
expect(response.status()).toBe(200);
```

## Common Patterns

### Pattern 1: Block Resource Types

```typescript
test('block images and css', async ({ page }) => {
  await page.route('**/*', route => {
    const type = route.request().resourceType();
    if (type === 'image' || type === 'stylesheet') {
      return route.abort();
    }
    return route.continue();
  });
  
  await page.goto('https://example.com');
});
```

### Pattern 2: Add Custom Headers

```typescript
test('add auth header', async ({ page }) => {
  await page.route('**/*', route => {
    const headers = {
      ...route.request().headers(),
      'Authorization': 'Bearer token123'
    };
    route.continue({ headers });
  });
  
  await page.goto('https://example.com');
});
```

### Pattern 3: Modify API Response

```typescript
test('modify API response', async ({ page }) => {
  await page.route('**/api/user', async route => {
    const response = await route.fetch();
    const json = await response.json();
    json.isPremium = true;  // Modify data
    await route.fulfill({ response, json });
  });
  
  await page.goto('https://example.com');
});
```

### Pattern 4: Monitor Specific API Calls

```typescript
test('monitor API calls', async ({ page }) => {
  const apiCalls = [];
  
  page.on('request', request => {
    if (request.url().includes('/api/')) {
      apiCalls.push({
        method: request.method(),
        url: request.url()
      });
    }
  });
  
  await page.goto('https://example.com');
  
  // Assert API calls
  expect(apiCalls).toHaveLength(3);
});
```

### Pattern 5: Wait for Multiple Responses

```typescript
test('wait for multiple responses', async ({ page }) => {
  const response1Promise = page.waitForResponse('**/api/users');
  const response2Promise = page.waitForResponse('**/api/products');
  
  await page.goto('https://example.com');
  
  const [response1, response2] = await Promise.all([
    response1Promise,
    response2Promise
  ]);
  
  expect(response1.status()).toBe(200);
  expect(response2.status()).toBe(200);
});
```

## Use Cases for Solely Art Platform

### 1. Monitor Booking API Calls

```typescript
test('monitor booking API', async ({ page }) => {
  const bookingCalls = [];
  
  page.on('request', request => {
    if (request.url().includes('/api/bookings')) {
      bookingCalls.push({
        method: request.method(),
        url: request.url(),
        postData: request.postData()
      });
    }
  });
  
  await page.goto('/artist/profile');
  await page.getByRole('button', { name: 'Book Now' }).click();
  
  // Verify booking API was called
  expect(bookingCalls.length).toBeGreaterThan(0);
});
```

### 2. Block External Resources

```typescript
test('block external resources for faster tests', async ({ page }) => {
  await page.route('**/*', route => {
    const url = route.request().url();
    // Block external CDNs, analytics, ads
    if (url.includes('google-analytics') || 
        url.includes('facebook.com') ||
        url.includes('cdn.')) {
      return route.abort();
    }
    return route.continue();
  });
  
  await page.goto('/');
});
```

### 3. Test Payment Error Handling

```typescript
test('handle payment API error', async ({ page }) => {
  await page.route('**/api/payments/process', route => 
    route.fulfill({ 
      status: 500,
      json: { error: 'Payment processing failed' }
    })
  );
  
  await page.goto('/checkout');
  await page.getByRole('button', { name: 'Pay Now' }).click();
  
  // Verify error message displayed
  await expect(page.getByText('Payment failed')).toBeVisible();
});
```

### 4. Monitor WebSocket Messages

```typescript
test('monitor real-time messaging', async ({ page }) => {
  const messages = [];
  
  page.on('websocket', ws => {
    ws.on('framereceived', event => {
      messages.push(JSON.parse(event.payload));
    });
  });
  
  await page.goto('/messages');
  
  // Trigger message send
  await page.getByRole('textbox').fill('Hello');
  await page.getByRole('button', { name: 'Send' }).click();
  
  // Wait for response
  await page.waitForTimeout(1000);
  
  // Verify messages received
  expect(messages.length).toBeGreaterThan(0);
});
```

### 5. Add Authentication Headers

```typescript
test('add auth token to API requests', async ({ page }) => {
  await page.route('**/api/**', route => {
    const headers = {
      ...route.request().headers(),
      'Authorization': 'Bearer test-token-123'
    };
    route.continue({ headers });
  });
  
  await page.goto('/dashboard');
});
```

## Summary

### Key Capabilities

1. **Monitor** - Track all network requests and responses
2. **Mock** - Intercept and return custom responses
3. **Modify** - Change requests or responses in-flight
4. **Abort** - Block specific requests
5. **Wait** - Wait for specific network responses

### Scope Options

- **Context-level** - Applies to all pages, popups, links
- **Page-level** - Applies to single page only

### Pattern Types

- **Glob patterns** - Simple wildcard matching
- **RegExp** - Complex pattern matching
- **Predicate functions** - Conditional logic

### Common Use Cases

- Block resources (images, CSS) for faster tests
- Mock API responses for isolated testing
- Modify responses for edge case testing
- Monitor network for debugging
- Add authentication headers
- Test error handling
- Simulate slow networks

## Related Topics

- API mocking guide
- Mock APIs
- HAR files
- WebSockets
- Service Workers
- HTTP authentication
- Proxy configuration
- Request routing
- Response fulfillment
