# Playwright Documentation Research - UI Mode

**Page:** UI Mode  
**URL:** https://playwright.dev/docs/test-ui-mode  
**Research Date:** December 13, 2025

## Overview

**UI Mode** is an interactive graphical interface for exploring, running, and debugging tests with a time travel experience and watch mode.

**Key features:**
- Visual test exploration
- Interactive test running
- Time travel debugging
- Watch mode
- DOM snapshot inspection
- Full trace viewing

## Introduction

UI Mode provides:
- All test files displayed in testing sidebar
- Expand files and describe blocks
- Individually run, view, watch, and debug each test
- Full trace of tests with hover-over actions
- Pop out DOM snapshots for better debugging

### Filtering Capabilities

Filter tests by:
- **Name** (text search)
- **Projects** (set in `playwright.config`)
- **@tag** (tag annotations)
- **Execution status**: passed, failed, skipped

## Opening UI Mode

### Command

```bash
npx playwright test --ui
```

**Result:** Opens interactive UI Mode interface in browser.

## Running Your Tests

### Running Tests

Once UI Mode launches:
- See list of all test files
- Run all tests: Click triangle icon in sidebar
- Run single test file: Hover over name, click triangle
- Run test block: Hover over describe block, click triangle
- Run single test: Hover over test name, click triangle

**Navigation:** Expand/collapse test files and describe blocks in sidebar.

## Filtering Tests

### Filter Options

1. **Text filter**: Search by test name
2. **@tag filter**: Filter by tag annotations
3. **Status filter**: passed, failed, or skipped
4. **Project filter**: Filter by projects from `playwright.config`

### Project Dependencies Note

If using project dependencies:
- Manually run setup tests first
- UI mode doesn't automatically consider setup tests
- Setup tests must be run before dependent tests

## Timeline View

Located at the top of the trace.

### Features

**Visual representation:**
- Timeline with different colors
- Highlights navigation and actions
- Image snapshot for each action on hover

**Interactions:**
- Hover back and forth to see snapshots
- Double click action to see time range
- Use slider to increase selected actions

**Filtering:**
- Actions tab shows selected actions
- Console logs filtered to selected actions
- Network logs filtered to selected actions

## Actions Tab

### Information Displayed

For each action:
- Locator used
- Duration (how long it took)
- Visual DOM snapshot changes

### Interactions

- Hover over action to see DOM changes
- Go back and forward in time
- Click action to inspect and debug
- Use **Before** and **After** tabs to compare

**Time travel:** Navigate through test execution step by step.

## Pop Out and Inspect the DOM

### Pop Out Feature

**How to use:**
- Click pop out icon above DOM snapshot
- Opens DOM snapshot in separate window

**Benefits:**
- Better debugging experience
- Access to browser DevTools
- Inspect HTML, CSS, Console, etc.

**Workflow:**
- Pop out one action
- Click another action in UI Mode
- Pop that one out too
- Compare side by side or debug individually

## Pick Locator

### Locator Picker Tool

**How to use:**
1. Click "pick locator" button
2. Hover over DOM snapshot
3. See locator highlighted for each element
4. Click element to add to locator playground

### Locator Playground

**Features:**
- Modify locator
- See if modified locator matches DOM elements
- Copy button to copy locator
- Paste into your test

**Use case:** Refine and test locators interactively.

## Source Tab

### Code Integration

**Features:**
- Shows source code of test
- Highlights line of code as you hover over actions
- "Open in VSCode" button (top-right)

**Workflow:**
- Hover over action in trace
- See corresponding code line highlighted
- Click "Open in VSCode" to jump to that line

**Benefit:** Seamless connection between trace and code.

## Call Tab

### Action Details

Shows information about each action:
- Time taken
- Locator used
- Strict mode status
- Key used (for keyboard actions)

**Purpose:** Detailed action metadata for debugging.

## Log Tab

### Playwright Internal Logs

See full log of what Playwright does behind the scenes:
- Scrolling into view
- Waiting for element to be visible
- Waiting for element to be enabled
- Waiting for element to be stable
- Performing actions (click, fill, press, etc.)

**Use case:** Understand Playwright's auto-waiting behavior.

## Errors Tab

### Error Information

When test fails:
- Error messages for each test
- Timeline shows red line at error location
- Source tab shows error line in code

**Workflow:**
- View error message in Errors tab
- See red line in timeline
- Click source tab to see code line

## Console Tab

### Console Logs

Displays:
- Console logs from browser
- Console logs from test file
- Different icons for browser vs. test logs

**Benefit:** Distinguish between browser console and test console output.

## Network Tab

### Network Request Information

**Displays all network requests** made during test.

**Sorting options:**
- Request type
- Status code
- Method
- Request URL
- Content type
- Duration
- Size

**Details view:**
Click on request to see:
- Request headers
- Response headers
- Request body
- Response body

**Use case:** Debug network-related issues, API calls, resource loading.

## Attachments Tab

### Test Attachments

Explore attachments from tests.

### Visual Regression Testing

For screenshot comparisons:
- **Image diff**: See differences highlighted
- **Actual image**: What test produced
- **Expected image**: What was expected

**Slider feature:**
- Click on expected image
- Use slider to overlay images
- Easily see differences

**Use case:** Debug visual regression test failures.

## Metadata Tab

### Test Information

Located next to Actions tab.

**Shows:**
- Browser used
- Viewport size
- Test duration
- Additional test metadata

**Purpose:** Context about test execution environment.

## Watch Mode

### Activating Watch Mode

**How to use:**
- Click eye icon next to test name in sidebar
- Test re-runs automatically when you make changes

**Options:**
- Watch individual tests: Click eye icon next to each test
- Watch multiple tests: Click eye icon for multiple tests
- Watch all tests: Click eye icon at top of sidebar

**Benefit:** Instant feedback during test development.

## Docker & GitHub Codespaces

### Running UI Mode in Browser

For containerized environments, bind to `0.0.0.0` interface:

```bash
npx playwright test --ui-host=0.0.0.0
```

**Reason:** Endpoint needs to be accessible outside container.

### GitHub Codespaces

Port is forwarded automatically. Open UI mode by clicking link in terminal.

### Static Port

Specify port with `--ui-port` flag:

```bash
npx playwright test --ui-port=8080 --ui-host=0.0.0.0
```

### Security Warning

⚠️ **Important:** When using `--ui-host=0.0.0.0`:
- UI Mode is accessible from other machines in your network
- Traces, passwords, and secrets are exposed
- In GitHub Codespaces: ports only accessible from your account by default

## Best Practices

### 1. Use UI Mode for Test Development

```bash
npx playwright test --ui
```

Great for writing and debugging new tests.

### 2. Enable Watch Mode for Active Development

Click eye icon to auto-rerun tests on changes.

### 3. Use Timeline for Understanding Test Flow

Hover over timeline to see what happened at each moment.

### 4. Pop Out DOM for Detailed Inspection

Use pop out feature to access DevTools for deep debugging.

### 5. Use Pick Locator for Refining Selectors

Interactively test and refine locators before adding to tests.

### 6. Filter Tests During Development

Use filters to focus on specific tests or failed tests.

### 7. Compare Before/After States

Use Before and After tabs to understand action effects.

### 8. Check Network Tab for API Issues

Debug API calls and network requests visually.

### 9. Use Attachments for Visual Regression

Leverage slider to compare expected vs. actual screenshots.

### 10. Secure UI Mode in Containers

Only use `--ui-host=0.0.0.0` in secure, trusted networks.

## Common Patterns

### Local Development Workflow

```bash
# Start UI Mode
npx playwright test --ui

# Enable watch mode for test you're working on
# (Click eye icon in UI)

# Use pick locator to refine selectors
# Use timeline to understand test flow
# Pop out DOM to inspect with DevTools
```

### Debugging Failed Tests

```bash
# Open UI Mode
npx playwright test --ui

# Filter to failed tests
# Click on failed test
# Check Errors tab for error message
# Use timeline to see where it failed
# Hover over actions before failure
# Pop out DOM at failure point
# Inspect with DevTools
```

### Visual Regression Debugging

```bash
# Open UI Mode
npx playwright test --ui

# Navigate to failed visual test
# Go to Attachments tab
# Use slider to compare images
# Identify visual differences
# Fix test or update baseline
```

### Container/Codespaces Setup

```bash
# For Docker
npx playwright test --ui-host=0.0.0.0 --ui-port=8080

# For GitHub Codespaces (port auto-forwarded)
npx playwright test --ui-host=0.0.0.0
# Click link in terminal to open
```

### Multi-Project Testing

```bash
# Open UI Mode
npx playwright test --ui

# Use project filter to focus on specific browser
# Run setup tests first if using project dependencies
# Then run dependent tests
```

## Related Topics to Explore

- Test debugging
- Trace viewer
- Watch mode
- Locators
- Visual regression testing
- Test annotations
- Projects and dependencies
- Network inspection
- DevTools integration
- Test organization
