# Playwright Documentation Research - Canary Releases

**Page:** Canary Releases  
**URL:** https://playwright.dev/docs/canary  
**Research Date:** December 14, 2025  
**Status:** ✅ Complete (Previously 404, now documented from provided content)

## Overview

Playwright for Node.js offers a **canary releases system** that allows developers to test new, unreleased features before they are included in a full stable release. These releases are published daily under the `@next` NPM dist tag, providing a way to give feedback to maintainers and ensure that newly implemented features work as intended.

## Purpose and Benefits

### Early Access to New Features

Canary releases permit you to test new unreleased features instead of waiting for a full release. This allows developers to:
- Validate new features in their specific environment
- Identify potential issues before stable release
- Provide early feedback to maintainers

### Safety and Stability

While using a canary release in production might seem risky, the documentation notes that it is generally safe in practice:
- Each canary release passes all automated tests
- Used to test core components like HTML report, Trace Viewer, and Playwright Inspector
- Validated with end-to-end tests before publication

## NPM Dist Tags

Playwright uses NPM distribution tags to manage its release channels:

| Tag | Description | Update Frequency |
| :--- | :--- | :--- |
| **`latest`** | Stable releases, recommended for production use | Per release schedule |
| **`next`** | Canary releases with latest code from `main` branch | Daily |
| **`beta`** | Beta releases on release branch | Per commit (week before stable release) |

### Next NPM Dist Tag

For any code-related commit on the `main` branch, the continuous integration system will publish a daily canary release under the `@next` npm dist tag.

## Installation

To use a canary release, install it using NPM with the `@next` tag:

```bash
npm install -D @playwright/test@next
```

This command will install the latest daily canary release of Playwright, allowing you to test the newest features.

## Documentation Access

The documentation for both stable and canary releases is available on [playwright.dev](https://playwright.dev).

**To access the `next` (canary) documentation:**
- Press the **Shift** key **5 times** on the keyboard
- This will switch the documentation view to show the canary version

## When to Use Canary Releases

### Testing New Features

If you need to test a specific new feature that has not yet been released, canary releases are the best way to do so. This is particularly useful when:
- A feature you need is in development
- You want to validate a feature before it reaches stable
- You're contributing to Playwright and need to test your changes

### Providing Feedback

If you are an active contributor or want to help improve Playwright, using canary releases and reporting issues is highly valuable. This helps:
- Identify bugs before they reach stable releases
- Validate that new features work as intended
- Improve the overall quality of Playwright

### Verifying Bug Fixes

If a bug you reported has been fixed in the `main` branch, you can use a canary release to verify the fix before the next stable release. This ensures:
- The fix resolves your specific issue
- No regressions were introduced
- The fix works in your environment

## Best Practices

### Use in a Separate Environment

While generally safe, it is recommended to use canary releases in a separate testing environment to avoid any potential impact on your production tests. This approach:
- Isolates potential issues from production
- Allows for thorough testing without risk
- Provides a safe space for experimentation

### Pin the Version

To ensure reproducible builds, it is a good practice to pin the exact version of the canary release in your `package.json` file. For example:

```json
{
  "devDependencies": {
    "@playwright/test": "1.50.0-next-20251214"
  }
}
```

This ensures:
- Consistent builds across environments
- Ability to reproduce issues
- Clear tracking of which canary version is in use

### Monitor for Changes

Keep an eye on the Playwright repository for any breaking changes or updates that might affect your tests. This includes:
- Watching the GitHub repository
- Following release notes
- Subscribing to Playwright announcements
- Reviewing commit messages for breaking changes

## Solely Art Platform Application

For the Solely Art Platform, canary releases can be used to:

### Test New Browser Versions or Features

Stay ahead of browser updates by testing with the latest Playwright features that support new browser capabilities. This is particularly important for:
- New CSS features
- Updated JavaScript APIs
- Browser-specific behaviors
- Performance improvements

### Validate Fixes for Reported Bugs

If the Solely Art Platform encounters a Playwright bug and it has been fixed in the `main` branch, canary releases allow immediate validation of the fix without waiting for the next stable release. This enables:
- Faster resolution of blocking issues
- Reduced downtime
- Improved development velocity

### Experiment with New Testing Patterns

Canary releases provide access to new testing patterns or APIs that are not yet available in the stable release. This allows the team to:
- Explore new testing approaches
- Validate new features for future adoption
- Stay current with best practices
- Prepare for upcoming stable releases

## Summary

### Key Takeaways

- **Daily releases:** Canary releases are published daily under the `@next` npm tag
- **Safe for testing:** Pass all automated tests and are used internally by Playwright
- **Three dist tags:** `latest` (stable), `next` (canary), `beta` (pre-release)
- **Easy installation:** `npm install -D @playwright/test@next`
- **Documentation access:** Press Shift 5 times to view canary documentation
- **Best for:** Testing new features, providing feedback, verifying bug fixes

### Related Topics

- Release Notes
- Installation
- Continuous Integration
- Best Practices
- TypeScript

### Implementation Recommendations

1. **Set up a canary testing environment** separate from production
2. **Pin canary versions** in package.json for reproducibility
3. **Monitor the Playwright repository** for breaking changes
4. **Use canary releases** to test critical bug fixes before stable release
5. **Provide feedback** to maintainers when issues are discovered
6. **Document canary usage** in team testing guidelines

### Future Considerations

- **Automated canary testing:** Set up CI/CD pipeline to automatically test with canary releases
- **Canary monitoring:** Track which canary versions are being used across environments
- **Feedback process:** Establish a process for reporting issues found in canary releases
- **Upgrade strategy:** Define when to upgrade from canary to stable releases
