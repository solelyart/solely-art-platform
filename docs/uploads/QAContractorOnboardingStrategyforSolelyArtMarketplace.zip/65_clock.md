# Playwright Documentation Research - Clock

**Page:** Clock
**URL:** https://playwright.dev/docs/clock
**Research Date:** December 14, 2025

## Overview

Playwright provides a `clock` fixture to control time in tests. This is useful for testing time-dependent functionality like timeouts, intervals, and animations.

### Key Features

- **Mock `Date` and `setTimeout`:** Control the passage of time in tests.
- **Fast-forward time:** Jump forward in time to trigger timeouts and intervals.
- **Pause time:** Stop time to inspect the state of the application.

## Usage

### Fast-forwarding Time

```javascript
await page.clock.fastForward("01:00"); // Fast-forward 1 minute
```

### Pausing and Resuming Time

```javascript
await page.clock.pauseAt(new Date()); // Pause time at the current date
// ...
await page.clock.resume(); // Resume time
```

## Summary

### Key Takeaways

- **Use the `clock` fixture:** To control time in tests.
- **`fastForward()`:** To jump forward in time.
- **`pauseAt()` and `resume()`:** To pause and resume time.

### Related Topics

- Fixtures
- Timeouts
