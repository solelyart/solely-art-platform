# Playwright Documentation Research - Agents

**Page:** Agents
**URL:** https://playwright.dev/docs/agents
**Research Date:** December 14, 2025
**Status:** ✅ Complete (Previously 404, now documented from provided content)

## Overview

Playwright Agents are a suite of AI-powered tools designed to automate the entire testing lifecycle, from test planning and generation to maintenance and repair. The feature introduces three distinct agents that can be used independently or chained together in an agentic loop to achieve comprehensive test coverage for a web application.

## The Three Core Agents

Playwright comes with three Playwright Test Agents out of the box:

### 1. 🎭 Planner

The Planner agent explores the application and produces a Markdown test plan.

**Input:**
- URL of the target application

**Process:**
- Autonomously navigates the application
- Identifies key user flows and interactive elements
- Discovers potential areas for testing

**Output:**
- Human-readable Markdown test plan (`.md`) in the `specs/` directory
- Outlines test scenarios, steps, and expected outcomes

### 2. 🎭 Generator

The Generator agent transforms the Markdown plan into executable Playwright Test files.

**Input:**
- Markdown plan from `specs/` directory

**Process:**
- Parses the Markdown test plan
- Interprets test steps and expected outcomes
- Verifies selectors and assertions live as it performs the scenarios
- Uses generation hints and assertion catalog for efficient validation

**Output:**
- Test suite under `tests/` directory
- Generated tests may include initial errors that can be healed automatically by the healer agent

**Example Generated Test:**

```typescript
// spec: specs/basic-operations.md
// seed: tests/seed.spec.ts

import { test, expect } from '../fixtures';

test.describe('Adding New Todos', () => {
  test('Add Valid Todo', async ({ page }) => {
    // 1. Click in the "What needs to be done?" input field
    const todoInput = page.getByRole('textbox', { name: 'What needs to be done?' });
    await todoInput.click();

    // 2. Type "Buy groceries"
    await todoInput.fill('Buy groceries');

    // 3. Press Enter key
    await todoInput.press('Enter');

    // Expected Results:
    // - Todo appears in the list with unchecked checkbox
    await expect(page.getByText('Buy groceries')).toBeVisible();
    const todoCheckbox = page.getByRole('checkbox', { name: 'Toggle Todo' });
    await expect(todoCheckbox).toBeVisible();
    await expect(todoCheckbox).not.toBeChecked();

    // - Counter shows "1 item left"
    await expect(page.getByText('1 item left')).toBeVisible();

    // - Input field is cleared and ready for next entry
    await expect(todoInput).toHaveValue('');
    await expect(todoInput).toBeFocused();

    // - Todo list controls become visible (Mark all as complete checkbox)
    await expect(page.getByRole('checkbox', { name: '❯Mark all as complete' })).toBeVisible();
  });
});
```

### 3. 🎭 Healer

The Healer agent executes the test suite and automatically repairs failing tests.

**Input:**
- Failing test name

**Process:**
When a test fails, the healer agent:
1. Replays the failing steps
2. Inspects the current UI to locate equivalent elements or flows
3. Suggests a patch (e.g., locator update, wait adjustment, data fix)
4. Re-runs the test until it passes or until guardrails stop the loop

**Output:**
- A passing test, or
- A skipped test if the healer believes that the functionality is broken

## Getting Started

Start by adding Playwright Test Agent definitions to your project using the `init-agents` command. These definitions should be regenerated whenever Playwright is updated to pick up new tools and instructions.

```bash
npx playwright init-agents --loop=vscode
```

## The Agentic Loop

The three agents can be used:
- **Independently:** Use each agent separately for specific tasks
- **Sequentially:** Use them in order (planner → generator → healer) to produce test coverage
- **As chained calls:** In an agentic loop for continuous test generation and maintenance

The agentic loop workflow:
1. **Planner** explores the app and creates a test plan
2. **Generator** converts the plan into Playwright tests
3. **Healer** executes the tests and automatically fixes any failures

## Artifacts and Conventions

The static agent definitions and generated files follow a simple, auditable structure:

```
repo/
  .github/                    # agent definitions
  specs/                      # human-readable test plans
    basic-operations.md
  tests/                      # generated Playwright tests
    seed.spec.ts              # seed test for environment
    tests/create/add-valid-todo.spec.ts
  playwright.config.ts
```

### Agent Definitions

Under the hood, agent definitions are collections of instructions and MCP (Model Context Protocol) tools. They are provided by Playwright and should be regenerated whenever Playwright is updated.

Example for Claude Code subagents:

```bash
npx playwright init-agents --loop=vscode
```

### Specs in `specs/`

Specs are structured plans describing scenarios in human-readable terms. They include:
- Steps
- Expected outcomes
- Test data

Specs can start from scratch or extend a seed test.

### Tests in `tests/`

Generated Playwright tests, aligned one-to-one with specs wherever feasible.

### Seed Tests (`seed.spec.ts`)

Seed tests provide a ready-to-use page context to bootstrap execution. They set up the initial state of the application before running the generated tests.

## Key Benefits

### 1. Increased Efficiency
- Automates tedious and time-consuming tasks of test creation and maintenance
- Reduces manual effort required for writing and updating tests

### 2. Improved Test Coverage
- Planner agent can identify user flows and edge cases that might be missed by human testers
- Ensures comprehensive coverage of application functionality

### 3. Enhanced Resilience
- Healer agent automatically repairs broken tests
- Makes the test suite more resilient to changes in the application

### 4. Reduced Maintenance Overhead
- Automated test repair significantly reduces manual maintenance effort
- Tests stay up-to-date with application changes

## Potential Challenges

### 1. AI Reliability
- Effectiveness depends on the reliability of underlying AI models
- False positives or incorrect repairs could introduce new issues
- Requires monitoring and validation of agent-generated tests

### 2. Configuration and Setup
- Proper configuration of agent definitions is crucial for optimal performance
- Requires understanding of the agentic loop and how agents interact

### 3. Guardrails
- Guardrails that prevent the Healer agent from infinite loops need careful configuration
- Balance between automatic repair attempts and manual intervention

## Solely Art Platform Application

For the Solely Art Platform, Playwright Agents can be used to:

### 1. Comprehensive Test Planning
- Generate test plans for all user flows:
  - Artist registration and profile setup
  - Artwork upload and management
  - Booking flow (browse → select → book)
  - Payment processing
  - Messaging between users and artists

### 2. Automated Test Generation
- Automatically generate Playwright tests for all test scenarios
- Ensure complete test coverage across all features
- Generate tests for edge cases and error scenarios

### 3. Continuous Test Maintenance
- Maintain the test suite by automatically repairing broken tests
- Keep tests up-to-date as the platform evolves
- Reduce manual effort required for test maintenance

### 4. Integration with QA Workflow
- Integrate with the Monday.com QA workflow established earlier
- Agents can generate tests that QA contractors then validate
- Healer agent can automatically fix tests that fail during QA runs

## Summary

### Key Takeaways

- **Three AI-powered agents:** Planner, Generator, and Healer work together to automate the testing lifecycle
- **Agentic loop:** Continuous cycle of test planning, generation, execution, and repair
- **MCP-based:** Uses Model Context Protocol for agent definitions and tools
- **Auditable structure:** Simple file organization with specs and tests
- **Automatic repair:** Healer agent fixes broken tests automatically
- **Reduced maintenance:** Significantly reduces manual effort for test maintenance

### Related Topics

- Test Generator (Codegen)
- Fixtures
- Locators
- Assertions
- Best Practices
- CI/CD Integration

### Implementation Recommendations

1. **Start with Planner:** Use the Planner agent to explore the Solely Art Platform and generate an initial test plan
2. **Review and refine:** Review the generated test plan and refine it based on domain knowledge
3. **Generate tests:** Use the Generator agent to create executable Playwright tests
4. **Enable Healer:** Configure the Healer agent to automatically repair failing tests
5. **Monitor and validate:** Regularly review agent-generated tests and repairs to ensure quality
6. **Integrate with CI/CD:** Incorporate the agentic loop into the CI/CD pipeline for continuous testing

### Future Considerations

- **Agent customization:** Explore options for customizing agent behavior for Solely Art Platform-specific needs
- **Guardrail tuning:** Fine-tune guardrails based on experience with the Healer agent
- **Test coverage metrics:** Track test coverage generated by agents to ensure comprehensive coverage
- **Human-in-the-loop:** Establish processes for human review and validation of agent-generated tests
