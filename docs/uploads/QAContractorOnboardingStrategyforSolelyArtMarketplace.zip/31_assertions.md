# Playwright Documentation Research - Assertions

**Page:** Assertions  
**URL:** https://playwright.dev/docs/test-assertions  
**Research Date:** December 13, 2025

## Overview

Playwright includes test assertions in the form of **`expect` function**.

**To make an assertion:**
```typescript
expect(value) // and choose a matcher
```

**Two types of matchers:**
1. **Generic matchers** - `toEqual`, `toContain`, `toBeTruthy` (for any conditions)
2. **Web-specific async matchers** - Wait until expected condition is met

## Introduction

### Generic Matchers

```typescript
expect(success).toBeTruthy();
```

### Web-Specific Async Matchers

**Auto-retry until condition met:**

```typescript
await expect(page.getByTestId('status')).toHaveText('Submitted');
```

**How it works:**
- Playwright re-tests the element until condition met
- Re-fetches element and checks repeatedly
- Continues until condition met **or timeout reached**

**Timeout configuration:**
- Pass timeout directly
- Configure once via `testConfig.expect` in test config

**Default timeout:** 5 seconds

## Auto-Retrying Assertions

Assertions that **retry until assertion passes** or timeout reached.

**Important:** Retrying assertions are **async**, so you must `await` them.

### Locator Assertions

| Assertion | Description |
|-----------|-------------|
| `await expect(locator).toBeAttached()` | Element is attached |
| `await expect(locator).toBeChecked()` | Checkbox is checked |
| `await expect(locator).toBeDisabled()` | Element is disabled |
| `await expect(locator).toBeEditable()` | Element is editable |
| `await expect(locator).toBeEmpty()` | Container is empty |
| `await expect(locator).toBeEnabled()` | Element is enabled |
| `await expect(locator).toBeFocused()` | Element is focused |
| `await expect(locator).toBeHidden()` | Element is not visible |
| `await expect(locator).toBeInViewport()` | Element intersects viewport |
| `await expect(locator).toBeVisible()` | Element is visible |
| `await expect(locator).toContainText()` | Element contains text |
| `await expect(locator).toContainClass()` | Element has specified CSS classes |
| `await expect(locator).toHaveAccessibleDescription()` | Element has matching accessible description |
| `await expect(locator).toHaveAccessibleName()` | Element has matching accessible name |
| `await expect(locator).toHaveAttribute()` | Element has DOM attribute |
| `await expect(locator).toHaveClass()` | Element has specified CSS class property |
| `await expect(locator).toHaveCount()` | List has exact number of children |
| `await expect(locator).toHaveCSS()` | Element has CSS property |
| `await expect(locator).toHaveId()` | Element has an ID |
| `await expect(locator).toHaveJSProperty()` | Element has JavaScript property |
| `await expect(locator).toHaveRole()` | Element has specific ARIA role |
| `await expect(locator).toHaveScreenshot()` | Element has a screenshot |
| `await expect(locator).toHaveText()` | Element matches text |
| `await expect(locator).toHaveValue()` | Input has a value |
| `await expect(locator).toHaveValues()` | Select has options selected |
| `await expect(locator).toMatchAriaSnapshot()` | Element matches Aria snapshot |

### Page Assertions

| Assertion | Description |
|-----------|-------------|
| `await expect(page).toHaveScreenshot()` | Page has a screenshot |
| `await expect(page).toHaveTitle()` | Page has a title |
| `await expect(page).toHaveURL()` | Page has a URL |

### Response Assertions

| Assertion | Description |
|-----------|-------------|
| `await expect(response).toBeOK()` | Response has an OK status |

## Non-Retrying Assertions

Assertions that **do not auto-retry**.

⚠️ **Warning:** Web pages show information asynchronously. Using non-retrying assertions can lead to **flaky tests**.

**Recommendation:** Prefer auto-retrying assertions whenever possible. For complex assertions that need retry, use `expect.poll` or `expect.toPass`.

### Value Assertions

| Assertion | Description |
|-----------|-------------|
| `expect(value).toBe()` | Value is the same |
| `expect(value).toBeCloseTo()` | Number is approximately equal |
| `expect(value).toBeDefined()` | Value is not `undefined` |
| `expect(value).toBeFalsy()` | Value is falsy (false, 0, null, etc.) |
| `expect(value).toBeGreaterThan()` | Number is more than |
| `expect(value).toBeGreaterThanOrEqual()` | Number is more than or equal |
| `expect(value).toBeInstanceOf()` | Object is instance of class |
| `expect(value).toBeLessThan()` | Number is less than |
| `expect(value).toBeLessThanOrEqual()` | Number is less than or equal |
| `expect(value).toBeNaN()` | Value is `NaN` |
| `expect(value).toBeNull()` | Value is `null` |
| `expect(value).toBeTruthy()` | Value is truthy (not false, 0, null, etc.) |
| `expect(value).toBeUndefined()` | Value is `undefined` |
| `expect(value).toContain()` | String contains substring / Array contains element |
| `expect(value).toContainEqual()` | Array or set contains similar element |
| `expect(value).toEqual()` | Value is similar (deep equality and pattern matching) |
| `expect(value).toHaveLength()` | Array or string has length |
| `expect(value).toHaveProperty()` | Object has a property |
| `expect(value).toMatch()` | String matches regular expression |
| `expect(value).toMatchObject()` | Object contains specified properties |
| `expect(value).toStrictEqual()` | Value is similar, including property types |
| `expect(value).toThrow()` | Function throws an error |

## Asymmetric Matchers

Expressions that can be **nested in other assertions** for more relaxed matching.

| Matcher | Description |
|---------|-------------|
| `expect.any()` | Matches any instance of class/primitive |
| `expect.anything()` | Matches anything |
| `expect.arrayContaining()` | Array contains specific elements |
| `expect.arrayOf()` | Array contains elements of specific type |
| `expect.closeTo()` | Number is approximately equal |
| `expect.objectContaining()` | Object contains specific properties |
| `expect.stringContaining()` | String contains substring |
| `expect.stringMatching()` | String matches regular expression |

## Negating Matchers

Add `.not` to expect the opposite:

```typescript
expect(value).not.toEqual(0);
await expect(locator).not.toContainText('some text');
```

## Soft Assertions

**Default behavior:** Failed assertion terminates test execution.

**Soft assertions:** Failed soft assertions **do not** terminate test execution, but mark test as failed.

### Basic Usage

```typescript
// Make checks that will not stop test when failed
await expect.soft(page.getByTestId('status')).toHaveText('Success');
await expect.soft(page.getByTestId('eta')).toHaveText('1 day');

// Continue test to check more things
await page.getByRole('link', { name: 'next page' }).click();
await expect.soft(page.getByRole('heading', { name: 'Make another order' })).toBeVisible();
```

### Checking for Soft Assertion Failures

```typescript
// Make checks that will not stop test when failed
await expect.soft(page.getByTestId('status')).toHaveText('Success');
await expect.soft(page.getByTestId('eta')).toHaveText('1 day');

// Avoid running further if there were soft assertion failures
expect(test.info().errors).toHaveLength(0);
```

**Note:** Soft assertions only work with **Playwright test runner**.

## Custom Expect Message

Specify custom message as **second argument** to `expect`:

```typescript
await expect(page.getByText('Name'), 'should be logged in').toBeVisible();
```

**Shown in reporters** for both passing and failing expects.

### When Expect Passes

```
✅ should be logged in    @example.spec.ts:18
```

### When Expect Fails

```
Error: should be logged in

Call log:
  - expect.toBeVisible with timeout 5000ms
  - waiting for "getByText('Name')"

  2 |
  3 | test('example test', async({ page }) => {
> 4 |   await expect(page.getByText('Name'), 'should be logged in').toBeVisible();
    |                                                                  ^
  5 | });
  6 |
```

### Soft Assertions with Custom Message

```typescript
expect.soft(value, 'my soft assertion').toBe(56);
```

## expect.configure

Create pre-configured expect instance with own defaults (timeout, soft).

### Custom Timeout

```typescript
const slowExpect = expect.configure({ timeout: 10000 });
await slowExpect(locator).toHaveText('Submit');
```

### Always Soft Assertions

```typescript
// Always do soft assertions
const softExpect = expect.configure({ soft: true });
await softExpect(locator).toHaveText('Submit');
```

## expect.poll

Convert any **synchronous expect to asynchronous polling** one.

### Basic Usage

Poll function until it returns expected value:

```typescript
await expect.poll(async () => {
  const response = await page.request.get('https://api.example.com');
  return response.status();
}, {
  // Custom expect message for reporting, optional
  message: 'make sure API eventually succeeds',
  // Poll for 10 seconds; defaults to 5 seconds. Pass 0 to disable timeout
  timeout: 10000,
}).toBe(200);
```

### Custom Polling Intervals

```typescript
await expect.poll(async () => {
  const response = await page.request.get('https://api.example.com');
  return response.status();
}, {
  // Probe, wait 1s, probe, wait 2s, probe, wait 10s, probe, wait 10s, probe
  // Defaults to [100, 250, 500, 1000]
  intervals: [1_000, 2_000, 10_000],
  timeout: 60_000
}).toBe(200);
```

### Combine with Soft Assertions

```typescript
const softExpect = expect.configure({ soft: true });
await softExpect.poll(async () => {
  const response = await page.request.get('https://api.example.com');
  return response.status();
}, {}).toBe(200);
```

**Allows test to continue even if assertion inside poll fails.**

## expect.toPass

Retry **blocks of code** until passing successfully.

### Basic Usage

```typescript
await expect(async () => {
  const response = await page.request.get('https://api.example.com');
  expect(response.status()).toBe(200);
}).toPass();
```

### Custom Timeout and Intervals

```typescript
await expect(async () => {
  const response = await page.request.get('https://api.example.com');
  expect(response.status()).toBe(200);
}).toPass({
  // Probe, wait 1s, probe, wait 2s, probe, wait 10s, probe, wait 10s, probe
  // Defaults to [100, 250, 500, 1000]
  intervals: [1_000, 2_000, 10_000],
  timeout: 60_000
});
```

**Note:** By default `toPass` has **timeout 0** and does not respect custom expect timeout.

## Add Custom Matchers Using expect.extend

Extend Playwright assertions with custom matchers.

### Example: Custom toHaveAmount Matcher

```typescript
// fixtures.ts
import { expect as baseExpect } from '@playwright/test';
import type { Locator } from '@playwright/test';

export { test } from '@playwright/test';

export const expect = baseExpect.extend({
  async toHaveAmount(locator: Locator, expected: number, options?: { timeout?: number }) {
    const assertionName = 'toHaveAmount';
    let pass: boolean;
    let matcherResult: any;
    try {
      const expectation = this.isNot ? baseExpect(locator).not : baseExpect(locator);
      await expectation.toHaveAttribute('data-amount', String(expected), options);
      pass = true;
    } catch (e: any) {
      matcherResult = e.matcherResult;
      pass = false;
    }

    if (this.isNot) {
      pass = !pass;
    }

    const message = pass
      ? () => this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          `Locator: ${locator}\n` +
          `Expected: not ${this.utils.printExpected(expected)}\n` +
          (matcherResult ? `Received: ${this.utils.printReceived(matcherResult.actual)}` : '')
      : () =>  this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          `Locator: ${locator}\n` +
          `Expected: ${this.utils.printExpected(expected)}\n` +
          (matcherResult ? `Received: ${this.utils.printReceived(matcherResult.actual)}` : '');

    return {
      message,
      pass,
      name: assertionName,
      expected,
      actual: matcherResult?.actual,
    };
  },
});
```

### Using Custom Matcher

```typescript
// example.spec.ts
import { test, expect } from './fixtures';

test('amount', async () => {
  await expect(page.locator('.cart')).toHaveAmount(4);
});
```

## Compatibility with expect Library

⚠️ **Note:** Do not confuse Playwright's `expect` with the `expect` library. The latter is not fully integrated with Playwright test runner.

**Always use Playwright's own `expect`.**

## Combine Custom Matchers from Multiple Modules

Combine custom matchers from multiple files or modules.

```typescript
// fixtures.ts
import { mergeTests, mergeExpects } from '@playwright/test';
import { test as dbTest, expect as dbExpect } from 'database-test-utils';
import { test as a11yTest, expect as a11yExpect } from 'a11y-test-utils';

export const expect = mergeExpects(dbExpect, a11yExpect);
export const test = mergeTests(dbTest, a11yTest);
```

```typescript
// test.spec.ts
import { test, expect } from './fixtures';

test('passes', async ({ database }) => {
  await expect(database).toHaveDatabaseUser('admin');
});
```

## Best Practices

### 1. Prefer Auto-Retrying Assertions

Use web-specific async matchers whenever possible.

### 2. Use Soft Assertions for Multiple Checks

```typescript
await expect.soft(locator1).toBeVisible();
await expect.soft(locator2).toBeVisible();
```

### 3. Add Custom Messages for Context

```typescript
await expect(locator, 'user should be logged in').toBeVisible();
```

### 4. Use expect.poll for API Polling

```typescript
await expect.poll(async () => {
  return await getStatus();
}).toBe('ready');
```

### 5. Use expect.toPass for Complex Retry Logic

```typescript
await expect(async () => {
  // Complex assertions
}).toPass();
```

### 6. Configure Custom Timeouts When Needed

```typescript
const slowExpect = expect.configure({ timeout: 10000 });
```

### 7. Create Custom Matchers for Domain Logic

Extend expect for business-specific assertions.

### 8. Use Asymmetric Matchers for Flexible Matching

```typescript
expect(obj).toEqual(expect.objectContaining({ id: expect.any(Number) }));
```

### 9. Negate Matchers When Appropriate

```typescript
await expect(locator).not.toBeVisible();
```

### 10. Check Soft Assertion Failures

```typescript
expect(test.info().errors).toHaveLength(0);
```

## Related Topics to Explore

- Locators
- Auto-waiting
- Timeouts
- Test fixtures
- Custom matchers
- Polling strategies
- Soft assertions
- Test reporters
- Error handling
- Assertion patterns
