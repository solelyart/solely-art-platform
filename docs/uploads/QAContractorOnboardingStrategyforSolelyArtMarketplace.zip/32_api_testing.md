# Playwright Documentation Research - API Testing

**Page:** API testing  
**URL:** https://playwright.dev/docs/api-testing  
**Research Date:** December 13, 2025

## Overview

Playwright can be used to get access to the **REST API** of your application.

**Use cases for API testing:**
- Test your server API
- Prepare server side state before visiting web application in test
- Validate server side post-conditions after running actions in browser

**Achieved via:** `APIRequestContext` methods

## Writing API Test

### APIRequestContext Capabilities

`APIRequestContext` can send all kinds of **HTTP(S) requests** over network.

### Example: GitHub API Testing

Test suite that:
1. Creates new repository before running tests
2. Creates few issues and validates server state
3. Deletes repository after running tests

## Configuration

### Basic Configuration

Configure once for all tests in `playwright.config.ts`:

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // All requests we send go to this API endpoint
    baseURL: 'https://api.github.com',
    extraHTTPHeaders: {
      // Set header per GitHub guidelines
      'Accept': 'application/vnd.github.v3+json',
      // Add authorization token to all requests
      // Assuming personal access token available in environment
      'Authorization': `token ${process.env.API_TOKEN}`,
    },
  }
});
```

### Proxy Configuration

If tests need to run behind proxy:

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    proxy: {
      server: 'http://my-proxy:8080',
      username: 'user',
      password: 'secret'
    },
  }
});
```

**Note:** `request` fixture will pick up proxy configuration automatically.

## Writing Tests

### Using request Fixture

Playwright Test comes with built-in **`request` fixture** that:
- Respects configuration options like `baseURL` or `extraHTTPHeaders`
- Ready to send requests

### Example Tests

```typescript
const REPO = 'test-repo-1';
const USER = 'github-username';

test('should create a bug report', async ({ request }) => {
  const newIssue = await request.post(`/repos/${USER}/${REPO}/issues`, {
    data: {
      title: '[Bug] report 1',
      body: 'Bug description',
    }
  });
  expect(newIssue.ok()).toBeTruthy();

  const issues = await request.get(`/repos/${USER}/${REPO}/issues`);
  expect(issues.ok()).toBeTruthy();
  expect(await issues.json()).toContainEqual(expect.objectContaining({
    title: '[Bug] report 1',
    body: 'Bug description'
  }));
});

test('should create a feature request', async ({ request }) => {
  const newIssue = await request.post(`/repos/${USER}/${REPO}/issues`, {
    data: {
      title: '[Feature] request 1',
      body: 'Feature description',
    }
  });
  expect(newIssue.ok()).toBeTruthy();

  const issues = await request.get(`/repos/${USER}/${REPO}/issues`);
  expect(issues.ok()).toBeTruthy();
  expect(await issues.json()).toContainEqual(expect.objectContaining({
    title: '[Feature] request 1',
    body: 'Feature description'
  }));
});
```

## Setup and Teardown

Use `beforeAll` and `afterAll` hooks for test setup/cleanup:

```typescript
test.beforeAll(async ({ request }) => {
  // Create a new repository
  const response = await request.post('/user/repos', {
    data: {
      name: REPO
    }
  });
  expect(response.ok()).toBeTruthy();
});

test.afterAll(async ({ request }) => {
  // Delete the repository
  const response = await request.delete(`/repos/${USER}/${REPO}`);
  expect(response.ok()).toBeTruthy();
});
```

## Using Request Context

### Manual Context Creation

Behind the scenes, `request` fixture calls `apiRequest.newContext()`. You can create manually for more control:

```typescript
import { request } from '@playwright/test';

const REPO = 'test-repo-1';
const USER = 'github-username';

(async () => {
  // Create a context that will issue http requests
  const context = await request.newContext({
    baseURL: 'https://api.github.com',
  });

  // Create a repository
  await context.post('/user/repos', {
    headers: {
      'Accept': 'application/vnd.github.v3+json',
      // Add GitHub personal access token
      'Authorization': `token ${process.env.API_TOKEN}`,
    },
    data: {
      name: REPO
    }
  });

  // Delete a repository
  await context.delete(`/repos/${USER}/${REPO}`, {
    headers: {
      'Accept': 'application/vnd.github.v3+json',
      // Add GitHub personal access token
      'Authorization': `token ${process.env.API_TOKEN}`,
    }
  });
})();
```

## Sending API Requests from UI Tests

While running tests inside browsers, you may want to make calls to HTTP API.

**Use cases:**
- Prepare server state before running test
- Check postconditions on server after performing actions in browser

### Establishing Preconditions

Create data via API, then verify in UI:

```typescript
import { test, expect } from '@playwright/test';

const REPO = 'test-repo-1';
const USER = 'github-username';

// Request context is reused by all tests in the file
let apiContext;

test.beforeAll(async ({ playwright }) => {
  apiContext = await playwright.request.newContext({
    // All requests we send go to this API endpoint
    baseURL: 'https://api.github.com',
    extraHTTPHeaders: {
      // Set header per GitHub guidelines
      'Accept': 'application/vnd.github.v3+json',
      // Add authorization token to all requests
      // Assuming personal access token available in environment
      'Authorization': `token ${process.env.API_TOKEN}`,
    },
  });
});

test.afterAll(async ({ }) => {
  // Dispose all responses
  await apiContext.dispose();
});

test('last created issue should be first in the list', async ({ page }) => {
  const newIssue = await apiContext.post(`/repos/${USER}/${REPO}/issues`, {
    data: {
      title: '[Feature] request 1',
    }
  });
  expect(newIssue.ok()).toBeTruthy();

  await page.goto(`https://github.com/${USER}/${REPO}/issues`);
  const firstIssue = page.locator(`a[data-hovercard-type='issue']`).first();
  await expect(firstIssue).toHaveText('[Feature] request 1');
});
```

### Validating Postconditions

Create data via UI, then verify via API:

```typescript
test('last created issue should be on the server', async ({ page }) => {
  await page.goto(`https://github.com/${USER}/${REPO}/issues`);
  await page.getByText('New Issue').click();
  await page.getByRole('textbox', { name: 'Title' }).fill('Bug report 1');
  await page.getByRole('textbox', { name: 'Comment body' }).fill('Bug description');
  await page.getByText('Submit new issue').click();
  const issueId = new URL(page.url()).pathname.split('/').pop();

  const newIssue = await apiContext.get(
      `https://api.github.com/repos/${USER}/${REPO}/issues/${issueId}`
  );
  expect(newIssue.ok()).toBeTruthy();
  expect(newIssue.json()).toEqual(expect.objectContaining({
    title: 'Bug report 1'
  }));
});
```

## Reusing Authentication State

Web apps use **cookie-based** or **token-based** authentication.

**Method:** `apiRequestContext.storageState()` retrieves storage state from authenticated context, then creates new contexts with that state.

### Storage State Interchangeability

Storage state is **interchangeable** between `BrowserContext` and `APIRequestContext`.

**Use case:** Log in via API calls, then create new context with cookies already there.

```typescript
const requestContext = await request.newContext({
  httpCredentials: {
    username: 'user',
    password: 'passwd'
  }
});
await requestContext.get(`https://api.example.com/login`);

// Save storage state into file
await requestContext.storageState({ path: 'state.json' });

// Create new context with saved storage state
const context = await browser.newContext({ storageState: 'state.json' });
```

## Context Request vs Global Request

### Two Types of APIRequestContext

1. **Associated with BrowserContext**
2. **Isolated instance** (created via `apiRequest.newContext()`)

### Main Difference

`APIRequestContext` accessible via `browserContext.request` and `page.request`:
- Populates request's `Cookie` header from browser context
- Automatically updates browser cookies if `APIResponse` has `Set-Cookie` header

### Context Request (Shared Cookie Storage)

```typescript
test('context request will share cookie storage with its browser context', async ({
  page,
  context,
}) => {
  await context.route('https://www.github.com/', async route => {
    // Send API request that shares cookie storage with browser context
    const response = await context.request.fetch(route.request());
    const responseHeaders = response.headers();

    // Response will have 'Set-Cookie' header
    const responseCookies = new Map(responseHeaders['set-cookie']
        .split('\n')
        .map(c => c.split(';', 2)[0].split('=')));
    // Response will have 3 cookies in 'Set-Cookie' header
    expect(responseCookies.size).toBe(3);
    
    const contextCookies = await context.cookies();
    // Browser context will already contain all cookies from API response
    expect(new Map(contextCookies.map(({ name, value }) =>
      [name, value])
    )).toEqual(responseCookies);

    await route.fulfill({
      response,
      headers: { ...responseHeaders, foo: 'bar' },
    });
  });
  await page.goto('https://www.github.com/');
});
```

### Global Request (Isolated Cookie Storage)

If you don't want `APIRequestContext` to use and update cookies from browser context, create new isolated instance:

```typescript
test('global context request has isolated cookie storage', async ({
  page,
  context,
  browser,
  playwright
}) => {
  // Create new instance of APIRequestContext with isolated cookie storage
  const request = await playwright.request.newContext();
  
  await context.route('https://www.github.com/', async route => {
    const response = await request.fetch(route.request());
    const responseHeaders = response.headers();

    const responseCookies = new Map(responseHeaders['set-cookie']
        .split('\n')
        .map(c => c.split(';', 2)[0].split('=')));
    // Response will have 3 cookies in 'Set-Cookie' header
    expect(responseCookies.size).toBe(3);
    
    const contextCookies = await context.cookies();
    // Browser context will NOT have any cookies from isolated API request
    expect(contextCookies.length).toBe(0);

    // Manually export cookie storage
    const storageState = await request.storageState();
    // Create new context and initialize it with cookies from global request
    const browserContext2 = await browser.newContext({ storageState });
    const contextCookies2 = await browserContext2.cookies();
    // New browser context will already contain all cookies from API response
    expect(
        new Map(contextCookies2.map(({ name, value }) => [name, value]))
    ).toEqual(responseCookies);

    await route.fulfill({
      response,
      headers: { ...responseHeaders, foo: 'bar' },
    });
  });
  await page.goto('https://www.github.com/');
  await request.dispose();
});
```

## Best Practices

### 1. Configure baseURL and Headers Globally

Set in `playwright.config.ts` for all tests.

### 2. Use request Fixture for Simple Cases

Built-in fixture respects configuration automatically.

### 3. Create Manual Context for More Control

Use `apiRequest.newContext()` when needed.

### 4. Use beforeAll/afterAll for Setup/Teardown

Create and clean up test data efficiently.

### 5. Establish Preconditions via API

Faster than UI-based setup.

### 6. Validate Postconditions via API

More reliable than UI-based validation.

### 7. Reuse Authentication State

Save and load storage state to avoid repeated logins.

### 8. Choose Appropriate Request Context Type

- Use context request for shared cookie storage
- Use global request for isolated cookie storage

### 9. Dispose API Contexts

Always dispose contexts in `afterAll` to clean up resources.

### 10. Use Proxy Configuration When Needed

Configure proxy in config file for automatic pickup.

## Common Patterns

### Pure API Testing

```typescript
test('API endpoint test', async ({ request }) => {
  const response = await request.post('/api/endpoint', {
    data: { key: 'value' }
  });
  expect(response.ok()).toBeTruthy();
  expect(await response.json()).toMatchObject({ result: 'success' });
});
```

### API Setup + UI Verification

```typescript
test('create via API, verify in UI', async ({ page }) => {
  // Setup via API
  const response = await apiContext.post('/api/items', {
    data: { name: 'Test Item' }
  });
  
  // Verify in UI
  await page.goto('/items');
  await expect(page.getByText('Test Item')).toBeVisible();
});
```

### UI Action + API Validation

```typescript
test('create via UI, validate via API', async ({ page }) => {
  // Action in UI
  await page.goto('/create');
  await page.fill('[name="title"]', 'New Item');
  await page.click('button[type="submit"]');
  
  // Validate via API
  const response = await apiContext.get('/api/items');
  const items = await response.json();
  expect(items).toContainEqual(
    expect.objectContaining({ title: 'New Item' })
  );
});
```

### Authentication State Reuse

```typescript
// Login via API
const loginContext = await request.newContext();
await loginContext.post('/api/login', {
  data: { username: 'user', password: 'pass' }
});
await loginContext.storageState({ path: 'auth.json' });

// Use in browser context
const context = await browser.newContext({ 
  storageState: 'auth.json' 
});
```

## Related Topics to Explore

- APIRequestContext methods
- Storage state management
- Cookie handling
- Authentication patterns
- Request/response handling
- HTTP methods (GET, POST, PUT, DELETE, PATCH)
- Headers and authentication
- Proxy configuration
- Test fixtures
- Setup and teardown hooks
