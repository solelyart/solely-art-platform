# Playwright Documentation Research - Agents

**Page:** Agents  
**URL:** https://playwright.dev/docs/agents  
**Research Date:** December 13, 2025  
**Status:** Page Not Found (404)

## Note

The Agents page is currently unavailable. The documentation navigation includes this link, but the page returns a 404 error.

## Information from Release Notes

Based on the Release Notes (Version 1.56), Playwright Test Agents were introduced as three custom agent definitions designed to guide LLMs through the core process of building Playwright tests:

### Three Agent Types

1. **planner** - Explores the app and produces a Markdown test plan
2. **generator** - Transforms the Markdown plan into Playwright Test files  
3. **healer** - Executes the test suite and automatically repairs failing tests

### Usage

```bash
# Generate agent files for each agentic loop
npx playwright init-agents --loop=vscode
npx playwright init-agents --loop=claude
npx playwright init-agents --loop=opencode
```

### Context

This feature represents Playwright's integration with AI/LLM workflows for test generation and maintenance. The agents provide structured prompts and workflows for AI assistants to help with test creation and debugging.

## Alternative Sources

More detailed information about agents may be available through:
- GitHub repository documentation
- Release notes
- Community discussions
- Example repositories
- Blog posts about the feature
