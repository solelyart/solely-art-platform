# Playwright Documentation Research - Extensibility

**Page:** Extensibility  
**URL:** https://playwright.dev/docs/extensibility  
**Research Date:** December 14, 2025

## Custom Selector Engines

**Capability:** Playwright supports **custom selector engines**, registered with `selectors.register()`.

### Required Properties

**Selector engine should have the following properties:**

**1. `query` function** - To query first element matching `selector` relative to the `root`.

**2. `queryAll` function** - To query all elements matching `selector` relative to the `root`.

### Execution Context

**By default:** Engine is run directly in frame's JavaScript context and, for example, can call application-defined function.

**Isolation option:** To isolate engine from any JavaScript in frame, but leave access to DOM, register engine with `{contentScript: true}` option.

### Content Script Engine

**Safety:** Content script engine is safer because it is protected from any tampering with global objects, for example altering `Node.prototype` methods.

**Built-in engines:** All built-in selector engines run as content scripts.

**Note:** Running as content script is not guaranteed when engine is used together with other custom engines.

### Registration Timing

**Important:** Selectors must be registered **before creating the page**.

## Example: Tag Name Selector Engine

### baseTest.ts

```typescript
import { test as base } from '@playwright/test';

export { expect } from '@playwright/test';

// Must be a function that evaluates to a selector engine instance.
const createTagNameEngine = () => ({
  // Returns the first element matching given selector in the root's subtree.
  query(root, selector) {
    return root.querySelector(selector);
  },

  // Returns all elements matching given selector in the root's subtree.
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(selector));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  // Register selectors once per worker.
  selectorRegistration: [async ({ playwright }, use) => {
    // Register the engine. Selectors will be prefixed with "tag=".
    await playwright.selectors.register('tag', createTagNameEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});
```

### example.spec.ts

```typescript
import { test, expect } from './baseTest';

test('selector engine test', async ({ page }) => {
  // Now we can use 'tag=' selectors.
  const button = page.locator('tag=button');
  await button.click();

  // We can combine it with built-in locators.
  await page.locator('tag=div').getByText('Click me').click();

  // We can use it in any methods supporting selectors.
  await expect(page.locator('tag=button')).toHaveCount(3);
});
```

## Best Practices

### 1. Register Once Per Worker

**✅ Good:**
```typescript
export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('custom', createEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});
```

### 2. Use Content Script for Safety

**✅ Good:**
```typescript
await playwright.selectors.register('custom', createEngine, {
  contentScript: true
});
```

### 3. Register Before Page Creation

**✅ Good:**
```typescript
// Register in worker fixture (auto: true)
export const test = base.extend({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('custom', createEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

test('test', async ({ page }) => {
  // Page created after registration
  await page.goto('/');
});
```

**❌ Bad:**
```typescript
test('test', async ({ page, playwright }) => {
  await page.goto('/');
  await playwright.selectors.register('custom', createEngine); // Too late!
});
```

### 4. Implement Both query and queryAll

**✅ Good:**
```typescript
const createEngine = () => ({
  query(root, selector) {
    return root.querySelector(selector);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(selector));
  }
});
```

### 5. Return Correct Types

**✅ Good:**
```typescript
const createEngine = () => ({
  query(root, selector) {
    return root.querySelector(selector); // Returns Element | null
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(selector)); // Returns Element[]
  }
});
```

## Common Use Cases

### Use Case 1: Data Attribute Selector

```typescript
const createDataAttrEngine = () => ({
  query(root, selector) {
    return root.querySelector(`[data-test="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[data-test="${selector}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('data', createDataAttrEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('test', async ({ page }) => {
  await page.locator('data=submit-button').click();
});
```

### Use Case 2: React Component Selector

```typescript
const createReactEngine = () => ({
  query(root, selector) {
    // Find element by React component name
    const elements = root.querySelectorAll('*');
    for (const el of elements) {
      const reactKey = Object.keys(el).find(key => 
        key.startsWith('__reactInternalInstance') || 
        key.startsWith('__reactFiber')
      );
      if (reactKey) {
        const fiber = el[reactKey];
        if (fiber?.type?.name === selector) {
          return el;
        }
      }
    }
    return null;
  },
  queryAll(root, selector) {
    const results = [];
    const elements = root.querySelectorAll('*');
    for (const el of elements) {
      const reactKey = Object.keys(el).find(key => 
        key.startsWith('__reactInternalInstance') || 
        key.startsWith('__reactFiber')
      );
      if (reactKey) {
        const fiber = el[reactKey];
        if (fiber?.type?.name === selector) {
          results.push(el);
        }
      }
    }
    return results;
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('react', createReactEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('test', async ({ page }) => {
  await page.locator('react=SubmitButton').click();
});
```

### Use Case 3: Custom ID Prefix Selector

```typescript
const createIdPrefixEngine = () => ({
  query(root, selector) {
    return root.querySelector(`[id^="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[id^="${selector}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('idprefix', createIdPrefixEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('test', async ({ page }) => {
  await page.locator('idprefix=user-').click();
});
```

### Use Case 4: Aria Label Selector

```typescript
const createAriaEngine = () => ({
  query(root, selector) {
    return root.querySelector(`[aria-label="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[aria-label="${selector}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('aria', createAriaEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('test', async ({ page }) => {
  await page.locator('aria=Submit form').click();
});
```

## Use Cases for Solely Art Platform

### Example 1: Artist ID Selector

```typescript
const createArtistIdEngine = () => ({
  query(root, selector) {
    return root.querySelector(`[data-artist-id="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[data-artist-id="${selector}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('artist', createArtistIdEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('select artist', async ({ page }) => {
  await page.goto('/artists');
  await page.locator('artist=123').click();
  await expect(page).toHaveURL('/artist/123');
});
```

### Example 2: Booking Status Selector

```typescript
const createBookingStatusEngine = () => ({
  query(root, selector) {
    return root.querySelector(`[data-booking-status="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[data-booking-status="${selector}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('booking', createBookingStatusEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('filter bookings by status', async ({ page }) => {
  await page.goto('/bookings');
  const confirmedBookings = page.locator('booking=confirmed');
  await expect(confirmedBookings).toHaveCount(5);
});
```

### Example 3: Category Selector

```typescript
const createCategoryEngine = () => ({
  query(root, selector) {
    return root.querySelector(`[data-category="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[data-category="${selector}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('category', createCategoryEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('filter artists by category', async ({ page }) => {
  await page.goto('/search');
  const musicArtists = page.locator('category=music');
  await expect(musicArtists).toHaveCount(10);
});
```

### Example 4: Test ID Selector

```typescript
const createTestIdEngine = () => ({
  query(root, selector) {
    return root.querySelector(`[data-testid="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[data-testid="${selector}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('testid', createTestIdEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('use test IDs', async ({ page }) => {
  await page.goto('/');
  await page.locator('testid=login-button').click();
  await page.locator('testid=username-input').fill('user@example.com');
  await page.locator('testid=password-input').fill('password');
  await page.locator('testid=submit-button').click();
});
```

## Advanced Patterns

### Pattern 1: Content Script Engine

```typescript
const createSafeEngine = () => ({
  query(root, selector) {
    return root.querySelector(selector);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(selector));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('safe', createSafeEngine, {
      contentScript: true // Isolated from page JavaScript
    });
    await use();
  }, { scope: 'worker', auto: true }],
});
```

### Pattern 2: Complex Selector Logic

```typescript
const createComplexEngine = () => ({
  query(root, selector) {
    const [attr, value] = selector.split('=');
    return root.querySelector(`[${attr}="${value}"]`);
  },
  queryAll(root, selector) {
    const [attr, value] = selector.split('=');
    return Array.from(root.querySelectorAll(`[${attr}="${value}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('attr', createComplexEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('test', async ({ page }) => {
  await page.locator('attr=data-user-id=123').click();
});
```

### Pattern 3: Multiple Custom Engines

```typescript
const createEngine1 = () => ({
  query(root, selector) {
    return root.querySelector(`[data-test="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[data-test="${selector}"]`));
  }
});

const createEngine2 = () => ({
  query(root, selector) {
    return root.querySelector(`[data-id="${selector}"]`);
  },
  queryAll(root, selector) {
    return Array.from(root.querySelectorAll(`[data-id="${selector}"]`));
  }
});

export const test = base.extend<{}, { selectorRegistration: void }>({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('test', createEngine1);
    await playwright.selectors.register('id', createEngine2);
    await use();
  }, { scope: 'worker', auto: true }],
});

// Usage
test('test', async ({ page }) => {
  await page.locator('test=submit').click();
  await page.locator('id=user-123').click();
});
```

### Pattern 4: Combining with Built-in Locators

```typescript
test('combine custom and built-in', async ({ page }) => {
  // Custom selector
  const container = page.locator('testid=user-list');
  
  // Built-in locator within custom selector
  const firstUser = container.getByRole('button').first();
  
  await firstUser.click();
});
```

## Selector Engine Methods

### playwright.selectors.register(name, script, options)

**Purpose:** Register custom selector engine.

**Parameters:**
- `name` - Selector prefix (e.g., 'tag', 'data', 'testid')
- `script` - Function that creates selector engine
- `options` - Optional configuration (e.g., `{ contentScript: true }`)

```typescript
await playwright.selectors.register('custom', createEngine, {
  contentScript: true
});
```

### query(root, selector)

**Purpose:** Query first element matching selector.

**Returns:** Element | null

```typescript
query(root, selector) {
  return root.querySelector(selector);
}
```

### queryAll(root, selector)

**Purpose:** Query all elements matching selector.

**Returns:** Element[]

```typescript
queryAll(root, selector) {
  return Array.from(root.querySelectorAll(selector));
}
```

## Troubleshooting

### Issue: Selector Not Working

**Cause:** Selector registered after page creation.

**Solution:** Register in worker fixture with auto: true.

```typescript
// ✅ Correct
export const test = base.extend({
  selectorRegistration: [async ({ playwright }, use) => {
    await playwright.selectors.register('custom', createEngine);
    await use();
  }, { scope: 'worker', auto: true }],
});

// ❌ Wrong
test('test', async ({ page, playwright }) => {
  await playwright.selectors.register('custom', createEngine); // Too late
  await page.goto('/');
});
```

### Issue: queryAll Returns NodeList

**Cause:** Returning NodeList instead of Array.

**Solution:** Convert to Array.

```typescript
// ✅ Correct
queryAll(root, selector) {
  return Array.from(root.querySelectorAll(selector));
}

// ❌ Wrong
queryAll(root, selector) {
  return root.querySelectorAll(selector); // Returns NodeList
}
```

### Issue: Engine Not Isolated

**Cause:** Not using contentScript option.

**Solution:** Use contentScript: true for safety.

```typescript
// ✅ Correct
await playwright.selectors.register('custom', createEngine, {
  contentScript: true
});

// ❌ Less safe
await playwright.selectors.register('custom', createEngine);
```

## Summary

### Key Concepts

**1. Custom selector engines:** Extend Playwright with custom selectors

**2. Required methods:** query() and queryAll()

**3. Registration timing:** Must register before page creation

**4. Content script:** Use for isolation from page JavaScript

**5. Worker scope:** Register once per worker with auto fixture

### Selector Engine Structure

```typescript
const createEngine = () => ({
  query(root, selector) {
    // Return first matching element or null
  },
  queryAll(root, selector) {
    // Return array of matching elements
  }
});
```

### Best Practices

1. Register once per worker
2. Use content script for safety
3. Register before page creation
4. Implement both query and queryAll
5. Return correct types

### Common Use Cases

- Data attribute selectors
- React component selectors
- Custom ID selectors
- Test ID selectors
- Category/status selectors

## Related Topics

- Locators
- Selectors
- Fixtures
- Workers
- Page object models
- Testing patterns
