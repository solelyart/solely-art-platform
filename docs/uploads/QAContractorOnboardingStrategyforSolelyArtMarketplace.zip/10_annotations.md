# Playwright Documentation Research - Annotations

**Page:** Annotations  
**URL:** https://playwright.dev/docs/test-annotations  
**Research Date:** December 13, 2025

## Overview

Playwright supports tags and annotations that are displayed in test reports. These features enable test organization, filtering, and metadata management. Custom tags and annotations can be added at any time, and Playwright provides several built-in annotations for common use cases.

## Built-in Annotations

Playwright includes four primary built-in annotations for test management:

### test.skip()

Marks the test as irrelevant. Playwright does not run such tests. This annotation is used when a test is not applicable in a specific configuration.

**Usage:**
```typescript
test.skip('skip this test', async ({ page }) => {
  // This test is not run
});
```

**Conditional skipping:**
```typescript
test('skip this test', async ({ page, browserName }) => {
  test.skip(browserName === 'firefox', 'Still working on it');
});
```

### test.fail()

Marks the test as failing. Playwright runs this test and ensures it does indeed fail. If the test does not fail, Playwright will complain. This is useful for documenting known failures or testing error conditions.

**Key characteristic:** The test is executed and expected to fail.

### test.fixme()

Marks the test as failing. Playwright will NOT run this test, as opposed to the `fail` annotation. Use `fixme` when running the test is slow or crashes.

**Key characteristic:** The test is skipped entirely, unlike `test.fail()` which still runs.

**Use cases:**
- Tests that crash the test runner
- Extremely slow tests that need fixing
- Tests temporarily disabled during development

### test.slow()

Marks the test as slow and triples the test timeout. This prevents slow tests from timing out prematurely while signaling that the test requires extended execution time.

**Effect:** Multiplies the configured timeout by 3.

## Annotation Scope

Annotations can be applied at different levels:

**Single test level** - Annotate individual tests with specific markers.

**Group level** - Apply annotations to entire test groups using `test.describe()`.

**Conditional application** - Annotations can be conditional, applying only when a condition is truthy, and may depend on test fixtures.

**Multiple annotations** - The same test can have multiple annotations, possibly in different configurations.

## Focus Tests

The `test.only()` annotation focuses specific tests. When focused tests exist, only those tests run.

```typescript
test.only('focus this test', async ({ page }) => {
  // Run only focused tests in the entire project
});
```

**Behavior:** All other tests are skipped when any test uses `.only()`.

## Test Grouping

Tests can be grouped using `test.describe()` to provide logical organization or scope before/after hooks to specific groups.

```typescript
import { test, expect } from '@playwright/test';

test.describe('two tests', () => {
  test('one', async ({ page }) => {
    // ...
  });
  
  test('two', async ({ page }) => {
    // ...
  });
});
```

**Benefits:**
- Logical test organization
- Scoped hooks (beforeEach, afterEach, beforeAll, afterAll)
- Group-level annotations
- Hierarchical test structure

## Tags

Tags enable test categorization and filtering. Tests can be tagged as `@fast`, `@slow`, or any custom category, then filtered in test reports or during execution.

### Tag Syntax

Tags must start with the `@` symbol and can be added in two ways:

**Method 1: Details object**
```typescript
test('test login page', {
  tag: '@fast',
}, async ({ page }) => {
  // ...
});
```

**Method 2: In test title**
```typescript
test('test full report @slow', async ({ page }) => {
  // ...
});
```

### Multiple Tags

Tests can have multiple tags:

```typescript
test('test full report', {
  tag: ['@slow', '@vrt'],
}, async ({ page }) => {
  // ...
});
```

### Group-Level Tags

Tags can be applied to entire test groups:

```typescript
test.describe('group', {
  tag: '@report',
}, () => {
  test('test report header', async ({ page }) => {
    // ...
  });
  
  test('test full report', {
    tag: ['@slow', '@vrt'],
  }, async ({ page }) => {
    // ...
  });
});
```

## Tag Filtering

### Command Line Filtering

**Run tests with specific tag:**
```bash
npx playwright test --grep @fast
```

**Skip tests with specific tag:**
```bash
npx playwright test --grep-invert @fast
```

**Logical OR (tests with either tag):**
```bash
npx playwright test --grep "@fast|@slow"
```

**Logical AND (tests with both tags) using regex lookaheads:**
```bash
npx playwright test --grep "(?=.*@fast)(?=.*@slow)"
```

### Configuration File Filtering

Tags can also be filtered in configuration files via:
- `testConfig.grep`
- `testProject.grep`

## Custom Annotations

Beyond tags, tests can be annotated with more substantial metadata. Annotations have a `type` and a `description` for additional context, and are available in the reporter API.

### Single Annotation

```typescript
test('test login page', {
  annotation: {
    type: 'issue',
    description: 'https://github.com/microsoft/playwright/issues/23180',
  },
}, async ({ page }) => {
  // ...
});
```

### Multiple Annotations

```typescript
test('test full report', {
  annotation: [
    { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/23180' },
    { type: 'performance', description: 'very slow test!' },
  ],
}, async ({ page }) => {
  // ...
});
```

### Group-Level Annotations

```typescript
test.describe('report tests', {
  annotation: { type: 'category', description: 'report' },
}, () => {
  test('test report header', async ({ page }) => {
    // ...
  });
  
  test('test full report', {
    annotation: [
      { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/23180' },
      { type: 'performance', description: 'very slow test!' },
    ],
  }, async ({ page }) => {
    // ...
  });
});
```

## Annotation Visibility in Reports

Playwright's built-in HTML reporter shows all annotations, **except** those where `type` starts with `_` symbol. This allows for internal annotations that don't clutter reports.

**Public annotation:** `{ type: 'issue', description: '...' }` - Shown in reports
**Private annotation:** `{ type: '_internal', description: '...' }` - Hidden from reports

## Conditional Annotations with Callbacks

Annotations can use callbacks to conditionally apply based on test fixtures or configuration.

### Browser-Specific Tests

```typescript
test.describe('chromium only', () => {
  test.skip(({ browserName }) => browserName !== 'chromium', 'Chromium only!');
  
  test.beforeAll(async () => {
    // This hook is only run in Chromium
  });
  
  test('test 1', async ({ page }) => {
    // This test is only run in Chromium
  });
  
  test('test 2', async ({ page }) => {
    // This test is only run in Chromium
  });
});
```

### Annotations in beforeEach Hooks

To avoid running `beforeEach` hooks for skipped tests, place annotations in the hook itself:

```typescript
test.beforeEach(async ({ page, isMobile }) => {
  test.fixme(isMobile, 'Settings page does not work in mobile yet');
  await page.goto('http://localhost:3000/settings');
});

test('user profile', async ({ page }) => {
  await page.getByText('My Profile').click();
  // ...
});
```

**Benefit:** The hook (including navigation) is skipped when the condition is met, saving execution time.

## Runtime Annotations

Annotations can be added dynamically during test execution using `test.info().annotations`:

```typescript
test('example test', async ({ page, browser }) => {
  test.info().annotations.push({
    type: 'browser version',
    description: browser.version(),
  });
  // ...
});
```

**Use cases:**
- Adding runtime-determined metadata
- Recording dynamic test conditions
- Capturing environment information
- Logging test-specific details

## Best Practices

1. **Use Descriptive Tags** - Choose meaningful tag names that clearly indicate test characteristics (@smoke, @regression, @critical)

2. **Combine Tags for Flexibility** - Use multiple tags to enable various filtering combinations

3. **Document Known Issues** - Use annotations to link tests to issue trackers

4. **Skip Strategically** - Use test.skip() for configuration-specific tests rather than commenting out code

5. **Differentiate fail vs fixme** - Use test.fail() for tests that should fail, test.fixme() for tests that crash or are too slow

6. **Mark Slow Tests** - Use test.slow() to prevent timeout failures on legitimately slow tests

7. **Group Related Tests** - Use test.describe() with group-level annotations for better organization

8. **Hide Internal Annotations** - Prefix internal annotation types with underscore to keep reports clean

9. **Conditional Annotations in Hooks** - Place conditional skips in beforeEach to avoid unnecessary setup

10. **Add Runtime Context** - Use test.info().annotations for dynamic metadata that aids debugging

## Related Topics to Explore

- Test reporters and report customization
- Test configuration and projects
- Test fixtures
- Command line options
- Grep patterns and regex filtering
- Test organization patterns
- CI/CD integration with filtered test runs
