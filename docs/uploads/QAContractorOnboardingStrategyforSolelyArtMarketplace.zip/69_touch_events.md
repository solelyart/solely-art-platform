# Playwright Documentation Research - Touch Events

**Page:** Touch Events
**URL:** https://playwright.dev/docs/eventsource
**Research Date:** December 14, 2025

## Overview

Playwright provides support for touch events. This allows you to test touch-based interactions like tapping, swiping, and pinching.

### Key Features

- **`touchscreen` API:** To dispatch touch events.
- **`tap()`:** To simulate a tap.
- **`swipe()`:** To simulate a swipe.

## Usage

```javascript
await page.touchscreen.tap(100, 100);
```

## Summary

### Key Takeaways

- **`page.touchscreen`:** To access the touch events API.
- **`tap()` and `swipe()`:** To simulate touch interactions.

### Related Topics

- Actions
- Emulation
