# Playwright Documentation Research - Reporters

**Page:** Reporters  
**URL:** https://playwright.dev/docs/test-reporters  
**Research Date:** December 13, 2025

## Overview

Playwright Test includes built-in reporters for different needs and supports custom reporters. Reporters control how test results are displayed and saved.

**Configuration methods:**
1. Command line: `--reporter` flag
2. Configuration file: `reporter` option

## Basic Usage

### Command Line

```bash
npx playwright test --reporter=line
```

### Configuration File

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: 'line',
});
```

## Multiple Reporters

Use multiple reporters simultaneously for different outputs.

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [
    ['list'],
    ['json', { outputFile: 'test-results.json' }]
  ],
});
```

**Use case:** Terminal output (`list`) + machine-readable file (`json`)

## Reporters on CI

Use different reporters for local development vs CI environments.

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Concise 'dot' for CI, default 'list' when running locally
  reporter: process.env.CI ? 'dot' : 'list',
});
```

**Best practice:** Use concise reporters on CI to reduce output noise.

## Built-in Reporters

All built-in reporters show detailed failure information. They differ mainly in verbosity for successful runs.

### List Reporter

**Default reporter** (except on CI where `dot` is default). Prints a line for each test.

#### Command Line

```bash
npx playwright test --reporter=list
```

#### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: 'list',
});
```

#### Example Output

```
Running 124 tests using 6 workers

 1  ✓ should access error in env (438ms)
 2  ✓ handle long test names (515ms)
 3  x 1) render expected (691ms)
 4  ✓ should timeout (932ms)
 5    should repeat each:
 6  ✓ should respect enclosing .gitignore (569ms)
 7    should teardown env after timeout:
 8    should respect excluded tests:
 9  ✓ should handle env beforeEach error (638ms)
10    should respect enclosing .gitignore:
```

#### Step Rendering

Enable step-by-step output:

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['list', { printSteps: true }]],
});
```

#### Configuration Options

| Environment Variable | Config Option | Description | Default |
|---------------------|---------------|-------------|---------|
| `PLAYWRIGHT_LIST_PRINT_STEPS` | `printSteps` | Print each step on its own line | `false` |
| `PLAYWRIGHT_FORCE_TTY` | - | Produce output for live terminal | TTY mode dependent |
| `FORCE_COLOR` | - | Produce colored output | TTY mode dependent |

### Line Reporter

More concise than list reporter. Uses single line for progress, prints failures inline.

**Best for:** Large test suites where you want progress without spam.

#### Command Line

```bash
npx playwright test --reporter=line
```

#### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: 'line',
});
```

#### Example Output

```
Running 124 tests using 6 workers
  1) dot-reporter.spec.ts:20:1 › render expected ===================================

    Error: expect(received).toBe(expected) // Object.is equality

    Expected: 1
    Received: 0

[23/124] gitignore.spec.ts - should respect nested .gitignore
```

#### Configuration Options

| Environment Variable | Config Option | Description | Default |
|---------------------|---------------|-------------|---------|
| `PLAYWRIGHT_FORCE_TTY` | - | Produce output for live terminal | TTY mode dependent |
| `FORCE_COLOR` | - | Produce colored output | TTY mode dependent |

### Dot Reporter

Very concise - single character per test. **Default on CI**.

**Best for:** CI environments where minimal output is desired.

#### Command Line

```bash
npx playwright test --reporter=dot
```

#### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: 'dot',
});
```

#### Example Output

```
Running 124 tests using 6 workers
······F·············································
```

#### Character Legend

| Character | Description |
|-----------|-------------|
| `·` | Passed |
| `F` | Failed |
| `×` | Failed or timed out - will be retried |
| `±` | Passed on retry (flaky) |
| `T` | Timed out |
| `°` | Skipped |

#### Configuration Options

| Environment Variable | Config Option | Description | Default |
|---------------------|---------------|-------------|---------|
| `PLAYWRIGHT_FORCE_TTY` | - | Produce output for live terminal | TTY mode dependent |
| `FORCE_COLOR` | - | Produce colored output | TTY mode dependent |

### HTML Reporter

Produces self-contained HTML report that can be served as web page.

#### Command Line

```bash
npx playwright test --reporter=html
```

#### Auto-Open Behavior

By default, opens automatically if tests failed. Control with `open` option:
- `'always'` - Always open
- `'never'` - Never open
- `'on-failure'` - Open only on failures (default)

#### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['html', { open: 'never' }]],
});
```

#### Custom Output Folder

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['html', { outputFolder: 'my-report' }]],
});
```

#### External Attachments

For attachments uploaded to external storage:

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['html', { 
    attachmentsBaseURL: 'https://external-storage.com/' 
  }]],
});
```

#### View Report

```bash
# View last report
npx playwright show-report

# View custom folder
npx playwright show-report my-report
```

#### Configuration Options

| Environment Variable | Config Option | Description | Default |
|---------------------|---------------|-------------|---------|
| `PLAYWRIGHT_HTML_TITLE` | `title` | Title in generated report | No title |
| `PLAYWRIGHT_HTML_OUTPUT_DIR` | `outputFolder` | Directory to save report | `playwright-report` |
| `PLAYWRIGHT_HTML_OPEN` | `open` | When to open: `'always'`, `'never'`, `'on-failure'` | `'on-failure'` |
| `PLAYWRIGHT_HTML_HOST` | `host` | Hostname to serve report | `localhost` |
| `PLAYWRIGHT_HTML_PORT` | `port` | Port to serve report | `9323` |
| `PLAYWRIGHT_HTML_ATTACHMENTS_BASE_URL` | `attachmentsBaseURL` | External attachment location | `data/` |
| `PLAYWRIGHT_HTML_NO_COPY_PROMPT` | `noCopyPrompt` | Disable copy prompt for errors | `false` |
| `PLAYWRIGHT_HTML_NO_SNIPPETS` | `noSnippets` | Disable code snippets in action log | `false` |

### Blob Reporter

Contains all test run details. **Primary function:** Facilitate merging reports from sharded tests.

#### Command Line

```bash
npx playwright test --reporter=blob
```

#### Configuration for Sharding

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: 'blob',
});
```

#### File Naming

**Format:** `report-<hash>.zip` or `report-<hash>-<shard_number>.zip`

**Hash computed from:**
- `--grep`
- `--grepInverted`
- `--project`
- `testConfig.tag`
- File filters

**Purpose:** Ensures different command line options produce different but stable report names.

#### Configuration Options

| Environment Variable | Config Option | Description | Default |
|---------------------|---------------|-------------|---------|
| `PLAYWRIGHT_BLOB_OUTPUT_DIR` | `outputDir` | Directory to save output | `blob-report` |
| `PLAYWRIGHT_BLOB_OUTPUT_NAME` | `fileName` | Report file name | `report-<project>-<hash>-<shard_number>.zip` |
| `PLAYWRIGHT_BLOB_OUTPUT_FILE` | `outputFile` | Full path to output file | `undefined` |

### JSON Reporter

Produces JSON object with all test run information.

#### Command Line with Environment Variable

```bash
PLAYWRIGHT_JSON_OUTPUT_NAME=results.json npx playwright test --reporter=json
```

#### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['json', { outputFile: 'results.json' }]],
});
```

#### Configuration Options

| Environment Variable | Config Option | Description | Default |
|---------------------|---------------|-------------|---------|
| `PLAYWRIGHT_JSON_OUTPUT_DIR` | - | Directory to save output | cwd or config directory |
| `PLAYWRIGHT_JSON_OUTPUT_NAME` | `outputFile` | Base file name | Printed to stdout |
| `PLAYWRIGHT_JSON_OUTPUT_FILE` | `outputFile` | Full path to output file | Printed to stdout |

### JUnit Reporter

Produces JUnit-style XML report.

#### Command Line with Environment Variable

```bash
PLAYWRIGHT_JUNIT_OUTPUT_NAME=results.xml npx playwright test --reporter=junit
```

#### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['junit', { outputFile: 'results.xml' }]],
});
```

#### Configuration Options

| Environment Variable | Config Option | Description | Default |
|---------------------|---------------|-------------|---------|
| `PLAYWRIGHT_JUNIT_OUTPUT_DIR` | - | Directory to save output | cwd or config directory |
| `PLAYWRIGHT_JUNIT_OUTPUT_NAME` | `outputFile` | Base file name | Printed to stdout |
| `PLAYWRIGHT_JUNIT_OUTPUT_FILE` | `outputFile` | Full path to output file | Printed to stdout |
| `PLAYWRIGHT_JUNIT_STRIP_ANSI` | `stripANSIControlSequences` | Remove ANSI control sequences | Not removed by default |
| `PLAYWRIGHT_JUNIT_INCLUDE_PROJECT_IN_TEST_NAME` | `includeProjectInTestName` | Include project name in test case | Not included by default |
| `PLAYWRIGHT_JUNIT_SUITE_ID` | - | Value of id attribute on root | Empty string |
| `PLAYWRIGHT_JUNIT_SUITE_NAME` | - | Value of name attribute on root | Empty string |

### GitHub Actions Annotations

Built-in reporter for automatic failure annotations in GitHub Actions.

**Note:** Not recommended with matrix strategy (stack traces multiply and obscure file view).

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // 'github' for GitHub Actions CI to generate annotations, plus 'dot'
  // default 'list' when running locally
  reporter: process.env.CI ? 'github' : 'list',
});
```

## Custom Reporters

Create custom reporter by implementing reporter methods.

### Basic Custom Reporter

```typescript
// my-awesome-reporter.ts
import type {
  FullConfig, FullResult, Reporter, Suite, TestCase, TestResult
} from '@playwright/test/reporter';

class MyReporter implements Reporter {
  onBegin(config: FullConfig, suite: Suite) {
    console.log(`Starting the run with ${suite.allTests().length} tests`);
  }

  onTestBegin(test: TestCase, result: TestResult) {
    console.log(`Starting test ${test.title}`);
  }

  onTestEnd(test: TestCase, result: TestResult) {
    console.log(`Finished test ${test.title}: ${result.status}`);
  }

  onEnd(result: FullResult) {
    console.log(`Finished the run: ${result.status}`);
  }
}

export default MyReporter;
```

### Use Custom Reporter

#### In Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: './my-awesome-reporter.ts',
});
```

#### Command Line

```bash
npx playwright test --reporter="./myreporter/my-awesome-reporter.ts"
```

### Open Source Reporter Examples

- **Allure Reporter**
- **Github Actions Reporter**
- **Mail Reporter**
- **ReportPortal**
- **Monocart**

## Best Practices

### 1. Use Different Reporters for Different Environments

```typescript
reporter: process.env.CI ? 'dot' : 'list',
```

### 2. Combine Multiple Reporters

```typescript
reporter: [
  ['list'],                                    // Terminal output
  ['json', { outputFile: 'results.json' }],   // Machine-readable
  ['html', { open: 'never' }],                // Web report
]
```

### 3. Configure HTML Report for CI

```typescript
reporter: [
  ['html', { 
    open: 'never',
    outputFolder: 'test-results/html'
  }]
]
```

### 4. Use Blob Reporter for Sharded Tests

```typescript
// On each shard
reporter: 'blob'

// Then merge reports
```

### 5. Use GitHub Reporter on GitHub Actions

```typescript
reporter: process.env.GITHUB_ACTIONS ? 'github' : 'list'
```

### 6. Save JSON for Post-Processing

```typescript
reporter: [
  ['list'],
  ['json', { outputFile: 'results.json' }]
]
```

### 7. Use JUnit for CI Integration

```typescript
reporter: [
  ['junit', { outputFile: 'junit.xml' }]
]
```

### 8. Enable Step Printing for Debugging

```typescript
reporter: [['list', { printSteps: true }]]
```

### 9. Custom Reporter for Slack/Teams Notifications

```typescript
class NotificationReporter implements Reporter {
  async onEnd(result: FullResult) {
    if (result.status === 'failed') {
      await sendSlackNotification(result);
    }
  }
}
```

### 10. Disable HTML Auto-Open in CI

```typescript
reporter: [
  ['html', { open: process.env.CI ? 'never' : 'on-failure' }]
]
```

## Common Patterns

### Local Development Setup

```typescript
reporter: [
  ['list', { printSteps: true }],
  ['html', { open: 'on-failure' }]
]
```

### CI Setup

```typescript
reporter: process.env.CI ? [
  ['dot'],
  ['json', { outputFile: 'results.json' }],
  ['junit', { outputFile: 'junit.xml' }],
  ['html', { open: 'never' }]
] : 'list'
```

### Sharded Test Reporting

```typescript
// Shard configuration
reporter: 'blob'

// After merging
reporter: [
  ['html'],
  ['json', { outputFile: 'merged-results.json' }]
]
```

### GitHub Actions with Artifacts

```typescript
reporter: [
  ['github'],
  ['html', { open: 'never', outputFolder: 'playwright-report' }]
]
```

### Multi-Environment Reporting

```typescript
reporter: [
  ['list'],
  ['json', { 
    outputFile: `results-${process.env.ENV || 'dev'}.json` 
  }]
]
```

## Related Topics to Explore

- Reporter API documentation
- Test result objects
- Sharding and merging reports
- CI/CD integration
- Custom reporter development
- Test attachments
- Trace viewer
- Test artifacts
- GitHub Actions integration
- Report hosting and sharing
