# Playwright Documentation Research - Global Setup and Teardown

**Page:** Global setup and teardown  
**URL:** https://playwright.dev/docs/test-global-setup-teardown  
**Research Date:** December 13, 2025

## Overview

There are two ways to configure global setup and teardown in Playwright:

1. **Project Dependencies** (Recommended) - Define a project that runs before all other projects
2. **globalSetup Config Option** - Set a global setup file in the configuration

**Recommendation:** Use project dependencies as they integrate better with the Playwright test runner, providing HTML report visibility, trace recording, and full fixture support.

## Comparison of Approaches

| Feature | Project Dependencies (recommended) | globalSetup (config option) |
|---------|-----------------------------------|----------------------------|
| Runs before all tests | ✅ Yes | ✅ Yes |
| HTML report visibility | ✅ Shown as a separate project | ❌ Not shown |
| Trace recording | ✅ Full trace available | ❌ Not supported |
| Playwright fixtures | ✅ Fully supported | ❌ Not supported |
| Browser management | ✅ Via `browser` fixture | ❌ Fully manual via `browserType.launch()` |
| Parallelism and retries | ✅ Supported via standard config | ❌ Not applicable |
| Config options like `headless` or `testIdAttribute` | ✅ Automatically applied | ❌ Ignored |

## Option 1: Project Dependencies (Recommended)

Project dependencies allow you to define projects that must run before tests in other projects. This approach provides full integration with Playwright's test runner features.

### Setup

**Step 1: Create a setup project**

Define a new project with a name and match it to a specific setup file:

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  projects: [
    {
      name: 'setup db',
      testMatch: /global\.setup\.ts/,
    },
    // other projects...
  ]
});
```

**Step 2: Add dependencies to other projects**

Configure projects to depend on the setup project:

```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  projects: [
    {
      name: 'setup db',
      testMatch: /global\.setup\.ts/,
    },
    {
      name: 'chromium with db',
      use: { ...devices['Desktop Chrome'] },
      dependencies: ['setup db'],
    },
  ]
});
```

**Step 3: Create the setup test**

Setup and teardown code must be defined as regular tests using the `test()` function:

```typescript
// tests/global.setup.ts
import { test as setup } from '@playwright/test';

setup('create new database', async ({ }) => {
  console.log('creating new database...');
  // Initialize the database
});
```

**Step 4: Use in tests**

```typescript
// tests/menu.spec.ts
import { test, expect } from '@playwright/test';

test('menu', async ({ page }) => {
  // Your test that depends on the database
});
```

### Teardown

Add a teardown project that runs after all dependent projects complete.

**Step 1: Add teardown property to setup project**

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  projects: [
    {
      name: 'setup db',
      testMatch: /global\.setup\.ts/,
      teardown: 'cleanup db',
    },
    {
      name: 'cleanup db',
      testMatch: /global\.teardown\.ts/,
    },
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
      dependencies: ['setup db'],
    },
  ]
});
```

**Step 2: Create teardown test**

```typescript
// tests/global.teardown.ts
import { test as teardown } from '@playwright/test';

teardown('delete database', async ({ }) => {
  console.log('deleting test database...');
  // Delete the database
});
```

### Test Filtering with Dependencies

All test filtering options (--grep, --grep-invert, --shard, test.only(), etc.) select primary tests. If those tests belong to a project with dependencies, all tests from dependencies will also run.

**Skip dependencies:**
```bash
npx playwright test --no-deps
```

This ignores all dependencies and teardowns, running only directly selected projects.

### Benefits of Project Dependencies

1. **Full Feature Support** - Access to all Playwright features
2. **Trace Recording** - Full traces available for debugging
3. **HTML Reports** - Setup shown as separate project
4. **Fixtures** - Can use browser, page, and custom fixtures
5. **Standard Config** - Parallelism, retries, and all config options work
6. **Better Debugging** - Setup failures clearly visible

### Common Use Cases

**Database Setup:**
```typescript
setup('initialize database', async ({ }) => {
  await db.migrate();
  await db.seed();
});
```

**Authentication:**
```typescript
setup('authenticate admin', async ({ page }) => {
  await page.goto('/login');
  await page.fill('[name="username"]', 'admin');
  await page.fill('[name="password"]', 'password');
  await page.click('button[type="submit"]');
  await page.context().storageState({ path: 'admin-state.json' });
});
```

**Service Startup:**
```typescript
setup('start test server', async ({ }) => {
  await startServer({ port: 3000, env: 'test' });
});
```

## Option 2: Configure globalSetup (Legacy)

Use the `globalSetup` option in the configuration file to run something once before all tests.

**Important:** This approach lacks many features. Consider using project dependencies instead.

### Basic Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  globalSetup: require.resolve('./global-setup'),
  globalTeardown: require.resolve('./global-teardown'),
});
```

### Global Setup File

The global setup file must export a single function that takes a config object:

```typescript
// global-setup.ts
import { chromium, type FullConfig } from '@playwright/test';

async function globalSetup(config: FullConfig) {
  const { baseURL, storageState } = config.projects[0].use;
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto(baseURL!);
  await page.getByLabel('User Name').fill('user');
  await page.getByLabel('Password').fill('password');
  await page.getByText('Sign in').click();
  await page.context().storageState({ path: storageState as string });
  await browser.close();
}

export default globalSetup;
```

### Configuration with baseURL and storageState

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  globalSetup: require.resolve('./global-setup'),
  use: {
    baseURL: 'http://localhost:3000/',
    storageState: 'state.json',
  },
});
```

### Using in Tests

Tests start already authenticated because storageState was populated by global setup:

```typescript
import { test } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('/');
  // You are signed in!
});
```

### Global Teardown

**Option 1: Separate file**
```typescript
// playwright.config.ts
export default defineConfig({
  globalSetup: require.resolve('./global-setup'),
  globalTeardown: require.resolve('./global-teardown'),
});
```

**Option 2: Return function from globalSetup**
```typescript
// global-setup.ts
async function globalSetup(config: FullConfig) {
  // Setup code...
  
  return async () => {
    // Teardown code...
  };
}

export default globalSetup;
```

### Passing Data via Environment Variables

You can make arbitrary data available in tests by setting environment variables:

```typescript
// global-setup.ts
import type { FullConfig } from '@playwright/test';

async function globalSetup(config: FullConfig) {
  process.env.FOO = 'some data';
  // Or complex data as JSON:
  process.env.BAR = JSON.stringify({ some: 'data' });
}

export default globalSetup;
```

**Access in tests:**
```typescript
import { test } from '@playwright/test';

test('test', async ({ page }) => {
  // Environment variables set in globalSetup are available inside test()
  const { FOO, BAR } = process.env;
  
  expect(FOO).toEqual('some data');
  
  const complexData = JSON.parse(BAR);
  expect(complexData).toEqual({ some: 'data' });
});
```

### Limitations of globalSetup

1. **No Fixtures** - Cannot use browser, page, or custom fixtures
2. **Manual Browser Management** - Must use browserType.launch() directly
3. **No Traces** - Trace recording not supported
4. **No HTML Report** - Setup not shown in reports
5. **Config Options Ignored** - Options like headless, testIdAttribute not applied
6. **No Parallelism/Retries** - Standard test features unavailable

## Capturing Trace of Failures During Global Setup

When using project dependencies, you can capture traces of failures in global setup.

### Example: Start Tracing in Global Setup

```typescript
// global-setup.ts
import { test as setup, expect } from '@playwright/test';

setup('authenticate', async ({ page, context }) => {
  // Start tracing
  await context.tracing.start({ screenshots: true, snapshots: true });
  
  await page.goto('https://github.com/login');
  await page.getByLabel('Username or email address').fill('username');
  await page.getByLabel('Password').fill('password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  
  await expect(page.getByRole('button', { name: 'View profile and more' }))
    .toBeVisible();
  
  await page.context().storageState({ path: 'state.json' });
  
  // Stop tracing
  await context.tracing.stop({ path: 'setup-trace.zip' });
});
```

**Benefits:**
- Trace available if setup fails
- Screenshots and snapshots captured
- Full debugging information preserved

## Best Practices

### 1. Use Project Dependencies

**Recommended:**
```typescript
projects: [
  { name: 'setup', testMatch: /global\.setup\.ts/ },
  { name: 'tests', dependencies: ['setup'] },
]
```

**Avoid:**
```typescript
globalSetup: require.resolve('./global-setup')
```

### 2. Keep Setup Fast

Setup runs before all tests, so keep it minimal:
- Only essential initialization
- Avoid unnecessary operations
- Use worker fixtures for per-worker setup

### 3. Use Fixtures for Per-Worker Setup

For setup that should run per worker (not globally), use worker-scoped fixtures:

```typescript
export const test = base.extend<{}, { workerSetup: void }>({
  workerSetup: [async ({}, use) => {
    // Setup per worker
    await use();
    // Teardown per worker
  }, { scope: 'worker', auto: true }],
});
```

### 4. Store Authentication State

Save authentication state to reuse across tests:

```typescript
await page.context().storageState({ path: 'auth-state.json' });
```

Then configure in tests:
```typescript
use: {
  storageState: 'auth-state.json',
}
```

### 5. Handle Setup Failures Gracefully

Add error handling and cleanup:

```typescript
setup('initialize', async ({ }) => {
  try {
    await initializeResources();
  } catch (error) {
    await cleanup();
    throw error;
  }
});
```

### 6. Use Teardown for Cleanup

Always clean up resources in teardown:

```typescript
teardown('cleanup', async ({ }) => {
  await stopServer();
  await cleanDatabase();
  await removeTestFiles();
});
```

### 7. Document Setup Requirements

Add comments explaining what setup does:

```typescript
setup('database initialization', async ({ }) => {
  // Creates test database with schema
  // Seeds with minimal test data
  // Sets up database connection pool
  await setupDatabase();
});
```

### 8. Use Environment Variables for Configuration

Pass configuration from setup to tests:

```typescript
// In setup
process.env.TEST_DB_URL = dbUrl;
process.env.TEST_API_KEY = apiKey;

// In tests
const { TEST_DB_URL, TEST_API_KEY } = process.env;
```

### 9. Enable Tracing for Setup

Capture traces to debug setup failures:

```typescript
setup('authenticate', async ({ page, context }) => {
  await context.tracing.start({ screenshots: true, snapshots: true });
  // ... setup code ...
  await context.tracing.stop({ path: 'setup-trace.zip' });
});
```

### 10. Test Setup Independently

Run setup project independently to verify:

```bash
npx playwright test --project=setup
```

## Common Patterns

### Authentication Setup

```typescript
// global.setup.ts
import { test as setup } from '@playwright/test';

setup('authenticate as admin', async ({ page }) => {
  await page.goto('/login');
  await page.fill('[name="email"]', 'admin@example.com');
  await page.fill('[name="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForURL('/dashboard');
  await page.context().storageState({ path: 'admin-auth.json' });
});

setup('authenticate as user', async ({ page }) => {
  await page.goto('/login');
  await page.fill('[name="email"]', 'user@example.com');
  await page.fill('[name="password"]', 'user123');
  await page.click('button[type="submit"]');
  await page.waitForURL('/home');
  await page.context().storageState({ path: 'user-auth.json' });
});
```

### Database Setup

```typescript
// global.setup.ts
import { test as setup } from '@playwright/test';
import { db } from './database';

setup('initialize database', async ({ }) => {
  await db.connect();
  await db.migrate();
  await db.seed({
    users: 10,
    posts: 50,
    comments: 200,
  });
  process.env.DB_READY = 'true';
});
```

### Server Startup

```typescript
// global.setup.ts
import { test as setup } from '@playwright/test';
import { startServer } from './server';

let server;

setup('start test server', async ({ }) => {
  server = await startServer({ port: 3000, env: 'test' });
  process.env.SERVER_URL = `http://localhost:${server.port}`;
});
```

### Multiple Setup Projects

```typescript
// playwright.config.ts
export default defineConfig({
  projects: [
    { name: 'setup:db', testMatch: /setup\.db\.ts/ },
    { name: 'setup:auth', testMatch: /setup\.auth\.ts/, dependencies: ['setup:db'] },
    {
      name: 'tests',
      dependencies: ['setup:auth'],
      use: { storageState: 'auth-state.json' },
    },
  ],
});
```

## Related Resources

- [Authentication guide](https://playwright.dev/docs/auth)
- [Blog post: A better global setup in Playwright](https://playwright.dev/blog)
- [v1.31 release video](https://www.youtube.com/watch?v=PI50YAPTAs4)
- [Project dependencies documentation](https://playwright.dev/docs/test-projects#dependencies)

## Related Topics to Explore

- Project dependencies
- Worker-scoped fixtures
- Authentication patterns
- Storage state management
- Test isolation
- Trace viewer
- HTML reporter
- Database testing strategies
- API testing setup
- Environment configuration
