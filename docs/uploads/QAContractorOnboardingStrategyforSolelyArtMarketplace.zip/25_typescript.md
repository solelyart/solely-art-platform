# Playwright Documentation Research - TypeScript

**Page:** TypeScript  
**URL:** https://playwright.dev/docs/test-typescript  
**Research Date:** December 13, 2025

## Overview

Playwright supports TypeScript **out of the box**. You write tests in TypeScript, and Playwright automatically reads, transforms to JavaScript, and runs them.

**Important note:** Playwright does not check types and will run tests even if there are non-critical TypeScript compilation errors.

## Type Checking

### Recommended Approach

Run TypeScript compiler alongside Playwright to catch type errors.

### GitHub Actions Example

```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    ...
    - name: Run type checks
      run: npx tsc -p tsconfig.json --noEmit
    - name: Run Playwright tests
      run: npx playwright test
```

**Key flags:**
- `-p tsconfig.json` - Use specific tsconfig
- `--noEmit` - Only check types, don't generate output files

### Local Development

Run `tsc` in watch mode:

```bash
npx tsc -p tsconfig.json --noEmit -w
```

**Flags:**
- `-w` - Watch mode (automatically recompile on changes)
- `--noEmit` - Type check only

## tsconfig.json

Playwright picks up `tsconfig.json` for each source file it loads.

### Supported Options

Playwright **only supports** the following tsconfig options:
- `allowJs`
- `baseUrl`
- `paths`
- `references`

### Recommended Directory Structure

```
src/
    source.ts
tests/
    tsconfig.json      # test-specific tsconfig
    example.spec.ts
tsconfig.json          # generic tsconfig for all typescript sources
playwright.config.ts
```

**Benefit:** Separate test-specific configuration from main application configuration.

### Example Test-Specific tsconfig.json

```json
{
  "compilerOptions": {
    "target": "ESNext",
    "module": "commonjs",
    "moduleResolution": "Node",
    "sourceMap": true
  }
}
```

## tsconfig Path Mapping

Playwright supports path mapping declared in `tsconfig.json`. **Requirement:** `baseUrl` must also be set.

### Example Configuration

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@myhelper/*": ["packages/myhelper/*"]
    }
  }
}
```

**Note:** Path mapping is relative to `baseUrl`.

### Using Mapped Paths

```typescript
// example.spec.ts
import { test, expect } from '@playwright/test';
import { username, password } from '@myhelper/credentials';

test('example', async ({ page }) => {
  await page.getByLabel('User Name').fill(username);
  await page.getByLabel('Password').fill(password);
});
```

**Benefits:**
- Cleaner imports
- Avoid relative path hell (`../../../`)
- Easier refactoring

## tsconfig Resolution

### Automatic Resolution (Default)

By default, Playwright looks up the closest tsconfig for each imported file by going up the directory structure and looking for:
- `tsconfig.json`
- `jsconfig.json`

**Example:**
```
tests/tsconfig.json  # Used only for tests
```

Playwright automatically picks it up:

```bash
# Playwright will choose tsconfig automatically
npx playwright test
```

### Command Line Override

Specify a single tsconfig file for all imported files:

```bash
# Pass a specific tsconfig
npx playwright test --tsconfig=tsconfig.test.json
```

**Scope:** Used for all imported files, not just test files.

### Config File Override

Specify tsconfig in the configuration file:

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  tsconfig: './tsconfig.test.json',
});
```

**Usage:** Used for loading test files, reporters, etc.

**Limitation:** Not used while loading the playwright config itself or any files imported from it.

## Manually Compile Tests with TypeScript

Sometimes Playwright Test cannot transform TypeScript code correctly (e.g., experimental or very recent TypeScript features).

**Solution:** Perform your own TypeScript compilation before sending tests to Playwright.

### Step 1: Create tests/tsconfig.json

```json
{
  "compilerOptions": {
    "target": "ESNext",
    "module": "commonjs",
    "moduleResolution": "Node",
    "sourceMap": true,
    "outDir": "../tests-out"
  }
}
```

**Key setting:** `outDir` specifies where compiled JavaScript goes.

### Step 2: Add Scripts to package.json

```json
{
  "scripts": {
    "pretest": "tsc --incremental -p tests/tsconfig.json",
    "test": "playwright test -c tests-out"
  }
}
```

**Explanation:**
- `pretest` - Runs TypeScript compiler on tests
- `--incremental` - Faster recompilation
- `-p tests/tsconfig.json` - Use specific tsconfig
- `test` - Runs compiled tests from `tests-out` directory
- `-c tests-out` - Configures test runner to look for tests in `tests-out`

### Step 3: Run Tests

```bash
npm run test
```

**Process:**
1. `pretest` script compiles TypeScript to JavaScript
2. `test` script runs the compiled tests

## Best Practices

### 1. Always Run Type Checks in CI

```yaml
- name: Run type checks
  run: npx tsc -p tsconfig.json --noEmit
```

### 2. Use Watch Mode for Local Development

```bash
npx tsc -p tsconfig.json --noEmit -w
```

### 3. Create Separate Test tsconfig

```
tests/
  tsconfig.json  # Test-specific configuration
```

### 4. Use Path Mapping for Clean Imports

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@helpers/*": ["tests/helpers/*"],
      "@fixtures/*": ["tests/fixtures/*"],
      "@pages/*": ["tests/pages/*"]
    }
  }
}
```

### 5. Enable Strict Mode

```json
{
  "compilerOptions": {
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true
  }
}
```

### 6. Use Source Maps for Debugging

```json
{
  "compilerOptions": {
    "sourceMap": true
  }
}
```

### 7. Manually Compile for Advanced Features

If using experimental TypeScript features, compile manually:

```json
{
  "scripts": {
    "pretest": "tsc --incremental -p tests/tsconfig.json",
    "test": "playwright test -c tests-out"
  }
}
```

### 8. Specify tsconfig in Config File

```typescript
export default defineConfig({
  tsconfig: './tests/tsconfig.json',
});
```

### 9. Use ESNext Target for Modern Features

```json
{
  "compilerOptions": {
    "target": "ESNext"
  }
}
```

### 10. Enable Module Resolution

```json
{
  "compilerOptions": {
    "moduleResolution": "Node"
  }
}
```

## Common Patterns

### Complete Test tsconfig.json

```json
{
  "compilerOptions": {
    "target": "ESNext",
    "module": "commonjs",
    "moduleResolution": "Node",
    "strict": true,
    "sourceMap": true,
    "baseUrl": ".",
    "paths": {
      "@helpers/*": ["helpers/*"],
      "@pages/*": ["pages/*"],
      "@fixtures/*": ["fixtures/*"]
    }
  },
  "include": ["**/*.ts"],
  "exclude": ["node_modules"]
}
```

### CI/CD with Type Checking

```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-node@v3
      with:
        node-version: 18
    
    - name: Install dependencies
      run: npm ci
    
    - name: Run type checks
      run: npx tsc -p tests/tsconfig.json --noEmit
    
    - name: Run Playwright tests
      run: npx playwright test
```

### Path Mapping for Page Objects

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@pages/*": ["tests/pages/*"]
    }
  }
}
```

```typescript
// Clean import
import { LoginPage } from '@pages/login-page';

// Instead of
import { LoginPage } from '../../../pages/login-page';
```

### Manual Compilation Setup

```json
{
  "scripts": {
    "pretest": "tsc --incremental -p tests/tsconfig.json",
    "test": "playwright test -c tests-out",
    "test:watch": "tsc --incremental -p tests/tsconfig.json -w & playwright test -c tests-out --watch"
  }
}
```

### Multiple tsconfig Files

```
project/
  tsconfig.json              # Root config
  src/
    tsconfig.json            # Source code config
  tests/
    tsconfig.json            # Test config
    e2e/
      tsconfig.json          # E2E specific config
    unit/
      tsconfig.json          # Unit test config
```

## Troubleshooting

### Type Errors Not Showing

**Problem:** Playwright runs tests despite type errors

**Solution:** Run `tsc` separately with `--noEmit`:
```bash
npx tsc -p tsconfig.json --noEmit
```

### Path Mapping Not Working

**Problem:** Imports using path aliases fail

**Solution:** Ensure `baseUrl` is set:
```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@helpers/*": ["helpers/*"]
    }
  }
}
```

### TypeScript Transformation Fails

**Problem:** Playwright can't transform advanced TypeScript features

**Solution:** Manually compile tests:
```json
{
  "scripts": {
    "pretest": "tsc --incremental -p tests/tsconfig.json",
    "test": "playwright test -c tests-out"
  }
}
```

### Wrong tsconfig Used

**Problem:** Playwright uses wrong tsconfig

**Solution:** Specify explicitly:
```bash
npx playwright test --tsconfig=tests/tsconfig.json
```

Or in config:
```typescript
export default defineConfig({
  tsconfig: './tests/tsconfig.json',
});
```

## Related Topics to Explore

- TypeScript compiler options
- Path mapping
- Module resolution
- Source maps
- Test organization
- Page object models
- Custom fixtures
- Type-safe test helpers
- ESLint with TypeScript
- IDE TypeScript configuration
