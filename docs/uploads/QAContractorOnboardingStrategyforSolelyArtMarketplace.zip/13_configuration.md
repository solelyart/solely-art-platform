# Playwright Documentation Research - Configuration

**Page:** Configuration  
**URL:** https://playwright.dev/docs/test-configuration  
**Research Date:** December 13, 2025

## Overview

Playwright provides extensive configuration options to control how tests are run. These options are specified in the configuration file (typically `playwright.config.ts` or `playwright.config.js`). An important distinction is that test runner options are **top-level** and should NOT be placed in the `use` section.

## Basic Configuration

Here is a comprehensive example showing the most common configuration options:

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  // Look for test files in the "tests" directory, relative to this configuration file
  testDir: 'tests',
  
  // Run all tests in parallel
  fullyParallel: true,
  
  // Fail the build on CI if you accidentally left test.only in the source code
  forbidOnly: !!process.env.CI,
  
  // Retry on CI only
  retries: process.env.CI ? 2 : 0,
  
  // Opt out of parallel tests on CI
  workers: process.env.CI ? 1 : undefined,
  
  // Reporter to use
  reporter: 'html',
  
  use: {
    // Base URL to use in actions like `await page.goto('/')`
    baseURL: 'http://localhost:3000',
    
    // Collect trace when retrying the failed test
    trace: 'on-first-retry',
  },
  
  // Configure projects for major browsers
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  
  // Run your local dev server before starting the tests
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
```

## Common Configuration Options

### testConfig.forbidOnly

**Purpose:** Whether to exit with an error if any tests are marked as `test.only`.

**Use case:** Useful on CI to prevent accidentally committed focused tests from skipping the test suite.

**Common pattern:**
```typescript
forbidOnly: !!process.env.CI
```

This ensures the check only runs in CI environments, allowing developers to use `.only()` locally for focused testing.

### testConfig.fullyParallel

**Purpose:** Run all tests in all files in parallel.

**Related topics:** Parallelism and Sharding

**Effect:** When enabled, tests don't wait for others to complete, maximizing parallelization across the entire test suite.

### testConfig.projects

**Purpose:** Run tests in multiple configurations or on multiple browsers.

**Use case:** Testing across different browsers, devices, or configurations in a single test run.

**Example:**
```typescript
projects: [
  {
    name: 'chromium',
    use: { ...devices['Desktop Chrome'] },
  },
  {
    name: 'firefox',
    use: { ...devices['Desktop Firefox'] },
  },
  {
    name: 'webkit',
    use: { ...devices['Desktop Safari'] },
  },
]
```

### testConfig.reporter

**Purpose:** Specify which reporter(s) to use for test results.

**Options:** 'html', 'list', 'dot', 'line', 'json', 'junit', custom reporters

**Related topic:** Test Reporters documentation

**Example:**
```typescript
reporter: 'html'
// or multiple reporters
reporter: [['html'], ['json', { outputFile: 'results.json' }]]
```

### testConfig.retries

**Purpose:** The maximum number of retry attempts per test.

**Related topic:** Test Retries documentation

**Common pattern:**
```typescript
retries: process.env.CI ? 2 : 0
```

This retries flaky tests in CI but not locally, balancing reliability with development speed.

### testConfig.testDir

**Purpose:** Directory containing the test files.

**Default:** Looks for tests relative to the configuration file location.

**Example:**
```typescript
testDir: 'tests'
// or absolute path
testDir: './e2e/tests'
```

### testConfig.use

**Purpose:** Options that configure test execution behavior, browser context, and page settings.

**Important:** This is where browser and context options go, NOT top-level test runner options.

**Common use options:**
- `baseURL` - Base URL for navigation
- `trace` - Trace collection mode
- `screenshot` - Screenshot capture mode
- `video` - Video recording mode
- `viewport` - Browser viewport size
- `userAgent` - Custom user agent
- `locale` - Browser locale
- `timezoneId` - Timezone

### testConfig.webServer

**Purpose:** Launch a development server before running tests.

**Use case:** Automatically start your application server for testing.

**Configuration:**
```typescript
webServer: {
  command: 'npm run start',
  url: 'http://localhost:3000',
  reuseExistingServer: !process.env.CI,
}
```

**Key properties:**
- `command` - Command to start the server
- `url` - URL to wait for before starting tests
- `reuseExistingServer` - Whether to reuse an already running server
- `timeout` - Maximum time to wait for server to start
- `wait` - Wait for specific log output (added in recent versions)

### testConfig.workers

**Purpose:** The maximum number of concurrent worker processes for parallelizing tests.

**Format:** Can be a number or percentage of logical CPU cores (e.g., `'50%'`).

**Related topics:** Parallelism and Sharding

**Common patterns:**
```typescript
// Sequential in CI, parallel locally
workers: process.env.CI ? 1 : undefined

// 50% of CPU cores
workers: '50%'

// Fixed number
workers: 4
```

## Filtering Tests

Configure which test files to include or exclude using glob patterns or regular expressions.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Glob patterns or regular expressions to ignore test files
  testIgnore: '*test-assets',
  
  // Glob patterns or regular expressions that match test files
  testMatch: '*todo-tests/*.spec.ts',
});
```

### testConfig.testIgnore

**Purpose:** Glob patterns or regular expressions for files to ignore when looking for tests.

**Example:** `'*test-assets'` ignores all files/directories with "test-assets" in the name.

**Use case:** Exclude helper files, fixtures, or test data from being treated as test files.

### testConfig.testMatch

**Purpose:** Glob patterns or regular expressions that match test files.

**Default:** Playwright runs `.*(test|spec).(js|ts|mjs)` files by default.

**Example:** `'*todo-tests/*.spec.ts'` only runs spec files in directories ending with "todo-tests".

## Advanced Configuration

Additional configuration options for test execution and output.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Folder for test artifacts such as screenshots, videos, traces, etc.
  outputDir: 'test-results',
  
  // Path to the global setup file
  globalSetup: require.resolve('./global-setup'),
  
  // Path to the global teardown file
  globalTeardown: require.resolve('./global-teardown'),
  
  // Each test is given 30 seconds
  timeout: 30000,
});
```

### testConfig.globalSetup

**Purpose:** Path to the global setup file that runs before all tests.

**Requirements:** Must export a single function.

**Use case:** Database seeding, starting services, environment preparation.

**Example:**
```typescript
globalSetup: require.resolve('./global-setup')
```

### testConfig.globalTeardown

**Purpose:** Path to the global teardown file that runs after all tests.

**Requirements:** Must export a single function.

**Use case:** Cleanup operations, stopping services, database teardown.

**Example:**
```typescript
globalTeardown: require.resolve('./global-teardown')
```

### testConfig.outputDir

**Purpose:** Folder for test artifacts such as screenshots, videos, traces, etc.

**Default:** 'test-results'

**Example:**
```typescript
outputDir: 'test-results'
```

### testConfig.timeout

**Purpose:** Maximum time each test can run before timing out.

**Default:** 30 seconds (30000 milliseconds)

**Scope:** Includes time spent in test function, test fixtures, and beforeEach hooks.

**Example:**
```typescript
timeout: 30000  // 30 seconds
```

## Expect Options

Configuration for the expect assertion library, controlling assertion timeouts and visual comparison thresholds.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  expect: {
    // Maximum time expect() should wait for the condition to be met
    timeout: 5000,
    
    toHaveScreenshot: {
      // An acceptable amount of pixels that could be different, unset by default
      maxDiffPixels: 10,
    },
    
    toMatchSnapshot: {
      // An acceptable ratio of pixels that are different to the
      // total amount of pixels, between 0 and 1
      maxDiffPixelRatio: 0.1,
    },
  },
});
```

### testConfig.expect

**Purpose:** Configure web-first assertions like `expect(locator).toHaveText()`.

**Default timeout:** 5 seconds

**Scope:** This is separate from the test timeout and applies specifically to expect assertions.

**Related topic:** Test and expect timeouts documentation

### expect(page).toHaveScreenshot()

**Purpose:** Configuration for screenshot comparison assertions.

**Key option: maxDiffPixels** - Acceptable number of different pixels (absolute count).

**Use case:** Allow minor rendering differences while catching significant visual regressions.

**Example:**
```typescript
toHaveScreenshot: {
  maxDiffPixels: 10,
}
```

### expect(value).toMatchSnapshot()

**Purpose:** Configuration for snapshot comparison assertions.

**Key option: maxDiffPixelRatio** - Acceptable ratio of different pixels (between 0 and 1).

**Use case:** Percentage-based tolerance for visual differences, useful for responsive designs.

**Example:**
```typescript
toMatchSnapshot: {
  maxDiffPixelRatio: 0.1,  // 10% difference allowed
}
```

## Configuration Structure

### Top-Level vs Use Section

**Critical distinction:** Test runner options are top-level, while browser/context options go in the `use` section.

**Top-level options:**
- testDir
- fullyParallel
- forbidOnly
- retries
- workers
- reporter
- projects
- webServer
- timeout
- globalSetup
- globalTeardown
- outputDir
- testMatch
- testIgnore

**Use section options:**
- baseURL
- trace
- screenshot
- video
- viewport
- userAgent
- locale
- timezoneId
- permissions
- geolocation
- colorScheme
- and other browser context options

## Environment-Specific Configuration

Common pattern for different configurations in development vs CI:

```typescript
export default defineConfig({
  // CI-specific settings
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,  // Don't reuse in CI
  },
});
```

**Benefits:**
- Stricter checks in CI (forbidOnly)
- Retry flaky tests in CI only
- Sequential execution in CI for stability
- Fresh server in CI, reuse locally for speed

## Best Practices

1. **Use Environment Variables** - Configure different behavior for CI vs local development

2. **Enable forbidOnly in CI** - Prevent accidentally committed `.only()` tests

3. **Configure Retries for CI** - Add retries in CI to handle flaky tests, but not locally

4. **Adjust Workers Based on Environment** - Single worker in CI for stability, multiple workers locally

5. **Set Appropriate Timeouts** - Balance between catching hung tests and allowing legitimate slow operations

6. **Configure Visual Comparison Thresholds** - Set maxDiffPixels or maxDiffPixelRatio based on acceptable visual variance

7. **Use testIgnore for Non-Test Files** - Exclude helpers, fixtures, and utilities from test discovery

8. **Leverage Global Setup/Teardown** - Use for expensive one-time operations like database seeding

9. **Configure webServer for Integration Tests** - Automatically start your application for testing

10. **Organize with testDir** - Keep test files organized in dedicated directories

## Related Topics to Explore

- Parallelism strategies
- Sharding for distributed testing
- Test reporters and customization
- Test retries and flaky test handling
- Projects for multi-browser testing
- Global setup and teardown patterns
- Timeout configuration and management
- Web server integration
- Device emulation with projects
- Custom reporter development
