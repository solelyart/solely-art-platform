# Playwright Documentation Research - Videos

**Page:** Videos  
**URL:** https://playwright.dev/docs/videos  
**Research Date:** December 13, 2025

## Introduction

**Feature:** With Playwright you can record videos for your tests.

## Record Video

### Configuration

**Control:** Playwright Test can record videos for tests, controlled by `video` option in Playwright config.

**Default:** Videos are off by default.

### Video Modes

**1. 'off'** - Do not record video.

**2. 'on'** - Record video for each test.

**3. 'retain-on-failure'** - Record video for each test, but remove all videos from successful test runs.

**4. 'on-first-retry'** - Record video only when retrying a test for the first time.

### Video Output Location

**Location:** Video files appear in test output directory, typically `test-results`.

**Advanced configuration:** See `testOptions.video` for more options.

### Important Note

**Timing:** Videos are saved upon browser context closure at the end of test.

**Manual context:** If you create browser context manually, make sure to await `browserContext.close()`.

### Basic Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    video: 'on-first-retry',
  },
});
```

### Video Size Configuration

**Default size:** Video size defaults to viewport size scaled down to fit 800x800.

**Placement:** Video of viewport placed in top-left corner of output video, scaled down to fit if necessary.

**Note:** May need to set viewport size to match desired video size.

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    video: {
      mode: 'on-first-retry',
      size: { width: 640, height: 480 }
    }
  },
});
```

### Access Video Path

**For multi-page scenarios:** Access video file associated with page via `page.video()`.

```typescript
const path = await page.video().path();
```

**Important:** Video is only available after page or browser context is closed.

## Best Practices

### 1. Use 'retain-on-failure' for CI

**Recommended for CI/CD:**
```typescript
export default defineConfig({
  use: {
    video: 'retain-on-failure',
  },
});
```

**Benefit:** 
- Records all tests
- Only keeps videos of failed tests
- Saves storage space
- Provides debugging information for failures

### 2. Use 'on-first-retry' for Flaky Tests

**Recommended for flaky test debugging:**
```typescript
export default defineConfig({
  use: {
    video: 'on-first-retry',
  },
});
```

**Benefit:**
- Only records when test is retried
- Captures flaky behavior
- Minimal storage overhead

### 3. Use 'off' for Local Development

**Recommended for local testing:**
```typescript
export default defineConfig({
  use: {
    video: 'off',
  },
});
```

**Benefit:**
- Faster test execution
- No disk space used
- Use debugging tools instead

### 4. Configure Video Size for Performance

**Balance quality and file size:**
```typescript
export default defineConfig({
  use: {
    video: {
      mode: 'retain-on-failure',
      size: { width: 1280, height: 720 } // 720p
    }
  },
});
```

**Considerations:**
- Larger size = better quality, larger files
- Smaller size = faster processing, smaller files
- Match viewport size for best results

### 5. Access Video Path for Custom Processing

**Example: Upload to cloud storage**
```typescript
test.afterEach(async ({ page }, testInfo) => {
  if (testInfo.status !== testInfo.expectedStatus) {
    const video = page.video();
    if (video) {
      const path = await video.path();
      // Upload to S3, Azure, etc.
      await uploadToCloud(path);
    }
  }
});
```

## Common Use Cases

### Use Case 1: Debug Failed Tests in CI

**Configuration:**
```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    video: 'retain-on-failure',
  },
});
```

**Workflow:**
1. Tests run in CI
2. Videos recorded for all tests
3. Failed test videos retained
4. Successful test videos deleted
5. Review failed test videos to debug

### Use Case 2: Capture Flaky Test Behavior

**Configuration:**
```typescript
export default defineConfig({
  use: {
    video: 'on-first-retry',
  },
  retries: 2,
});
```

**Workflow:**
1. Test fails first time
2. Video recorded on retry
3. Compare behavior between runs
4. Identify flakiness cause

### Use Case 3: Generate Test Documentation

**Configuration:**
```typescript
export default defineConfig({
  use: {
    video: 'on',
  },
});
```

**Use case:**
- Create demo videos
- Document user flows
- Training materials
- Product demos

### Use Case 4: Multi-Page Testing

**Example:**
```typescript
test('multi-page scenario', async ({ page, context }) => {
  // Open first page
  await page.goto('/page1');
  
  // Open second page
  const page2 = await context.newPage();
  await page2.goto('/page2');
  
  // Get video paths
  const video1Path = await page.video()?.path();
  const video2Path = await page2.video()?.path();
  
  await context.close(); // Videos saved here
});
```

### Use Case 5: Custom Video Processing

**Example: Attach to test report**
```typescript
import { test } from '@playwright/test';

test.afterEach(async ({ page }, testInfo) => {
  const video = page.video();
  if (video) {
    const path = await video.path();
    await testInfo.attach('video', { 
      path, 
      contentType: 'video/webm' 
    });
  }
});
```

## Use Cases for Solely Art Platform

### Example 1: Debug Booking Flow Failures

```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    video: 'retain-on-failure',
  },
});

test('complete booking flow', async ({ page }) => {
  await page.goto('/artist/123');
  await page.getByRole('button', { name: 'Book Now' }).click();
  await page.getByLabel('Date').fill('2025-01-15');
  await page.getByRole('button', { name: 'Confirm' }).click();
  
  // If this fails, video will be retained
  await expect(page.getByText('Booking confirmed')).toBeVisible();
});
```

### Example 2: Capture Payment Integration Issues

```typescript
export default defineConfig({
  projects: [
    {
      name: 'payment-tests',
      use: {
        video: 'on', // Always record payment tests
      },
    },
  ],
});

test('payment flow', async ({ page }) => {
  await page.goto('/checkout');
  // ... payment steps
  // Video always recorded for audit trail
});
```

### Example 3: Document User Flows

```typescript
test('create demo video', async ({ page }) => {
  // Configure for high quality
  await page.setViewportSize({ width: 1920, height: 1080 });
  
  await page.goto('/');
  await page.getByRole('link', { name: 'Browse Artists' }).click();
  await page.getByRole('button', { name: 'Filter' }).click();
  // ... complete user flow
  
  // Video path available after context closes
});
```

### Example 4: Debug Real-Time Messaging

```typescript
test('messaging system', async ({ page }) => {
  await page.goto('/messages');
  
  // Send message
  await page.getByRole('textbox').fill('Hello');
  await page.getByRole('button', { name: 'Send' }).click();
  
  // Wait for response
  await expect(page.getByText('Message sent')).toBeVisible();
  
  // Video captures WebSocket interactions
});
```

### Example 5: Multi-Page Artist Comparison

```typescript
test('compare artists', async ({ page, context }) => {
  // Open first artist
  await page.goto('/artist/123');
  
  // Open second artist in new page
  const page2 = await context.newPage();
  await page2.goto('/artist/456');
  
  // Both pages recorded in separate videos
  
  await context.close();
  
  // Access both video paths
  const video1 = await page.video()?.path();
  const video2 = await page2.video()?.path();
});
```

## Advanced Patterns

### Pattern 1: Environment-Specific Configuration

```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    video: process.env.CI ? 'retain-on-failure' : 'off',
  },
});
```

**Benefit:** Videos only in CI, not locally.

### Pattern 2: Project-Specific Video Settings

```typescript
export default defineConfig({
  projects: [
    {
      name: 'critical-tests',
      use: {
        video: 'on', // Always record critical tests
      },
    },
    {
      name: 'regression-tests',
      use: {
        video: 'retain-on-failure', // Only failures
      },
    },
    {
      name: 'smoke-tests',
      use: {
        video: 'off', // No videos for smoke tests
      },
    },
  ],
});
```

### Pattern 3: Custom Video Storage

```typescript
test.afterEach(async ({ page }, testInfo) => {
  const video = page.video();
  if (video) {
    await page.context().close(); // Ensure video is saved
    
    const path = await video.path();
    const timestamp = Date.now();
    const newPath = `videos/${testInfo.title}-${timestamp}.webm`;
    
    // Move to custom location
    await fs.rename(path, newPath);
  }
});
```

### Pattern 4: Video with Custom Viewport

```typescript
test.use({
  viewport: { width: 1280, height: 720 },
  video: {
    mode: 'on',
    size: { width: 1280, height: 720 }
  }
});

test('full HD video', async ({ page }) => {
  await page.goto('/');
  // Video matches viewport exactly
});
```

### Pattern 5: Conditional Video Recording

```typescript
test('conditional video', async ({ page }, testInfo) => {
  // Start recording only if needed
  if (testInfo.retry > 0) {
    // Already retrying, video will be recorded
  }
  
  await page.goto('/');
  // ... test steps
});
```

## Configuration Options

### Video Mode Options

**'off'** - No recording
```typescript
video: 'off'
```

**'on'** - Always record
```typescript
video: 'on'
```

**'retain-on-failure'** - Keep only failures
```typescript
video: 'retain-on-failure'
```

**'on-first-retry'** - Record on retry
```typescript
video: 'on-first-retry'
```

### Advanced Configuration

**Full configuration object:**
```typescript
video: {
  mode: 'retain-on-failure',
  size: { width: 1280, height: 720 }
}
```

## Performance Considerations

### Storage Impact

**'on' mode:**
- Records all tests
- Large storage requirement
- Slow in CI

**'retain-on-failure' mode:**
- Records all, deletes successes
- Moderate storage
- Good for CI

**'on-first-retry' mode:**
- Records only retries
- Minimal storage
- Best for flaky tests

**'off' mode:**
- No storage
- Fastest
- No debugging aid

### Processing Time

**Video recording adds overhead:**
- CPU for encoding
- Disk I/O for writing
- Memory for buffering

**Recommendation:** Use 'off' locally, 'retain-on-failure' in CI.

## Troubleshooting

### Video Not Created

**Issue:** Video file not found.

**Solution:** Ensure browser context is closed.
```typescript
await page.context().close();
```

### Video Path Returns Null

**Issue:** `page.video()` returns null.

**Cause:** Video recording not enabled in config.

**Solution:** Enable video in config.

### Video Size Too Large

**Issue:** Video files too big.

**Solution:** Reduce video size.
```typescript
video: {
  mode: 'retain-on-failure',
  size: { width: 640, height: 480 }
}
```

### Video Quality Poor

**Issue:** Video hard to read.

**Solution:** Increase video size.
```typescript
video: {
  mode: 'on',
  size: { width: 1920, height: 1080 }
}
```

## Summary

### Key Concepts

**1. Video recording:** Controlled by `video` option in config

**2. Four modes:** 'off', 'on', 'retain-on-failure', 'on-first-retry'

**3. Output location:** `test-results` directory

**4. Timing:** Videos saved when browser context closes

**5. Video size:** Configurable, defaults to viewport scaled to 800x800

### Best Practices

1. Use 'retain-on-failure' in CI
2. Use 'on-first-retry' for flaky tests
3. Use 'off' for local development
4. Configure video size for performance
5. Access video path for custom processing

### Common Use Cases

1. Debug failed tests in CI
2. Capture flaky test behavior
3. Generate test documentation
4. Multi-page testing
5. Custom video processing

### Configuration

- Global: In `playwright.config.ts` under `use.video`
- Project-specific: In project config
- Environment-specific: Using environment variables

## Related Topics

- Test configuration
- Browser contexts
- Test reporters
- Debugging
- CI/CD integration
- Test artifacts
- Screenshots
- Trace viewer
