# Playwright Documentation Research - Evaluating JavaScript

**Page:** Evaluating JavaScript  
**URL:** https://playwright.dev/docs/evaluating  
**Research Date:** December 14, 2025

## Introduction

**Key concept:** Playwright scripts run in your **Playwright environment**. Your page scripts run in the **browser page environment**.

**Separation:** Those environments don't intersect - they are running in:
- Different virtual machines
- Different processes
- Even potentially on different computers

### page.evaluate() API

**Purpose:** Can run JavaScript function in context of web page and bring results back to Playwright environment.

**Browser globals:** Like `window` and `document` can be used in `evaluate`.

**Basic example:**
```typescript
const href = await page.evaluate(() => document.location.href);
```

### Async Support

**If result is Promise** or if function is asynchronous, `evaluate` will automatically wait until it's resolved:

```typescript
const status = await page.evaluate(async () => {
  const response = await fetch(location.href);
  return response.status;
});
```

## Different Environments

**Critical concept:** Evaluated scripts run in **browser environment**, while your test runs in **testing environment**.

**Implication:** You cannot use variables from your test in the page and vice versa.

**Solution:** Pass them explicitly as an argument.

### Wrong Approach

**❌ WRONG** - Uses variable directly:
```typescript
const data = 'some data';
const result = await page.evaluate(() => {
  // WRONG: there is no "data" in the web page.
  window.myApp.use(data);
});
```

### Correct Approach

**✅ CORRECT** - Passes value explicitly as argument:
```typescript
const data = 'some data';
// Pass |data| as a parameter.
const result = await page.evaluate(data => {
  window.myApp.use(data);
}, data);
```

## Evaluation Argument

**Capability:** Playwright evaluation methods like `page.evaluate()` take single optional argument.

**Argument types:** Can be mix of:
- **Serializable** values
- **JSHandle** instances

**Auto-conversion:** Handles are automatically converted to value they represent.

### Primitive Value

```typescript
await page.evaluate(num => num, 42);
```

### Array

```typescript
await page.evaluate(array => array.length, [1, 2, 3]);
```

### Object

```typescript
await page.evaluate(object => object.foo, { foo: 'bar' });
```

### Single Handle

```typescript
const button = await page.evaluateHandle('window.button');
await page.evaluate(button => button.textContent, button);
```

### Alternative Notation with JSHandle.evaluate

```typescript
await button.evaluate((button, from) => button.textContent.substring(from), 5);
```

### Object with Multiple Handles

```typescript
const button1 = await page.evaluateHandle('window.button1');
const button2 = await page.evaluateHandle('window.button2');
await page.evaluate(
    o => o.button1.textContent + o.button2.textContent,
    { button1, button2 });
```

### Object Destructuring

**Note:** Property names must match between destructured object and argument. Also note required parenthesis.

```typescript
await page.evaluate(
    ({ button1, button2 }) => button1.textContent + button2.textContent,
    { button1, button2 });
```

### Array Destructuring

**Note:** Arbitrary names can be used for destructuring. Note required parenthesis.

```typescript
await page.evaluate(
    ([b1, b2]) => b1.textContent + b2.textContent,
    [button1, button2]);
```

### Mixed Serializables and Handles

```typescript
await page.evaluate(
    x => x.button1.textContent + x.list[0].textContent + String(x.foo),
    { button1, list: [button2], foo: null });
```

## Init Scripts

**Use case:** Sometimes convenient to evaluate something in page **before it starts loading**.

**Examples:**
- Setup mocks
- Setup test data

**Methods:**
- `page.addInitScript()`
- `browserContext.addInitScript()`

### Init Script from File

**Example:** Replace `Math.random()` with constant value.

**Step 1:** Create `preload.js` file:
```javascript
// preload.js
Math.random = () => 42;
```

**Step 2:** Add init script to page:
```typescript
import { test, expect } from '@playwright/test';
import path from 'path';

test.beforeEach(async ({ page }) => {
  // Add script for every test in the beforeEach hook.
  // Make sure to correctly resolve the script path.
  await page.addInitScript({ path: path.resolve(__dirname, '../mocks/preload.js') });
});
```

### Init Script from Function

**Alternative:** Pass function instead of creating preload script file.

**Benefit:** More convenient for short or one-off scripts. Can also pass argument this way.

```typescript
import { test, expect } from '@playwright/test';

// Add script for every test in the beforeEach hook.
test.beforeEach(async ({ page }) => {
  const value = 42;
  await page.addInitScript(value => {
    Math.random = () => value;
  }, value);
});
```

## Best Practices

### 1. Pass Variables as Arguments

**✅ Good:**
```typescript
const userId = 123;
const result = await page.evaluate(id => {
  return window.getUserData(id);
}, userId);
```

**❌ Bad:**
```typescript
const userId = 123;
const result = await page.evaluate(() => {
  return window.getUserData(userId); // userId not available in browser
});
```

### 2. Use Async/Await in Evaluate

**✅ Good:**
```typescript
const data = await page.evaluate(async () => {
  const response = await fetch('/api/data');
  return response.json();
});
```

### 3. Return Serializable Values

**✅ Good:**
```typescript
const data = await page.evaluate(() => {
  return { name: 'John', age: 30 }; // Serializable
});
```

**❌ Bad:**
```typescript
const element = await page.evaluate(() => {
  return document.querySelector('button'); // DOM element not serializable
});
```

**Solution:** Use `evaluateHandle()` for non-serializable values:
```typescript
const elementHandle = await page.evaluateHandle(() => {
  return document.querySelector('button');
});
```

### 4. Use Init Scripts for Global Mocks

**✅ Good:**
```typescript
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    window.mockData = { users: [] };
  });
});
```

### 5. Keep Evaluate Functions Simple

**✅ Good:**
```typescript
const count = await page.evaluate(() => {
  return document.querySelectorAll('.item').length;
});
```

**❌ Bad:**
```typescript
const result = await page.evaluate(() => {
  // Complex logic that should be in test
  const items = document.querySelectorAll('.item');
  const filtered = Array.from(items).filter(item => item.textContent.includes('test'));
  return filtered.length;
});
```

## Common Use Cases

### Use Case 1: Get Page Data

```typescript
test('get page data', async ({ page }) => {
  await page.goto('/');
  
  const title = await page.evaluate(() => document.title);
  const url = await page.evaluate(() => document.location.href);
  
  expect(title).toBe('Home Page');
  expect(url).toContain('localhost');
});
```

### Use Case 2: Execute JavaScript in Page

```typescript
test('execute JavaScript', async ({ page }) => {
  await page.goto('/');
  
  await page.evaluate(() => {
    localStorage.setItem('theme', 'dark');
  });
  
  const theme = await page.evaluate(() => {
    return localStorage.getItem('theme');
  });
  
  expect(theme).toBe('dark');
});
```

### Use Case 3: Fetch Data from API

```typescript
test('fetch data from API', async ({ page }) => {
  await page.goto('/');
  
  const data = await page.evaluate(async () => {
    const response = await fetch('/api/users');
    return response.json();
  });
  
  expect(data.users).toBeDefined();
  expect(data.users.length).toBeGreaterThan(0);
});
```

### Use Case 4: Manipulate DOM

```typescript
test('manipulate DOM', async ({ page }) => {
  await page.goto('/');
  
  await page.evaluate(() => {
    const div = document.createElement('div');
    div.id = 'test-element';
    div.textContent = 'Test Content';
    document.body.appendChild(div);
  });
  
  await expect(page.locator('#test-element')).toHaveText('Test Content');
});
```

### Use Case 5: Get Element Properties

```typescript
test('get element properties', async ({ page }) => {
  await page.goto('/');
  
  const button = page.locator('button');
  
  const text = await button.evaluate(el => el.textContent);
  const className = await button.evaluate(el => el.className);
  const disabled = await button.evaluate(el => el.disabled);
  
  expect(text).toBe('Click me');
  expect(className).toContain('btn');
  expect(disabled).toBe(false);
});
```

### Use Case 6: Mock Math.random()

```typescript
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    Math.random = () => 0.5;
  });
});

test('use mocked Math.random', async ({ page }) => {
  await page.goto('/');
  
  const randomValue = await page.evaluate(() => Math.random());
  
  expect(randomValue).toBe(0.5);
});
```

## Use Cases for Solely Art Platform

### Example 1: Get Booking Data from Page

```typescript
test('get booking data', async ({ page }) => {
  await page.goto('/booking/123');
  
  const bookingData = await page.evaluate(() => {
    return {
      artistName: document.querySelector('.artist-name')?.textContent,
      eventDate: document.querySelector('.event-date')?.textContent,
      totalPrice: document.querySelector('.total-price')?.textContent,
    };
  });
  
  expect(bookingData.artistName).toBe('John Doe');
  expect(bookingData.eventDate).toContain('2025-01-15');
  expect(bookingData.totalPrice).toContain('$500');
});
```

### Example 2: Set Artist Availability in LocalStorage

```typescript
test('set artist availability', async ({ page }) => {
  await page.goto('/artist/123');
  
  await page.evaluate(() => {
    const availability = {
      dates: ['2025-01-15', '2025-01-16', '2025-01-17'],
      timeSlots: ['morning', 'afternoon', 'evening'],
    };
    localStorage.setItem('artistAvailability', JSON.stringify(availability));
  });
  
  // Reload to apply availability
  await page.reload();
  
  await expect(page.locator('.available-date')).toHaveCount(3);
});
```

### Example 3: Fetch Artist Data from API

```typescript
test('fetch artist data', async ({ page }) => {
  await page.goto('/artist/123');
  
  const artistData = await page.evaluate(async () => {
    const response = await fetch('/api/artists/123');
    return response.json();
  });
  
  expect(artistData.id).toBe(123);
  expect(artistData.name).toBe('John Doe');
  expect(artistData.category).toBe('Music');
  expect(artistData.rating).toBeGreaterThan(4);
});
```

### Example 4: Manipulate Booking Calendar

```typescript
test('manipulate booking calendar', async ({ page }) => {
  await page.goto('/artist/123/book');
  
  await page.evaluate(() => {
    // Highlight available dates
    const availableDates = document.querySelectorAll('.calendar-date.available');
    availableDates.forEach(date => {
      date.style.backgroundColor = 'green';
    });
  });
  
  // Verify highlighting
  const greenDates = await page.evaluate(() => {
    return document.querySelectorAll('.calendar-date[style*="green"]').length;
  });
  
  expect(greenDates).toBeGreaterThan(0);
});
```

### Example 5: Get Message Count

```typescript
test('get unread message count', async ({ page }) => {
  await page.goto('/messages');
  
  const unreadCount = await page.evaluate(() => {
    const badge = document.querySelector('.unread-badge');
    return badge ? parseInt(badge.textContent || '0') : 0;
  });
  
  expect(unreadCount).toBeGreaterThanOrEqual(0);
});
```

### Example 6: Mock Payment Gateway

```typescript
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    // Mock Stripe
    window.Stripe = () => ({
      elements: () => ({
        create: () => ({
          mount: () => {},
          on: () => {},
        }),
      }),
      createPaymentMethod: async () => ({
        paymentMethod: { id: 'pm_test_123' },
      }),
    });
  });
});

test('use mocked Stripe', async ({ page }) => {
  await page.goto('/checkout');
  
  const stripeLoaded = await page.evaluate(() => {
    return typeof window.Stripe === 'function';
  });
  
  expect(stripeLoaded).toBe(true);
});
```

### Example 7: Get Search Results Count

```typescript
test('get search results count', async ({ page }) => {
  await page.goto('/search?q=artist');
  
  const resultsCount = await page.evaluate(() => {
    return document.querySelectorAll('.search-result').length;
  });
  
  expect(resultsCount).toBeGreaterThan(0);
});
```

### Example 8: Set Mock User Session

```typescript
test('set mock user session', async ({ page }) => {
  await page.addInitScript(() => {
    const mockUser = {
      id: 123,
      name: 'Test User',
      email: 'test@example.com',
      role: 'artist',
    };
    localStorage.setItem('user', JSON.stringify(mockUser));
    localStorage.setItem('authToken', 'mock_token_123');
  });
  
  await page.goto('/dashboard');
  
  const userName = await page.evaluate(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user.name;
  });
  
  expect(userName).toBe('Test User');
});
```

## Advanced Patterns

### Pattern 1: Pass Complex Objects

```typescript
test('pass complex object', async ({ page }) => {
  await page.goto('/');
  
  const config = {
    theme: 'dark',
    language: 'en',
    features: ['chat', 'booking', 'payment'],
  };
  
  const result = await page.evaluate(cfg => {
    window.appConfig = cfg;
    return cfg.features.length;
  }, config);
  
  expect(result).toBe(3);
});
```

### Pattern 2: Use Element Handle

```typescript
test('use element handle', async ({ page }) => {
  await page.goto('/');
  
  const button = page.locator('button');
  const text = await button.evaluate(el => el.textContent);
  
  expect(text).toBe('Click me');
});
```

### Pattern 3: Multiple Handles

```typescript
test('use multiple handles', async ({ page }) => {
  await page.goto('/');
  
  const title = page.locator('h1');
  const subtitle = page.locator('h2');
  
  const combined = await page.evaluate(
    ({ titleEl, subtitleEl }) => {
      return titleEl.textContent + ' - ' + subtitleEl.textContent;
    },
    { titleEl: await title.elementHandle(), subtitleEl: await subtitle.elementHandle() }
  );
  
  expect(combined).toContain(' - ');
});
```

### Pattern 4: Evaluate on Locator

```typescript
test('evaluate on locator', async ({ page }) => {
  await page.goto('/');
  
  const items = page.locator('.item');
  
  const texts = await items.evaluateAll(elements => {
    return elements.map(el => el.textContent);
  });
  
  expect(texts.length).toBeGreaterThan(0);
});
```

### Pattern 5: Init Script with Path

```typescript
test.beforeEach(async ({ page }) => {
  await page.addInitScript({ 
    path: path.resolve(__dirname, './mocks/analytics.js') 
  });
});
```

### Pattern 6: Context-Wide Init Script

```typescript
test.beforeEach(async ({ context }) => {
  await context.addInitScript(() => {
    window.mockAnalytics = {
      track: () => console.log('Analytics tracked'),
    };
  });
});
```

### Pattern 7: Return Promise from Evaluate

```typescript
test('return promise from evaluate', async ({ page }) => {
  await page.goto('/');
  
  const data = await page.evaluate(async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return { loaded: true };
  });
  
  expect(data.loaded).toBe(true);
});
```

## Evaluation Methods

### page.evaluate(pageFunction, arg)

**Purpose:** Execute function in page context and return result.

```typescript
const result = await page.evaluate(() => document.title);
```

### page.evaluateHandle(pageFunction, arg)

**Purpose:** Execute function in page context and return JSHandle.

```typescript
const handle = await page.evaluateHandle(() => document.body);
```

### locator.evaluate(pageFunction, arg)

**Purpose:** Execute function on element.

```typescript
const text = await page.locator('button').evaluate(el => el.textContent);
```

### locator.evaluateAll(pageFunction, arg)

**Purpose:** Execute function on all matching elements.

```typescript
const texts = await page.locator('.item').evaluateAll(els => 
  els.map(el => el.textContent)
);
```

### page.addInitScript(script, arg)

**Purpose:** Add script to execute before page loads.

```typescript
await page.addInitScript(() => {
  window.mockData = [];
});
```

### browserContext.addInitScript(script, arg)

**Purpose:** Add script to all pages in context.

```typescript
await context.addInitScript(() => {
  window.mockData = [];
});
```

## Troubleshooting

### Issue: Variable Not Available in Page

**Cause:** Trying to use test variable directly in evaluate.

**Solution:** Pass variable as argument.

```typescript
// ✅ Correct
const userId = 123;
await page.evaluate(id => window.setUser(id), userId);

// ❌ Wrong
const userId = 123;
await page.evaluate(() => window.setUser(userId)); // userId not available
```

### Issue: Cannot Return DOM Element

**Cause:** DOM elements are not serializable.

**Solution:** Use `evaluateHandle()` or return serializable data.

```typescript
// ✅ Correct - Use evaluateHandle
const handle = await page.evaluateHandle(() => document.body);

// ✅ Correct - Return serializable data
const data = await page.evaluate(() => ({
  tagName: document.body.tagName,
  className: document.body.className,
}));

// ❌ Wrong
const element = await page.evaluate(() => document.body); // Error
```

### Issue: Async Function Not Awaited

**Cause:** Forgetting to use async/await in evaluate.

**Solution:** Use async/await properly.

```typescript
// ✅ Correct
const data = await page.evaluate(async () => {
  const response = await fetch('/api/data');
  return response.json();
});

// ❌ Wrong
const data = await page.evaluate(() => {
  const response = fetch('/api/data'); // Returns Promise, not data
  return response.json(); // Error
});
```

### Issue: Init Script Not Working

**Cause:** Init script added after page loaded.

**Solution:** Add init script before navigation.

```typescript
// ✅ Correct
await page.addInitScript(() => window.mockData = []);
await page.goto('/');

// ❌ Wrong
await page.goto('/');
await page.addInitScript(() => window.mockData = []); // Too late
```

## Summary

### Key Concepts

**1. Different environments:** Playwright runs in test environment, evaluated code runs in browser

**2. Pass variables as arguments:** Cannot use test variables directly in evaluate

**3. Serializable values:** Return values must be serializable (or use evaluateHandle)

**4. Async support:** Evaluate automatically waits for Promises

**5. Init scripts:** Run code before page loads

### Evaluation Methods

- `page.evaluate(fn, arg)` - Execute function in page, return result
- `page.evaluateHandle(fn, arg)` - Execute function, return JSHandle
- `locator.evaluate(fn, arg)` - Execute on element
- `locator.evaluateAll(fn, arg)` - Execute on all elements
- `page.addInitScript(script, arg)` - Add init script
- `browserContext.addInitScript(script, arg)` - Add context-wide init script

### Best Practices

1. Pass variables as arguments
2. Use async/await for async operations
3. Return serializable values
4. Use init scripts for global mocks
5. Keep evaluate functions simple
6. Use evaluateHandle for non-serializable values

### Common Patterns

- Get page data
- Execute JavaScript in page
- Fetch data from API
- Manipulate DOM
- Get element properties
- Mock global functions

## Related Topics

- Handles
- Locators
- Pages
- Browser contexts
- Mocking
- Testing
- Serialization
