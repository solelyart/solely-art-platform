# Playwright Documentation Research - Running and Debugging Tests

**Page:** Running and debugging tests  
**URL:** https://playwright.dev/docs/running-tests  
**Research Date:** December 13, 2025

## Overview

Playwright provides flexible options for running and debugging tests. Tests can run as a single test, a set of tests, or all tests. They execute in parallel by default and in headless mode, with results displayed in the terminal.

## Test Execution Modes

### Default Execution
- Tests run in **parallel** by default
- Tests run in **headless mode** (no browser window visible)
- Results appear in the terminal
- Configured browsers run based on `playwright.config` file

### Headed Mode
Use the `--headed` flag to see the browser window and visually observe Playwright's interactions:

```bash
npx playwright test --headed
```

### UI Mode (Recommended)
The highly recommended mode for development, providing visual step-through debugging:

```bash
npx playwright test --ui
```

**UI Mode Features:**
- Walk through each step of the test visually
- See what happened before, during, and after each step
- Locator picker tool
- Watch mode
- Full trace visualization

## Command Line Options

### Basic Test Execution

```bash
# Run all tests
npx playwright test

# Run in UI mode (recommended)
npx playwright test --ui

# Run in headed mode
npx playwright test --headed
```

### Browser Selection

```bash
# Run on specific browser
npx playwright test --project webkit

# Run on multiple browsers
npx playwright test --project webkit --project firefox
```

### File and Test Filtering

```bash
# Run single test file
npx playwright test landing-page.spec.ts

# Run multiple directories
npx playwright test tests/todo-page/ tests/landing-page/

# Run files matching keywords
npx playwright test landing login

# Run test by title
npx playwright test -g "add a todo item"

# Run only failed tests from last run
npx playwright test --last-failed
```

## Debugging Approaches

Playwright offers multiple debugging methods to suit different workflows and preferences.

### 1. UI Mode Debugging (Recommended)

```bash
npx playwright test --ui
```

**Features:**
- Visual step-through of each test action
- View logs and errors
- Inspect network requests
- Examine DOM snapshots
- Pick Locator tool for element selection
- Edit locators with live highlighting
- Copy locators to clipboard
- Watch mode for continuous testing

### 2. Playwright Inspector

```bash
# Debug all tests
npx playwright test --debug

# Debug specific file
npx playwright test example.spec.ts --debug

# Debug from specific line number
npx playwright test example.spec.ts:10 --debug
```

**Inspector Features:**
- Opens browser window alongside Inspector
- Step over button to advance through test steps
- Play button to run test from start to finish
- Pick Locator button for element selection
- Edit locators with live highlighting in browser
- Copy Locator button for clipboard export
- Browser window closes automatically when test finishes

### 3. VS Code Extension

Tests can be run directly from VS Code:
- Click the green triangle next to individual tests
- Run all tests from the testing sidebar
- Integrated debugging experience
- Full IDE integration

### 4. Traditional Node.js Debugging

Since Playwright runs in Node.js, standard debugging approaches work:
- `console.log` statements
- IDE debugger integration
- VS Code debugger
- Any Node.js-compatible debugger

## Locator Debugging

Both UI Mode and Playwright Inspector include locator debugging tools:

1. **Pick Locator Button** - Click to select elements on the page
2. **Locator Display** - Shows the locator Playwright would use
3. **Locator Editor** - Edit and refine locators
4. **Live Highlighting** - See locator matches highlighted in real-time
5. **Copy Locator** - Copy finalized locator to clipboard

## HTML Test Reporter

The HTML Reporter provides comprehensive test result analysis:

```bash
npx playwright show-report
```

**Features:**
- Full report of all tests
- Filter by browsers
- Filter by test status (passed, failed, skipped, flaky)
- Search functionality
- Click individual tests to see errors
- Explore each step of the test
- Automatic opening when tests fail (configurable)

**Report Capabilities:**
- Visual representation of test results
- Detailed error messages
- Step-by-step test execution view
- Browser-specific results
- Test duration metrics

## Best Practices Identified

1. **Use UI Mode for Development** - Provides the best developer experience with visual debugging
2. **Run in Headless for CI** - Faster execution and resource efficiency in automated pipelines
3. **Use --last-failed for Quick Iteration** - Focus on fixing failures without re-running passing tests
4. **Leverage Locator Picker** - Learn and verify locator strategies interactively
5. **Filter Tests Strategically** - Use file names, keywords, or titles to run relevant test subsets
6. **Debug from Specific Lines** - Jump directly to problematic tests using line numbers
7. **Use VS Code Extension** - Integrate testing into your development workflow

## Execution Characteristics

### Parallelization
- Tests run in parallel by default
- Improves overall test suite execution time
- Each test gets isolated browser context
- Configurable in playwright.config file

### Headless vs Headed
- **Headless** (default): No browser UI, faster, less resource-intensive
- **Headed**: Shows browser window, useful for debugging and development
- **UI Mode**: Enhanced headed mode with debugging tools

### Browser Configuration
- Multiple browsers can be configured in playwright.config
- Use `--project` flag to run specific browsers
- Can run same tests across multiple browsers in single command

## Integration Points

### VS Code Integration
- Native extension available
- Run tests from editor
- Visual test results
- Integrated debugging
- No command line required

### CI/CD Integration
- Headless mode ideal for CI pipelines
- Terminal output for logs
- Multiple reporter formats
- Parallel execution for speed

## Related Topics to Explore

- UI Mode detailed features
- Playwright Inspector capabilities
- VS Code extension setup
- HTML Reporter configuration
- Debugging guide
- Browser Developer tools integration
- Test configuration options
- Parallel execution settings
- Reporter customization
