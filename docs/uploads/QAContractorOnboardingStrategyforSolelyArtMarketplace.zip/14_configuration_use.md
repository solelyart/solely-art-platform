# Playwright Documentation Research - Configuration (use)

**Page:** Configuration (use)  
**URL:** https://playwright.dev/docs/test-use-options  
**Research Date:** December 13, 2025

## Overview

In addition to configuring the test runner, Playwright allows configuration of Emulation, Network, and Recording options for the Browser or BrowserContext. These options are passed to the `use: {}` object in the Playwright config file.

**Key distinction:** The `use` section is specifically for browser and context options, while test runner options are top-level in the config.

## Basic Options

Fundamental options for test execution and authentication.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // Base URL to use in actions like `await page.goto('/')`.
    baseURL: 'http://localhost:3000',
    
    // Populates context with given storage state.
    storageState: 'state.json',
  },
});
```

### testOptions.baseURL

**Purpose:** Base URL used for all pages in the context.

**Benefit:** Allows navigating by using just the path instead of full URLs.

**Example usage:**
```typescript
// With baseURL set to 'http://localhost:3000'
await page.goto('/settings');  // Navigates to http://localhost:3000/settings
await page.goto('/profile');   // Navigates to http://localhost:3000/profile
```

**Use cases:**
- Simplify test code by removing repeated URL prefixes
- Easy switching between environments (dev, staging, production)
- Cleaner test maintenance

### testOptions.storageState

**Purpose:** Populates context with given storage state.

**Primary use case:** Easy authentication by reusing login state across tests.

**How it works:**
1. Perform login once and save storage state
2. Load storage state in subsequent tests
3. Skip login steps, start tests already authenticated

**Benefits:**
- Faster test execution (skip repeated logins)
- Reduced flakiness from authentication flows
- Better test isolation

## Emulation Options

Playwright can emulate real devices, locations, locales, and user preferences.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // Emulates `'prefers-colors-scheme'` media feature.
    colorScheme: 'dark',
    
    // Context geolocation.
    geolocation: { longitude: 12.492507, latitude: 41.889938 },
    
    // Emulates the user locale.
    locale: 'en-GB',
    
    // Grants specified permissions to the browser context.
    permissions: ['geolocation'],
    
    // Emulates the user timezone.
    timezoneId: 'Europe/Paris',
    
    // Viewport used for all pages in the context.
    viewport: { width: 1280, height: 720 },
  },
});
```

### testOptions.colorScheme

**Purpose:** Emulates `'prefers-colors-scheme'` media feature.

**Supported values:** `'light'` and `'dark'`

**Use case:** Test dark mode and light mode implementations.

**Example:**
```typescript
colorScheme: 'dark'  // Test dark mode
colorScheme: 'light' // Test light mode
```

### testOptions.geolocation

**Purpose:** Set context geolocation.

**Format:** Object with `longitude` and `latitude` properties.

**Use case:** Test location-based features without physical location changes.

**Example:**
```typescript
geolocation: { longitude: 12.492507, latitude: 41.889938 }  // Rome, Italy
```

**Note:** Requires `permissions: ['geolocation']` to be granted.

### testOptions.locale

**Purpose:** Emulates the user locale.

**Format:** Locale string (e.g., `en-GB`, `de-DE`, `fr-FR`)

**Use case:** Test internationalization and localization.

**Example:**
```typescript
locale: 'en-GB'  // British English
locale: 'de-DE'  // German
locale: 'ja-JP'  // Japanese
```

**Effects:**
- Date/time formatting
- Number formatting
- Currency display
- Language-specific content

### testOptions.permissions

**Purpose:** Grant specific permissions to all pages in the context.

**Format:** Array of permission strings.

**Common permissions:**
- `'geolocation'`
- `'notifications'`
- `'camera'`
- `'microphone'`
- `'clipboard-read'`
- `'clipboard-write'`

**Example:**
```typescript
permissions: ['geolocation', 'notifications']
```

### testOptions.timezoneId

**Purpose:** Changes the timezone of the context.

**Format:** IANA timezone identifier.

**Use case:** Test timezone-sensitive features.

**Examples:**
```typescript
timezoneId: 'Europe/Paris'
timezoneId: 'America/New_York'
timezoneId: 'Asia/Tokyo'
```

### testOptions.viewport

**Purpose:** Viewport size used for all pages in the context.

**Format:** Object with `width` and `height` properties.

**Use case:** Test responsive designs at specific screen sizes.

**Example:**
```typescript
viewport: { width: 1280, height: 720 }  // Desktop
viewport: { width: 375, height: 667 }   // Mobile (iPhone SE)
viewport: { width: 1920, height: 1080 } // Full HD
```

## Network Options

Configure networking behavior including downloads, headers, authentication, and proxies.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // Whether to automatically download all the attachments.
    acceptDownloads: false,
    
    // An object containing additional HTTP headers to be sent with every request.
    extraHTTPHeaders: {
      'X-My-Header': 'value',
    },
    
    // Credentials for HTTP authentication.
    httpCredentials: {
      username: 'user',
      password: 'pass',
    },
    
    // Whether to ignore HTTPS errors during navigation.
    ignoreHTTPSErrors: true,
    
    // Whether to emulate network being offline.
    offline: true,
    
    // Proxy settings used for all pages in the test.
    proxy: {
      server: 'http://myproxy.com:3128',
      bypass: 'localhost',
    },
  },
});
```

### testOptions.acceptDownloads

**Purpose:** Whether to automatically download all attachments.

**Default:** `true`

**Use case:** Control download behavior during tests.

**Related:** Working with downloads guide

### testOptions.extraHTTPHeaders

**Purpose:** Additional HTTP headers sent with every request.

**Format:** Object with header name-value pairs.

**Requirement:** All header values must be strings.

**Use cases:**
- Custom authentication headers
- API keys
- Tracking headers
- Feature flags

**Example:**
```typescript
extraHTTPHeaders: {
  'X-API-Key': 'abc123',
  'X-Custom-Header': 'value',
}
```

### testOptions.httpCredentials

**Purpose:** Credentials for HTTP authentication (Basic Auth).

**Format:** Object with `username` and `password`.

**Use case:** Test pages protected by HTTP Basic Authentication.

**Example:**
```typescript
httpCredentials: {
  username: 'admin',
  password: 'secret123',
}
```

### testOptions.ignoreHTTPSErrors

**Purpose:** Whether to ignore HTTPS errors during navigation.

**Default:** `false`

**Use case:** Test against development servers with self-signed certificates.

**Warning:** Should not be used in production testing.

### testOptions.offline

**Purpose:** Emulate network being offline.

**Use case:** Test offline functionality and error handling.

**Example:**
```typescript
offline: true  // All network requests will fail
```

### testOptions.proxy

**Purpose:** Proxy settings used for all pages in the test.

**Format:** Object with `server` and optional `bypass`.

**Use cases:**
- Route traffic through corporate proxy
- Test proxy handling
- Network monitoring

**Example:**
```typescript
proxy: {
  server: 'http://myproxy.com:3128',
  bypass: 'localhost,*.internal.com',
}
```

### Network Mocking Note

**Important:** You don't need to configure anything to mock network requests. Just define a custom Route that mocks the network for a browser context. See the network mocking guide for details.

## Recording Options

Configure screenshots, videos, and traces for debugging and documentation.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // Capture screenshot after each test failure.
    screenshot: 'only-on-failure',
    
    // Record trace only when retrying a test for the first time.
    trace: 'on-first-retry',
    
    // Record video only when retrying a test for the first time.
    video: 'on-first-retry'
  },
});
```

**Output location:** Trace files, screenshots, and videos appear in the test output directory, typically `test-results`.

### testOptions.screenshot

**Purpose:** Capture screenshots of your test.

**Options:**
- `'off'` - No screenshots
- `'on'` - Screenshot after each test
- `'only-on-failure'` - Screenshot only when test fails

**Use case:** Visual debugging and failure documentation.

**Recommendation:** Use `'only-on-failure'` to minimize storage while capturing failures.

### testOptions.trace

**Purpose:** Produce test traces for detailed execution analysis.

**Options:**
- `'off'` - No traces
- `'on'` - Trace for every test
- `'on-first-retry'` - Trace only on first retry
- `'retain-on-failure'` - Keep traces only for failed tests

**Use case:** Deep debugging with Trace Viewer.

**Recommendation:** Use `'on-first-retry'` to capture flaky test details without overhead.

### testOptions.video

**Purpose:** Record videos of test execution.

**Options:**
- `'off'` - No videos
- `'on'` - Video for every test
- `'on-first-retry'` - Video only on first retry
- `'retain-on-failure'` - Keep videos only for failed tests

**Use case:** Visual documentation and debugging.

**Recommendation:** Use `'on-first-retry'` or `'retain-on-failure'` to balance storage and debugging needs.

## Other Options

Additional configuration options for browser behavior and test execution.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // Maximum time each action such as `click()` can take. Defaults to 0 (no limit).
    actionTimeout: 0,
    
    // Name of the browser that runs tests. For example `chromium`, `firefox`, `webkit`.
    browserName: 'chromium',
    
    // Toggles bypassing Content-Security-Policy.
    bypassCSP: true,
    
    // Channel to use, for example "chrome", "chrome-beta", "msedge", "msedge-beta".
    channel: 'chrome',
    
    // Run browser in headless mode.
    headless: false,
    
    // Change the default data-testid attribute.
    testIdAttribute: 'pw-test-id',
  },
});
```

### testOptions.actionTimeout

**Purpose:** Timeout for each Playwright action in milliseconds.

**Default:** `0` (no timeout)

**Scope:** Applies to individual actions like `click()`, `fill()`, `type()`, etc.

**Use case:** Prevent individual actions from hanging indefinitely.

**Example:**
```typescript
actionTimeout: 10000  // 10 seconds per action
```

### testOptions.browserName

**Purpose:** Name of the browser that runs tests.

**Default:** `'chromium'`

**Options:** `'chromium'`, `'firefox'`, `'webkit'`

**Note:** Usually configured per project rather than globally.

### testOptions.bypassCSP

**Purpose:** Toggles bypassing Content-Security-Policy.

**Default:** `false`

**Use case:** Useful when CSP includes the production origin and blocks test scripts.

**Warning:** Use carefully as it changes browser security behavior.

### testOptions.channel

**Purpose:** Browser channel to use.

**Options:**
- `'chrome'` - Stable Chrome
- `'chrome-beta'` - Chrome Beta
- `'msedge'` - Stable Edge
- `'msedge-beta'` - Edge Beta

**Use case:** Test against specific browser versions or channels.

### testOptions.headless

**Purpose:** Whether to run the browser in headless mode.

**Default:** `true`

**Options:**
- `true` - No browser UI shown
- `false` - Browser window visible

**Use case:** Set to `false` for debugging, `true` for CI.

### testOptions.testIdAttribute

**Purpose:** Changes the default `data-testid` attribute used by Playwright locators.

**Default:** `'data-testid'`

**Use case:** Match your application's existing test ID convention.

**Example:**
```typescript
testIdAttribute: 'data-test-id'  // Use data-test-id instead
testIdAttribute: 'data-qa'       // Use data-qa instead
```

## More Browser and Context Options

Any options accepted by `browserType.launch()`, `browser.newContext()`, or `browserType.connect()` can be placed in `launchOptions`, `contextOptions`, or `connectOptions` respectively.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    launchOptions: {
      slowMo: 50,  // Slow down operations by 50ms
    },
  },
});
```

**Note:** Most common options like `headless` or `viewport` are available directly in the `use` section.

## Explicit Context Creation and Option Inheritance

When using the built-in `browser` fixture and calling `browser.newContext()`, the context inherits options from the config.

**Config:**
```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    userAgent: 'some custom ua',
    viewport: { width: 100, height: 100 },
  },
});
```

**Test:**
```typescript
test('should inherit use options on context when using built-in browser fixture', async ({
  browser,
}) => {
  const context = await browser.newContext();
  const page = await context.newPage();
  expect(await page.evaluate(() => navigator.userAgent)).toBe('some custom ua');
  expect(await page.evaluate(() => window.innerWidth)).toBe(100);
  await context.close();
});
```

**Key insight:** Options flow from config to explicitly created contexts.

## Configuration Scopes

Playwright options can be configured at three levels with increasing specificity:

1. **Global** - In the config file's `use` section
2. **Project** - In a specific project's `use` section
3. **Test/Describe** - Using `test.use()` in test files

### Global Configuration

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    locale: 'en-GB'
  },
});
```

**Scope:** Applies to all tests in all projects.

### Project Configuration

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        locale: 'de-DE',  // Override global locale for this project
      },
    },
  ],
});
```

**Scope:** Applies to all tests in this specific project.

### Test File Configuration

```typescript
import { test, expect } from '@playwright/test';

test.use({ locale: 'fr-FR' });

test('example', async ({ page }) => {
  // This test runs with French locale
});
```

**Scope:** Applies to all tests in this file.

### Describe Block Configuration

```typescript
import { test, expect } from '@playwright/test';

test.describe('french language block', () => {
  test.use({ locale: 'fr-FR' });
  
  test('example', async ({ page }) => {
    // This test runs with French locale
  });
});
```

**Scope:** Applies to all tests in this describe block.

## Reset an Option

You can reset an option to the value defined in the config file or completely unset it.

### Reset to Config Value

**Config:**
```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    baseURL: 'https://playwright.dev',
  },
});
```

**Test file:**
```typescript
import { test } from '@playwright/test';

// Configure baseURL for this file
test.use({ baseURL: 'https://playwright.dev/docs/intro' });

test('check intro contents', async ({ page }) => {
  // Uses "https://playwright.dev/docs/intro"
});

test.describe(() => {
  // Reset to config-defined value
  test.use({ baseURL: undefined });
  
  test('can navigate to intro from the home page', async ({ page }) => {
    // Uses "https://playwright.dev" from config
  });
});
```

### Completely Unset an Option

Use long-form fixture notation to completely unset a value:

```typescript
import { test } from '@playwright/test';

// Completely unset baseURL for this file
test.use({
  baseURL: [async ({}, use) => use(undefined), { scope: 'test' }],
});

test('no base url', async ({ page }) => {
  // This test will not have a base url
});
```

## Configuration Hierarchy

**Precedence (highest to lowest):**
1. Test-level `test.use()`
2. Describe-level `test.use()`
3. File-level `test.use()`
4. Project-level `use` in config
5. Global `use` in config

**Key principle:** More specific configurations override less specific ones.

## Best Practices

1. **Use baseURL for Environment Flexibility** - Easily switch between dev, staging, and production

2. **Leverage storageState for Authentication** - Save time and reduce flakiness by reusing login state

3. **Configure Recording Options Wisely** - Use `'on-first-retry'` or `'only-on-failure'` to balance debugging needs with storage

4. **Set Appropriate Emulation** - Test with realistic viewport, locale, and timezone settings

5. **Use Projects for Multi-Browser Testing** - Configure different browsers with appropriate options

6. **Configure actionTimeout** - Prevent individual actions from hanging indefinitely

7. **Use testIdAttribute Consistently** - Match your application's test ID convention

8. **Leverage Configuration Scopes** - Set defaults globally, override for specific projects or tests

9. **Reset Options When Needed** - Use `undefined` to reset to config values or completely unset

10. **Test Offline Scenarios** - Use `offline: true` to verify error handling

## Related Topics to Explore

- Emulation guide (devices, mobile, tablet)
- Authentication patterns
- Network mocking
- Trace Viewer usage
- Screenshot and video best practices
- Projects configuration
- Device emulation
- HTTP authentication
- Proxy configuration
- Custom fixtures
