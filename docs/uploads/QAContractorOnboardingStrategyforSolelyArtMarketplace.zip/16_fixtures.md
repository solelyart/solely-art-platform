# Playwright Documentation Research - Fixtures

**Page:** Fixtures  
**URL:** https://playwright.dev/docs/test-fixtures  
**Research Date:** December 13, 2025

## Overview

Playwright Test is based on the concept of **test fixtures**. Test fixtures are used to establish the environment for each test, giving the test everything it needs and nothing else. Test fixtures are isolated between tests, allowing you to group tests based on their meaning rather than their common setup.

## Built-in Fixtures

Playwright provides several pre-defined fixtures that are commonly used:

| Fixture | Type | Description |
|---------|------|-------------|
| `page` | Page | Isolated page for this test run |
| `context` | BrowserContext | Isolated context for this test run. The page fixture belongs to this context |
| `browser` | Browser | Browsers are shared across tests to optimize resources |
| `browserName` | string | The name of the browser currently running the test (chromium, firefox, or webkit) |
| `request` | APIRequestContext | Isolated APIRequestContext instance for this test run |

### Basic Usage

```typescript
import { test, expect } from '@playwright/test';

test('basic test', async ({ page }) => {
  await page.goto('https://playwright.dev/');
  await expect(page).toHaveTitle(/Playwright/);
});
```

The `{ page }` argument tells Playwright Test to set up the page fixture and provide it to your test function.

## Advantages of Fixtures Over Hooks

Fixtures provide significant advantages over traditional before/after hooks:

1. **Encapsulation** - Setup and teardown in the same place, easier to write and maintain
2. **Reusability** - Define once, use in all tests across multiple files
3. **On-demand** - Only fixtures needed by the test are set up
4. **Composable** - Fixtures can depend on each other for complex behaviors
5. **Flexible** - Tests can use any combination without affecting other tests
6. **Simplified grouping** - No need to wrap tests in describes for environment setup

## Without Fixtures (Traditional Approach)

**Using beforeEach/afterEach hooks:**

```typescript
const { test } = require('@playwright/test');
const { TodoPage } = require('./todo-page');

test.describe('todo tests', () => {
  let todoPage;
  
  test.beforeEach(async ({ page }) => {
    todoPage = new TodoPage(page);
    await todoPage.goto();
    await todoPage.addToDo('item1');
    await todoPage.addToDo('item2');
  });
  
  test.afterEach(async () => {
    await todoPage.removeAll();
  });
  
  test('should add an item', async () => {
    await todoPage.addToDo('my item');
    // ...
  });
  
  test('should remove an item', async () => {
    await todoPage.remove('item1');
    // ...
  });
});
```

**Problems:**
- Setup and teardown separated
- todoPage variable shared across tests
- Must use describe block for grouping
- Not reusable across files

## With Fixtures (Modern Approach)

**Using fixtures:**

```typescript
import { test as base } from '@playwright/test';
import { TodoPage } from './todo-page';

// Extend basic test by providing a "todoPage" fixture
const test = base.extend<{ todoPage: TodoPage }>({
  todoPage: async ({ page }, use) => {
    const todoPage = new TodoPage(page);
    await todoPage.goto();
    await todoPage.addToDo('item1');
    await todoPage.addToDo('item2');
    await use(todoPage);
    await todoPage.removeAll();
  },
});

test('should add an item', async ({ todoPage }) => {
  await todoPage.addToDo('my item');
  // ...
});

test('should remove an item', async ({ todoPage }) => {
  await todoPage.remove('item1');
  // ...
});
```

**Benefits:**
- Setup and teardown together
- Isolated per test
- No describe block needed
- Reusable across files
- Type-safe

## Creating a Fixture

Use `test.extend()` to create custom fixtures.

```typescript
import { test as base } from '@playwright/test';
import { TodoPage } from './todo-page';
import { SettingsPage } from './settings-page';

// Declare the types of your fixtures
type MyFixtures = {
  todoPage: TodoPage;
  settingsPage: SettingsPage;
};

// Extend base test by providing fixtures
export const test = base.extend<MyFixtures>({
  todoPage: async ({ page }, use) => {
    // Set up the fixture
    const todoPage = new TodoPage(page);
    await todoPage.goto();
    await todoPage.addToDo('item1');
    await todoPage.addToDo('item2');
    
    // Use the fixture value in the test
    await use(todoPage);
    
    // Clean up the fixture
    await todoPage.removeAll();
  },
  
  settingsPage: async ({ page }, use) => {
    await use(new SettingsPage(page));
  },
});

export { expect } from '@playwright/test';
```

**Naming rules:** Custom fixture names must start with a letter or underscore, and can contain only letters, numbers, and underscores.

## Using a Fixture

Simply mention the fixture in your test function argument:

```typescript
import { test, expect } from './my-test';

test.beforeEach(async ({ settingsPage }) => {
  await settingsPage.switchToDarkMode();
});

test('basic test', async ({ todoPage, page }) => {
  await todoPage.addToDo('something nice');
  await expect(page.getByTestId('todo-title')).toContainText(['something nice']);
});
```

**Key points:**
- Fixtures are available in tests, hooks, and other fixtures
- Type-safe with TypeScript
- Test runner automatically handles setup and teardown

## Overriding Fixtures

You can override existing fixtures to customize behavior.

### Example: Auto-navigate to baseURL

```typescript
import { test as base } from '@playwright/test';

export const test = base.extend({
  page: async ({ baseURL, page }, use) => {
    await page.goto(baseURL);
    await use(page);
  },
});
```

**Usage:**
```typescript
test.use({ baseURL: 'https://playwright.dev' });
```

### Example: Custom storageState

```typescript
import { test as base } from '@playwright/test';

export const test = base.extend({
  storageState: async ({}, use) => {
    const cookie = await getAuthCookie();
    await use({ cookies: [cookie] });
  },
});
```

## Worker-Scoped Fixtures

Worker fixtures are set up once per worker process and shared across test files.

**Use cases:**
- Set up services
- Run servers
- Create shared resources
- Initialize databases

### Example: Shared Account Fixture

```typescript
import { test as base } from '@playwright/test';

type Account = {
  username: string;
  password: string;
};

// Note: worker fixture types as second template parameter
export const test = base.extend<{}, { account: Account }>({
  account: [async ({ browser }, use, workerInfo) => {
    // Unique username per worker
    const username = 'user' + workerInfo.workerIndex;
    const password = 'verysecure';
    
    // Create the account
    const page = await browser.newPage();
    await page.goto('/signup');
    await page.getByLabel('User Name').fill(username);
    await page.getByLabel('Password').fill(password);
    await page.getByText('Sign up').click();
    await expect(page.getByTestId('result')).toHaveText('Success');
    await page.close();
    
    // Use the account value
    await use({ username, password });
    
    // Cleanup (runs once at end of worker)
    const cleanupPage = await browser.newPage();
    await cleanupPage.goto('/delete-account');
    await cleanupPage.getByLabel('User Name').fill(username);
    await cleanupPage.getByLabel('Password').fill(password);
    await cleanupPage.getByText('Delete account').click();
    await cleanupPage.close();
  }, { scope: 'worker' }],
});
```

**Syntax:** Tuple-like syntax with `{ scope: 'worker' }` option.

**Key characteristics:**
- Set up once per worker
- Shared across multiple test files
- Torn down when worker process ends
- Access to `workerInfo` for unique values

## Automatic Fixtures

Automatic fixtures are set up for each test/worker even when not explicitly listed.

**Syntax:** Use tuple syntax with `{ auto: true }`

### Example: Auto-attach Debug Logs

```typescript
import debug from 'debug';
import fs from 'fs';
import { test as base } from '@playwright/test';

export const test = base.extend<{ saveLogs: void }>({
  saveLogs: [async ({}, use, testInfo) => {
    // Collecting logs during the test
    const logs = [];
    debug.log = (...args) => logs.push(args.map(String).join(''));
    debug.enable('myserver');
    
    await use();
    
    // After the test check if it failed
    if (testInfo.status !== testInfo.expectedStatus) {
      const logFile = testInfo.outputPath('logs.txt');
      await fs.promises.writeFile(logFile, logs.join('\n'), 'utf8');
      testInfo.attachments.push({ 
        name: 'logs', 
        contentType: 'text/plain', 
        path: logFile 
      });
    }
  }, { auto: true }],
});

export { expect } from '@playwright/test';
```

**Use cases:**
- Logging and monitoring
- Automatic cleanup
- Performance tracking
- Error reporting

## Fixture Timeout

Fixtures can have separate timeouts, useful for slow operations.

```typescript
import { test as base, expect } from '@playwright/test';

const test = base.extend<{ slowFixture: string }>({
  slowFixture: [async ({}, use) => {
    // ... perform a slow operation ...
    await use('hello');
  }, { timeout: 60000 }]
});

test('example test', async ({ slowFixture }) => {
  // ...
});
```

**Default:** Fixtures inherit the test timeout if not specified.

## Fixtures-Options

Parameterize tests with options and fixtures.

```typescript
import { test as base } from '@playwright/test';
import { TodoPage } from './todo-page';

// Declare your options
export type MyOptions = {
  defaultItem: string;
};

type MyFixtures = {
  todoPage: TodoPage;
};

// Extend base test with options and fixtures
export const test = base.extend<MyOptions & MyFixtures>({
  // Define an option with default value
  defaultItem: ['Something nice', { option: true }],
  
  // Fixture depends on the option
  todoPage: async ({ page, defaultItem }, use) => {
    const todoPage = new TodoPage(page);
    await todoPage.goto();
    await todoPage.addToDo(defaultItem);
    await use(todoPage);
    await todoPage.removeAll();
  },
});

export { expect } from '@playwright/test';
```

**Usage:**
```typescript
test.use({ defaultItem: 'Custom item' });
```

### Array Options

Arrays must be wrapped in an extra array:

```typescript
type Person = { name: string };

const test = base.extend<{ persons: Person[] }>({
  persons: [[], { option: true }],
});

// Correct: wrap in array
const actualPersons = [{ name: 'Alice' }, { name: 'Bob' }];
test.use({
  persons: [actualPersons, { scope: 'test' }],
});
```

## Execution Order

Fixtures follow specific rules for execution order:

1. **Dependency order:** When fixture A depends on fixture B, B is set up before A and torn down after A
2. **Lazy execution:** Non-automatic fixtures only run when needed
3. **Scope-based teardown:** Test-scoped fixtures tear down after each test, worker-scoped after worker ends

### Execution Flow Example

Given fixtures with different scopes and auto settings:

**Worker setup:**
1. browser setup (required by autoWorkerFixture)
2. autoWorkerFixture setup (automatic worker fixtures first)
3. beforeAll runs

**First test:**
1. autoTestFixture setup (automatic test fixtures first)
2. page setup (required by beforeEach)
3. beforeEach runs
4. test runs
5. afterEach runs
6. page teardown (test-scoped)
7. autoTestFixture teardown (test-scoped)

**Second test:**
1. autoTestFixture setup
2. page setup
3. beforeEach runs
4. workerFixture setup (lazy, only when needed)
5. testFixture setup (depends on workerFixture)
6. test runs
7. afterEach runs
8. testFixture teardown (test-scoped)
9. page teardown (test-scoped)
10. autoTestFixture teardown (test-scoped)

**Worker teardown:**
1. afterAll runs
2. workerFixture teardown (worker-scoped)
3. autoWorkerFixture teardown (worker-scoped)
4. browser teardown (worker-scoped)

**Key observations:**
- Test-scoped fixtures set up and tear down for each test
- Unused fixtures never run
- Worker-scoped fixtures set up lazily but tear down once
- Automatic fixtures always run

## Combine Custom Fixtures from Multiple Modules

Use `mergeTests` to combine fixtures from different modules:

```typescript
// fixtures.ts
import { mergeTests } from '@playwright/test';
import { test as dbTest } from 'database-test-utils';
import { test as a11yTest } from 'a11y-test-utils';

export const test = mergeTests(dbTest, a11yTest);
```

```typescript
// test.spec.ts
import { test } from './fixtures';

test('passes', async ({ database, page, a11y }) => {
  // use database and a11y fixtures
});
```

## Box Fixtures

Hide fixture steps from UI and reports to reduce noise.

```typescript
import { test as base } from '@playwright/test';

export const test = base.extend({
  helperFixture: [async ({}, use, testInfo) => {
    // ...
  }, { box: true }],
});
```

**Options:**
- `box: true` - Hide fixture and all steps inside
- `box: 'self'` - Hide fixture but show steps inside

**Use case:** Non-interesting helper fixtures that clutter reports.

## Custom Fixture Title

Give fixtures custom titles for reports and error messages:

```typescript
import { test as base } from '@playwright/test';

export const test = base.extend({
  innerFixture: [async ({}, use, testInfo) => {
    // ...
  }, { title: 'my fixture' }],
});
```

## Adding Global beforeEach/afterEach Hooks

Use automatic test-scoped fixtures for global hooks:

```typescript
// fixtures.ts
import { test as base } from '@playwright/test';

export const test = base.extend<{ forEachTest: void }>({
  forEachTest: [async ({ page }, use) => {
    // This code runs before every test
    await page.goto('http://localhost:8000');
    await use();
    // This code runs after every test
    console.log('Last URL:', page.url());
  }, { auto: true }],
});
```

```typescript
// mytest.spec.ts
import { test } from './fixtures';
import { expect } from '@playwright/test';

test('basic', async ({ page }) => {
  expect(page).toHaveURL('http://localhost:8000');
  await page.goto('https://playwright.dev');
});
```

## Adding Global beforeAll/afterAll Hooks

Use automatic worker-scoped fixtures for global worker hooks:

```typescript
// fixtures.ts
import { test as base } from '@playwright/test';

export const test = base.extend<{}, { forEachWorker: void }>({
  forEachWorker: [async ({}, use) => {
    // This code runs before all tests in the worker
    console.log(`Starting test worker ${test.info().workerIndex}`);
    await use();
    // This code runs after all tests in the worker
    console.log(`Stopping test worker ${test.info().workerIndex}`);
  }, { scope: 'worker', auto: true }],
});
```

```typescript
// mytest.spec.ts
import { test } from './fixtures';
import { expect } from '@playwright/test';

test('basic', async ({ }) => {
  // ...
});
```

**Note:** Fixtures run once per worker, no need to redeclare in every file.

## Best Practices

1. **Use Fixtures Over Hooks** - Encapsulate setup and teardown together

2. **Create Reusable Fixtures** - Define once, use across all test files

3. **Leverage Worker Fixtures** - Share expensive setup across tests

4. **Use Automatic Fixtures Sparingly** - Only for truly global concerns

5. **Set Appropriate Timeouts** - Give slow fixtures adequate time

6. **Box Helper Fixtures** - Reduce noise in reports

7. **Compose Fixtures** - Build complex behaviors from simple fixtures

8. **Override Built-in Fixtures** - Customize default behavior when needed

9. **Use Options for Parameterization** - Make fixtures configurable

10. **Merge Fixtures from Modules** - Organize by concern, combine when needed

## Common Patterns

### Page Object Model Fixture

```typescript
export const test = base.extend<{ todoPage: TodoPage }>({
  todoPage: async ({ page }, use) => {
    const todoPage = new TodoPage(page);
    await todoPage.goto();
    await use(todoPage);
  },
});
```

### Authentication Fixture

```typescript
export const test = base.extend<{}, { authenticatedUser: User }>({
  authenticatedUser: [async ({ browser }, use) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    await page.goto('/login');
    // ... perform login ...
    const user = { username: 'test', token: 'abc123' };
    await use(user);
    await context.close();
  }, { scope: 'worker' }],
});
```

### Database Fixture

```typescript
export const test = base.extend<{}, { db: Database }>({
  db: [async ({}, use) => {
    const db = await connectToDatabase();
    await use(db);
    await db.close();
  }, { scope: 'worker' }],
});
```

## Related Topics to Explore

- Page Object Model pattern
- Test configuration and projects
- Worker processes and parallelism
- Test isolation strategies
- Authentication patterns
- Global setup and teardown
- Custom reporters
- Test organization
