# Playwright Documentation Research - Parallelism

**Page:** Parallelism  
**URL:** https://playwright.dev/docs/test-parallel  
**Research Date:** December 13, 2025

## Overview

Playwright Test runs tests in parallel by default using multiple worker processes. By default, **test files** are run in parallel, while tests within a single file run sequentially in the same worker process.

**Key capabilities:**
- Configure tests in a single file to run in parallel using `test.describe.configure()`
- Configure entire project for full parallelism using `fullyParallel` option
- Disable parallelism by limiting workers to one
- Control number of parallel worker processes
- Limit failures for efficiency

## Worker Processes

All tests run in worker processes, which are independent OS processes orchestrated by the test runner.

**Characteristics:**
- Each worker has identical environment
- Each worker starts its own browser
- Workers cannot communicate with each other
- Workers are reused across test files for efficiency
- Workers are shutdown after test failures to ensure pristine environment

**Worker reuse:**
Multiple test files usually run in a single worker, one after another, to improve performance.

**Failure handling:**
Workers always shut down after a test failure to guarantee a clean environment for subsequent tests.

## Limit Workers

Control the maximum number of parallel worker processes.

### Command Line

```bash
npx playwright test --workers 4
```

### Configuration File

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Limit the number of workers on CI, use default locally
  workers: process.env.CI ? 2 : undefined,
});
```

**Best practice:** Use fewer workers on CI to conserve resources, use default (CPU cores) locally.

## Disable Parallelism

Run all tests sequentially by limiting to a single worker.

### Command Line

```bash
npx playwright test --workers=1
```

### Configuration File

```typescript
export default defineConfig({
  workers: 1,
});
```

**Use cases:**
- Debugging
- Tests with shared state
- Resource-constrained environments
- Controlling test execution order

## Parallelize Tests in a Single File

By default, tests in a single file run sequentially. Enable parallel execution within a file for independent tests.

### Using test.describe.configure()

```typescript
import { test } from '@playwright/test';

test.describe.configure({ mode: 'parallel' });

test('runs in parallel 1', async ({ page }) => { /* ... */ });
test('runs in parallel 2', async ({ page }) => { /* ... */ });
```

**Important notes:**
- Parallel tests execute in separate worker processes
- Cannot share state or global variables
- Each test executes all relevant hooks (beforeAll, afterAll) independently

### Global Configuration

Enable for all tests in all files:

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  fullyParallel: true,
});
```

### Project-Specific Configuration

Enable for specific projects only:

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
      fullyParallel: true,
    },
  ]
});
```

## Serial Mode

Annotate inter-dependent tests as serial. If one serial test fails, all subsequent tests are skipped. All tests in the group are retried together.

**Warning:** Using serial mode is not recommended. It's better to make tests isolated so they can run independently.

```typescript
import { test, type Page } from '@playwright/test';

// Annotate entire file as serial
test.describe.configure({ mode: 'serial' });

let page: Page;

test.beforeAll(async ({ browser }) => {
  page = await browser.newPage();
});

test.afterAll(async () => {
  await page.close();
});

test('runs first', async () => {
  await page.goto('https://playwright.dev/');
});

test('runs second', async () => {
  await page.getByText('Get Started').click();
});
```

**Characteristics:**
- Tests run in declaration order
- Failure in one test skips all subsequent tests
- All tests retried together as a group
- Shared state possible (but discouraged)

## Opt Out of Fully Parallel Mode

Override global parallel configuration for specific test groups:

```typescript
test.describe('runs in parallel with other describes', () => {
  test.describe.configure({ mode: 'default' });
  test('in order 1', async ({ page }) => {});
  test('in order 2', async ({ page }) => {});
});
```

**Use case:** When most tests run in parallel but some need sequential execution.

## Shard Tests Between Multiple Machines

Distribute test suite across multiple machines for faster execution.

```bash
npx playwright test --shard=2/3
```

**Format:** `--shard=<current>/<total>`

**Example:** Running on 3 machines:
- Machine 1: `--shard=1/3`
- Machine 2: `--shard=2/3`
- Machine 3: `--shard=3/3`

See sharding guide for more details.

## Limit Failures and Fail Fast

Stop test execution after a specified number of failures to avoid wasting resources on broken test suites.

### Command Line

```bash
npx playwright test --max-failures=10
```

### Configuration File

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Limit the number of failures on CI to save resources
  maxFailures: process.env.CI ? 10 : undefined,
});
```

**Behavior:**
- Playwright stops after reaching max failures
- Remaining tests are skipped
- Useful for CI to save resources

## Worker Index and Parallel Index

Each worker process has two IDs:

1. **Worker Index** - Unique identifier starting from 1, changes on worker restart
2. **Parallel Index** - Between 0 and workers-1, stays same on worker restart

### Access via Environment Variables

```typescript
const workerIndex = process.env.TEST_WORKER_INDEX;
const parallelIndex = process.env.TEST_PARALLEL_INDEX;
```

### Access via testInfo

```typescript
test('example', async ({ }, testInfo) => {
  console.log(testInfo.workerIndex);
  console.log(testInfo.parallelIndex);
});
```

**Key difference:**
- When worker restarts (e.g., after failure), `workerIndex` changes but `parallelIndex` stays the same

## Isolate Test Data Between Parallel Workers

Use worker index to isolate data (e.g., database users) between workers.

### Create Worker-Scoped Fixture

```typescript
// playwright/fixtures.ts
import { test as baseTest, expect } from '@playwright/test';
import { createUserInTestDatabase, deleteUserFromTestDatabase } from './my-db-utils';

export * from '@playwright/test';

export const test = baseTest.extend<{}, { dbUserName: string }>({
  // Returns db user name unique for the worker
  dbUserName: [async ({ }, use) => {
    // Use workerIndex as unique identifier
    const userName = `user-${test.info().workerIndex}`;
    
    // Initialize user in the database
    await createUserInTestDatabase(userName);
    await use(userName);
    
    // Clean up after tests are done
    await deleteUserFromTestDatabase(userName);
  }, { scope: 'worker' }],
});
```

### Use in Tests

```typescript
// tests/example.spec.ts
// Important: import our fixtures
import { test, expect } from '../playwright/fixtures';

test('test', async ({ dbUserName }) => {
  // Use the user name in the test
  console.log(`Testing with ${dbUserName}`);
});
```

**Benefits:**
- Each worker has isolated test data
- No conflicts between parallel tests
- Automatic cleanup after worker finishes
- All tests in worker reuse same user

## Control Test Order

### Within a Single File

Tests run in declaration order unless parallelized.

### Across Files

No guaranteed order by default due to parallel execution.

**Options when parallelism is disabled:**
1. Sort test files alphabetically
2. Use a test list file

### Sort Test Files Alphabetically

When parallelism is disabled, files run in alphabetical order:

```
001-user-signin-flow.spec.ts
002-create-new-document.spec.ts
003-edit-document.spec.ts
```

**Configuration:**
```typescript
export default defineConfig({
  workers: 1,
});
```

### Use a Test List File

**Warning:** Test lists are discouraged and supported as best-effort only. Some features (VS Code Extension, tracing) may not work properly.

**Step 1: Create test modules with exported functions**

```typescript
// feature-a.spec.ts
import { test, expect } from '@playwright/test';

export default function createTests() {
  test('feature-a example test', async ({ page }) => {
    // ... test goes here
  });
}
```

```typescript
// feature-b.spec.ts
import { test, expect } from '@playwright/test';

export default function createTests() {
  test.use({ viewport: { width: 500, height: 500 } });
  
  test('feature-b example test', async ({ page }) => {
    // ... test goes here
  });
}
```

**Step 2: Create test list file**

```typescript
// test.list.ts
import { test } from '@playwright/test';
import featureBTests from './feature-b.spec.ts';
import featureATests from './feature-a.spec.ts';

test.describe(featureBTests);
test.describe(featureATests);
```

**Step 3: Configure to use test list**

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  workers: 1,
  testMatch: 'test.list.ts',
});
```

**Important:** Do not define tests directly in helper files. Always wrap tests in functions explicitly called by test list file.

## Best Practices

### 1. Use Default Parallelism

Let Playwright run test files in parallel for best performance:
```typescript
// Default behavior - no configuration needed
```

### 2. Limit Workers on CI

Conserve resources on CI environments:
```typescript
workers: process.env.CI ? 2 : undefined
```

### 3. Make Tests Independent

Avoid serial mode by ensuring tests don't depend on each other:
```typescript
// Good: Independent test
test('create user', async ({ page }) => {
  const userId = generateUniqueId();
  await createUser(userId);
});

// Avoid: Dependent tests
let userId;
test('create user', async () => { userId = await create(); });
test('update user', async () => { await update(userId); }); // Depends on previous
```

### 4. Use Worker-Scoped Fixtures for Shared Resources

Isolate data per worker:
```typescript
export const test = base.extend<{}, { dbUser: User }>({
  dbUser: [async ({}, use) => {
    const user = await createUser(`worker-${test.info().workerIndex}`);
    await use(user);
    await deleteUser(user.id);
  }, { scope: 'worker' }],
});
```

### 5. Fail Fast on CI

Stop early on broken builds:
```typescript
maxFailures: process.env.CI ? 10 : undefined
```

### 6. Use Sharding for Large Test Suites

Distribute across machines:
```bash
# Machine 1
npx playwright test --shard=1/4

# Machine 2
npx playwright test --shard=2/4

# Machine 3
npx playwright test --shard=3/4

# Machine 4
npx playwright test --shard=4/4
```

### 7. Parallelize Independent Tests in Same File

For files with many independent tests:
```typescript
test.describe.configure({ mode: 'parallel' });
```

### 8. Monitor Worker Count

Adjust based on system resources:
```typescript
// Local: use all cores (default)
// CI: limit to conserve resources
workers: process.env.CI ? 2 : undefined
```

### 9. Avoid Test Lists

Use only when absolutely necessary. Prefer independent tests with proper isolation.

### 10. Use Parallel Index for Port Allocation

Assign unique ports to workers:
```typescript
test('start server', async ({}, testInfo) => {
  const port = 3000 + testInfo.parallelIndex;
  await startServer(port);
});
```

## Common Patterns

### Database Isolation Pattern

```typescript
export const test = base.extend<{}, { dbConnection: Database }>({
  dbConnection: [async ({}, use) => {
    const dbName = `test_db_worker_${test.info().workerIndex}`;
    const db = await createDatabase(dbName);
    await use(db);
    await dropDatabase(dbName);
  }, { scope: 'worker' }],
});
```

### Port Allocation Pattern

```typescript
export const test = base.extend<{}, { serverPort: number }>({
  serverPort: [async ({}, use) => {
    const port = 3000 + test.info().parallelIndex;
    await use(port);
  }, { scope: 'worker' }],
});
```

### Conditional Parallelism Pattern

```typescript
export default defineConfig({
  fullyParallel: !process.env.DEBUG,
  workers: process.env.DEBUG ? 1 : undefined,
});
```

## Related Topics to Explore

- Sharding guide
- Worker-scoped fixtures
- Test isolation strategies
- CI/CD optimization
- Resource management
- Test organization
- Debugging parallel tests
- Performance optimization
