# Playwright Documentation Research - Navigations

**Page:** Navigations  
**URL:** https://playwright.dev/docs/navigations  
**Research Date:** December 14, 2025

## Introduction

**Capability:** Playwright can navigate to URLs and handle navigations caused by page interactions.

## Basic Navigation

### Simplest Form

**Opening a URL:**
```typescript
// Navigate the page
await page.goto('https://example.com');
```

### Load Event

**Behavior:** Code above loads page and waits for web page to fire `load` event.

**Load event:** Fired when whole page has loaded, including all dependent resources such as:
- Stylesheets
- Scripts
- iframes
- Images

### Client-Side Redirect

**Note:** If page does client-side redirect before `load`, `page.goto()` will wait for redirected page to fire `load` event.

## When is the Page Loaded?

### Modern Pages Behavior

**After load event:** Modern pages perform numerous activities after `load` event was fired:
- Fetch data lazily
- Populate UI
- Load expensive resources, scripts and styles

**Challenge:** There is no way to tell that page is "loaded" - it depends on page, framework, etc.

### Playwright's Approach

**Key insight:** In Playwright you can interact with page at any moment.

**Auto-waiting:** It will automatically wait for target elements to become **actionable**.

**Example:**
```typescript
// Navigate and click element
// Click will auto-wait for the element
await page.goto('https://example.com');
await page.getByText('Example Domain').click();
```

**Behavior:** For scenario above, Playwright will:
1. Wait for text to become visible
2. Wait for rest of actionability checks to pass for that element
3. Click it

### Very Fast User

**Concept:** Playwright operates as very fast user - moment it sees button, it clicks it.

**General case:** You don't need to worry about whether all resources loaded, etc.

## Hydration

### Poor Hydration Problem

**Symptoms:**
- Playwright performs action, but nothing seemingly happens
- Enter text into input field and it will disappear

**Most probable reason:** Poor page **hydration**.

### How Hydration Works

**Process:**
1. First, static version of page is sent to browser
2. Then dynamic part is sent and page becomes "live"

**Problem:** As very fast user, Playwright will start interacting with page moment it sees it.

**Issue:** If button on page is enabled, but listeners have not yet been added, Playwright will do its job, but click won't have any effect.

### Verifying Poor Hydration

**Method:**
1. Open Chrome DevTools
2. Pick "Slow 3G" network emulation in Network panel
3. Reload page
4. Once you see element of interest, interact with it

**Result:** You'll see that:
- Button clicks will be ignored
- Entered text will be reset by subsequent page load code

### Fix for Poor Hydration

**Right fix:** Make sure that all interactive controls are **disabled** until after hydration, when page is fully functional.

## Waiting for Navigation

### Multiple Navigations

**Scenario:** Clicking element could trigger multiple navigations.

**Recommendation:** Explicitly use `page.waitForURL()` to specific URL.

**Example:**
```typescript
await page.getByText('Click me').click();
await page.waitForURL('**/login');
```

## Navigation Events

### Navigation vs Loading

**Playwright splits** process of showing new document in page into:
1. **Navigation**
2. **Loading**

### Navigation Process

**Navigation starts** by:
- Changing page URL, or
- Interacting with page (e.g., clicking link)

**Navigation intent** may be:
- Canceled (e.g., on hitting unresolved DNS address)
- Transformed into file download

**Navigation is committed** when:
- Response headers have been parsed
- Session history is updated

**After navigation succeeds (is committed):** Page starts **loading** the document.

### Loading Process

**Loading covers:**
- Getting remaining response body over network
- Parsing
- Executing scripts
- Firing load events

**Loading steps:**
1. `page.url()` is set to new URL
2. Document content is loaded over network and parsed
3. `page.on('domcontentloaded')` event is fired
4. Page executes some scripts and loads resources like stylesheets and images
5. `page.on('load')` event is fired
6. Page executes dynamically loaded scripts

## Best Practices

### 1. Use Auto-Waiting

**✅ Good:**
```typescript
await page.goto('/');
await page.getByRole('button').click(); // Auto-waits for button
```

**No need to manually wait** for page to load in most cases.

### 2. Wait for Specific URL After Navigation

**✅ Good:**
```typescript
await page.getByRole('link', { name: 'Login' }).click();
await page.waitForURL('**/login');
```

**Benefit:** Ensures navigation completed to expected URL.

### 3. Handle Hydration Issues

**✅ Good (in application code):**
```typescript
// Disable buttons until hydration complete
<button disabled={!isHydrated}>Submit</button>
```

**In tests:**
```typescript
// Wait for specific element that indicates hydration complete
await page.getByText('Page ready').waitFor();
```

### 4. Use Load States When Needed

**Pattern:**
```typescript
await page.goto('/', { waitUntil: 'domcontentloaded' });
// Or
await page.goto('/', { waitUntil: 'networkidle' });
```

### 5. Listen to Navigation Events

**Pattern:**
```typescript
page.on('load', () => console.log('Page loaded'));
page.on('domcontentloaded', () => console.log('DOM loaded'));
```

## Common Use Cases

### Use Case 1: Basic Navigation

```typescript
test('navigate to page', async ({ page }) => {
  await page.goto('https://example.com');
  await expect(page).toHaveURL('https://example.com');
  await expect(page).toHaveTitle(/Example/);
});
```

### Use Case 2: Navigation with Wait for URL

```typescript
test('login and wait for dashboard', async ({ page }) => {
  await page.goto('/login');
  
  await page.getByLabel('Email').fill('user@example.com');
  await page.getByLabel('Password').fill('password');
  await page.getByRole('button', { name: 'Login' }).click();
  
  // Wait for navigation to dashboard
  await page.waitForURL('**/dashboard');
  
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
});
```

### Use Case 3: Handle Multiple Navigations

```typescript
test('handle redirect chain', async ({ page }) => {
  await page.goto('/start');
  
  await page.getByRole('link', { name: 'Continue' }).click();
  await page.waitForURL('**/step2');
  
  await page.getByRole('button', { name: 'Next' }).click();
  await page.waitForURL('**/step3');
  
  await expect(page).toHaveURL(/step3/);
});
```

### Use Case 4: Wait for Network Idle

```typescript
test('wait for all resources to load', async ({ page }) => {
  await page.goto('/', { waitUntil: 'networkidle' });
  
  // All network requests finished
  await expect(page.getByText('Content loaded')).toBeVisible();
});
```

### Use Case 5: Handle Hydration

```typescript
test('wait for hydration', async ({ page }) => {
  await page.goto('/');
  
  // Wait for hydration indicator
  await page.getByTestId('hydrated').waitFor();
  
  // Now safe to interact
  await page.getByRole('button', { name: 'Submit' }).click();
});
```

### Use Case 6: Navigation Events

```typescript
test('listen to navigation events', async ({ page }) => {
  let domContentLoaded = false;
  let loaded = false;
  
  page.on('domcontentloaded', () => {
    domContentLoaded = true;
  });
  
  page.on('load', () => {
    loaded = true;
  });
  
  await page.goto('/');
  
  expect(domContentLoaded).toBe(true);
  expect(loaded).toBe(true);
});
```

## Use Cases for Solely Art Platform

### Example 1: Navigate to Artist Profile

```typescript
test('navigate to artist profile', async ({ page }) => {
  await page.goto('/artists');
  
  await page.getByRole('link', { name: 'John Doe' }).click();
  await page.waitForURL('**/artist/**');
  
  await expect(page.getByRole('heading', { name: 'John Doe' })).toBeVisible();
  await expect(page).toHaveURL(/\/artist\/\d+/);
});
```

### Example 2: Booking Flow Navigation

```typescript
test('complete booking flow navigation', async ({ page }) => {
  // Step 1: Search
  await page.goto('/search');
  await page.getByLabel('Location').fill('New York');
  await page.getByRole('button', { name: 'Search' }).click();
  await page.waitForURL('**/search?location=New+York');
  
  // Step 2: Artist details
  await page.getByText('Artist Name').click();
  await page.waitForURL('**/artist/**');
  
  // Step 3: Book
  await page.getByRole('button', { name: 'Book Now' }).click();
  await page.waitForURL('**/booking/**');
  
  // Step 4: Checkout
  await page.getByRole('button', { name: 'Continue to Payment' }).click();
  await page.waitForURL('**/checkout/**');
  
  // Verify final URL
  await expect(page).toHaveURL(/\/checkout\/\d+/);
});
```

### Example 3: Login Redirect

```typescript
test('login redirects to intended page', async ({ page }) => {
  // Try to access protected page
  await page.goto('/my-bookings');
  
  // Should redirect to login
  await page.waitForURL('**/login**');
  
  // Login
  await page.getByLabel('Email').fill('user@example.com');
  await page.getByLabel('Password').fill('password');
  await page.getByRole('button', { name: 'Login' }).click();
  
  // Should redirect back to intended page
  await page.waitForURL('**/my-bookings');
  
  await expect(page.getByRole('heading', { name: 'My Bookings' })).toBeVisible();
});
```

### Example 4: Payment Flow with Hydration

```typescript
test('payment form waits for Stripe hydration', async ({ page }) => {
  await page.goto('/checkout');
  
  // Wait for Stripe to load (hydration)
  await page.waitForSelector('iframe[name*="stripe"]');
  await page.waitForTimeout(1000); // Additional wait for Stripe initialization
  
  // Fill booking details
  await page.getByLabel('Event Date').fill('2025-01-15');
  await page.getByLabel('Event Time').fill('14:00');
  
  // Fill payment details in Stripe iframe
  const stripeFrame = page.frameLocator('iframe[name*="stripe"]');
  await stripeFrame.getByPlaceholder('Card number').fill('4242424242424242');
  
  // Submit
  await page.getByRole('button', { name: 'Pay Now' }).click();
  
  // Wait for success page
  await page.waitForURL('**/booking/success/**');
  
  await expect(page.getByText('Booking confirmed')).toBeVisible();
});
```

### Example 5: Artist Gallery with Lazy Loading

```typescript
test('artist gallery loads all images', async ({ page }) => {
  await page.goto('/artist/123/gallery', { waitUntil: 'networkidle' });
  
  // Scroll to load lazy images
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  
  // Wait for all images to load
  await page.waitForLoadState('networkidle');
  
  const images = page.locator('img.gallery-image');
  const count = await images.count();
  
  expect(count).toBeGreaterThan(0);
});
```

### Example 6: Search with URL Parameters

```typescript
test('search updates URL parameters', async ({ page }) => {
  await page.goto('/search');
  
  // Fill search form
  await page.getByLabel('Location').fill('New York');
  await page.getByLabel('Date').fill('2025-01-15');
  await page.getByLabel('Category').selectOption('Music');
  
  await page.getByRole('button', { name: 'Search' }).click();
  
  // Wait for URL to update with parameters
  await page.waitForURL('**/search?**');
  
  // Verify URL parameters
  const url = new URL(page.url());
  expect(url.searchParams.get('location')).toBe('New York');
  expect(url.searchParams.get('date')).toBe('2025-01-15');
  expect(url.searchParams.get('category')).toBe('Music');
});
```

### Example 7: Back Navigation

```typescript
test('navigate back to previous page', async ({ page }) => {
  await page.goto('/artists');
  await page.getByRole('link', { name: 'John Doe' }).click();
  await page.waitForURL('**/artist/**');
  
  // Go back
  await page.goBack();
  await page.waitForURL('**/artists');
  
  await expect(page.getByRole('heading', { name: 'Artists' })).toBeVisible();
});
```

## Advanced Patterns

### Pattern 1: Navigation with Timeout

```typescript
test('navigate with custom timeout', async ({ page }) => {
  await page.goto('/', { timeout: 60000 }); // 60 seconds
});
```

### Pattern 2: Wait for Multiple Conditions

```typescript
test('wait for multiple navigation conditions', async ({ page }) => {
  await page.goto('/');
  
  await Promise.all([
    page.waitForURL('**/dashboard'),
    page.waitForSelector('.dashboard-loaded'),
    page.waitForLoadState('networkidle'),
  ]);
});
```

### Pattern 3: Conditional Navigation

```typescript
test('conditional navigation based on URL', async ({ page }) => {
  await page.goto('/');
  
  const currentURL = page.url();
  
  if (currentURL.includes('login')) {
    // Handle login
    await page.getByLabel('Email').fill('user@example.com');
    await page.getByLabel('Password').fill('password');
    await page.getByRole('button', { name: 'Login' }).click();
    await page.waitForURL('**/dashboard');
  }
});
```

### Pattern 4: Navigation with Referer

```typescript
test('navigate with referer', async ({ page }) => {
  await page.goto('/', {
    referer: 'https://google.com',
  });
});
```

### Pattern 5: Wait for Navigation After Action

```typescript
test('wait for navigation after click', async ({ page }) => {
  await page.goto('/');
  
  await Promise.all([
    page.waitForNavigation(),
    page.getByRole('link', { name: 'About' }).click(),
  ]);
  
  await expect(page).toHaveURL('**/about');
});
```

### Pattern 6: Navigation with Load State

```typescript
test('navigate with specific load state', async ({ page }) => {
  // Wait only for DOM to be loaded
  await page.goto('/', { waitUntil: 'domcontentloaded' });
  
  // Or wait for network to be idle
  await page.goto('/', { waitUntil: 'networkidle' });
  
  // Or wait for commit (fastest)
  await page.goto('/', { waitUntil: 'commit' });
});
```

### Pattern 7: Reload Page

```typescript
test('reload page', async ({ page }) => {
  await page.goto('/');
  
  // Reload page
  await page.reload();
  
  // Or reload with specific options
  await page.reload({ waitUntil: 'networkidle' });
});
```

### Pattern 8: Get Current URL

```typescript
test('verify current URL', async ({ page }) => {
  await page.goto('/artists');
  
  const url = page.url();
  expect(url).toContain('/artists');
  
  // Or use assertion
  await expect(page).toHaveURL(/\/artists/);
});
```

## Navigation Methods

### page.goto(url, options)

**Purpose:** Navigate to URL.

```typescript
await page.goto('https://example.com');
```

**Options:**
- `waitUntil`: 'load' | 'domcontentloaded' | 'networkidle' | 'commit'
- `timeout`: Number (milliseconds)
- `referer`: String

### page.waitForURL(url, options)

**Purpose:** Wait for page to navigate to matching URL.

```typescript
await page.waitForURL('**/login');
```

**URL patterns:**
- Glob pattern: `**/login`
- RegExp: `/\/login$/`
- Function: `url => url.pathname === '/login'`

### page.waitForNavigation(options)

**Purpose:** Wait for navigation to finish.

```typescript
await page.waitForNavigation();
```

**Note:** Deprecated in favor of `waitForURL()`.

### page.waitForLoadState(state, options)

**Purpose:** Wait for specific load state.

```typescript
await page.waitForLoadState('networkidle');
```

**States:**
- `'load'` - load event fired
- `'domcontentloaded'` - DOMContentLoaded event fired
- `'networkidle'` - no network connections for 500ms

### page.goBack(options)

**Purpose:** Navigate to previous page in history.

```typescript
await page.goBack();
```

### page.goForward(options)

**Purpose:** Navigate to next page in history.

```typescript
await page.goForward();
```

### page.reload(options)

**Purpose:** Reload current page.

```typescript
await page.reload();
```

### page.url()

**Purpose:** Get current page URL.

```typescript
const url = page.url();
```

### page.on('load')

**Purpose:** Listen to load event.

```typescript
page.on('load', () => console.log('Page loaded'));
```

### page.on('domcontentloaded')

**Purpose:** Listen to DOMContentLoaded event.

```typescript
page.on('domcontentloaded', () => console.log('DOM loaded'));
```

## Troubleshooting

### Issue: Page Not Loaded

**Cause:** Waiting for wrong load state.

**Solution:** Use appropriate load state.

```typescript
// For modern SPAs
await page.goto('/', { waitUntil: 'domcontentloaded' });

// For pages with many resources
await page.goto('/', { waitUntil: 'networkidle' });
```

### Issue: Navigation Timeout

**Cause:** Page takes too long to load.

**Solution:** Increase timeout or use different wait strategy.

```typescript
await page.goto('/', { timeout: 60000 });
// Or
await page.goto('/', { waitUntil: 'domcontentloaded' });
```

### Issue: Hydration Problems

**Cause:** Interacting with page before hydration complete.

**Solution:** Wait for hydration indicator.

```typescript
await page.goto('/');
await page.getByTestId('hydrated').waitFor();
// Now safe to interact
```

### Issue: Multiple Navigations

**Cause:** Action triggers multiple redirects.

**Solution:** Use waitForURL to wait for final URL.

```typescript
await page.getByRole('button').click();
await page.waitForURL('**/final-page');
```

### Issue: URL Not Matching

**Cause:** URL pattern incorrect.

**Solution:** Use correct pattern syntax.

```typescript
// Glob pattern
await page.waitForURL('**/login');

// RegExp
await page.waitForURL(/\/login$/);

// Function
await page.waitForURL(url => url.pathname === '/login');
```

## Summary

### Key Concepts

**1. Basic navigation:** `page.goto()` loads page and waits for load event

**2. Auto-waiting:** Playwright automatically waits for elements to be actionable

**3. Very fast user:** Playwright operates as very fast user

**4. Hydration:** Poor hydration can cause interactions to have no effect

**5. Navigation vs Loading:** Playwright splits process into navigation and loading

**6. Wait for URL:** Use `waitForURL()` for explicit navigation waiting

### Navigation Methods

- `page.goto(url)` - Navigate to URL
- `page.waitForURL(url)` - Wait for URL
- `page.waitForLoadState(state)` - Wait for load state
- `page.goBack()` - Go back
- `page.goForward()` - Go forward
- `page.reload()` - Reload page
- `page.url()` - Get current URL

### Load States

- `'load'` - Load event fired (default)
- `'domcontentloaded'` - DOM loaded
- `'networkidle'` - No network activity
- `'commit'` - Navigation committed

### Best Practices

1. Use auto-waiting (don't manually wait in most cases)
2. Wait for specific URL after navigation
3. Handle hydration issues in application code
4. Use appropriate load states
5. Listen to navigation events when needed

## Related Topics

- Pages
- Auto-waiting
- Assertions
- Events
- Load states
- Hydration
- URL patterns
- Navigation events
