# Playwright Documentation Research - Command Line

**Page:** Command line  
**URL:** https://playwright.dev/docs/test-cli  
**Research Date:** December 13, 2025

## Overview

Playwright provides a powerful command line interface (CLI) for running tests, generating code, debugging, and more. The most up-to-date list of commands and arguments can always be retrieved via `npx playwright --help`.

## Essential Commands

### Run Tests

The primary command for executing Playwright tests with extensive configuration options.

**Syntax:**
```bash
npx playwright test [options] [test-filter...]
```

**Common Examples:**

```bash
# Run all tests
npx playwright test

# Run a single test file
npx playwright test tests/todo-page.spec.ts

# Run a set of test files
npx playwright test tests/todo-page/ tests/landing-page/

# Run tests at a specific line
npx playwright test my-spec.ts:42

# Run tests by title
npx playwright test -g "add a todo item"

# Run tests in headed browsers
npx playwright test --headed

# Run tests for a specific project
npx playwright test --project=chromium

# Get help
npx playwright test --help
```

**Special Execution Modes:**

```bash
# Disable parallelization
npx playwright test --workers=1

# Run in debug mode with Playwright Inspector
npx playwright test --debug

# Run tests in interactive UI mode
npx playwright test --ui
```

### Common Options

| Option | Description |
|--------|-------------|
| `--debug` | Run tests with Playwright Inspector. Shortcut for `PWDEBUG=1` environment variable and `--timeout=0 --max-failures=1 --headed --workers=1` options |
| `--headed` | Run tests in headed browsers (default: headless) |
| `-g <grep>` or `--grep <grep>` | Only run tests matching this regular expression (default: ".*") |
| `--project <project-name...>` | Only run tests from the specified list of projects, supports '*' wildcard (default: run all projects) |
| `--ui` | Run tests in interactive UI mode |
| `-j <workers>` or `--workers <workers>` | Number of concurrent workers or percentage of logical CPU cores, use 1 to run in a single worker (default: 50%) |

### All Options

**Non-option arguments:** Each argument is treated as a regular expression matched against the full test file path. Only tests from files matching the pattern will be executed. Special symbols like `$` or `*` should be escaped with `\`. In many shells/terminals you may need to quote the arguments.

**Configuration and Execution:**

| Option | Description |
|--------|-------------|
| `-c <file>` or `--config <file>` | Configuration file, or a test directory with optional "playwright.config.{m,c}?{js,ts}". Defaults to `playwright.config.ts` or `playwright.config.js` in the current directory |
| `--debug` | Run tests with Playwright Inspector. Shortcut for `PWDEBUG=1` environment variable and `--timeout=0 --max-failures=1 --headed --workers=1` options |
| `--fail-on-flaky-tests` | Fail if any test is flagged as flaky (default: false) |
| `--forbid-only` | Fail if `test.only` is called (default: false). Useful on CI |
| `--fully-parallel` | Run all tests in parallel (default: false) |
| `--global-timeout <timeout>` | Maximum time this test suite can run in milliseconds (default: unlimited) |

**Test Filtering:**

| Option | Description |
|--------|-------------|
| `-g <grep>` or `--grep <grep>` | Only run tests matching this regular expression (default: ".*") |
| `--grep-invert <grep>` | Only run tests that do not match this regular expression |
| `--test-list <file>` | Path to a file containing a list of tests to run |
| `--test-list-invert <file>` | Path to a file containing a list of tests to skip |
| `--only-changed [ref]` | Only run test files that have been changed between 'HEAD' and 'ref'. Defaults to running all uncommitted changes. Only supports Git |

**Execution Control:**

| Option | Description |
|--------|-------------|
| `--headed` | Run tests in headed browsers (default: headless) |
| `-j <workers>` or `--workers <workers>` | Number of concurrent workers or percentage of logical CPU cores, use 1 to run in a single worker (default: 50%) |
| `--last-failed` | Only re-run the failures |
| `--list` | Collect all the tests and report them, but do not run |
| `--max-failures <N>` or `-x` | Stop after the first N failures. Passing `-x` stops after the first failure |
| `--no-deps` | Do not run project dependencies |
| `--pass-with-no-tests` | Makes test run succeed even if no tests were found |
| `--project <project-name...>` | Only run tests from the specified list of projects, supports '*' wildcard (default: run all projects) |
| `--repeat-each <N>` | Run each test N times (default: 1) |
| `--retries <retries>` | Maximum retry count for flaky tests, zero for no retries (default: no retries) |
| `--shard <shard>` | Shard tests and execute only the selected shard, specified in the form "current/all", 1-based, e.g., "3/5" |

**Output and Reporting:**

| Option | Description |
|--------|-------------|
| `--output <dir>` | Folder for output artifacts (default: "test-results") |
| `--quiet` | Suppress stdio |
| `--reporter <reporter>` | Reporter to use, comma-separated, can be "dot", "line", "list", or others (default: "list"). You can also pass a path to a custom reporter file |

**Timeouts:**

| Option | Description |
|--------|-------------|
| `--timeout <timeout>` | Specify test timeout threshold in milliseconds, zero for unlimited (default: 30 seconds) |
| `--global-timeout <timeout>` | Maximum time this test suite can run in milliseconds (default: unlimited) |

**Tracing and Debugging:**

| Option | Description |
|--------|-------------|
| `--trace <mode>` | Force tracing mode, can be `on`, `off`, `on-first-retry`, `on-all-retries`, `retain-on-failure`, `retain-on-first-failure` |
| `--ui` | Run tests in interactive UI mode |
| `--ui-host <host>` | Host to serve UI on; specifying this option opens UI in a browser tab |
| `--ui-port <port>` | Port to serve UI on, 0 for any free port; specifying this option opens UI in a browser tab |

**Snapshots:**

| Option | Description |
|--------|-------------|
| `--ignore-snapshots` | Ignore screenshot and snapshot expectations |
| `-u` or `--update-snapshots [mode]` | Update snapshots with actual results. Possible values are "all", "changed", "missing", and "none". Running tests without the flag defaults to "missing"; running tests with the flag but without a value defaults to "changed" |
| `--update-source-method [mode]` | Update snapshots with actual results. Possible values are "patch" (default), "3way" and "overwrite". "Patch" creates a unified diff file that can be used to update the source code later. "3way" generates merge conflict markers in source code. "Overwrite" overwrites the source code with the new snapshot values |

**TypeScript:**

| Option | Description |
|--------|-------------|
| `--tsconfig <path>` | Path to a single tsconfig applicable to all imported files (default: look up tsconfig for each imported file separately) |

**Quick Stop:**

| Option | Description |
|--------|-------------|
| `-x` | Stop after the first failure |

## Test List Files

Options `--test-list` and `--test-list-invert` accept a path to a test list file. This file should list tests in a format similar to the output produced in `--list` mode.

**Test List File Format:**

```
# This is a test list file.
# It can include comments and empty lines.

# Fully qualified test with a project:
[chromium] › path/to/example.spec.ts:3:9 › suite › nested suite › example test

# This test is included for all projects:
path/to/example.spec.ts:3:9 › example test

# Use "›" or ">" as a separator:
[firefox] > example.spec.ts > suite > nested suite > example test

# Line/column numbers are completely ignored, you can omit them.
# Three entries below refer to the same test:
example.spec.ts › example test
example.spec.ts:15 › example test
example.spec.ts:42:42 › example test
```

**Key characteristics:**
- Comments start with `#`
- Empty lines are allowed
- Tests can be project-specific or apply to all projects
- Line and column numbers are optional and ignored
- Both `›` and `>` can be used as separators

## Show Report

Display HTML report from previous test run.

**Syntax:**
```bash
npx playwright show-report [report] [options]
```

**Examples:**
```bash
# Show latest test report
npx playwright show-report

# Show a specific report
npx playwright show-report playwright-report/

# Show report on custom port
npx playwright show-report --port 8080
```

**Options:**

| Option | Description |
|--------|-------------|
| `--host <host>` | Host to serve report on (default: localhost) |
| `--port <port>` | Port to serve report on (default: 9323) |

## Install Browsers

Install browsers required by Playwright.

**Syntax:**
```bash
npx playwright install [options] [browser...]
npx playwright install-deps [options] [browser...]
npx playwright uninstall
```

**Examples:**
```bash
# Install all browsers
npx playwright install

# Install only Chromium
npx playwright install chromium

# Install specific browsers
npx playwright install chromium webkit

# Install browsers with dependencies
npx playwright install --with-deps
```

**Install Options:**

| Option | Description |
|--------|-------------|
| `--force` | Force reinstall of stable browser channels |
| `--with-deps` | Install browser system dependencies |
| `--dry-run` | Don't perform installation, just print information |
| `--only-shell` | Only install chromium-headless-shell instead of full Chromium |
| `--no-shell` | Don't install chromium-headless-shell |

**Install Deps Options:**

| Option | Description |
|--------|-------------|
| `--dry-run` | Don't perform installation, just print information |

## Generation & Debugging Tools

### Code Generation

Record actions and generate tests for multiple languages.

**Syntax:**
```bash
npx playwright codegen [options] [url]
```

**Examples:**
```bash
# Start recording with interactive UI
npx playwright codegen

# Record on specific site
npx playwright codegen https://playwright.dev

# Generate Python code
npx playwright codegen --target=python
```

**Options:**

| Option | Description |
|--------|-------------|
| `-b, --browser <name>` | Browser to use: chromium, firefox, or webkit (default: chromium) |
| `-o, --output <file>` | Output file for the generated script |
| `--target <language>` | Language to use: javascript, playwright-test, python, etc. |
| `--test-id-attribute <attr>` | Attribute to use for test IDs |

### Trace Viewer

Analyze and view test traces for debugging.

**Syntax:**
```bash
npx playwright show-trace [options] [trace]
```

**Examples:**
```bash
# Open trace viewer without a specific trace (can load traces via UI)
npx playwright show-trace

# View a trace file
npx playwright show-trace trace.zip

# View trace from directory
npx playwright show-trace trace/
```

**Options:**

| Option | Description |
|--------|-------------|
| `-b, --browser <name>` | Browser to use: chromium, firefox, or webkit (default: chromium) |
| `-h, --host <host>` | Host to serve trace on |
| `-p, --port <port>` | Port to serve trace on |

## Specialized Commands

### Merge Reports

Read blob reports and combine them.

**Syntax:**
```bash
npx playwright merge-reports [options] <blob dir>
```

**Examples:**
```bash
# Combine test reports
npx playwright merge-reports ./reports
```

**Options:**

| Option | Description |
|--------|-------------|
| `-c, --config <file>` | Configuration file. Can be used to specify additional configuration for the output report |
| `--reporter <reporter>` | Reporter to use, comma-separated, can be "list", "line", "dot", "json", "junit", "null", "github", "html", "blob" (default: "list") |

### Clear Cache

Clear all Playwright caches.

**Syntax:**
```bash
npx playwright clear-cache
```

## Key Insights

### Debug Mode Shortcut

The `--debug` flag is a powerful shortcut that combines multiple options:
- Sets `PWDEBUG=1` environment variable
- Sets `--timeout=0` (unlimited timeout)
- Sets `--max-failures=1` (stop after first failure)
- Sets `--headed` (show browser)
- Sets `--workers=1` (single worker)

### Worker Configuration

Workers can be specified as:
- **Absolute number:** `--workers=4` (exactly 4 workers)
- **Percentage:** `--workers=50%` (50% of logical CPU cores, default)
- **Single worker:** `--workers=1` (sequential execution)

### Grep Patterns

The `--grep` option supports regular expressions for flexible test filtering:
- Simple match: `--grep "login"`
- Logical OR: `--grep "login|signup"`
- Logical AND: `--grep "(?=.*login)(?=.*admin)"` (using lookaheads)

### Snapshot Update Modes

The `--update-snapshots` flag supports multiple modes:
- **all:** Update all snapshots
- **changed:** Update only changed snapshots (default when flag is present)
- **missing:** Update only missing snapshots (default when flag is absent)
- **none:** Don't update any snapshots

### Update Source Methods

The `--update-source-method` flag provides different strategies for updating source code with new snapshots:
- **patch (default):** Creates unified diff file for later application
- **3way:** Generates merge conflict markers in source code
- **overwrite:** Directly overwrites source code with new values

## Best Practices

1. **Use --debug for Interactive Debugging** - Combines all necessary flags for effective debugging

2. **Leverage Test Lists for Complex Filtering** - Use `--test-list` for precise test selection beyond regex capabilities

3. **Use --only-changed in CI** - Run only changed tests first for faster feedback in pull requests

4. **Set --forbid-only in CI** - Prevent accidentally committed `.only()` tests from skipping test suites

5. **Use --fail-on-flaky-tests** - Enforce test stability by failing on flaky test detection

6. **Configure Workers Based on Environment** - Use single worker (`--workers=1`) in CI for stability, multiple workers locally for speed

7. **Shard Large Test Suites** - Use `--shard` to distribute tests across multiple machines

8. **Use --last-failed for Quick Iteration** - Rerun only failed tests during development

9. **Leverage --max-failures** - Stop early when multiple tests fail to save CI time

10. **Use --quiet in CI** - Reduce log noise in automated environments

## Related Topics to Explore

- Configuration file options
- Reporter customization
- Sharding strategies
- Parallelization best practices
- UI Mode features
- Trace viewer capabilities
- Test organization patterns
- CI/CD integration
