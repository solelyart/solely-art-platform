# Playwright Documentation Research - Library

**Page:** Library  
**URL:** https://playwright.dev/docs/library  
**Research Date:** December 13, 2025

## Overview

**Playwright Library** provides unified APIs for launching and interacting with browsers, while **Playwright Test** provides all this plus a fully managed end-to-end Test Runner and experience.

**Recommendation:** For end-to-end testing, use `@playwright/test` (Playwright Test), not `playwright` (Playwright Library) directly.

## Differences When Using Library

### Library Example

Using Playwright Library directly to launch Chromium:

```typescript
import { chromium, devices } from 'playwright';
import assert from 'node:assert';

(async () => {
  // Setup
  const browser = await chromium.launch();
  const context = await browser.newContext(devices['iPhone 11']);
  const page = await context.newPage();

  // The actual interesting bit
  await context.route('**.jpg', route => route.abort());
  await page.goto('https://example.com/');

  assert(await page.title() === 'Example Domain'); // 👎 not a Web First assertion

  // Teardown
  await context.close();
  await browser.close();
})();
```

**Run with:** `node my-script.js`

### Test Example

Equivalent test using Playwright Test:

```typescript
import { expect, test, devices } from '@playwright/test';

test.use(devices['iPhone 11']);

test('should be titled', async ({ page, context }) => {
  await context.route('**.jpg', route => route.abort());
  await page.goto('https://example.com/');

  await expect(page).toHaveTitle('Example');
});
```

**Run with:** `npx playwright test`

## Key Differences

### Installation

| Library | Test |
|---------|------|
| `npm install playwright` | `npm init playwright@latest` |
| Note: **install** vs. **init** | |

### Install Browsers

| Library | Test |
|---------|------|
| Install `@playwright/browser-chromium`, `@playwright/browser-firefox`, `@playwright/browser-webkit` | `npx playwright install` or `npx playwright install chromium` |

### Import From

| Library | Test |
|---------|------|
| `playwright` | `@playwright/test` |

### Initialization

**Library:** Explicitly need to:
1. Pick a browser (e.g., `chromium`)
2. Launch browser with `browserType.launch()`
3. Create context with `browser.newContext()` and pass options
4. Create page with `browserContext.newPage()`

**Test:** 
- Isolated `page` and `context` provided to each test automatically
- Built-in fixtures
- Lazy initialization (created only if referenced)

### Assertions

**Library:**
- No built-in Web-First Assertions
- Use standard assertions (e.g., `assert`)

**Test:**
- Web-First assertions like:
  - `expect(page).toHaveTitle()`
  - `expect(page).toHaveScreenshot()`
- Auto-wait and retry for conditions

### Timeouts

**Library:**
- Defaults to 30s for most operations

**Test:**
- Most operations don't time out
- Every test has a timeout (30s default)

### Cleanup

**Library:** Explicitly need to:
1. Close context with `browserContext.close()`
2. Close browser with `browser.close()`

**Test:**
- No explicit close needed
- Test Runner handles cleanup automatically

### Running

**Library:**
- Run as Node.js script
- Possibly with compilation first
- `node my-script.js`

**Test:**
- Use `npx playwright test` command
- Test Runner handles compilation
- Config determines what and how to run

## Additional Playwright Test Features

Beyond the basic differences, Playwright Test includes:

1. **Configuration Matrix and Projects**
   - Specify matrix of configurations in one place
   - Run same test under multiple configurations
   - No need to modify script for different browsers/devices

2. **Parallelization**
   - Run tests in parallel automatically
   - Utilize multiple CPU cores

3. **Web-First Assertions**
   - Auto-waiting assertions
   - Retry logic built-in

4. **Reporting**
   - Multiple reporter options
   - HTML, JSON, JUnit, etc.

5. **Retries**
   - Automatic retry on failure
   - Configurable retry count

6. **Easily Enabled Tracing**
   - Visual debugging
   - Time travel through test execution

7. **And more...**

## Usage

### Installation

```bash
npm i -D playwright
```

**Note:** See system requirements before installing.

### Install Browsers

**Option 1: Manual installation**
```bash
# Download Chromium, Firefox and WebKit browsers
npx playwright install chromium firefox webkit
```

**Option 2: Automatic with helper packages**
```bash
# Packages download browser upon npm install
npm i -D @playwright/browser-chromium @playwright/browser-firefox @playwright/browser-webkit
```

### Basic Usage

```javascript
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  // Create pages, interact with UI elements, assert values
  await browser.close();
})();
```

### Async/Await Pattern

Playwright APIs are asynchronous and return Promise objects.

**Pattern used in examples:**
```javascript
(async () => { // Start of async arrow function
  // Function code
  // ...
})(); // End of the function and () to invoke itself
```

**Purpose:** Unnamed async arrow function that invokes itself.

## First Script

Navigate to a page and take a screenshot:

```javascript
const { webkit } = require('playwright');

(async () => {
  const browser = await webkit.launch();
  const page = await browser.newPage();
  await page.goto('https://playwright.dev/');
  await page.screenshot({ path: `example.png` });
  await browser.close();
})();
```

### Headless Mode

**Default:** Playwright runs browsers in headless mode.

**To see browser UI:**
```javascript
firefox.launch({ headless: false, slowMo: 50 });
```

**Options:**
- `headless: false` - Show browser UI
- `slowMo: 50` - Slow down execution (50ms delay)

## Record Scripts

Use command line tools to record interactions and generate code:

```bash
npx playwright codegen wikipedia.org
```

**Result:** Generates JavaScript code from user interactions.

## Browser Downloads

### Explicit Download

```bash
# Download all browsers
npx playwright install
```

### Automatic Download with Helper Packages

```bash
# Browser downloads during npm install
npm install @playwright/browser-chromium
```

### Download Behind Firewall or Proxy

Use `HTTPS_PROXY` environment variable:

```bash
# Manual
HTTPS_PROXY=https://192.0.2.1 npx playwright install

# With helper packages
HTTPS_PROXY=https://192.0.2.1 npm install
```

### Download from Artifact Repository

Use `PLAYWRIGHT_DOWNLOAD_HOST` to download from internal repository:

```bash
# Manual
PLAYWRIGHT_DOWNLOAD_HOST=192.0.2.1 npx playwright install

# With helper packages
PLAYWRIGHT_DOWNLOAD_HOST=192.0.2.1 npm install
```

**Default:** Playwright downloads from Microsoft's CDN.

### Skip Browser Download

Use `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD` when browser binaries are managed separately:

```bash
# With helper packages
PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm install
```

## TypeScript Support

Playwright includes built-in TypeScript support. Type definitions are imported automatically.

**Recommendation:** Use type-checking to improve IDE experience.

### In JavaScript

**Option 1: Add type-checking comment**
```javascript
// @ts-check
// ...
```

**Result:** Get type-checking in VS Code or WebStorm.

**Option 2: Use JSDoc**
```javascript
/** @type {import('playwright').Page} */
let page;
```

### In TypeScript

TypeScript support works out-of-the-box.

**Explicit type import:**
```typescript
let page: import('playwright').Page;
```

## Best Practices

### 1. Use Playwright Test for E2E Testing

Library is for specific use cases; Test is for comprehensive testing.

### 2. Use Helper Packages for Browser Installation

```bash
npm i -D @playwright/browser-chromium
```

Automatic browser download on install.

### 3. Use Async/Await Pattern

```javascript
(async () => {
  // Your code
})();
```

### 4. Enable TypeScript Type Checking

```javascript
// @ts-check
```

### 5. Use Headless Mode in CI

```javascript
browser.launch({ headless: true })
```

### 6. Use slowMo for Debugging

```javascript
browser.launch({ headless: false, slowMo: 50 })
```

### 7. Always Close Resources

```javascript
await context.close();
await browser.close();
```

### 8. Use Codegen for Quick Scripts

```bash
npx playwright codegen example.com
```

### 9. Configure Proxy for Corporate Networks

```bash
HTTPS_PROXY=proxy.company.com npx playwright install
```

### 10. Skip Downloads When Using Custom Binaries

```bash
PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm install
```

## Common Use Cases for Library

### 1. Web Scraping

```javascript
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto('https://example.com');
  const data = await page.$$eval('.item', items => 
    items.map(item => item.textContent)
  );
  console.log(data);
  await browser.close();
})();
```

### 2. Screenshot Generation

```javascript
const { webkit } = require('playwright');

(async () => {
  const browser = await webkit.launch();
  const page = await browser.newPage();
  await page.goto('https://example.com');
  await page.screenshot({ path: 'screenshot.png', fullPage: true });
  await browser.close();
})();
```

### 3. PDF Generation

```javascript
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto('https://example.com');
  await page.pdf({ path: 'page.pdf', format: 'A4' });
  await browser.close();
})();
```

### 4. Automation Scripts

```javascript
const { firefox } = require('playwright');

(async () => {
  const browser = await firefox.launch({ headless: false });
  const page = await browser.newPage();
  await page.goto('https://example.com/login');
  await page.fill('#username', 'user');
  await page.fill('#password', 'pass');
  await page.click('button[type="submit"]');
  await page.waitForNavigation();
  // Perform automated tasks
  await browser.close();
})();
```

### 5. Integration with Other Tools

```javascript
const { chromium } = require('playwright');

async function getBrowserPage() {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  return { browser, page };
}

module.exports = { getBrowserPage };
```

## When to Use Library vs Test

### Use Library When:
- Building web scraping tools
- Generating screenshots/PDFs programmatically
- Creating custom automation scripts
- Integrating browser automation into existing applications
- Need fine-grained control over browser lifecycle

### Use Test When:
- Writing end-to-end tests
- Need test runner features (parallelization, retries, reporting)
- Want automatic fixture management
- Need Web-First assertions
- Building comprehensive test suites

## Related Topics to Explore

- Playwright Test getting started
- Browser contexts
- Page objects
- Fixtures
- Web-First assertions
- Test configuration
- Reporters
- Parallelization
- Retries
- Tracing
