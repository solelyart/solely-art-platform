# Playwright Documentation Research - Other Locators

**Page:** Other locators  
**URL:** https://playwright.dev/docs/other-locators  
**Research Date:** December 14, 2025

## Introduction

**Note:** Check out the main **locators guide** for most common and recommended locators.

**In addition to recommended locators** like `page.getByRole()` and `page.getByText()`, Playwright supports a variety of other locators described in this guide.

## CSS Locator

**Warning:** We recommend prioritizing **user-visible locators** like text or accessible role instead of using CSS that is tied to the implementation and could break when the page changes.

**Capability:** Playwright can locate an element by CSS selector.

```typescript
await page.locator('css=button').click();
```

**Playwright augments standard CSS selectors in two ways:**

1. **CSS selectors pierce open shadow DOM**
2. **Playwright adds custom pseudo-classes** like `:visible`, `:has-text()`, `:has()`, `:is()`, `:nth-match()` and more

### CSS: Matching by Text

**Playwright includes a number of CSS pseudo-classes to match elements by their text content:**

#### :has-text() Pseudo-Class

**Description:** Matches any element containing specified text somewhere inside, possibly in a child or a descendant element.

**Matching:** Case-insensitive, trims whitespace and searches for a substring.

**Example:** `article:has-text("Playwright")` matches `<article><div>Playwright</div></article>`.

**Important:** `:has-text()` should be used together with other CSS specifiers, otherwise it will match all the elements containing specified text, including the `<body>`.

```typescript
// Wrong, will match many elements including <body>
await page.locator(':has-text("Playwright")').click();

// Correct, only matches the <article> element
await page.locator('article:has-text("Playwright")').click();
```

#### :text() Pseudo-Class

**Description:** Matches the smallest element containing specified text.

**Matching:** Case-insensitive, trims whitespace and searches for a substring.

**Example:** Find an element with text "Home" somewhere inside the #nav-bar element:

```typescript
await page.locator('#nav-bar :text("Home")').click();
```

#### :text-is() Pseudo-Class

**Description:** Matches the smallest element with exact text.

**Matching:** Exact matching is case-sensitive, trims whitespace and searches for the full string.

**Examples:**
- `:text-is("Log")` does NOT match `<button>Log in</button>` because `<button>` contains a single text node "Log in" that is not equal to "Log"
- `:text-is("Log")` DOES match `<button> Log <span>in</span></button>`, because `<button>` contains a text node " Log "
- `:text-is("Download")` will NOT match `<button>download</button>` because it is case-sensitive

#### :text-matches() Pseudo-Class

**Description:** Matches the smallest element with text content matching the JavaScript-like regex.

**Example:** `:text-matches("Log\\s*in", "i")` matches `<button>Login</button>` and `<button>log IN</button>`.

**Note:** Text matching always normalizes whitespace. For example, it turns multiple spaces into one, turns line breaks into spaces and ignores leading and trailing whitespace.

**Note:** Input elements of the type `button` and `submit` are matched by their `value` instead of text content. For example, `:text("Log in")` matches `<input type=button value="Log in">`.

### CSS: Matching Only Visible Elements

**:visible Pseudo-Class:** Playwright supports the `:visible` pseudo class in CSS selectors.

**Example:** `css=button` matches all the buttons on the page, while `css=button:visible` only matches visible buttons.

**Use case:** This is useful to distinguish elements that are very similar but differ in visibility.

```html
<button style='display: none'>Invisible</button>
<button>Visible</button>
```

```typescript
// This will find both buttons and throw a strictness violation error:
await page.locator('button').click();

// This will only find a second button, because it is visible, and then click it.
await page.locator('button:visible').click();
```

### CSS: Elements That Contain Other Elements

**:has() Pseudo-Class:** This is an **experimental CSS pseudo-class**. It returns an element if any of the selectors passed as parameters relative to the `:scope` of the given element match at least one element.

**Example:** Returns text content of an `<article>` element that has a `<div class=promo>` inside.

```typescript
await page.locator('article:has(div.promo)').textContent();
```

### CSS: Elements Matching One of the Conditions

**Comma-separated list:** CSS selectors will match all elements that can be selected by one of the selectors in that list.

```typescript
// Clicks a <button> that has either a "Log in" or "Sign in" text.
await page.locator('button:has-text("Log in"), button:has-text("Sign in")').click();
```

**:is() Pseudo-Class:** This is an **experimental CSS pseudo-class** that may be useful for specifying a list of extra conditions on an element.

### CSS: Matching Elements Based on Layout

**Warning:** Layout selectors are deprecated and may be removed in the future. Matching based on layout may produce unexpected results. For example, a different element could be matched when layout changes by one pixel.

**Recommendation:** We recommend prioritizing user-visible locators instead.

**Use case:** Sometimes, it is hard to come up with a good selector to the target element when it lacks distinctive features. In this case, using Playwright layout CSS pseudo-classes could help.

**Example:** `input:right-of(:text("Password"))` matches an input field that is to the right of text "Password" - useful when the page has multiple inputs that are hard to distinguish between each other.

**Important:** Note that layout pseudo-classes are useful in addition to something else, like `input`. If you use a layout pseudo-class alone, like `:right-of(:text("Password"))`, most likely you'll get not the input you are looking for, but some empty element in between the text and the target input.

**Layout pseudo-classes use bounding client rect** to compute distance and relative position of the elements.

**Available layout pseudo-classes:**
- `:right-of(div > button)` - Matches elements that are to the right of any element matching the inner selector, at any vertical position
- `:left-of(div > button)` - Matches elements that are to the left of any element matching the inner selector, at any vertical position
- `:above(div > button)` - Matches elements that are above any of the elements matching the inner selector, at any horizontal position
- `:below(div > button)` - Matches elements that are below any of the elements matching the inner selector, at any horizontal position
- `:near(div > button)` - Matches elements that are near (within 50 CSS pixels) any of the elements matching the inner selector

**Note:** Resulting matches are sorted by their distance to the anchor element, so you can use `locator.first()` to pick the closest one. This is only useful if you have something like a list of similar elements, where the closest is obviously the right one.

```typescript
// Fill an input to the right of "Username".
await page.locator('input:right-of(:text("Username"))').fill('value');

// Click a button near the promo card.
await page.locator('button:near(.promo-card)').click();

// Click the radio input in the list closest to the "Label 3".
await page.locator('[type=radio]:left-of(:text("Label 3"))').first().click();
```

**Optional maximum pixel distance:** All layout pseudo-classes support optional maximum pixel distance as the last argument. For example `button:near(:text("Username"), 120)` matches a button that is at most 120 CSS pixels away from the element with the text "Username".

### CSS: Pick N-th Match from the Query Result

**Note:** It is usually possible to distinguish elements by some attribute or text content, which is more resilient to page changes.

**Use case:** Sometimes page contains a number of similar elements, and it is hard to select a particular one.

```html
<section> <button>Buy</button> </section>
<article><div> <button>Buy</button> </div></article>
<div><div> <button>Buy</button> </div></div>
```

**:nth-match() Pseudo-Class:** In this case, `:nth-match(:text("Buy"), 3)` will select the third button from the snippet above. Note that index is one-based.

```typescript
// Click the third "Buy" button
await page.locator(':nth-match(:text("Buy"), 3)').click();
```

**:nth-match() with waitFor():** `:nth-match()` is also useful to wait until a specified number of elements appear, using `locator.waitFor()`.

```typescript
// Wait until all three buttons are visible
await page.locator(':nth-match(:text("Buy"), 3)').waitFor();
```

**Note:** Unlike `:nth-child()`, elements do not have to be siblings, they could be anywhere on the page. In the snippet above, all three buttons match `:text("Buy")` selector, and `:nth-match()` selects the third button.

## N-th Element Locator

**You can narrow down query to the n-th match** using the `nth=` locator passing a zero-based index.

```typescript
// Click first button
await page.locator('button').locator('nth=0').click();

// Click last button
await page.locator('button').locator('nth=-1').click();
```

## Parent Element Locator

**When you need to target a parent element** of some other element, most of the time you should `locator.filter()` by the child locator.

**Example DOM structure:**
```html
<li><label>Hello</label></li>
<li><label>World</label></li>
```

**Recommended approach using locator.filter():**
```typescript
const child = page.getByText('Hello');
const parent = page.getByRole('listitem').filter({ has: child });
```

**Alternative using xpath:** If you cannot find a suitable locator for the parent element, use `xpath=...`. Note that this method is not as reliable, because any changes to the DOM structure will break your tests. Prefer `locator.filter()` when possible.

```typescript
const parent = page.getByText('Hello').locator('xpath=..');
```

## React Locator

**Note:** React locator is **experimental** and prefixed with `_`. The functionality might change in future.

**Capability:** React locator allows finding elements by their component name and property values. The syntax is very similar to CSS attribute selectors and supports all CSS attribute selector operators.

**In React locator, component names are transcribed with CamelCase.**

```typescript
await page.locator('_react=BookItem').click();
```

**More examples:**
- `_react=BookItem` - match by component
- `_react=BookItem[author = "Steven King"]` - match by component and exact property value, case-sensitive
- `_react=[author = "steven king" i]` - match by property value only, case-insensitive
- `_react=MyButton[enabled]` - match by component and truthy property value
- `_react=MyButton[enabled = false]` - match by component and boolean value
- `_react=[author *= "King"]` - match by property value substring
- `_react=BookItem[author *= "king" i][year = 1990]` - match by component and multiple properties
- `_react=[some.nested.value = 12]` - match by nested property value
- `_react=BookItem[author ^= "Steven"]` - match by component and property value prefix
- `_react=BookItem[author $= "Steven"]` - match by component and property value suffix
- `_react=BookItem[key = '2']` - match by component and key
- `_react=[author = /Steven(\\s+King)?/i]` - match by property value regex

**To find React element names in a tree** use React DevTools.

**Note:** React locator supports React 15 and above.

**Note:** React locator, as well as React DevTools, only work against unminified application builds.

## Vue Locator

**Note:** Vue locator is **experimental** and prefixed with `_`. The functionality might change in future.

**Capability:** Vue locator allows finding elements by their component name and property values. The syntax is very similar to CSS attribute selectors and supports all CSS attribute selector operators.

**In Vue locator, component names are transcribed with kebab-case.**

```typescript
await page.locator('_vue=book-item').click();
```

**More examples:**
- `_vue=book-item` - match by component
- `_vue=book-item[author = "Steven King"]` - match by component and exact property value, case-sensitive
- `_vue=[author = "steven king" i]` - match by property value only, case-insensitive
- `_vue=my-button[enabled]` - match by component and truthy property value
- `_vue=my-button[enabled = false]` - match by component and boolean value
- `_vue=[author *= "King"]` - match by property value substring
- `_vue=book-item[author *= "king" i][year = 1990]` - match by component and multiple properties
- `_vue=[some.nested.value = 12]` - match by nested property value
- `_vue=book-item[author ^= "Steven"]` - match by component and property value prefix
- `_vue=book-item[author $= "Steven"]` - match by component and property value suffix
- `_vue=[author = /Steven(\\s+King)?/i]` - match by property value regex

**To find Vue element names in a tree** use Vue DevTools.

**Note:** Vue locator supports Vue2 and above.

**Note:** Vue locator, as well as Vue DevTools, only work against unminified application builds.

## XPath Locator

**Warning:** We recommend prioritizing **user-visible locators** like text or accessible role instead of using XPath that is tied to the implementation and easily break when the page changes.

**XPath locators are equivalent to calling `Document.evaluate`.**

```typescript
await page.locator('xpath=//button').click();
```

**Note:** Any selector string starting with `//` or `..` are assumed to be an xpath selector. For example, Playwright converts `'//html/body'` to `'xpath=//html/body'`.

**Note:** XPath does not pierce shadow roots.

### XPath Union

**Pipe operator (`|`)** can be used to specify multiple selectors in XPath. It will match all elements that can be selected by one of the selectors in that list.

```typescript
// Waits for either confirmation dialog or load spinner.
await page.locator(
    `//span[contains(@class, 'spinner__loading')]|//div[@id='confirmation']`
).waitFor();
```

## Label to Form Control Retargeting

**Warning:** We recommend locating by label text instead of relying to label-to-control retargeting.

**Capability:** Targeted input actions in Playwright automatically distinguish between labels and controls, so you can target the label to perform an action on the associated control.

**Example DOM structure:** `<label for="password">Password:</label><input id="password" type="password">`

**You can target the label by its "Password" text** using `page.getByText()`. However, the following actions will be performed on the input instead of the label:

- `locator.click()` will click the label and automatically focus the input field
- `locator.fill()` will fill the input field
- `locator.inputValue()` will return the value of the input field
- `locator.selectText()` will select text in the input field
- `locator.setInputFiles()` will set files for the input field with type=file
- `locator.selectOption()` will select an option from the select box

```typescript
// Fill the input by targeting the label.
await page.getByText('Password').fill('secret');
```

**However, other methods will target the label itself**, for example `expect(locator).toHaveText()` will assert the text content of the label, not the input field.

```typescript
// Fill the input by targeting the label.
await expect(page.locator('label')).toHaveText('Password');
```

## Legacy Text Locator

**Warning:** We recommend the modern text locator instead.

**Legacy text locator matches elements that contain passed text.**

```typescript
await page.locator('text=Log in').click();
```

**Legacy text locator has a few variations:**

### text=Log in (Default)

**Matching:** Case-insensitive, trims whitespace and searches for a substring.

**Example:** `text=Log` matches `<button>Log in</button>`.

```typescript
await page.locator('text=Log in').click();
```

### text="Log in" (Exact Match with Quotes)

**Text body can be escaped with single or double quotes** to search for a text node with exact content after trimming whitespace.

**Example:** `text="Log"` does NOT match `<button>Log in</button>` because `<button>` contains a single text node "Log in" that is not equal to "Log". However, `text="Log"` DOES match `<button> Log <span>in</span></button>`, because `<button>` contains a text node " Log ".

**This exact mode implies case-sensitive matching**, so `text="Download"` will not match `<button>download</button>`.

**Quoted body follows the usual escaping rules**, e.g. use `\"` to escape double quote in a double-quoted string: `text="foo\"bar"`.

```typescript
await page.locator('text="Log in"').click();
```

### /Log\s*in/i (Regex)

**Body can be a JavaScript-like regex wrapped in `/` symbols.**

**Example:** `text=/Log\\s*in/i` matches `<button>Login</button>` and `<button>log IN</button>`.

```typescript
await page.locator('text=/Log\\s*in/i').click();
```

**Note:** String selectors starting and ending with a quote (either `"` or `'`) are assumed to be a legacy text locators. For example, `"Log in"` is converted to `text="Log in"` internally.

**Note:** Matching always normalizes whitespace. For example, it turns multiple spaces into one, turns line breaks into spaces and ignores leading and trailing whitespace.

**Note:** Input elements of the type `button` and `submit` are matched by their `value` instead of text content. For example, `text=Log in` matches `<input type=button value="Log in">`.

## id, data-testid, data-test-id, data-test Selectors

**Warning:** We recommend locating by test id instead.

**Playwright supports shorthand for selecting elements using certain attributes.** Currently, only the following attributes are supported:

- `id`
- `data-testid`
- `data-test-id`
- `data-test`

```typescript
// Fill an input with the id "username"
await page.locator('id=username').fill('value');

// Click an element with data-test-id "submit"
await page.locator('data-test-id=submit').click();
```

**Note:** Attribute selectors are not CSS selectors, so anything CSS-specific like `:enabled` is not supported. For more features, use a proper css selector, e.g. `css=[data-test="login"]:enabled`.

## Chaining Selectors

**Warning:** We recommend chaining locators instead.

**Selectors defined as `engine=body` or in short-form can be combined with the `>>` token**, e.g. `selector1 >> selector2 >> selectors3`. When selectors are chained, the next one is queried relative to the previous one's result.

**Example:**
```typescript
css=article >> css=.bar > .baz >> css=span[attr=value]
```

**is equivalent to:**
```javascript
document
    .querySelector('article')
    .querySelector('.bar > .baz')
    .querySelector('span[attr=value]');
```

**If a selector needs to include `>>` in the body**, it should be escaped inside a string to not be confused with chaining separator, e.g. `text="some >> text"`.

## Intermediate Matches

**Warning:** We recommend filtering by another locator to locate elements that contain other elements.

**By default, chained selectors resolve to an element queried by the last selector.** A selector can be prefixed with `*` to capture elements that are queried by an intermediate selector.

**Example:** `css=article >> text=Hello` captures the element with the text Hello, and `*css=article >> text=Hello` (note the `*`) captures the article element that contains some element with the text Hello.

## Summary

### Key Concepts

**1. CSS locators** - Playwright augments CSS with custom pseudo-classes

**2. Text matching** - Multiple pseudo-classes for text matching (`:has-text()`, `:text()`, `:text-is()`, `:text-matches()`)

**3. Visibility** - `:visible` pseudo-class for visible elements only

**4. Layout selectors** - Deprecated but available (`:right-of()`, `:left-of()`, `:above()`, `:below()`, `:near()`)

**5. React/Vue locators** - Experimental locators for component-based frameworks

**6. XPath locators** - Traditional XPath support (not recommended)

**7. Legacy locators** - Text, id, data-testid selectors (not recommended)

### Best Practices

1. **Prioritize user-visible locators** (getByRole, getByText) over CSS/XPath
2. **Use :visible for visibility** when needed
3. **Avoid layout selectors** (deprecated)
4. **Use locator.filter()** instead of parent locators
5. **Prefer modern locators** over legacy text locators
6. **Use getByTestId()** instead of id/data-testid selectors

### CSS Pseudo-Classes

- `:has-text("text")` - Contains text (substring)
- `:text("text")` - Smallest element with text (substring)
- `:text-is("text")` - Exact text match (case-sensitive)
- `:text-matches("regex", "flags")` - Regex text match
- `:visible` - Only visible elements
- `:has(selector)` - Contains matching element
- `:nth-match(selector, n)` - N-th match (1-based)
- `:right-of()`, `:left-of()`, `:above()`, `:below()`, `:near()` - Layout (deprecated)

### Selector Types

- **CSS:** `css=button` or `button`
- **XPath:** `xpath=//button` or `//button`
- **Text:** `text=Log in` (legacy)
- **ID:** `id=username`
- **Test ID:** `data-testid=submit`
- **React:** `_react=BookItem` (experimental)
- **Vue:** `_vue=book-item` (experimental)
- **N-th:** `nth=0` (zero-based)
- **Chaining:** `css=article >> css=.bar` (not recommended)

### Related Topics

- Locators
- Selectors
- Auto-waiting
- Strictness
- Filtering
- Chaining
- Testing patterns
