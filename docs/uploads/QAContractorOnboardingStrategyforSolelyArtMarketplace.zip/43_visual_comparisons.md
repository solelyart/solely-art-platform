# Playwright Documentation Research - Visual Comparisons

**Page:** Visual comparisons  
**URL:** https://playwright.dev/docs/test-snapshots  
**Research Date:** December 13, 2025

## Introduction

### Feature

**Capability:** Playwright Test includes ability to produce and visually compare screenshots using `await expect(page).toHaveScreenshot()`.

**Process:**
1. On first execution, Playwright test generates reference screenshots
2. Subsequent runs compare against the reference

### Basic Example

```typescript
import { test, expect } from '@playwright/test';

test('example test', async ({ page }) => {
  await page.goto('https://playwright.dev');
  await expect(page).toHaveScreenshot();
});
```

### Important Warning

**Consistency requirement:** Browser rendering can vary based on:
- Host OS
- Version
- Settings
- Hardware
- Power source (battery vs. power adapter)
- Headless mode
- Other factors

**Best practice:** For consistent screenshots, run tests in same environment where baseline screenshots were generated.

## Generating Screenshots

### First Run

**Message on first run:**
```
Error: A snapshot doesn't exist at example.spec.ts-snapshots/example-test-1-chromium-darwin.png, writing actual.
```

**What happens:**
1. No golden file exists yet
2. Method takes screenshots until two consecutive screenshots match
3. Saves last screenshot to file system
4. Ready to be added to repository

### Folder Structure

**Folder naming:** Name starts with test file name.

**Example:**
```
drwxr-xr-x  5 user  group  160 Jun  4 11:46 .
drwxr-xr-x  6 user  group  192 Jun  4 11:45 ..
-rw-r--r--  1 user  group  231 Jun  4 11:16 example.spec.ts
drwxr-xr-x  3 user  group   96 Jun  4 11:46 example.spec.ts-snapshots
```

### Snapshot Naming

**Example name:** `example-test-1-chromium-darwin.png`

**Parts:**

**1. `example-test-1.png`** - Auto-generated snapshot name

**Alternative:** Specify custom name as first argument:
```typescript
await expect(page).toHaveScreenshot('landing.png');
```

**2. `chromium-darwin`** - Browser name and platform

**Reason:** Screenshots differ between browsers and platforms due to:
- Different rendering
- Fonts
- Other factors

**Multiple projects:** If using multiple projects in configuration file, project name used instead of `chromium`.

### Path Configuration

**Customization:** Snapshot name and path can be configured with `testConfig.snapshotPathTemplate` in playwright config.

**Array path segments:**
```typescript
expect().toHaveScreenshot(['relative', 'path', 'to', 'snapshot.png'])
```

**Restriction:** Path must stay within snapshots directory for each test file (e.g., `a.spec.js-snapshots`), otherwise throws error.

## Updating Screenshots

### When to Update

**Reason:** Sometimes need to update reference screenshot when page has changed.

### Command

```bash
npx playwright test --update-snapshots
```

**Effect:** Regenerates all baseline screenshots.

## Options

### maxDiffPixels

**Library:** Playwright Test uses pixelmatch library.

**Purpose:** Pass various options to modify comparison behavior.

**Example:**
```typescript
import { test, expect } from '@playwright/test';

test('example test', async ({ page }) => {
  await page.goto('https://playwright.dev');
  await expect(page).toHaveScreenshot({ maxDiffPixels: 100 });
});
```

**Global configuration:**
```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  expect: {
    toHaveScreenshot: { maxDiffPixels: 100 },
  },
});
```

**Benefit:** Share default value among all tests in project.

### stylePath

**Purpose:** Apply custom stylesheet to page while taking screenshot.

**Benefit:** Filter out dynamic or volatile elements, improving screenshot determinism.

**Example stylesheet:**
```css
/* screenshot.css */
iframe {
  visibility: hidden;
}
```

**Usage in test:**
```typescript
import { test, expect } from '@playwright/test';

test('example test', async ({ page }) => {
  await page.goto('https://playwright.dev');
  await expect(page).toHaveScreenshot({ 
    stylePath: path.join(__dirname, 'screenshot.css') 
  });
});
```

**Global configuration:**
```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  expect: {
    toHaveScreenshot: {
      stylePath: './screenshot.css'
    },
  },
});
```

## Non-Image Snapshots

### Text Snapshots

**Feature:** Use `expect(value).toMatchSnapshot(snapshotName)` to compare text or arbitrary binary data.

**Auto-detection:** Playwright Test auto-detects content type and uses appropriate comparison algorithm.

**Example:**
```typescript
import { test, expect } from '@playwright/test';

test('example test', async ({ page }) => {
  await page.goto('https://playwright.dev');
  expect(await page.textContent('.hero__title')).toMatchSnapshot('hero.txt');
});
```

### Storage

**Location:** Snapshots stored next to test file in separate directory.

**Example:** `my.spec.ts` produces snapshots in `my.spec.ts-snapshots` directory.

**Version control:** Should commit this directory to version control (e.g., git) and review any changes.

## Best Practices

### 1. Use Custom Snapshot Names

**✅ Good:**
```typescript
await expect(page).toHaveScreenshot('homepage-hero.png');
await expect(page).toHaveScreenshot('homepage-footer.png');
```

**❌ Bad:**
```typescript
await expect(page).toHaveScreenshot(); // Auto-generated names
```

**Benefit:** Clear, descriptive names make it easier to identify which screenshot failed.

### 2. Configure maxDiffPixels Globally

**Pattern:**
```typescript
// playwright.config.ts
export default defineConfig({
  expect: {
    toHaveScreenshot: { 
      maxDiffPixels: 100  // Allow small differences
    },
  },
});
```

**Benefit:** Consistent tolerance across all tests.

### 3. Use stylePath to Hide Dynamic Content

**Problem:** Dynamic content causes flaky visual tests.

**Solution:**
```css
/* screenshot.css */
.timestamp { visibility: hidden; }
.live-chat { visibility: hidden; }
.ad-banner { visibility: hidden; }
iframe { visibility: hidden; }
```

```typescript
await expect(page).toHaveScreenshot({ 
  stylePath: './screenshot.css' 
});
```

### 4. Test Components, Not Full Pages

**✅ Good:**
```typescript
test('header component', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('header')).toHaveScreenshot('header.png');
});
```

**Benefit:** Smaller, more focused tests that are less likely to have false positives.

### 5. Generate Baselines in CI

**Pattern:**
```bash
# In CI, generate baselines once
npx playwright test --update-snapshots

# Commit to repository
git add **/*-snapshots
git commit -m "Update visual baselines"
```

**Benefit:** Ensures consistent environment for all baselines.

### 6. Use Text Snapshots for API Responses

**Pattern:**
```typescript
test('API response structure', async ({ request }) => {
  const response = await request.get('/api/artists');
  const data = await response.json();
  expect(JSON.stringify(data, null, 2)).toMatchSnapshot('artists-api.json');
});
```

### 7. Mask Dynamic Elements

**Pattern:**
```typescript
await expect(page).toHaveScreenshot({
  mask: [page.locator('.timestamp'), page.locator('.user-avatar')],
});
```

## Common Use Cases

### Use Case 1: Full Page Visual Regression

```typescript
test('homepage visual regression', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveScreenshot('homepage.png', {
    fullPage: true,
    maxDiffPixels: 100
  });
});
```

### Use Case 2: Component Visual Testing

```typescript
test('button variants', async ({ page }) => {
  await page.goto('/components');
  
  await expect(page.locator('.btn-primary')).toHaveScreenshot('btn-primary.png');
  await expect(page.locator('.btn-secondary')).toHaveScreenshot('btn-secondary.png');
  await expect(page.locator('.btn-disabled')).toHaveScreenshot('btn-disabled.png');
});
```

### Use Case 3: Responsive Design Testing

```typescript
test('responsive homepage', async ({ page }) => {
  await page.goto('/');
  
  // Desktop
  await page.setViewportSize({ width: 1920, height: 1080 });
  await expect(page).toHaveScreenshot('homepage-desktop.png');
  
  // Tablet
  await page.setViewportSize({ width: 768, height: 1024 });
  await expect(page).toHaveScreenshot('homepage-tablet.png');
  
  // Mobile
  await page.setViewportSize({ width: 375, height: 667 });
  await expect(page).toHaveScreenshot('homepage-mobile.png');
});
```

### Use Case 4: Hide Dynamic Content

```typescript
test('page without dynamic content', async ({ page }) => {
  await page.goto('/');
  
  await expect(page).toHaveScreenshot('homepage.png', {
    stylePath: './hide-dynamic.css',
    mask: [
      page.locator('.live-chat'),
      page.locator('.timestamp')
    ]
  });
});
```

### Use Case 5: API Response Snapshots

```typescript
test('artist API response', async ({ request }) => {
  const response = await request.get('/api/artists/123');
  const artist = await response.json();
  
  expect(JSON.stringify(artist, null, 2)).toMatchSnapshot('artist-123.json');
});
```

## Use Cases for Solely Art Platform

### Example 1: Artist Profile Visual Regression

```typescript
test('artist profile visual test', async ({ page }) => {
  await page.goto('/artist/123');
  
  // Full page screenshot
  await expect(page).toHaveScreenshot('artist-profile-full.png', {
    fullPage: true,
    maxDiffPixels: 200  // Allow for small rendering differences
  });
  
  // Component screenshots
  await expect(page.locator('.artist-header')).toHaveScreenshot('artist-header.png');
  await expect(page.locator('.portfolio-grid')).toHaveScreenshot('portfolio-grid.png');
  await expect(page.locator('.booking-widget')).toHaveScreenshot('booking-widget.png');
});
```

### Example 2: Booking Flow Visual Testing

```typescript
test('booking flow screens', async ({ page }) => {
  await page.goto('/artist/123');
  
  // Step 1: Initial state
  await expect(page).toHaveScreenshot('booking-step1-initial.png');
  
  // Step 2: Date selection
  await page.getByRole('button', { name: 'Book Now' }).click();
  await expect(page).toHaveScreenshot('booking-step2-date-selection.png');
  
  // Step 3: Time selection
  await page.getByLabel('Date').fill('2025-01-15');
  await expect(page).toHaveScreenshot('booking-step3-time-selection.png');
  
  // Step 4: Confirmation
  await page.getByLabel('Time').selectOption('14:00');
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page).toHaveScreenshot('booking-step4-confirmation.png');
});
```

### Example 3: Hide Dynamic Content

```css
/* screenshot.css for Solely Art Platform */
.timestamp { visibility: hidden; }
.live-indicator { visibility: hidden; }
.user-avatar { visibility: hidden; }
.message-time { visibility: hidden; }
.booking-countdown { visibility: hidden; }
iframe { visibility: hidden; }
```

```typescript
test('artist profile without dynamic content', async ({ page }) => {
  await page.goto('/artist/123');
  
  await expect(page).toHaveScreenshot('artist-profile-stable.png', {
    stylePath: './screenshot.css'
  });
});
```

### Example 4: Responsive Artist Cards

```typescript
test('artist card responsive', async ({ page }) => {
  await page.goto('/artists');
  
  const artistCard = page.locator('.artist-card').first();
  
  // Desktop
  await page.setViewportSize({ width: 1920, height: 1080 });
  await expect(artistCard).toHaveScreenshot('artist-card-desktop.png');
  
  // Tablet
  await page.setViewportSize({ width: 768, height: 1024 });
  await expect(artistCard).toHaveScreenshot('artist-card-tablet.png');
  
  // Mobile
  await page.setViewportSize({ width: 375, height: 667 });
  await expect(artistCard).toHaveScreenshot('artist-card-mobile.png');
});
```

### Example 5: API Response Snapshots

```typescript
test('artist API response structure', async ({ request }) => {
  const response = await request.get('/api/artists/123');
  const artist = await response.json();
  
  // Snapshot of API response
  expect(JSON.stringify(artist, null, 2)).toMatchSnapshot('artist-api-response.json');
});

test('booking availability API', async ({ request }) => {
  const response = await request.get('/api/artists/123/availability?date=2025-01-15');
  const availability = await response.json();
  
  expect(JSON.stringify(availability, null, 2)).toMatchSnapshot('availability-api.json');
});
```

### Example 6: Error States Visual Testing

```typescript
test('error states', async ({ page }) => {
  await page.goto('/booking');
  
  // Trigger validation errors
  await page.getByRole('button', { name: 'Submit' }).click();
  
  await expect(page).toHaveScreenshot('booking-validation-errors.png');
});

test('404 page', async ({ page }) => {
  await page.goto('/nonexistent-page');
  await expect(page).toHaveScreenshot('404-page.png');
});
```

## Advanced Patterns

### Pattern 1: Threshold Configuration by Environment

```typescript
// playwright.config.ts
export default defineConfig({
  expect: {
    toHaveScreenshot: { 
      maxDiffPixels: process.env.CI ? 100 : 0  // Stricter locally
    },
  },
});
```

### Pattern 2: Project-Specific Thresholds

```typescript
export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: { 
        ...devices['Desktop Chrome'],
      },
      expect: {
        toHaveScreenshot: { maxDiffPixels: 100 }
      }
    },
    {
      name: 'webkit',
      use: { 
        ...devices['Desktop Safari'],
      },
      expect: {
        toHaveScreenshot: { maxDiffPixels: 200 }  // More lenient for WebKit
      }
    },
  ],
});
```

### Pattern 3: Conditional Snapshot Updates

```typescript
test('conditional update', async ({ page }) => {
  await page.goto('/');
  
  const updateSnapshots = process.env.UPDATE_SNAPSHOTS === 'true';
  
  if (updateSnapshots) {
    // Generate new baseline
    await page.screenshot({ path: 'baseline.png' });
  } else {
    // Compare against baseline
    await expect(page).toHaveScreenshot('baseline.png');
  }
});
```

### Pattern 4: Snapshot with Animations Disabled

```typescript
test('stable screenshot', async ({ page }) => {
  await page.goto('/');
  
  await expect(page).toHaveScreenshot('homepage.png', {
    animations: 'disabled',  // Disable CSS animations
    caret: 'hide'            // Hide text caret
  });
});
```

## Configuration Options

### Global Configuration

```typescript
// playwright.config.ts
export default defineConfig({
  expect: {
    toHaveScreenshot: {
      maxDiffPixels: 100,
      threshold: 0.2,
      animations: 'disabled',
      caret: 'hide',
      scale: 'css',
      stylePath: './screenshot.css'
    },
  },
});
```

### Per-Test Configuration

```typescript
await expect(page).toHaveScreenshot('homepage.png', {
  maxDiffPixels: 100,
  threshold: 0.2,
  fullPage: true,
  animations: 'disabled',
  caret: 'hide',
  mask: [page.locator('.dynamic')],
  stylePath: './screenshot.css'
});
```

## Troubleshooting

### Issue: Screenshots Always Fail

**Cause:** Running tests in different environments.

**Solution:** Run tests in same environment where baselines were generated, or use Docker for consistency.

### Issue: Small Pixel Differences

**Cause:** Font rendering, anti-aliasing differences.

**Solution:** Increase `maxDiffPixels` threshold.
```typescript
await expect(page).toHaveScreenshot({ maxDiffPixels: 100 });
```

### Issue: Dynamic Content Causes Failures

**Cause:** Timestamps, live data, ads.

**Solution:** Use `stylePath` to hide dynamic content or `mask` option.

### Issue: Need to Update All Baselines

**Command:**
```bash
npx playwright test --update-snapshots
```

## Summary

### Key Concepts

**1. Visual regression:** Compare screenshots against reference baselines

**2. First run:** Generates reference screenshots

**3. Subsequent runs:** Compare against reference

**4. Update command:** `--update-snapshots` flag

**5. Consistency:** Run in same environment for reliable results

### Main Methods

- `expect(page).toHaveScreenshot()` - Visual comparison
- `expect(value).toMatchSnapshot()` - Text/binary comparison

### Key Options

- `maxDiffPixels` - Pixel difference threshold
- `stylePath` - Custom CSS to hide dynamic content
- `mask` - Mask specific elements
- `fullPage` - Capture full scrollable page
- `animations` - Control animations
- `caret` - Control text caret

### Best Practices

1. Use custom snapshot names
2. Configure maxDiffPixels globally
3. Use stylePath to hide dynamic content
4. Test components, not full pages
5. Generate baselines in CI
6. Use text snapshots for API responses
7. Mask dynamic elements

## Related Topics

- Screenshots
- Test assertions
- Visual testing
- Test configuration
- CI/CD integration
- Pixelmatch library
- Test artifacts
