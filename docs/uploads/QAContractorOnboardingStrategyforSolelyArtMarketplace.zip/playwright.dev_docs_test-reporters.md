
The report file name looks like report-<hash>.zip or report-<hash>-<shard_number>.zip when sharding is used. The hash is an optional value computed from --grep, --grepInverted, --project, testConfig.tag and file filters passed as command line arguments. The hash guarantees that running Playwright with different command line options will produce different but stable between runs report names. The output file name can be overridden in the configuration file or passed as 'PLAYWRIGHT_BLOB_OUTPUT_FILE' environment variable.

Shards
Environments

When using blob report to merge multiple shards, you don't have to pass any options.

playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: 'blob',
});


Blob report supports following configuration options and environment variables:

Environment Variable Name	Reporter Config Option	Description	Default
PLAYWRIGHT_BLOB_OUTPUT_DIR	outputDir	Directory to save the output. Existing content is deleted before writing the new report.	blob-report
PLAYWRIGHT_BLOB_OUTPUT_NAME	fileName	Report file name.	report-<project>-<hash>-<shard_number>.zip
PLAYWRIGHT_BLOB_OUTPUT_FILE	outputFile	Full path to the output file. If defined, outputDir and fileName will be ignored.	undefined
JSON reporter​

JSON reporter produces an object with all information about the test run.

Most likely you want to write the JSON to a file. When running with --reporter=json, use PLAYWRIGHT_JSON_OUTPUT_NAME environment variable:

Bash
PowerShell
Batch
PLAYWRIGHT_JSON_OUTPUT_NAME=results.json npx playwright test --reporter=json


In configuration file, pass options directly:

playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['json', { outputFile: 'results.json' }]],
});


JSON report supports following configuration options and environment variables:

Environment Variable Name	Reporter Config Option	Description	Default
PLAYWRIGHT_JSON_OUTPUT_DIR		Directory to save the output file. Ignored if output file is specified.	cwd or config directory.
PLAYWRIGHT_JSON_OUTPUT_NAME	outputFile	Base file name for the output, relative to the output dir.	JSON report is printed to the stdout.
PLAYWRIGHT_JSON_OUTPUT_FILE	outputFile	Full path to the output file. If defined, PLAYWRIGHT_JSON_OUTPUT_DIR and PLAYWRIGHT_JSON_OUTPUT_NAME will be ignored.	JSON report is printed to the stdout.
JUnit reporter​

JUnit reporter produces a JUnit-style xml report.

Most likely you want to write the report to an xml file. When running with --reporter=junit, use PLAYWRIGHT_JUNIT_OUTPUT_NAME environment variable:

Bash
PowerShell
Batch
PLAYWRIGHT_JUNIT_OUTPUT_NAME=results.xml npx playwright test --reporter=junit


In configuration file, pass options directly:

playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['junit', { outputFile: 'results.xml' }]],
});


JUnit report supports following configuration options and environment variables:

Environment Variable Name	Reporter Config Option	Description	Default
PLAYWRIGHT_JUNIT_OUTPUT_DIR		Directory to save the output file. Ignored if output file is not specified.	cwd or config directory.
PLAYWRIGHT_JUNIT_OUTPUT_NAME	outputFile	Base file name for the output, relative to the output dir.	JUnit report is printed to the stdout.
PLAYWRIGHT_JUNIT_OUTPUT_FILE	outputFile	Full path to the output file. If defined, PLAYWRIGHT_JUNIT_OUTPUT_DIR and PLAYWRIGHT_JUNIT_OUTPUT_NAME will be ignored.	JUnit report is printed to the stdout.
PLAYWRIGHT_JUNIT_STRIP_ANSI	stripANSIControlSequences	Whether to remove ANSI control sequences from the text before writing it in the report.	By default output text is added as is.
PLAYWRIGHT_JUNIT_INCLUDE_PROJECT_IN_TEST_NAME	includeProjectInTestName	Whether to include Playwright project name in every test case as a name prefix.	By default not included.
PLAYWRIGHT_JUNIT_SUITE_ID		Value of the id attribute on the root <testsuites/> report entry.	Empty string.
PLAYWRIGHT_JUNIT_SUITE_NAME		Value of the name attribute on the root <testsuites/> report entry.	Empty string.
GitHub Actions annotations​

You can use the built in github reporter to get automatic failure annotations when running in GitHub actions.

Note that all other reporters work on GitHub Actions as well, but do not provide annotations. Also, it is not recommended to use this annotation type if running your tests with a matrix strategy as the stack trace failures will multiply and obscure the GitHub file view.

playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // 'github' for GitHub Actions CI to generate annotations, plus a concise 'dot'
  // default 'list' when running locally
  reporter: process.env.CI ? 'github' : 'list',
});

Custom reporters​

You can create a custom reporter by implementing a class with some of the reporter methods. Learn more about the Reporter API.

my-awesome-reporter.ts
import type {
  FullConfig, FullResult, Reporter, Suite, TestCase, TestResult
} from '@playwright/test/reporter';

class MyReporter implements Reporter {
  onBegin(config: FullConfig, suite: Suite) {
    console.log(`Starting the run with ${suite.allTests().length} tests`);
  }

  onTestBegin(test: TestCase, result: TestResult) {
    console.log(`Starting test ${test.title}`);
  }

  onTestEnd(test: TestCase, result: TestResult) {
    console.log(`Finished test ${test.title}: ${result.status}`);
  }

  onEnd(result: FullResult) {
    console.log(`Finished the run: ${result.status}`);
  }
}

export default MyReporter;


Now use this reporter with testConfig.reporter.

playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: './my-awesome-reporter.ts',
});


Or just pass the reporter file path as --reporter command line option:

npx playwright test --reporter="./myreporter/my-awesome-reporter.ts"


Here's a short list of open source reporter implementations that you can take a look at when writing your own reporter:

Allure Reporter
Github Actions Reporter
Mail Reporter
ReportPortal
Monocart
Previous
Projects
Next
Retries
Introduction
Multiple reporters
Reporters on CI
Built-in reporters
List reporter
Line reporter
Dot reporter
HTML reporter
Blob reporter
JSON reporter
JUnit reporter
GitHub Actions annotations
Custom reporters
Learn
Getting started
Playwright Training
Learn Videos
Feature Videos
Community
Stack Overflow
Discord
Twitter
LinkedIn
More
GitHub
YouTube
Blog
Ambassadors
Copyright © 2025 Microsoft