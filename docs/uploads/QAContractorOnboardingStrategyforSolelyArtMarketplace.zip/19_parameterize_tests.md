# Playwright Documentation Research - Parameterize Tests

**Page:** Parameterize tests  
**URL:** https://playwright.dev/docs/test-parameterize  
**Research Date:** December 13, 2025

## Overview

Playwright supports test parameterization at two levels:
1. **Test level** - Using forEach to generate multiple test cases
2. **Project level** - Using projects with different configurations

## Parameterized Tests

Generate multiple test cases from an array of data using `forEach`.

### Basic Pattern

```typescript
// example.spec.ts
[
  { name: 'Alice', expected: 'Hello, Alice!' },
  { name: 'Bob', expected: 'Hello, Bob!' },
  { name: 'Charlie', expected: 'Hello, Charlie!' },
].forEach(({ name, expected }) => {
  // You can also do it with test.describe() or with multiple tests 
  // as long as the test name is unique
  test(`testing with ${name}`, async ({ page }) => {
    await page.goto(`https://example.com/greet?name=${name}`);
    await expect(page.getByRole('heading')).toHaveText(expected);
  });
});
```

**Key points:**
- Each iteration creates a separate test
- Test names must be unique
- Can use with `test()` or `test.describe()`

## Before and After Hooks

### Hooks Outside forEach (Recommended)

Most of the time, put hooks outside `forEach` so they execute just once:

```typescript
// example.spec.ts
test.beforeEach(async ({ page }) => {
  // Runs once before each test
});

test.afterEach(async ({ page }) => {
  // Runs once after each test
});

[
  { name: 'Alice', expected: 'Hello, Alice!' },
  { name: 'Bob', expected: 'Hello, Bob!' },
  { name: 'Charlie', expected: 'Hello, Charlie!' },
].forEach(({ name, expected }) => {
  test(`testing with ${name}`, async ({ page }) => {
    await page.goto(`https://example.com/greet?name=${name}`);
    await expect(page.getByRole('heading')).toHaveText(expected);
  });
});
```

### Hooks Inside forEach

If you want hooks for each iteration, put them inside a `describe()`:

```typescript
// example.spec.ts
[
  { name: 'Alice', expected: 'Hello, Alice!' },
  { name: 'Bob', expected: 'Hello, Bob!' },
  { name: 'Charlie', expected: 'Hello, Charlie!' },
].forEach(({ name, expected }) => {
  test.describe(() => {
    test.beforeEach(async ({ page }) => {
      await page.goto(`https://example.com/greet?name=${name}`);
    });
    
    test(`testing with ${expected}`, async ({ page }) => {
      await expect(page.getByRole('heading')).toHaveText(expected);
    });
  });
});
```

## Parameterized Projects

Run multiple test projects with different configurations using custom options.

### Step 1: Define Custom Option

Create a custom test with options:

```typescript
// my-test.ts
import { test as base } from '@playwright/test';

export type TestOptions = {
  person: string;
};

export const test = base.extend<TestOptions>({
  // Define an option and provide a default value
  // We can later override it in the config
  person: ['John', { option: true }],
});
```

### Step 2: Use Option in Test

```typescript
// example.spec.ts
import { test } from './my-test';

test('test 1', async ({ page, person }) => {
  await page.goto(`/index.html`);
  await expect(page.locator('#node')).toContainText(person);
  // ...
});
```

### Step 3: Configure Projects

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';
import type { TestOptions } from './my-test';

export default defineConfig<TestOptions>({
  projects: [
    {
      name: 'alice',
      use: { person: 'Alice' },
    },
    {
      name: 'bob',
      use: { person: 'Bob' },
    },
  ]
});
```

**Result:** All tests run twice - once with `person: 'Alice'` and once with `person: 'Bob'`.

## Using Options in Fixtures

Options can be used within fixtures to customize fixture behavior:

```typescript
// my-test.ts
import { test as base } from '@playwright/test';

export type TestOptions = {
  person: string;
};

export const test = base.extend<TestOptions>({
  // Define an option and provide a default value
  person: ['John', { option: true }],
  
  // Override default "page" fixture
  page: async ({ page, person }, use) => {
    await page.goto('/chat');
    // We use "person" parameter as a "name" for the chat room
    await page.getByLabel('User Name').fill(person);
    await page.getByText('Enter chat room').click();
    // Each test will get a "page" that already has the person name
    await use(page);
  },
});
```

**Benefits:**
- Fixture setup uses the option value
- Tests automatically get customized fixtures
- Clean separation of concerns

## Passing Environment Variables

Use environment variables to configure tests from the command line.

### Basic Usage

```typescript
// example.spec.ts
test(`example test`, async ({ page }) => {
  // ...
  await page.getByLabel('User Name').fill(process.env.USER_NAME);
  await page.getByLabel('Password').fill(process.env.PASSWORD);
});
```

**Run with environment variables:**
```bash
USER_NAME=me PASSWORD=secret npx playwright test
```

### Environment Variables in Config

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    baseURL: process.env.STAGING === '1' 
      ? 'http://staging.example.test/' 
      : 'http://example.test/',
  }
});
```

**Run against different environments:**
```bash
# Production
npx playwright test

# Staging
STAGING=1 npx playwright test
```

## Using .env Files

Use `.env` files with the `dotenv` package for easier environment variable management.

### Install dotenv

```bash
npm install dotenv
```

### Configure in playwright.config.ts

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';
import dotenv from 'dotenv';
import path from 'path';

// Read from ".env" file
dotenv.config({ path: path.resolve(__dirname, '.env') });

// Alternatively, read from "../my.env" file
dotenv.config({ path: path.resolve(__dirname, '..', 'my.env') });

export default defineConfig({
  use: {
    baseURL: process.env.STAGING === '1' 
      ? 'http://staging.example.test/' 
      : 'http://example.test/',
  }
});
```

### Create .env File

```
# .env file
STAGING=0
USER_NAME=me
PASSWORD=secret
```

### Run Tests

```bash
npx playwright test
```

Environment variables are automatically picked up from the `.env` file.

## Create Tests via a CSV File

Read CSV files and generate tests dynamically using Node.js file system and CSV parsing libraries.

### Example CSV File

```csv
# input.csv
"test_case","some_value","some_other_value"
"value 1","value 11","foobar1"
"value 2","value 22","foobar21"
"value 3","value 33","foobar321"
"value 4","value 44","foobar4321"
```

### Install CSV Parser

```bash
npm install csv-parse
```

### Generate Tests from CSV

```typescript
// test.spec.ts
import fs from 'fs';
import path from 'path';
import { test } from '@playwright/test';
import { parse } from 'csv-parse/sync';

const records = parse(fs.readFileSync(path.join(__dirname, 'input.csv')), {
  columns: true,
  skip_empty_lines: true
});

for (const record of records) {
  test(`foo: ${record.test_case}`, async ({ page }) => {
    console.log(record.test_case, record.some_value, record.some_other_value);
  });
}
```

**Result:** One test generated for each row in the CSV file.

## Best Practices

### 1. Use Unique Test Names

Ensure each parameterized test has a unique name:
```typescript
test(`testing with ${name}`, async ({ page }) => {
  // Test name includes parameter for uniqueness
});
```

### 2. Keep Hooks Outside forEach

For better performance, place hooks outside the forEach loop:
```typescript
test.beforeEach(async ({ page }) => {
  // Runs once per test
});

data.forEach(item => {
  test(`test ${item.name}`, async ({ page }) => {
    // Test code
  });
});
```

### 3. Use Projects for Configuration Variants

For different configurations (browsers, viewports, users), use projects:
```typescript
projects: [
  { name: 'desktop', use: { viewport: { width: 1280, height: 720 } } },
  { name: 'mobile', use: { viewport: { width: 375, height: 667 } } },
]
```

### 4. Use .env Files for Secrets

Never commit secrets to source control:
```typescript
// .env (add to .gitignore)
API_KEY=secret123
DATABASE_URL=postgres://...
```

### 5. Validate Environment Variables

Check required environment variables early:
```typescript
if (!process.env.API_KEY) {
  throw new Error('API_KEY environment variable is required');
}
```

### 6. Use TypeScript for Type Safety

Define types for your options:
```typescript
export type TestOptions = {
  person: string;
  role: 'admin' | 'user' | 'guest';
};
```

### 7. Document Required Environment Variables

Add comments or README documentation:
```typescript
// Required environment variables:
// - USER_NAME: Test user name
// - PASSWORD: Test user password
// - STAGING: Set to '1' for staging environment
```

### 8. Use CSV for Large Datasets

For extensive test data, use CSV files:
- Easier to maintain
- Can be edited by non-developers
- Separates test data from test logic

### 9. Consider JSON for Complex Data

For nested or complex data structures, use JSON:
```typescript
import testData from './test-data.json';

testData.forEach(data => {
  test(`test ${data.name}`, async ({ page }) => {
    // Use data.nested.property
  });
});
```

### 10. Use Fixtures for Shared Setup

Combine options with fixtures for reusable setup:
```typescript
export const test = base.extend<TestOptions>({
  authenticatedPage: async ({ page, person }, use) => {
    await page.goto('/login');
    await login(page, person);
    await use(page);
  },
});
```

## Common Patterns

### Multiple Browser Testing

```typescript
['chromium', 'firefox', 'webkit'].forEach(browserName => {
  test(`test on ${browserName}`, async ({ page }) => {
    // Test runs on each browser
  });
});
```

### Multiple Viewport Testing

```typescript
[
  { width: 1920, height: 1080, name: 'desktop' },
  { width: 768, height: 1024, name: 'tablet' },
  { width: 375, height: 667, name: 'mobile' },
].forEach(({ width, height, name }) => {
  test(`test on ${name}`, async ({ page }) => {
    await page.setViewportSize({ width, height });
    // Test code
  });
});
```

### Multiple User Roles

```typescript
// my-test.ts
export type TestOptions = {
  userRole: 'admin' | 'user' | 'guest';
};

export const test = base.extend<TestOptions>({
  userRole: ['user', { option: true }],
});

// playwright.config.ts
projects: [
  { name: 'admin', use: { userRole: 'admin' } },
  { name: 'user', use: { userRole: 'user' } },
  { name: 'guest', use: { userRole: 'guest' } },
]
```

### API Endpoint Testing

```typescript
const endpoints = [
  { path: '/api/users', method: 'GET' },
  { path: '/api/posts', method: 'GET' },
  { path: '/api/comments', method: 'GET' },
];

endpoints.forEach(({ path, method }) => {
  test(`${method} ${path}`, async ({ request }) => {
    const response = await request[method.toLowerCase()](path);
    expect(response.ok()).toBeTruthy();
  });
});
```

### Localization Testing

```typescript
// playwright.config.ts
projects: [
  { name: 'en-US', use: { locale: 'en-US' } },
  { name: 'es-ES', use: { locale: 'es-ES' } },
  { name: 'fr-FR', use: { locale: 'fr-FR' } },
]
```

## Related Topics to Explore

- Projects configuration
- Fixtures
- Test configuration
- Environment variables
- Data-driven testing
- Test organization
- CI/CD integration
- Test data management
