# Screenshots | Playwright

**URL:** https://playwright.dev/docs/screenshots

---

Skip to main content
Playwright
Docs
API
Node.js
Community
Search
⌘
K
Getting Started
Installation
Writing tests
Generating tests
Running and debugging tests
Trace viewer
Setting up CI
Getting started - VS Code
Release notes
Canary releases
Playwright Test
Agents
Annotations
Command line
Configuration
Configuration (use)
Emulation
Fixtures
Global setup and teardown
Parallelism
Parameterize tests
Projects
Reporters
Retries
Sharding
Timeouts
TypeScript
UI Mode
Web server
Guides
Library
Accessibility testing
Actions
Assertions
API testing
Authentication
Auto-waiting
Best Practices
Browsers
Chrome extensions
Clock
Components (experimental)
Debugging Tests
Dialogs
Downloads
Evaluating JavaScript
Events
Extensibility
Frames
Handles
Isolation
Locators
Mock APIs
Mock browser APIs
Navigations
Network
Other locators
Pages
Page object models
Screenshots
Service Workers
Snapshot testing
Test generator
Touch events (legacy)
Trace viewer
Videos
Visual comparisons
WebView2
Migration
Integrations
Supported languages
GuidesScreenshots
Screenshots
Introduction​

Here is a quick way to capture a screenshot and save it into a file:

await page.screenshot({ path: 'screenshot.png' });


Screenshots API accepts many parameters for image format, clip area, quality, etc. Make sure to check them out.

Full page screenshots​

Full page screenshot is a screenshot of a full scrollable page, as if you had a very tall screen and the page could fit it entirely.

await page.screenshot({ path: 'screenshot.png', fullPage: true });

Capture into buffer​

Rather than writing into a file, you can get a buffer with the image and post-process it or pass it to a third party pixel diff facility.

const buffer = await page.screenshot();
console.log(buffer.toString('base64'));

Element screenshot​

Sometimes it is useful to take a screenshot of a single element.

await page.locator('.header').screenshot({ path: 'screenshot.png' });

Previous
Page object models
Next
Service Workers
Introduction
Full page screenshots
Capture into buffer
Element screenshot
Learn
Getting started
Playwright Training
Learn Videos
Feature Videos
Community
Stack Overflow
Discord
Twitter
LinkedIn
More
GitHub
YouTube
Blog
Ambassadors
Copyright © 2025 Microsoft