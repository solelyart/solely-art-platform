# Playwright Documentation Research - Mock Browser APIs

**Page:** Mock browser APIs  
**URL:** https://playwright.dev/docs/mock-browser-apis  
**Research Date:** December 14, 2025

## Introduction

**Context:** Playwright provides native support for most browser features. However, there are some:
- Experimental APIs
- APIs which are not (yet) fully supported by all browsers

**Playwright's approach:** Playwright usually doesn't provide dedicated automation APIs in such cases.

**Solution:** You can use **mocks** to test behavior of your application in such cases.

**Example:** This guide uses battery API example - mock battery API and check that page correctly displays battery status.

## Creating Mocks

**Timing consideration:** Since page may be calling API very early while loading, it's important to setup all mocks **before page started loading**.

**Method:** The easiest way to achieve that is to call `page.addInitScript()`.

### Basic Mock Example

```typescript
await page.addInitScript(() => {
  const mockBattery = {
    level: 0.75,
    charging: true,
    chargingTime: 1800,
    dischargingTime: Infinity,
    addEventListener: () => { }
  };
  // Override the method to always return mock battery info.
  window.navigator.getBattery = async () => mockBattery;
});
```

### Complete Test Example

**Once mocks are set up**, you can navigate page and check its UI state:

```typescript
// Configure mock API before each test.
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    const mockBattery = {
      level: 0.90,
      charging: true,
      chargingTime: 1800, // seconds
      dischargingTime: Infinity,
      addEventListener: () => { }
    };
    // Override the method to always return mock battery info.
    window.navigator.getBattery = async () => mockBattery;
  });
});

test('show battery status', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('.battery-percentage')).toHaveText('90%');
  await expect(page.locator('.battery-status')).toHaveText('Adapter');
  await expect(page.locator('.battery-fully')).toHaveText('00:30');
});
```

## Mocking Read-Only APIs

**Problem:** Some APIs are read-only so you won't be able to assign to navigator property.

**Example of what doesn't work:**
```typescript
// Following line will have no effect.
navigator.cookieEnabled = true;
```

**Solution:** However, if property is **configurable**, you can still override it using plain JavaScript:

```typescript
await page.addInitScript(() => {
  Object.defineProperty(Object.getPrototypeOf(navigator), 'cookieEnabled', { value: false });
});
```

## Verifying API Calls

**Use case:** Sometimes it is useful to check if page made all expected APIs calls.

**Approach:** You can record all API method invocations and then compare them with golden result.

**Tool:** `page.exposeFunction()` may come in handy for passing message from page back to test code.

### Example: Logging API Calls

```typescript
test('log battery calls', async ({ page }) => {
  const log = [];
  // Expose function for pushing messages to the Node.js script.
  await page.exposeFunction('logCall', msg => log.push(msg));
  await page.addInitScript(() => {
    const mockBattery = {
      level: 0.75,
      charging: true,
      chargingTime: 1800,
      dischargingTime: Infinity,
      // Log addEventListener calls.
      addEventListener: (name, cb) => logCall(`addEventListener:${name}`)
    };
    // Override the method to always return mock battery info.
    window.navigator.getBattery = async () => {
      logCall('getBattery');
      return mockBattery;
    };
  });

  await page.goto('/');
  await expect(page.locator('.battery-percentage')).toHaveText('75%');

  // Compare actual calls with golden.
  expect(log).toEqual([
    'getBattery',
    'addEventListener:chargingchange',
    'addEventListener:levelchange'
  ]);
});
```

## Updating Mock

**Use case:** To test that app correctly reflects battery status updates, it's important to make sure that mock battery object fires same events that browser implementation would.

### Example: Dynamic Mock Updates

```typescript
test('update battery status (no golden)', async ({ page }) => {
  await page.addInitScript(() => {
    // Mock class that will notify corresponding listeners when battery status changes.
    class BatteryMock {
      level = 0.10;
      charging = false;
      chargingTime = 1800;
      dischargingTime = Infinity;
      _chargingListeners = [];
      _levelListeners = [];
      addEventListener(eventName, listener) {
        if (eventName === 'chargingchange')
          this._chargingListeners.push(listener);
        if (eventName === 'levelchange')
          this._levelListeners.push(listener);
      }
      // Will be called by the test.
      _setLevel(value) {
        this.level = value;
        this._levelListeners.forEach(cb => cb());
      }
      _setCharging(value) {
        this.charging = value;
        this._chargingListeners.forEach(cb => cb());
      }
    }
    const mockBattery = new BatteryMock();
    // Override the method to always return mock battery info.
    window.navigator.getBattery = async () => mockBattery;
    // Save the mock object on window for easier access.
    window.mockBattery = mockBattery;
  });

  await page.goto('/');
  await expect(page.locator('.battery-percentage')).toHaveText('10%');

  // Update level to 27.5%
  await page.evaluate(() => window.mockBattery._setLevel(0.275));
  await expect(page.locator('.battery-percentage')).toHaveText('27.5%');
  await expect(page.locator('.battery-status')).toHaveText('Battery');

  // Emulate connected adapter
  await page.evaluate(() => window.mockBattery._setCharging(true));
  await expect(page.locator('.battery-status')).toHaveText('Adapter');
  await expect(page.locator('.battery-fully')).toHaveText('00:30');
});
```

## Best Practices

### 1. Setup Mocks in beforeEach

**✅ Good:**
```typescript
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    window.mockAPI = { /* mock implementation */ };
  });
});

test('test', async ({ page }) => {
  await page.goto('/');
  // Mock is ready
});
```

### 2. Use addInitScript for Early APIs

**✅ Good:**
```typescript
await page.addInitScript(() => {
  // Mock will be available before page loads
  window.navigator.getBattery = async () => mockBattery;
});
await page.goto('/');
```

**❌ Bad:**
```typescript
await page.goto('/');
await page.evaluate(() => {
  // Too late - page may have already called the API
  window.navigator.getBattery = async () => mockBattery;
});
```

### 3. Use Object.defineProperty for Read-Only Properties

**✅ Good:**
```typescript
await page.addInitScript(() => {
  Object.defineProperty(Object.getPrototypeOf(navigator), 'cookieEnabled', {
    value: false
  });
});
```

### 4. Expose Functions for Verification

**✅ Good:**
```typescript
const calls = [];
await page.exposeFunction('trackCall', call => calls.push(call));
await page.addInitScript(() => {
  window.originalAPI = window.someAPI;
  window.someAPI = (...args) => {
    trackCall({ method: 'someAPI', args });
    return window.originalAPI(...args);
  };
});
```

### 5. Create Mock Classes for Complex APIs

**✅ Good:**
```typescript
await page.addInitScript(() => {
  class GeolocationMock {
    _position = { lat: 37.7749, lng: -122.4194 };
    _listeners = [];
    
    getCurrentPosition(success) {
      success(this._position);
    }
    
    watchPosition(success) {
      this._listeners.push(success);
      return this._listeners.length - 1;
    }
    
    clearWatch(id) {
      delete this._listeners[id];
    }
    
    _updatePosition(pos) {
      this._position = pos;
      this._listeners.forEach(cb => cb && cb(pos));
    }
  }
  
  window.mockGeolocation = new GeolocationMock();
  navigator.geolocation = window.mockGeolocation;
});
```

## Common Use Cases

### Use Case 1: Mock Geolocation

```typescript
test('mock geolocation', async ({ page }) => {
  await page.addInitScript(() => {
    const mockGeolocation = {
      getCurrentPosition: (success) => {
        success({
          coords: {
            latitude: 37.7749,
            longitude: -122.4194,
            accuracy: 100
          }
        });
      }
    };
    navigator.geolocation = mockGeolocation;
  });

  await page.goto('/');
  await page.click('#get-location');
  await expect(page.locator('.location')).toHaveText('San Francisco');
});
```

### Use Case 2: Mock Date/Time

```typescript
test('mock date', async ({ page }) => {
  await page.addInitScript(() => {
    const mockDate = new Date('2025-01-15T12:00:00Z');
    Date = class extends Date {
      constructor(...args) {
        if (args.length === 0) {
          super(mockDate);
        } else {
          super(...args);
        }
      }
      static now() {
        return mockDate.getTime();
      }
    };
  });

  await page.goto('/');
  await expect(page.locator('.current-date')).toHaveText('January 15, 2025');
});
```

### Use Case 3: Mock Local Storage

```typescript
test('mock localStorage', async ({ page }) => {
  await page.addInitScript(() => {
    const mockStorage = {
      data: {},
      getItem(key) {
        return this.data[key] || null;
      },
      setItem(key, value) {
        this.data[key] = String(value);
      },
      removeItem(key) {
        delete this.data[key];
      },
      clear() {
        this.data = {};
      }
    };
    Object.defineProperty(window, 'localStorage', {
      value: mockStorage
    });
  });

  await page.goto('/');
  // Test with mocked localStorage
});
```

### Use Case 4: Mock Fetch API

```typescript
test('mock fetch', async ({ page }) => {
  await page.addInitScript(() => {
    window.fetch = async (url) => {
      if (url === '/api/users') {
        return {
          ok: true,
          json: async () => ({ users: ['Alice', 'Bob'] })
        };
      }
      return { ok: false };
    };
  });

  await page.goto('/');
  await page.click('#load-users');
  await expect(page.locator('.user')).toHaveCount(2);
});
```

## Use Cases for Solely Art Platform

### Example 1: Mock Payment API

```typescript
test('mock Stripe payment', async ({ page }) => {
  await page.addInitScript(() => {
    window.Stripe = () => ({
      elements: () => ({
        create: () => ({
          mount: () => {},
          on: () => {},
        }),
      }),
      createPaymentMethod: async () => ({
        paymentMethod: {
          id: 'pm_test_123',
          card: { last4: '4242' }
        }
      }),
      confirmCardPayment: async () => ({
        paymentIntent: {
          id: 'pi_test_123',
          status: 'succeeded'
        }
      })
    });
  });

  await page.goto('/checkout');
  await page.click('#pay-button');
  await expect(page.locator('.success')).toHaveText('Payment successful');
});
```

### Example 2: Mock Geolocation for Artist Search

```typescript
test('mock geolocation for nearby artists', async ({ page }) => {
  await page.addInitScript(() => {
    navigator.geolocation = {
      getCurrentPosition: (success) => {
        success({
          coords: {
            latitude: 37.7749,  // San Francisco
            longitude: -122.4194,
            accuracy: 100
          }
        });
      }
    };
  });

  await page.goto('/search');
  await page.click('#nearby-artists');
  await expect(page.locator('.artist-distance').first()).toContain('miles');
});
```

### Example 3: Mock WebSocket for Real-Time Chat

```typescript
test('mock WebSocket for chat', async ({ page }) => {
  const messages = [];
  
  await page.exposeFunction('trackMessage', msg => messages.push(msg));
  
  await page.addInitScript(() => {
    class MockWebSocket {
      constructor(url) {
        this.url = url;
        this.readyState = 1; // OPEN
        setTimeout(() => this.onopen && this.onopen(), 0);
      }
      
      send(data) {
        trackMessage({ type: 'sent', data });
        // Simulate server response
        setTimeout(() => {
          if (this.onmessage) {
            this.onmessage({ data: JSON.stringify({ echo: data }) });
          }
        }, 100);
      }
      
      close() {
        this.readyState = 3; // CLOSED
      }
    }
    
    window.WebSocket = MockWebSocket;
  });

  await page.goto('/messages/123');
  await page.fill('.message-input', 'Hello');
  await page.click('.send-button');
  
  await expect(page.locator('.message').last()).toHaveText('Hello');
  expect(messages).toHaveLength(1);
});
```

### Example 4: Mock File Upload API

```typescript
test('mock file upload', async ({ page }) => {
  await page.addInitScript(() => {
    class MockFile {
      constructor(bits, name, options) {
        this.name = name;
        this.size = bits[0].length;
        this.type = options?.type || '';
      }
    }
    
    window.File = MockFile;
    
    // Mock FileReader
    class MockFileReader {
      readAsDataURL(file) {
        setTimeout(() => {
          this.result = 'data:image/png;base64,mock_image_data';
          this.onload && this.onload();
        }, 0);
      }
    }
    
    window.FileReader = MockFileReader;
  });

  await page.goto('/artist/profile/edit');
  // Test file upload with mocked File API
});
```

### Example 5: Mock Analytics API

```typescript
test('mock Google Analytics', async ({ page }) => {
  const events = [];
  
  await page.exposeFunction('trackEvent', event => events.push(event));
  
  await page.addInitScript(() => {
    window.gtag = function(type, name, params) {
      trackEvent({ type, name, params });
    };
    
    window.dataLayer = [];
  });

  await page.goto('/artist/123');
  await page.click('.book-now');
  
  expect(events).toContainEqual({
    type: 'event',
    name: 'booking_started',
    params: expect.any(Object)
  });
});
```

## Advanced Patterns

### Pattern 1: Mock with Event Emitters

```typescript
test('mock with events', async ({ page }) => {
  await page.addInitScript(() => {
    class EventEmitter {
      constructor() {
        this._listeners = {};
      }
      
      on(event, callback) {
        if (!this._listeners[event]) {
          this._listeners[event] = [];
        }
        this._listeners[event].push(callback);
      }
      
      emit(event, data) {
        if (this._listeners[event]) {
          this._listeners[event].forEach(cb => cb(data));
        }
      }
    }
    
    window.mockAPI = new EventEmitter();
  });

  await page.goto('/');
  
  // Trigger event from test
  await page.evaluate(() => {
    window.mockAPI.emit('data', { value: 123 });
  });
});
```

### Pattern 2: Mock with Promises

```typescript
test('mock async API', async ({ page }) => {
  await page.addInitScript(() => {
    window.mockAsyncAPI = {
      fetchData: async () => {
        await new Promise(resolve => setTimeout(resolve, 100));
        return { data: 'mock data' };
      }
    };
  });

  await page.goto('/');
  await page.click('#load-data');
  await expect(page.locator('.data')).toHaveText('mock data');
});
```

### Pattern 3: Conditional Mocking

```typescript
test('conditional mock', async ({ page }) => {
  await page.addInitScript(() => {
    const originalFetch = window.fetch;
    window.fetch = async (url, options) => {
      if (url.includes('/api/mock')) {
        return {
          ok: true,
          json: async () => ({ mocked: true })
        };
      }
      return originalFetch(url, options);
    };
  });

  await page.goto('/');
});
```

### Pattern 4: Mock with State

```typescript
test('stateful mock', async ({ page }) => {
  await page.addInitScript(() => {
    class StatefulMock {
      constructor() {
        this.state = { count: 0 };
      }
      
      increment() {
        this.state.count++;
        return this.state.count;
      }
      
      getState() {
        return this.state;
      }
    }
    
    window.mockAPI = new StatefulMock();
  });

  await page.goto('/');
  
  const count1 = await page.evaluate(() => window.mockAPI.increment());
  const count2 = await page.evaluate(() => window.mockAPI.increment());
  
  expect(count1).toBe(1);
  expect(count2).toBe(2);
});
```

## Methods

### page.addInitScript(script, arg)

**Purpose:** Add init script that runs before page loads.

```typescript
await page.addInitScript(() => {
  window.mockAPI = { /* mock */ };
});
```

### page.exposeFunction(name, callback)

**Purpose:** Expose function from test to page.

```typescript
await page.exposeFunction('logCall', msg => console.log(msg));
```

### Object.defineProperty(obj, prop, descriptor)

**Purpose:** Define property on object (for read-only properties).

```typescript
Object.defineProperty(navigator, 'cookieEnabled', { value: false });
```

## Troubleshooting

### Issue: Mock Not Working

**Cause:** Mock added after page loaded.

**Solution:** Use addInitScript before goto.

```typescript
// ✅ Correct
await page.addInitScript(() => {
  window.mockAPI = {};
});
await page.goto('/');

// ❌ Wrong
await page.goto('/');
await page.evaluate(() => {
  window.mockAPI = {}; // Too late
});
```

### Issue: Read-Only Property Can't Be Mocked

**Cause:** Property is not configurable.

**Solution:** Use Object.defineProperty.

```typescript
// ✅ Correct
await page.addInitScript(() => {
  Object.defineProperty(navigator, 'cookieEnabled', { value: false });
});

// ❌ Wrong
await page.addInitScript(() => {
  navigator.cookieEnabled = false; // No effect
});
```

### Issue: Events Not Firing

**Cause:** Mock doesn't implement event listeners.

**Solution:** Implement addEventListener and event firing.

```typescript
// ✅ Correct
class MockAPI {
  _listeners = [];
  
  addEventListener(event, callback) {
    this._listeners.push({ event, callback });
  }
  
  _fireEvent(event, data) {
    this._listeners
      .filter(l => l.event === event)
      .forEach(l => l.callback(data));
  }
}
```

## Summary

### Key Concepts

**1. Use mocks for experimental/unsupported APIs**

**2. Setup mocks before page loads** using addInitScript

**3. Use Object.defineProperty for read-only properties**

**4. Use exposeFunction to verify API calls**

**5. Create mock classes for complex APIs with events**

### Common Patterns

- Mock browser APIs (battery, geolocation, etc.)
- Mock Date/Time
- Mock storage APIs
- Mock network APIs (fetch, WebSocket)
- Mock payment APIs
- Mock analytics APIs

### Best Practices

1. Setup mocks in beforeEach
2. Use addInitScript for early APIs
3. Use Object.defineProperty for read-only properties
4. Expose functions for verification
5. Create mock classes for complex APIs

### Methods

- `page.addInitScript()` - Add script before page loads
- `page.exposeFunction()` - Expose function to page
- `Object.defineProperty()` - Define read-only properties

## Related Topics

- Init scripts
- Evaluating JavaScript
- Page events
- Mocking
- Testing patterns
- Browser APIs
