# Playwright Documentation Research - Retries

**Page:** Retries  
**URL:** https://playwright.dev/docs/test-retries  
**Research Date:** December 13, 2025

## Overview

Test retries automatically re-run a test when it fails. Useful for handling flaky tests that fail intermittently. Retries are configured in the configuration file.

**Key concept:** Playwright Test runs tests in worker processes (OS processes running independently). Each worker has identical environment and starts its own browser.

## Failures and Worker Process Behavior

### Example Test Suite

```typescript
import { test } from '@playwright/test';

test.describe('suite', () => {
  test.beforeAll(async () => { /* ... */ });
  test('first good', async ({ page }) => { /* ... */ });
  test('second flaky', async ({ page }) => { /* ... */ });
  test('third good', async ({ page }) => { /* ... */ });
  test.afterAll(async () => { /* ... */ });
});
```

### Scenario 1: All Tests Pass

Tests run in order in the same worker process:

**Worker process starts:**
1. `beforeAll` hook runs
2. `first good` passes
3. `second flaky` passes
4. `third good` passes
5. `afterAll` hook runs

### Scenario 2: Test Fails (No Retries)

When any test fails, Playwright discards the entire worker process and browser, then starts a new one:

**Worker process #1 starts:**
1. `beforeAll` hook runs
2. `first good` passes
3. `second flaky` fails
4. `afterAll` hook runs

**Worker process #2 starts:**
1. `beforeAll` hook runs again
2. `third good` passes
3. `afterAll` hook runs

**Result:** Failed test is not retried, testing continues with next test in new worker.

### Scenario 3: Test Fails (With Retries Enabled)

Second worker process starts by retrying the failed test:

**Worker process #1 starts:**
1. `beforeAll` hook runs
2. `first good` passes
3. `second flaky` fails
4. `afterAll` hook runs

**Worker process #2 starts:**
1. `beforeAll` hook runs again
2. `second flaky` is retried and passes
3. `third good` passes
4. `afterAll` hook runs

**Benefits:**
- Works perfectly for independent tests
- Guarantees failing tests can't affect healthy ones
- Provides clean environment for each retry

## Configuring Retries

### Command Line

```bash
# Give failing tests 3 retry attempts
npx playwright test --retries=3
```

### Configuration File

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Give failing tests 3 retry attempts
  retries: 3,
});
```

**Default:** By default, failing tests are not retried (retries: 0).

## Test Categorization

Playwright Test categorizes tests based on retry behavior:

1. **"passed"** - Tests that passed on the first run
2. **"flaky"** - Tests that failed on the first run, but passed when retried
3. **"failed"** - Tests that failed on the first run and failed all retries

### Example Output

```
Running 3 tests using 1 worker

  ✓ example.spec.ts:4:2 › first passes (438ms)
  x example.spec.ts:5:2 › second flaky (691ms)
  ✓ example.spec.ts:5:2 › second flaky (522ms)
  ✓ example.spec.ts:6:2 › third passes (932ms)

  1 flaky
    example.spec.ts:5:2 › second flaky
  2 passed (4s)
```

**Interpretation:**
- First test: Passed immediately
- Second test: Failed first, passed on retry (marked as flaky)
- Third test: Passed immediately

## Detecting Retries at Runtime

Use `testInfo.retry` to detect if test is being retried. Accessible in any test, hook, or fixture.

```typescript
import { test, expect } from '@playwright/test';

test('my test', async ({ page }, testInfo) => {
  if (testInfo.retry)
    await cleanSomeCachesOnTheServer();
  // ...
});
```

**Use cases:**
- Clear caches before retry
- Use different test data on retry
- Skip expensive setup on retry
- Log retry attempts

**Value:**
- `testInfo.retry === 0` - First attempt
- `testInfo.retry === 1` - First retry
- `testInfo.retry === 2` - Second retry
- etc.

## Retries for Specific Tests

Configure retries for specific test groups or files using `test.describe.configure()`.

```typescript
import { test, expect } from '@playwright/test';

test.describe(() => {
  // All tests in this describe group will get 2 retry attempts
  test.describe.configure({ retries: 2 });
  
  test('test 1', async ({ page }) => {
    // ...
  });
  
  test('test 2', async ({ page }) => {
    // ...
  });
});
```

**Scope:** Overrides global retry configuration for tests within the describe block.

## Serial Mode with Retries

Use `test.describe.serial()` to group dependent tests that run together in order. If one test fails, subsequent tests are skipped. All tests in the group are retried together.

**Note:** It's usually better to make tests isolated for efficient independent execution.

### Example

```typescript
import { test } from '@playwright/test';

test.describe.configure({ mode: 'serial' });

test.beforeAll(async () => { /* ... */ });
test('first good', async ({ page }) => { /* ... */ });
test('second flaky', async ({ page }) => { /* ... */ });
test('third good', async ({ page }) => { /* ... */ });
```

### Without Retries

All tests after failure are skipped:

**Worker process #1:**
1. `beforeAll` hook runs
2. `first good` passes
3. `second flaky` fails
4. `third good` is skipped entirely

### With Retries

All tests are retried together:

**Worker process #1:**
1. `beforeAll` hook runs
2. `first good` passes
3. `second flaky` fails
4. `third good` is skipped

**Worker process #2:**
1. `beforeAll` hook runs again
2. `first good` passes again
3. `second flaky` passes
4. `third good` passes

**Key point:** In serial mode, all tests in the group are retried together, not just the failed test.

## Reuse Single Page Between Tests

Playwright Test creates isolated Page object for each test. To reuse a single Page across multiple tests:

```typescript
// example.spec.ts
import { test, type Page } from '@playwright/test';

test.describe.configure({ mode: 'serial' });

let page: Page;

test.beforeAll(async ({ browser }) => {
  page = await browser.newPage();
});

test.afterAll(async () => {
  await page.close();
});

test('runs first', async () => {
  await page.goto('https://playwright.dev/');
});

test('runs second', async () => {
  await page.getByText('Get Started').click();
});
```

**Requirements:**
- Use serial mode (`mode: 'serial'`)
- Create page in `beforeAll`
- Close page in `afterAll`
- Don't use `page` fixture in test signature

**Caution:** This creates test dependencies. Tests are no longer isolated.

## Best Practices

### 1. Use Retries Sparingly

```typescript
// Good: Low retry count
retries: 1

// Avoid: High retry count masks real issues
retries: 10
```

**Reason:** High retry counts can hide real problems and slow down test execution.

### 2. Different Retries for CI vs Local

```typescript
export default defineConfig({
  retries: process.env.CI ? 2 : 0,
});
```

**Rationale:** CI environments may be less stable, local development should catch issues immediately.

### 3. Use testInfo.retry for Cleanup

```typescript
test('flaky test', async ({ page }, testInfo) => {
  if (testInfo.retry) {
    // Clean up state from previous attempt
    await resetDatabase();
    await clearBrowserCache();
  }
  // Test code
});
```

### 4. Configure Retries Per Project

```typescript
projects: [
  {
    name: 'chromium',
    use: { ...devices['Desktop Chrome'] },
    retries: 2,
  },
  {
    name: 'webkit',
    use: { ...devices['Desktop Safari'] },
    retries: 3, // WebKit might be more flaky
  },
]
```

### 5. Make Tests Independent

```typescript
// Good: Independent test
test('create user', async ({ page }) => {
  const userId = generateUniqueId();
  await createUser(userId);
  await verifyUser(userId);
});

// Avoid: Dependent tests requiring serial mode
let userId;
test('create user', async () => { userId = await create(); });
test('verify user', async () => { await verify(userId); });
```

### 6. Log Retry Attempts

```typescript
test('my test', async ({ page }, testInfo) => {
  console.log(`Attempt ${testInfo.retry + 1} of ${testInfo.project.retries + 1}`);
  // Test code
});
```

### 7. Use Retries for Specific Test Types

```typescript
test.describe('API tests', () => {
  test.describe.configure({ retries: 3 }); // APIs might be flaky
  // Tests
});

test.describe('UI tests', () => {
  test.describe.configure({ retries: 1 }); // UI should be stable
  // Tests
});
```

### 8. Monitor Flaky Tests

Track tests marked as "flaky" in reports and investigate root causes:
- Network issues
- Timing problems
- Race conditions
- External service dependencies

### 9. Avoid Serial Mode When Possible

```typescript
// Prefer: Independent isolated tests
test('test 1', async ({ page }) => { /* ... */ });
test('test 2', async ({ page }) => { /* ... */ });

// Avoid: Serial dependent tests (unless necessary)
test.describe.configure({ mode: 'serial' });
```

### 10. Set Maximum Retries

```typescript
export default defineConfig({
  retries: 2, // Maximum 2 retries (3 total attempts)
});
```

**Reasoning:** Limits wasted time on consistently failing tests.

## Common Patterns

### Environment-Based Retries

```typescript
export default defineConfig({
  retries: process.env.CI ? 2 : 0,
});
```

### Project-Specific Retries

```typescript
projects: [
  {
    name: 'smoke',
    testMatch: /.*smoke.spec.ts/,
    retries: 0, // Smoke tests should be stable
  },
  {
    name: 'e2e',
    testMatch: /.*e2e.spec.ts/,
    retries: 2, // E2E tests can be flaky
  },
]
```

### Conditional Cleanup on Retry

```typescript
test('test with state', async ({ page }, testInfo) => {
  if (testInfo.retry) {
    await cleanupPreviousAttempt();
  }
  
  await setupTestState();
  await runTest();
});
```

### Retry with Different Strategy

```typescript
test('test with fallback', async ({ page }, testInfo) => {
  if (testInfo.retry === 0) {
    // First attempt: use fast method
    await fastButFlakyMethod();
  } else {
    // Retry: use slower but reliable method
    await slowButReliableMethod();
  }
});
```

### Serial Tests with Shared State

```typescript
test.describe.configure({ mode: 'serial' });

let sharedState: any;

test.beforeAll(async () => {
  sharedState = await setupExpensiveResource();
});

test('test 1', async () => {
  await useSharedState(sharedState);
});

test('test 2', async () => {
  await useSharedState(sharedState);
});

test.afterAll(async () => {
  await cleanupSharedState(sharedState);
});
```

## Related Topics to Explore

- Worker processes
- Test isolation
- Flaky test detection
- Test configuration
- Serial mode
- Test fixtures
- Test hooks (beforeAll, afterAll)
- Test reporters (flaky test reporting)
- CI/CD configuration
- Test stability strategies
