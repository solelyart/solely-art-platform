
Bash
PowerShell
Batch
PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT=120000 npx playwright install


If you are installing dependencies and need to use a proxy on Linux, make sure to run the command as a root user. Otherwise, Playwright will attempt to become a root and will not pass environment variables like HTTPS_PROXY to the linux package manager.

sudo HTTPS_PROXY=https://192.0.2.1 npx playwright install-deps

Download from artifact repository​

By default, Playwright downloads browsers from Microsoft's CDN.

Sometimes companies maintain an internal artifact repository to host browser binaries. In this case, Playwright can be configured to download from a custom location using the PLAYWRIGHT_DOWNLOAD_HOST env variable.

Bash
PowerShell
Batch
PLAYWRIGHT_DOWNLOAD_HOST=http://192.0.2.1 npx playwright install


It is also possible to use a per-browser download hosts using PLAYWRIGHT_CHROMIUM_DOWNLOAD_HOST, PLAYWRIGHT_FIREFOX_DOWNLOAD_HOST and PLAYWRIGHT_WEBKIT_DOWNLOAD_HOST env variables that take precedence over PLAYWRIGHT_DOWNLOAD_HOST.

Bash
PowerShell
Batch
PLAYWRIGHT_FIREFOX_DOWNLOAD_HOST=http://203.0.113.3 PLAYWRIGHT_DOWNLOAD_HOST=http://192.0.2.1 npx playwright install

Managing browser binaries​

Playwright downloads Chromium, WebKit and Firefox browsers into the OS-specific cache folders:

%USERPROFILE%\AppData\Local\ms-playwright on Windows
~/Library/Caches/ms-playwright on macOS
~/.cache/ms-playwright on Linux

These browsers will take a few hundred megabytes of disk space when installed:

du -hs ~/Library/Caches/ms-playwright/*
281M  chromium-XXXXXX
187M  firefox-XXXX
180M  webkit-XXXX


You can override default behavior using environment variables. When installing Playwright, ask it to download browsers into a specific location:

Bash
PowerShell
Batch
PLAYWRIGHT_BROWSERS_PATH=$HOME/pw-browsers npx playwright install


When running Playwright scripts, ask it to search for browsers in a shared location.

Bash
PowerShell
Batch
PLAYWRIGHT_BROWSERS_PATH=$HOME/pw-browsers npx playwright test


Playwright keeps track of packages that need those browsers and will garbage collect them as you update Playwright to the newer versions.

NOTE

Developers can opt-in in this mode via exporting PLAYWRIGHT_BROWSERS_PATH=$HOME/pw-browsers in their .bashrc.

Hermetic install​

You can opt into the hermetic install and place binaries in the local folder:

Bash
PowerShell
Batch
# Places binaries to node_modules/playwright-core/.local-browsers
PLAYWRIGHT_BROWSERS_PATH=0 npx playwright install

NOTE

PLAYWRIGHT_BROWSERS_PATH does not change installation path for Google Chrome and Microsoft Edge.

Stale browser removal​

Playwright keeps track of the clients that use its browsers. When there are no more clients that require a particular version of the browser, that version is deleted from the system. That way you can safely use Playwright instances of different versions and at the same time, you don't waste disk space for the browsers that are no longer in use.

To opt-out from the unused browser removal, you can set the PLAYWRIGHT_SKIP_BROWSER_GC=1 environment variable.

List all installed browsers:​

Prints list of browsers from all playwright installations on the machine.

npx playwright install --list

Uninstall browsers​

This will remove the browsers (chromium, firefox, webkit) of the current Playwright installation:

npx playwright uninstall


To remove browsers of other Playwright installations as well, pass --all flag:

npx playwright uninstall --all

Previous
Best Practices
Next
Chrome extensions
Introduction
Install browsers
Install system dependencies
Update Playwright regularly
Configure Browsers
Run tests on different browsers
Chromium
Chromium: headless shell
Chromium: new headless mode
Google Chrome & Microsoft Edge
Firefox
WebKit
Install behind a firewall or a proxy
Download from artifact repository
Managing browser binaries
Hermetic install
Stale browser removal
List all installed browsers:
Uninstall browsers
Learn
Getting started
Playwright Training
Learn Videos
Feature Videos
Community
Stack Overflow
Discord
Twitter
LinkedIn
More
GitHub
YouTube
Blog
Ambassadors
Copyright © 2025 Microsoft