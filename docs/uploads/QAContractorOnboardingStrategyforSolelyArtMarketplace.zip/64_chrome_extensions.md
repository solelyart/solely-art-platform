# Playwright Documentation Research - Chrome Extensions

**Page:** Chrome Extensions
**URL:** https://playwright.dev/docs/chrome-extensions
**Research Date:** December 14, 2025

## Overview

Playwright can be used to test Chrome extensions. This guide describes how to load and test Chrome extensions.

### Key Features

- **Load unpacked extensions:** Test extensions during development.
- **Access extension APIs:** Interact with extension background pages and content scripts.
- **Test extension UI:** Test popups and other extension UI elements.

## Usage

### Loading an Unpacked Extension

```javascript
const { _android, _electron, chromium, devices, firefox, webkit } = require("playwright");

(async () => {
  const pathToExtension = require("path").join(__dirname, "my-extension");
  const browserContext = await chromium.launchPersistentContext("", {
    headless: false,
    args: [
      `--disable-extensions-except=${pathToExtension}`,
      `--load-extension=${pathToExtension}`,
    ],
  });
  // ...
})();
```

### Accessing the Background Page

```javascript
const backgroundPage = await browserContext.backgroundPages()[0];
// Test the background page as you would any other page.
```

### Testing the Popup

```javascript
const popupPage = await browserContext.pages()[0];
// Test the popup as you would any other page.
```

## Summary

### Key Takeaways

- **Load extensions with launch arguments:** `--disable-extensions-except` and `--load-extension`.
- **Use `launchPersistentContext`:** To create a persistent browser context.
- **Access background pages with `browserContext.backgroundPages()`:** To test background scripts.
- **Access popups with `browserContext.pages()`:** To test extension UI.

### Related Topics

- Browser Contexts
- Pages
- Background Pages
