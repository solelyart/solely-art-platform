# Playwright Documentation Research - Supported Languages

**Page:** Supported Languages
**URL:** https://playwright.dev/docs/languages
**Research Date:** December 14, 2025

## Overview

Playwright is available for multiple programming languages, providing the same core functionality across all of them.

### Officially Supported Languages

- **Node.js** (JavaScript and TypeScript)
- **Python**
- **Java**
- **.NET** (C# and F#)

### Community Supported Languages

- **Go**
- **Ruby**
- **PHP**

## Node.js

- The primary and most feature-rich version of Playwright.
- Includes the Playwright Test runner.
- Supports both JavaScript and TypeScript.

## Python

- A popular choice for test automation and web scraping.
- Integrates with popular Python test runners like pytest.
- Provides a synchronous and asynchronous API.

## Java

- A robust and widely used language in enterprise environments.
- Integrates with popular Java build tools like Maven and Gradle.
- Provides a synchronous API.

## .NET

- A powerful framework for building applications on Windows, Linux, and macOS.
- Supports C# and F#.
- Integrates with popular .NET test runners like NUnit and MSTest.

## Community Projects

- Community-driven projects that bring Playwright to other languages.
- May not have the same level of features or support as the official versions.

## Summary

### Key Takeaways

- **Multiple Languages:** Playwright is available for a wide range of programming languages.
- **Official Support:** Node.js, Python, Java, and .NET are officially supported.
- **Community Support:** Go, Ruby, and PHP are supported by the community.
- **Consistent API:** The core API is consistent across all languages.

### Related Topics

- Playwright for Python
- Playwright for Java
- Playwright for .NET
