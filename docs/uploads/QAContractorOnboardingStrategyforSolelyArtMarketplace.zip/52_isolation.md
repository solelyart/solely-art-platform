# Playwright Documentation Research - Isolation

**Page:** Isolation  
**URL:** https://playwright.dev/docs/browser-contexts  
**Research Date:** December 14, 2025

## Introduction

**Key principle:** Tests written with Playwright execute in **isolated clean-slate environments** called **browser contexts**.

**Benefits of isolation model:**
- Improves reproducibility
- Prevents cascading test failures

## What is Test Isolation?

**Definition:** Test Isolation is when each test is **completely isolated** from another test. Every test runs **independently** from any other test.

### Each Test Has Its Own:
- Local storage
- Session storage
- Cookies
- etc.

### How Playwright Achieves This

**Mechanism:** Playwright achieves this using **BrowserContexts** which are equivalent to **incognito-like profiles**.

**Characteristics:**
- Fast to create
- Cheap to create
- Completely isolated, even when running in single browser

**Automatic creation:** Playwright creates context for each test, and provides default **Page** in that context.

## Why is Test Isolation Important?

### Benefit 1: No Failure Carry-Over

**Advantage:** If one test fails it doesn't affect the other test.

### Benefit 2: Easy to Debug

**Advantage:** Easy to debug errors or flakiness, because you can run just single test as many times as you'd like.

### Benefit 3: No Order Dependencies

**Advantage:** Don't have to think about the order when running in parallel, sharding, etc.

## Two Ways of Test Isolation

**Strategy 1: Start from scratch**

**Strategy 2: Cleanup in between**

### Problem with Cleanup Strategy

**Issues:**
- Can be easy to forget to clean up
- Some things are **impossible to clean up** such as "visited links"
- State from one test can leak into next test
- Can cause test to fail
- Makes debugging harder as problem comes from another test

### Advantage of Start from Scratch

**Benefit:** Starting from scratch means everything is new, so if test fails you only have to look within that test to debug.

## How Playwright Achieves Test Isolation

**Mechanism:** Playwright uses **browser contexts** to achieve Test Isolation.

**Pattern:** Each test has its own **Browser Context**.

**Behavior:** Running test creates new browser context each time.

### Automatic vs Manual Creation

**When using Playwright as Test Runner:** Browser contexts are created by default.

**Otherwise:** You can create browser contexts manually.

### Example: Automatic Context Creation

```typescript
import { test } from '@playwright/test';

test('example test', async ({ page, context }) => {
  // "context" is an isolated BrowserContext, created for this specific test.
  // "page" belongs to this context.
});

test('another test', async ({ page, context }) => {
  // "context" and "page" in this second test are completely
  // isolated from the first test.
});
```

### Emulation Capabilities

**Additional use:** Browser contexts can also be used to emulate multi-page scenarios involving:
- Mobile devices
- Permissions
- Locale
- Color scheme

**Reference:** Check out Emulation guide for more details.

## Multiple Contexts in a Single Test

**Capability:** Playwright can create **multiple browser contexts** within single scenario.

**Use case:** This is useful when you want to test for **multi-user functionality**, like chat.

### Example: Multiple Contexts

```typescript
import { test } from '@playwright/test';

test('admin and user', async ({ browser }) => {
  // Create two isolated browser contexts
  const adminContext = await browser.newContext();
  const userContext = await browser.newContext();

  // Create pages and interact with contexts independently
  const adminPage = await adminContext.newPage();
  const userPage = await userContext.newPage();
});
```

## Best Practices

### 1. Rely on Automatic Isolation

**✅ Good:**
```typescript
test('test 1', async ({ page }) => {
  // Automatic isolation via context
  await page.goto('/');
});

test('test 2', async ({ page }) => {
  // Completely isolated from test 1
  await page.goto('/');
});
```

### 2. Don't Share State Between Tests

**✅ Good:**
```typescript
test('test 1', async ({ page }) => {
  await page.goto('/login');
  await page.fill('#username', 'user1');
  // State is isolated
});

test('test 2', async ({ page }) => {
  await page.goto('/login');
  // Fresh state, no leftover from test 1
});
```

**❌ Bad:**
```typescript
let sharedData;

test('test 1', async ({ page }) => {
  sharedData = await page.evaluate(() => window.data);
});

test('test 2', async ({ page }) => {
  // Using shared data - bad practice
  expect(sharedData).toBeDefined();
});
```

### 3. Use Multiple Contexts for Multi-User Scenarios

**✅ Good:**
```typescript
test('multi-user chat', async ({ browser }) => {
  const user1Context = await browser.newContext();
  const user2Context = await browser.newContext();
  
  const user1Page = await user1Context.newPage();
  const user2Page = await user2Context.newPage();
  
  // Test chat between two users
});
```

### 4. Clean Up Contexts

**✅ Good:**
```typescript
test('custom context', async ({ browser }) => {
  const context = await browser.newContext();
  const page = await context.newPage();
  
  // Use context
  
  await context.close(); // Clean up
});
```

### 5. Don't Rely on Test Order

**✅ Good:**
```typescript
test('test A', async ({ page }) => {
  // Independent test
});

test('test B', async ({ page }) => {
  // Independent test, doesn't depend on test A
});
```

**❌ Bad:**
```typescript
test('test A', async ({ page }) => {
  await page.goto('/setup');
  // Setup for test B
});

test('test B', async ({ page }) => {
  // Assumes test A ran first - bad!
});
```

## Common Use Cases

### Use Case 1: Isolated Login Tests

```typescript
test('user can login with valid credentials', async ({ page }) => {
  await page.goto('/login');
  await page.fill('#username', 'user1');
  await page.fill('#password', 'pass1');
  await page.click('button[type="submit"]');
  
  await expect(page).toHaveURL('/dashboard');
});

test('user cannot login with invalid credentials', async ({ page }) => {
  // Completely isolated from previous test
  await page.goto('/login');
  await page.fill('#username', 'invalid');
  await page.fill('#password', 'wrong');
  await page.click('button[type="submit"]');
  
  await expect(page.locator('.error')).toBeVisible();
});
```

### Use Case 2: Multiple User Contexts

```typescript
test('admin and regular user have different permissions', async ({ browser }) => {
  // Admin context
  const adminContext = await browser.newContext();
  const adminPage = await adminContext.newPage();
  await adminPage.goto('/login');
  await adminPage.fill('#username', 'admin');
  await adminPage.fill('#password', 'admin123');
  await adminPage.click('button[type="submit"]');
  
  // Regular user context
  const userContext = await browser.newContext();
  const userPage = await userContext.newPage();
  await userPage.goto('/login');
  await userPage.fill('#username', 'user');
  await userPage.fill('#password', 'user123');
  await userPage.click('button[type="submit"]');
  
  // Verify different permissions
  await expect(adminPage.locator('.admin-panel')).toBeVisible();
  await expect(userPage.locator('.admin-panel')).not.toBeVisible();
  
  await adminContext.close();
  await userContext.close();
});
```

### Use Case 3: Isolated Cookie Tests

```typescript
test('cookies are isolated between tests', async ({ page, context }) => {
  await page.goto('/');
  await context.addCookies([
    { name: 'test', value: 'value1', url: 'http://localhost' }
  ]);
  
  const cookies = await context.cookies();
  expect(cookies).toHaveLength(1);
});

test('previous test cookies do not leak', async ({ page, context }) => {
  await page.goto('/');
  
  const cookies = await context.cookies();
  expect(cookies).toHaveLength(0); // No cookies from previous test
});
```

### Use Case 4: Parallel Test Execution

```typescript
test('test 1 can run in parallel', async ({ page }) => {
  await page.goto('/page1');
  await page.waitForTimeout(1000);
  // Isolated, won't interfere with test 2
});

test('test 2 can run in parallel', async ({ page }) => {
  await page.goto('/page2');
  await page.waitForTimeout(1000);
  // Isolated, won't interfere with test 1
});
```

## Use Cases for Solely Art Platform

### Example 1: Isolated Booking Tests

```typescript
test('artist can create booking', async ({ page }) => {
  await page.goto('/login');
  await page.fill('#email', 'artist@example.com');
  await page.fill('#password', 'password');
  await page.click('button[type="submit"]');
  
  await page.goto('/bookings/create');
  await page.fill('#date', '2025-01-15');
  await page.click('button[type="submit"]');
  
  await expect(page.locator('.success')).toBeVisible();
});

test('client can view bookings', async ({ page }) => {
  // Completely isolated from previous test
  await page.goto('/login');
  await page.fill('#email', 'client@example.com');
  await page.fill('#password', 'password');
  await page.click('button[type="submit"]');
  
  await page.goto('/bookings');
  await expect(page.locator('.booking-list')).toBeVisible();
});
```

### Example 2: Multi-User Chat Testing

```typescript
test('artist and client can chat', async ({ browser }) => {
  // Artist context
  const artistContext = await browser.newContext();
  const artistPage = await artistContext.newPage();
  await artistPage.goto('/login');
  await artistPage.fill('#email', 'artist@example.com');
  await artistPage.fill('#password', 'password');
  await artistPage.click('button[type="submit"]');
  await artistPage.goto('/messages/123');
  
  // Client context
  const clientContext = await browser.newContext();
  const clientPage = await clientContext.newPage();
  await clientPage.goto('/login');
  await clientPage.fill('#email', 'client@example.com');
  await clientPage.fill('#password', 'password');
  await clientPage.click('button[type="submit"]');
  await clientPage.goto('/messages/123');
  
  // Artist sends message
  await artistPage.fill('.message-input', 'Hello from artist');
  await artistPage.click('.send-button');
  
  // Client receives message
  await expect(clientPage.locator('.message').last()).toHaveText('Hello from artist');
  
  await artistContext.close();
  await clientContext.close();
});
```

### Example 3: Isolated Payment Tests

```typescript
test('successful payment creates booking', async ({ page }) => {
  await page.goto('/booking/123/checkout');
  await page.fill('#card-number', '4242424242424242');
  await page.fill('#exp-date', '12/25');
  await page.fill('#cvc', '123');
  await page.click('button[type="submit"]');
  
  await expect(page.locator('.success')).toBeVisible();
});

test('failed payment shows error', async ({ page }) => {
  // Isolated from previous test
  await page.goto('/booking/123/checkout');
  await page.fill('#card-number', '4000000000000002');
  await page.fill('#exp-date', '12/25');
  await page.fill('#cvc', '123');
  await page.click('button[type="submit"]');
  
  await expect(page.locator('.error')).toBeVisible();
});
```

### Example 4: Different User Roles

```typescript
test('artist and client have different dashboards', async ({ browser }) => {
  // Artist context
  const artistContext = await browser.newContext();
  const artistPage = await artistContext.newPage();
  await artistPage.goto('/login');
  await artistPage.fill('#email', 'artist@example.com');
  await artistPage.fill('#password', 'password');
  await artistPage.click('button[type="submit"]');
  
  // Client context
  const clientContext = await browser.newContext();
  const clientPage = await clientContext.newPage();
  await clientPage.goto('/login');
  await clientPage.fill('#email', 'client@example.com');
  await clientPage.fill('#password', 'password');
  await clientPage.click('button[type="submit"]');
  
  // Verify different dashboards
  await expect(artistPage.locator('.artist-dashboard')).toBeVisible();
  await expect(clientPage.locator('.client-dashboard')).toBeVisible();
  
  await artistContext.close();
  await clientContext.close();
});
```

### Example 5: Isolated Search Tests

```typescript
test('search for music artists', async ({ page }) => {
  await page.goto('/search');
  await page.fill('#search-input', 'music');
  await page.click('button[type="submit"]');
  
  await expect(page.locator('.search-result')).toHaveCount(10);
});

test('search for visual artists', async ({ page }) => {
  // Isolated from previous test
  await page.goto('/search');
  await page.fill('#search-input', 'visual');
  await page.click('button[type="submit"]');
  
  await expect(page.locator('.search-result')).toHaveCount(8);
});
```

## Advanced Patterns

### Pattern 1: Context with Custom Options

```typescript
test('mobile context', async ({ browser }) => {
  const context = await browser.newContext({
    viewport: { width: 375, height: 667 },
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)',
  });
  
  const page = await context.newPage();
  await page.goto('/');
  
  await context.close();
});
```

### Pattern 2: Context with Permissions

```typescript
test('context with geolocation', async ({ browser }) => {
  const context = await browser.newContext({
    permissions: ['geolocation'],
    geolocation: { latitude: 37.7749, longitude: -122.4194 },
  });
  
  const page = await context.newPage();
  await page.goto('/');
  
  await context.close();
});
```

### Pattern 3: Context with Locale

```typescript
test('context with French locale', async ({ browser }) => {
  const context = await browser.newContext({
    locale: 'fr-FR',
    timezoneId: 'Europe/Paris',
  });
  
  const page = await context.newPage();
  await page.goto('/');
  
  await context.close();
});
```

### Pattern 4: Context with Storage State

```typescript
test('context with saved auth state', async ({ browser }) => {
  const context = await browser.newContext({
    storageState: 'auth.json',
  });
  
  const page = await context.newPage();
  await page.goto('/dashboard'); // Already logged in
  
  await context.close();
});
```

### Pattern 5: Multiple Pages in Same Context

```typescript
test('multiple pages in same context share state', async ({ context }) => {
  const page1 = await context.newPage();
  const page2 = await context.newPage();
  
  await page1.goto('/login');
  await page1.fill('#username', 'user');
  await page1.click('button[type="submit"]');
  
  // page2 shares cookies with page1
  await page2.goto('/dashboard');
  await expect(page2.locator('.welcome')).toBeVisible();
});
```

## Context Methods

### browser.newContext(options)

**Purpose:** Create new browser context.

```typescript
const context = await browser.newContext({
  viewport: { width: 1280, height: 720 },
  userAgent: 'custom-agent',
});
```

### context.newPage()

**Purpose:** Create new page in context.

```typescript
const page = await context.newPage();
```

### context.close()

**Purpose:** Close context and all pages.

```typescript
await context.close();
```

### context.addCookies(cookies)

**Purpose:** Add cookies to context.

```typescript
await context.addCookies([
  { name: 'token', value: 'abc123', url: 'http://localhost' }
]);
```

### context.cookies()

**Purpose:** Get all cookies from context.

```typescript
const cookies = await context.cookies();
```

### context.clearCookies()

**Purpose:** Clear all cookies from context.

```typescript
await context.clearCookies();
```

### context.storageState(options)

**Purpose:** Get or save storage state.

```typescript
await context.storageState({ path: 'auth.json' });
```

## Troubleshooting

### Issue: State Leaking Between Tests

**Cause:** Sharing variables between tests.

**Solution:** Use isolated contexts (automatic in Playwright Test).

```typescript
// ✅ Correct - Isolated
test('test 1', async ({ page }) => {
  await page.goto('/');
});

test('test 2', async ({ page }) => {
  await page.goto('/'); // Fresh context
});

// ❌ Wrong - Shared state
let sharedPage;
test('test 1', async ({ page }) => {
  sharedPage = page;
});
test('test 2', async () => {
  await sharedPage.goto('/'); // Using shared page
});
```

### Issue: Tests Depend on Order

**Cause:** Tests assuming previous test ran.

**Solution:** Make each test independent.

```typescript
// ✅ Correct - Independent
test('test 1', async ({ page }) => {
  await page.goto('/login');
  await page.fill('#username', 'user');
  await page.click('button[type="submit"]');
  // Complete flow
});

test('test 2', async ({ page }) => {
  await page.goto('/login');
  await page.fill('#username', 'user');
  await page.click('button[type="submit"]');
  // Complete flow, doesn't depend on test 1
});
```

### Issue: Context Not Cleaned Up

**Cause:** Forgetting to close custom context.

**Solution:** Always close contexts.

```typescript
// ✅ Correct
test('custom context', async ({ browser }) => {
  const context = await browser.newContext();
  const page = await context.newPage();
  
  // Use context
  
  await context.close(); // Clean up
});
```

## Summary

### Key Concepts

**1. Test Isolation:** Each test completely isolated from others

**2. Browser Contexts:** Equivalent to incognito-like profiles

**3. Automatic Creation:** Playwright creates context for each test

**4. No State Leakage:** Each test has own storage, cookies, etc.

**5. Multiple Contexts:** Can create multiple contexts in single test

### Benefits of Isolation

- No failure carry-over
- Easy to debug
- No order dependencies
- Parallel execution safe

### Two Strategies

**1. Start from scratch** (Playwright's approach) - Everything is new

**2. Cleanup in between** - Can forget to clean up, some things impossible to clean

### Best Practices

1. Rely on automatic isolation
2. Don't share state between tests
3. Use multiple contexts for multi-user scenarios
4. Clean up custom contexts
5. Don't rely on test order

### Common Methods

- `browser.newContext()` - Create new context
- `context.newPage()` - Create new page
- `context.close()` - Close context
- `context.addCookies()` - Add cookies
- `context.cookies()` - Get cookies
- `context.storageState()` - Save/load state

## Related Topics

- Browser contexts
- Pages
- Emulation
- Authentication
- Parallelism
- Sharding
- Test organization
