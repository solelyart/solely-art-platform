# QA Contractor Sourcing Strategy for Solely Art Platform

**Document Version:** 1.0  
**Last Updated:** December 13, 2025  
**Author:** Manus AI

## 1. Overview

Finding the right QA contractor begins with knowing where to look and how to position your opportunity. This document provides a strategic approach to sourcing qualified candidates, including recommended platforms, outreach strategies, and best practices for attracting top talent.

---

## 2. Recommended Sourcing Platforms

The choice of platform significantly impacts the quality and quantity of candidates you will encounter. Each platform has distinct advantages and trade-offs that should be considered based on your budget, timeline, and quality requirements.

### Tier 1: Premium Vetted Platforms

These platforms conduct rigorous screening of their talent pool, which means you receive pre-qualified candidates. While the hourly rates are typically higher, the time saved in screening and the quality assurance provided often justify the investment.

| Platform | Strengths | Considerations | Best For |
|---|---|---|---|
| **Toptal** | Highly selective vetting process (accepts only top 3% of applicants). Clients include major brands like Bridgestone and Motorola. Strong matching algorithm. | Premium pricing. Longer onboarding process for contractors. | High-stakes projects where quality is paramount and budget is flexible. |
| **Braintrust** | Fast matching (often within minutes). Transparent pricing with no platform markup. Strong technical talent pool. | Smaller pool compared to Toptal. Newer platform with less brand recognition. | Projects requiring quick turnaround with strong technical requirements. |

**Recommendation:** Start with Toptal if you need a single, highly reliable contractor and have the budget. Use Braintrust if you need to move quickly and want competitive rates.

### Tier 2: Specialized QA Platforms

These platforms focus specifically on quality assurance and testing, which means the talent pool is highly relevant. Contractors on these platforms are often passionate about QA as a discipline.

| Platform | Strengths | Considerations | Best For |
|---|---|---|---|
| **Testlio** | Dedicated to QA testing. Offers managed testing services and individual contractors. Strong community reputation among QA professionals. | May have minimum engagement requirements. Pricing not always transparent. | Organizations looking for a long-term QA partnership or ongoing testing support. |
| **We Are Testers** | Requires contractors to have formal QA education, experience, or certification. Mission-based work structure. | Smaller talent pool. Less well-known than general freelance platforms. | Projects requiring certified or formally trained QA professionals. |

**Recommendation:** Use Testlio if you anticipate needing ongoing QA support beyond a single contractor. Use We Are Testers if formal certification is a priority.

### Tier 3: General Freelance Platforms

These platforms offer the largest talent pools and the most flexibility in terms of pricing and engagement models. However, they require more active screening and vetting on your part.

| Platform | Strengths | Considerations | Best For |
|---|---|---|---|
| **Upwork** | Massive talent pool. Flexible engagement models. Transparent pricing and reviews. Built-in time tracking and payment protection. | Quality varies significantly. Requires careful screening. Can be time-consuming to find the right candidate. | Budget-conscious projects or when you need multiple contractors for different specializations. |
| **Fiverr** | Project-based pricing. Quick turnaround for specific tasks. Good for one-off testing needs. | Less suitable for ongoing, complex projects. Quality can be inconsistent. | Specific, well-defined testing tasks (e.g., "test this new feature") rather than comprehensive QA. |

**Recommendation:** Use Upwork for its balance of pool size, flexibility, and built-in protections. Avoid Fiverr for the Solely Art Platform's complex, ongoing QA needs.

### Tier 4: Staffing Agencies

Staffing agencies handle much of the sourcing and initial screening for you, acting as an intermediary. This can save significant time but comes with agency fees.

| Platform | Strengths | Considerations | Best For |
|---|---|---|---|
| **Insight Global** | One of the largest IT staffing agencies in the U.S. Can provide contractors across many specializations. Handles payroll and HR. | Agency markup (typically 20-40% on top of contractor rate). Less control over the selection process. | Organizations that prefer a hands-off approach or need multiple contractors across different roles. |
| **MindfulQA** | Specialized in QA and software testing recruitment. Deep understanding of QA skill requirements. | Smaller agency, may have limited availability. Pricing varies. | Organizations that want specialized QA recruitment expertise. |

**Recommendation:** Use staffing agencies if you lack internal HR/recruitment capacity or need to fill multiple roles quickly.

---

## 3. Crafting an Effective Job Posting

Your job posting is your first opportunity to attract the right candidates and filter out those who are not a good fit. A well-crafted posting should be clear, specific, and compelling.

### Essential Components

**Project Title:** Be specific and appealing.
- ❌ **Poor:** "QA Tester Needed"
- ✅ **Good:** "Senior QA Contractor for Artist Booking Marketplace Platform"

**Project Overview:** Provide context about the Solely Art Platform, its purpose, and its technical stack. This helps candidates self-assess their fit.

> **Example:** "Solely Art is a marketplace platform connecting clients with artists through an integrated booking, messaging, and payment system. Built with React, Node.js, and MySQL, the platform handles complex availability calculations, Stripe payment integration, and real-time messaging. We are seeking an experienced QA contractor to ensure the highest quality standards across all features."

**Key Responsibilities:** Be specific about what the contractor will do.
- Execute manual and automated tests for booking engine, payment flows, and messaging features.
- Identify, document, and track defects using Monday.com.
- Collaborate with developers to diagnose and resolve issues.
- Provide feedback on user experience and accessibility.

**Required Skills:** List must-have skills clearly.
- 3+ years of experience in software quality assurance.
- Proficiency with manual testing and test case design.
- Basic knowledge of JavaScript or Python for understanding code and writing simple automation scripts.
- Experience testing payment integrations (Stripe preferred).
- Strong written and verbal communication skills.
- Familiarity with Agile/Scrum methodologies.

**Nice-to-Have Skills:** List preferred but not required skills.
- Experience with test automation tools (Selenium, Cypress, Playwright).
- SQL proficiency for database validation.
- Experience testing booking or scheduling systems.
- Familiarity with Monday.com or JIRA.

**Engagement Details:** Be transparent about the scope and compensation.
- **Duration:** 4-6 weeks initially, with potential for extension.
- **Hours:** 20-30 hours per week, flexible schedule.
- **Rate:** $40-70/hour depending on experience (adjust based on your budget and market research).
- **Location:** Remote, but preference for candidates in US time zones for easier collaboration.

---

## 4. Screening Candidates Efficiently

Once applications start coming in, you need a systematic way to screen them quickly without sacrificing quality.

### Initial Resume Screen (5 minutes per candidate)

Use this quick checklist to decide whether to move a candidate forward:

- [ ] **Relevant Experience:** Has the candidate worked on web applications, marketplaces, or platforms with similar complexity?
- [ ] **Payment Testing Experience:** Have they tested payment integrations or financial transactions?
- [ ] **Communication Quality:** Is their profile/cover letter well-written and professional?
- [ ] **Tool Proficiency:** Do they mention tools in your stack (React, Node.js, Stripe, Monday.com, JIRA)?
- [ ] **Red Flags:** Are there unexplained gaps, job-hopping every few months, or generic, copy-pasted applications?

**Decision:** If 3 or more boxes are checked and there are no red flags, move to the next stage.

### Pre-Interview Questionnaire

Before scheduling a live interview, send a short questionnaire to further qualify candidates. This saves time and provides additional data points.

**Sample Questions:**
1.  Describe a complex bug you discovered in a previous project. How did you identify it, and how did you communicate it to the team?
2.  What is your approach to prioritizing test cases when you have limited time before a release?
3.  Have you worked with payment systems like Stripe? If so, describe a specific testing challenge you encountered.
4.  What tools do you use for test management and bug tracking?
5.  Are you available to start within the next two weeks, and can you commit to 20-30 hours per week?

**Evaluation:** Look for specific, detailed answers that demonstrate real experience. Generic or vague responses are a red flag.

---

## 5. Outreach Strategy for Passive Candidates

The best candidates are often not actively looking for work. Proactive outreach can help you tap into this hidden talent pool.

### Identifying Passive Candidates

- **LinkedIn:** Search for "QA Engineer" or "Quality Assurance Tester" with filters for location, experience level, and skills (e.g., Selenium, Stripe, JavaScript).
- **GitHub:** Look for users who contribute to testing frameworks or have repositories with test automation code.
- **QA Communities:** Engage in communities like the Ministry of Testing, r/QualityAssurance on Reddit, or QA-focused Slack/Discord groups.

### Crafting Your Outreach Message

Your message should be personalized, concise, and value-focused. Avoid generic templates.

**Template:**

> **Subject:** Exciting QA Opportunity with Solely Art Platform
> 
> Hi [Name],
> 
> I came across your profile and was impressed by your experience with [specific skill or project from their profile]. I'm leading the QA efforts for Solely Art, a marketplace platform that connects clients with artists through an integrated booking and payment system.
> 
> We're looking for a skilled QA contractor to help us ensure the highest quality standards, particularly around our booking engine and Stripe payment integration. Given your background in [relevant experience], I thought you might be a great fit.
> 
> This is a remote, part-time contract (20-30 hours/week) with a competitive rate. If you're open to exploring this, I'd love to schedule a brief call to share more details.
> 
> Best,
> [Your Name]

---

## 6. Conclusion

Sourcing the right QA contractor is a strategic process that requires a clear understanding of your needs, the right platforms, and effective communication. By following this sourcing strategy, you can build a strong pipeline of qualified candidates and significantly increase your chances of finding the perfect fit for the Solely Art Platform.
