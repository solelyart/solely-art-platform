# Playwright Documentation Research - Frames

**Page:** Frames  
**URL:** https://playwright.dev/docs/frames  
**Research Date:** December 14, 2025

## Introduction

### Page and Frames

**Page structure:** A Page can have one or more Frame objects attached to it.

**Main frame:** Each page has main frame.

**Page-level interactions:** Page-level interactions (like `click`) are assumed to operate in main frame.

### Additional Frames

**iframe tag:** Page can have additional frames attached with `iframe` HTML tag.

**Frame access:** These frames can be accessed for interactions inside the frame.

### Frame Locator

**Basic usage:**
```typescript
// Locate element inside frame
const username = await page.frameLocator('.frame-class').getByLabel('User Name');
await username.fill('John');
```

## Frame Objects

### Accessing Frame Objects

**API:** Can access frame objects using `page.frame()` API.

### Get Frame by Name

**Pattern:**
```typescript
// Get frame using the frame's name attribute
const frame = page.frame('frame-login');
```

### Get Frame by URL

**Pattern:**
```typescript
// Get frame using frame's URL
const frame = page.frame({ url: /.*domain.*/ });
```

### Interact with Frame

**Pattern:**
```typescript
// Interact with the frame
await frame.fill('#username-input', 'John');
```

## Best Practices

### 1. Use frameLocator for Modern Approach

**✅ Good (Recommended):**
```typescript
const username = await page.frameLocator('iframe[name="login"]').getByLabel('Username');
await username.fill('John');
```

**Benefit:** More reliable, uses auto-waiting, works with Playwright locators.

**⚠️ Alternative (Frame object):**
```typescript
const frame = page.frame('login');
await frame.fill('#username', 'John');
```

### 2. Use Specific Frame Selectors

**✅ Good:**
```typescript
const frame = page.frameLocator('iframe[name="payment-form"]');
```

**❌ Bad:**
```typescript
const frame = page.frameLocator('iframe'); // Too generic
```

### 3. Chain Locators Inside Frames

**Pattern:**
```typescript
const frame = page.frameLocator('iframe.checkout');
await frame.getByLabel('Card Number').fill('4242424242424242');
await frame.getByLabel('Expiry').fill('12/25');
await frame.getByRole('button', { name: 'Pay' }).click();
```

### 4. Handle Nested Frames

**Pattern:**
```typescript
const outerFrame = page.frameLocator('iframe.outer');
const innerFrame = outerFrame.frameLocator('iframe.inner');
await innerFrame.getByText('Content').click();
```

### 5. Wait for Frame to Load

**Pattern:**
```typescript
await page.waitForSelector('iframe[name="content"]');
const frame = page.frameLocator('iframe[name="content"]');
await frame.getByRole('heading').waitFor();
```

## Common Use Cases

### Use Case 1: Login in iframe

```typescript
test('login in iframe', async ({ page }) => {
  await page.goto('/');
  
  const loginFrame = page.frameLocator('iframe[name="login-frame"]');
  await loginFrame.getByLabel('Username').fill('testuser');
  await loginFrame.getByLabel('Password').fill('password123');
  await loginFrame.getByRole('button', { name: 'Login' }).click();
  
  // Verify login success on main page
  await expect(page.getByText('Welcome')).toBeVisible();
});
```

### Use Case 2: Payment Form in iframe

```typescript
test('fill payment form in iframe', async ({ page }) => {
  await page.goto('/checkout');
  
  const paymentFrame = page.frameLocator('iframe.stripe-payment');
  await paymentFrame.getByLabel('Card number').fill('4242424242424242');
  await paymentFrame.getByLabel('Expiry date').fill('12/25');
  await paymentFrame.getByLabel('CVC').fill('123');
  await paymentFrame.getByLabel('ZIP').fill('10001');
  
  // Submit on main page
  await page.getByRole('button', { name: 'Complete Purchase' }).click();
});
```

### Use Case 3: Content in Multiple Frames

```typescript
test('interact with multiple frames', async ({ page }) => {
  await page.goto('/dashboard');
  
  const headerFrame = page.frameLocator('iframe#header');
  const contentFrame = page.frameLocator('iframe#content');
  const footerFrame = page.frameLocator('iframe#footer');
  
  // Interact with header
  await headerFrame.getByRole('link', { name: 'Profile' }).click();
  
  // Interact with content
  await contentFrame.getByRole('button', { name: 'Edit' }).click();
  
  // Interact with footer
  await footerFrame.getByText('Privacy Policy').click();
});
```

### Use Case 4: Nested Frames

```typescript
test('handle nested frames', async ({ page }) => {
  await page.goto('/nested');
  
  const outerFrame = page.frameLocator('iframe.outer');
  const innerFrame = outerFrame.frameLocator('iframe.inner');
  
  await innerFrame.getByRole('button', { name: 'Click Me' }).click();
  await expect(innerFrame.getByText('Clicked!')).toBeVisible();
});
```

### Use Case 5: Frame with Dynamic Content

```typescript
test('wait for frame content to load', async ({ page }) => {
  await page.goto('/');
  
  // Wait for iframe to be attached
  await page.waitForSelector('iframe[name="dynamic-content"]');
  
  const frame = page.frameLocator('iframe[name="dynamic-content"]');
  
  // Wait for content inside frame
  await frame.getByRole('heading').waitFor();
  
  const heading = await frame.getByRole('heading').textContent();
  expect(heading).toBe('Dynamic Content');
});
```

### Use Case 6: Get Frame by URL Pattern

```typescript
test('get frame by URL', async ({ page }) => {
  await page.goto('/');
  
  // Using frame object API
  const frame = page.frame({ url: /.*payment.*/ });
  if (frame) {
    await frame.fill('#card-number', '4242424242424242');
  }
});
```

## Use Cases for Solely Art Platform

### Example 1: Artist Portfolio in iframe

```typescript
test('view artist portfolio in iframe', async ({ page }) => {
  await page.goto('/artist/123');
  
  const portfolioFrame = page.frameLocator('iframe.artist-portfolio');
  
  // Navigate through portfolio
  await portfolioFrame.getByRole('button', { name: 'Next' }).click();
  await portfolioFrame.getByRole('button', { name: 'Next' }).click();
  
  // Verify image count
  const images = portfolioFrame.locator('img.portfolio-image');
  await expect(images).toHaveCount(10);
});
```

### Example 2: Stripe Payment iframe

```typescript
test('complete payment in Stripe iframe', async ({ page }) => {
  await page.goto('/checkout');
  
  // Fill booking details on main page
  await page.getByLabel('Event Date').fill('2025-01-15');
  await page.getByLabel('Event Time').fill('14:00');
  
  // Fill payment details in Stripe iframe
  const stripeFrame = page.frameLocator('iframe[name="__privateStripeFrame"]');
  await stripeFrame.getByPlaceholder('Card number').fill('4242424242424242');
  await stripeFrame.getByPlaceholder('MM / YY').fill('12/25');
  await stripeFrame.getByPlaceholder('CVC').fill('123');
  await stripeFrame.getByPlaceholder('ZIP').fill('10001');
  
  // Submit payment on main page
  await page.getByRole('button', { name: 'Pay Now' }).click();
  
  // Verify success
  await expect(page.getByText('Payment successful')).toBeVisible();
});
```

### Example 3: Embedded Booking Calendar

```typescript
test('select date from embedded calendar', async ({ page }) => {
  await page.goto('/book/artist/123');
  
  const calendarFrame = page.frameLocator('iframe.booking-calendar');
  
  // Select date
  await calendarFrame.getByRole('button', { name: '15' }).click();
  
  // Select time slot
  await calendarFrame.getByText('2:00 PM - 4:00 PM').click();
  
  // Confirm on main page
  await page.getByRole('button', { name: 'Continue' }).click();
  
  // Verify selection
  await expect(page.getByText('January 15, 2025')).toBeVisible();
  await expect(page.getByText('2:00 PM - 4:00 PM')).toBeVisible();
});
```

### Example 4: Artist Video Preview

```typescript
test('play artist video in iframe', async ({ page }) => {
  await page.goto('/artist/123/media');
  
  const videoFrame = page.frameLocator('iframe.video-player');
  
  // Play video
  await videoFrame.getByRole('button', { name: 'Play' }).click();
  
  // Wait for video to start
  await page.waitForTimeout(2000);
  
  // Pause video
  await videoFrame.getByRole('button', { name: 'Pause' }).click();
  
  // Verify video controls
  await expect(videoFrame.getByRole('slider', { name: 'Volume' })).toBeVisible();
});
```

### Example 5: Social Media Share Widget

```typescript
test('share artist profile via social media iframe', async ({ page }) => {
  await page.goto('/artist/123');
  
  // Click share button on main page
  await page.getByRole('button', { name: 'Share' }).click();
  
  // Interact with social media iframe
  const shareFrame = page.frameLocator('iframe.social-share');
  await shareFrame.getByRole('button', { name: 'Facebook' }).click();
  
  // Handle Facebook popup (if opens in iframe)
  await shareFrame.getByLabel('Add a comment').fill('Check out this amazing artist!');
  await shareFrame.getByRole('button', { name: 'Post' }).click();
});
```

### Example 6: Artist Availability Widget

```typescript
test('check artist availability in widget', async ({ page }) => {
  await page.goto('/search');
  
  // Click on artist card
  await page.getByText('Artist Name').click();
  
  // Availability widget loads in iframe
  const availabilityFrame = page.frameLocator('iframe.availability-widget');
  
  // Select month
  await availabilityFrame.getByRole('button', { name: 'Next Month' }).click();
  
  // Check available dates
  const availableDates = availabilityFrame.locator('.date.available');
  const count = await availableDates.count();
  expect(count).toBeGreaterThan(0);
  
  // Click first available date
  await availableDates.first().click();
});
```

### Example 7: Embedded Chat Support

```typescript
test('use chat support in iframe', async ({ page }) => {
  await page.goto('/help');
  
  // Open chat widget
  await page.getByRole('button', { name: 'Chat with us' }).click();
  
  const chatFrame = page.frameLocator('iframe.chat-widget');
  
  // Send message
  await chatFrame.getByPlaceholder('Type your message').fill('I need help with booking');
  await chatFrame.getByRole('button', { name: 'Send' }).click();
  
  // Wait for response
  await chatFrame.getByText('How can I help you?').waitFor();
  
  // Verify chat is active
  await expect(chatFrame.getByText('Agent is typing...')).toBeVisible();
});
```

## Advanced Patterns

### Pattern 1: Frame Locator with Assertions

```typescript
test('assert frame content', async ({ page }) => {
  await page.goto('/');
  
  const frame = page.frameLocator('iframe.content');
  
  await expect(frame.getByRole('heading')).toHaveText('Welcome');
  await expect(frame.getByRole('button')).toBeEnabled();
  await expect(frame.locator('.message')).toBeVisible();
});
```

### Pattern 2: Multiple Frames with Same Selector

```typescript
test('handle multiple frames', async ({ page }) => {
  await page.goto('/');
  
  // Get all frames with same class
  const frames = page.locator('iframe.content-frame');
  const count = await frames.count();
  
  for (let i = 0; i < count; i++) {
    const frame = page.frameLocator(`iframe.content-frame >> nth=${i}`);
    await frame.getByRole('button').click();
  }
});
```

### Pattern 3: Frame with Timeout

```typescript
test('wait for frame with timeout', async ({ page }) => {
  await page.goto('/');
  
  // Wait for iframe to appear
  await page.waitForSelector('iframe.lazy-frame', { timeout: 10000 });
  
  const frame = page.frameLocator('iframe.lazy-frame');
  await frame.getByText('Content').waitFor({ timeout: 5000 });
});
```

### Pattern 4: Conditional Frame Handling

```typescript
test('conditional frame interaction', async ({ page }) => {
  await page.goto('/');
  
  const frameExists = await page.locator('iframe.optional').count() > 0;
  
  if (frameExists) {
    const frame = page.frameLocator('iframe.optional');
    await frame.getByRole('button').click();
  } else {
    // Fallback to main page interaction
    await page.getByRole('button').click();
  }
});
```

### Pattern 5: Frame Object API (Alternative)

```typescript
test('use frame object API', async ({ page }) => {
  await page.goto('/');
  
  // Get frame by name
  const frame = page.frame('login-frame');
  
  if (frame) {
    await frame.fill('#username', 'testuser');
    await frame.fill('#password', 'password123');
    await frame.click('button[type="submit"]');
  }
});
```

### Pattern 6: Get All Frames

```typescript
test('list all frames', async ({ page }) => {
  await page.goto('/');
  
  const frames = page.frames();
  console.log(`Total frames: ${frames.length}`);
  
  for (const frame of frames) {
    console.log(`Frame URL: ${frame.url()}`);
    console.log(`Frame name: ${frame.name()}`);
  }
});
```

### Pattern 7: Main Frame vs Child Frames

```typescript
test('distinguish main frame from child frames', async ({ page }) => {
  await page.goto('/');
  
  const mainFrame = page.mainFrame();
  const childFrames = page.frames().filter(f => f !== mainFrame);
  
  console.log(`Main frame URL: ${mainFrame.url()}`);
  console.log(`Child frames count: ${childFrames.length}`);
});
```

## Frame Methods

### page.frameLocator(selector)

**Purpose:** Create frame locator for modern frame interactions.

```typescript
const frame = page.frameLocator('iframe.content');
```

**Returns:** FrameLocator that can be used with Playwright locators.

### page.frame(nameOrOptions)

**Purpose:** Get frame object by name or URL.

```typescript
// By name
const frame = page.frame('frame-name');

// By URL
const frame = page.frame({ url: /.*pattern.*/ });
```

**Returns:** Frame object or null.

### page.frames()

**Purpose:** Get all frames on page.

```typescript
const frames = page.frames();
```

**Returns:** Array of Frame objects.

### page.mainFrame()

**Purpose:** Get main frame of page.

```typescript
const mainFrame = page.mainFrame();
```

**Returns:** Main Frame object.

### frame.fill(selector, value)

**Purpose:** Fill input in frame.

```typescript
await frame.fill('#input', 'value');
```

### frame.click(selector)

**Purpose:** Click element in frame.

```typescript
await frame.click('button');
```

### frame.locator(selector)

**Purpose:** Create locator in frame.

```typescript
const locator = frame.locator('.element');
```

### frame.url()

**Purpose:** Get frame URL.

```typescript
const url = frame.url();
```

### frame.name()

**Purpose:** Get frame name.

```typescript
const name = frame.name();
```

## Troubleshooting

### Issue: Cannot Find Element in Frame

**Cause:** Not using frameLocator or frame object.

**Solution:** Use frameLocator to access frame content.

```typescript
// ✅ Correct
const frame = page.frameLocator('iframe');
await frame.getByLabel('Username').fill('test');

// ❌ Wrong
await page.getByLabel('Username').fill('test'); // Won't find element in iframe
```

### Issue: Frame Not Loaded

**Cause:** Interacting with frame before it's loaded.

**Solution:** Wait for frame to be attached.

```typescript
await page.waitForSelector('iframe[name="content"]');
const frame = page.frameLocator('iframe[name="content"]');
await frame.getByRole('heading').waitFor();
```

### Issue: Nested Frame Access

**Cause:** Trying to access nested frame from page directly.

**Solution:** Chain frameLocators.

```typescript
const outerFrame = page.frameLocator('iframe.outer');
const innerFrame = outerFrame.frameLocator('iframe.inner');
await innerFrame.getByText('Content').click();
```

### Issue: Frame vs FrameLocator

**Question:** When to use `page.frame()` vs `page.frameLocator()`?

**Answer:**
- **Use `frameLocator()`** (recommended): Modern API, works with Playwright locators, auto-waiting
- **Use `frame()`**: Legacy API, when you need Frame object methods

```typescript
// Modern (recommended)
const frame = page.frameLocator('iframe');
await frame.getByLabel('Username').fill('test');

// Legacy
const frame = page.frame('frame-name');
await frame.fill('#username', 'test');
```

### Issue: Multiple Frames with Same Selector

**Cause:** Multiple frames match the selector.

**Solution:** Use more specific selector or nth selector.

```typescript
// Specific selector
const frame = page.frameLocator('iframe[name="specific-frame"]');

// Or use nth
const frame = page.frameLocator('iframe >> nth=0');
```

## Summary

### Key Concepts

**1. Main frame:** Each page has main frame for page-level interactions

**2. iframe frames:** Additional frames attached with iframe HTML tag

**3. Frame locator:** Modern API for frame interactions (`page.frameLocator()`)

**4. Frame object:** Legacy API for frame access (`page.frame()`)

**5. Nested frames:** Frames can contain other frames

### Frame Methods

- `page.frameLocator(selector)` - Create frame locator (recommended)
- `page.frame(nameOrOptions)` - Get frame object
- `page.frames()` - Get all frames
- `page.mainFrame()` - Get main frame
- `frame.fill()`, `frame.click()`, `frame.locator()` - Frame interactions

### Best Practices

1. Use frameLocator for modern approach
2. Use specific frame selectors
3. Chain locators inside frames
4. Handle nested frames with chained frameLocators
5. Wait for frame to load before interacting

### Common Patterns

- Login in iframe
- Payment form in iframe
- Content in multiple frames
- Nested frames
- Dynamic frame content

## Related Topics

- Locators
- Pages
- Handles
- Isolation
- Auto-waiting
- Assertions
- iframes
- Nested frames
