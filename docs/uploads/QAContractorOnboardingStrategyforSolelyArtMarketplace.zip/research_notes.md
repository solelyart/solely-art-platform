# Research Notes: QA Contractor Evaluation

## Source 1: TestGorilla - 9 Most Important Quality Assurance Skills

**URL:** https://www.testgorilla.com/blog/how-assess-qa-skills/

### Key QA Skills to Evaluate:

1. **Ability to Run Tests**
   - Manual testing, regression testing, performance testing, automation testing
   - Tools: Selenium, Appium, Cypress
   - Should be assessed with practical QA tests

2. **Scripting and Programming**
   - Basic knowledge of Python, JavaScript, Java, C#
   - Needed for automated test scripts and understanding codebase
   - Don't need to be proficient coders, but should understand code

3. **SQL and Database Management**
   - Write SQL queries to validate data integrity
   - Perform backend testing
   - Ensure database functions correctly

4. **Project Management**
   - JIRA proficiency
   - Scrum methodology
   - Ability to manage multiple tests, documentation, communication

5. **Motivation**
   - Driven by challenge of identifying and resolving quality issues
   - Not just task completion

6. **Cultural Add**
   - QA interacts with everyone: sales, marketing, developers, stakeholders
   - 70% of employees are "not engaged" or "actively disengaged" - costs $450-550bn/year in lost productivity

7. **Critical Thinking & Problem-Solving**
   - Think outside the box
   - Analytical skills
   - Develop new approaches to problems
   - Quickly diagnose and settle on optimal solutions

8. **Communication (Written & Verbal)**
   - Document and explain issues to technical and non-technical audiences
   - Explain to shareholders in high-level, non-technical way
   - Tactful, empathetic, respectful communication

9. **Attention to Detail**
   - Go through code line by line
   - Test obscure scenarios (uncommon browsers, excessive text in forms)
   - Spot issues before they snowball into costly problems

### Assessment Methods Mentioned:

- Skills assessments (practical tests)
- QA Tester test
- SQLite Online Coding test
- SCRUM Master test
- Communication Skills test
- Attention to Detail (textual) test
- Selenium with Python test
- Culture Add test

### Key Statistics:

- 80% of customers switched brands due to poor customer experience (result of poor QA)
- 70% of employees not engaged at work costs $450-550bn/year in lost productivity


## Source 2: Yardstick - Effective Work Sample Exercises for Senior QA Engineers

**URL:** https://yardstick.team/work-samples/effective-work-sample-exercises-for-hiring-senior-qa-engineers

### Why Work Sample Exercises:

- Traditional interviews fall short in revealing true capabilities
- Resumes and behavioral questions can't demonstrate how candidates approach complex scenarios
- Work samples simulate actual job tasks
- Should evaluate: technical proficiency, strategic thinking, attention to detail, communication

### Activity #1: Test Strategy Development for a New Feature (45-60 min)

**What to Assess:**
- Strategic thinking and planning abilities
- Risk assessment and resource allocation
- How candidates prioritize testing efforts based on risk and business value

**Candidate Should Deliver:**
- Test scope and objectives
- Testing approaches and methodologies
- Test environment requirements
- Test data needs
- Risk assessment and mitigation strategies
- Resource requirements and time estimates
- Test automation opportunities
- Metrics for measuring test effectiveness

**Feedback Mechanism:**
- Provide feedback on 1 strength + 1 improvement area
- Give 10-15 min to revise based on feedback
- Assesses adaptability and receptiveness to feedback

### Activity #2: Automated Test Framework Design (60-90 min)

**What to Assess:**
- Technical expertise in test automation
- Ability to design scalable, maintainable frameworks
- Coding skills and architectural thinking
- Understanding of automation best practices

**Candidate Should Deliver:**
- Framework architecture and design patterns
- Programming language and tools selection (with justification)
- Test data management approach
- Reporting and monitoring capabilities
- CI/CD integration
- Maintainability and scalability considerations
- 2-3 automated tests as proof-of-concept

**Feedback Mechanism:**
- Provide feedback on 1 strong aspect + 1 enhancement area
- Give 15-20 min to refine design
- Tests technical adaptability and problem-solving

### Activity #3: Bug Investigation and Communication (45-60 min)

**What to Assess:**
- Analytical skills and attention to detail
- Ability to communicate technical issues to different stakeholders
- Root cause analysis capabilities

**Candidate Should Deliver:**
- Detailed reproduction steps
- Environment and configuration details
- Root cause analysis
- Potential impact on users
- Suggested fix or workaround
- Two communication artifacts:
  1. Technical explanation for developers
  2. Simplified explanation for product managers

**Feedback Mechanism:**
- Feedback on investigation + communication artifacts
- 15 min to revise one communication artifact
- Tests ability to adapt communication style based on audience

### Activity #4: QA Process Improvement Workshop (60-75 min)

**What to Assess:**
- Leadership abilities
- Process improvement mindset
- Collaborative approach to QA
- Ability to identify inefficiencies and implement improvements

**Candidate Should Deliver:**
- 3-5 specific improvement initiatives (prioritized)
- Implementation approach for each
- Required resources and challenges
- Success metrics and measurement approach
- Timeline for implementation
- Stakeholder impact analysis

**Feedback Mechanism:**
- Feedback on 1 valuable initiative + 1 refinement area
- 15 min to revise implementation approach
- Tests ability to incorporate stakeholder input and drive organizational change

### Key Insight:

All exercises include a **feedback and revision component** - this is critical for assessing:
- Adaptability
- Receptiveness to feedback
- Ability to quickly incorporate new perspectives
- Essential for senior roles


## Source 3: Platforms for Finding QA Contractors

### Premium/Vetted Platforms:

1. **Toptal** (https://www.toptal.com/developers/qa-testers)
   - Top QA testers on hourly, part-time, or full-time contract
   - Clients: Thumbtack, Bridgestone, Motorola
   - Rigorous vetting process

2. **Braintrust** (https://www.usebraintrust.com/hire/qa-testers)
   - Matches in minutes
   - Top technical talent
   - Contract and full-time roles

3. **Insight Global** (https://insightglobal.com/industries/it/qa-staffing/)
   - One of largest staffing agencies in US
   - QA professionals across array of specialties
   - Full-service staffing agency

### General Freelance Platforms:

4. **Upwork** (https://www.upwork.com/hire/software-qa-testers/)
   - Large pool of QA testers
   - "Best platform to hire skilled professionals when not looking for full-time"
   - 791+ open QA tester jobs

5. **Fiverr** (https://www.fiverr.com/hire/quality-assurance)
   - Quality assurance experts
   - Project-based work

### Specialized QA Platforms:

6. **Testlio** (https://testlio.com)
   - Specialized QA freelance platform
   - Different types of QA work
   - Recommended by QA community

7. **uTest**
   - Crowdtesting platform
   - Real-world testing scenarios

8. **We Are Testers** (http://www.we-are-testers.com/)
   - Pro QA testers only
   - Requires education, experience, or certification in QA
   - Mission-based work

### QA Consulting Firms:

9. **QA Consultants** (https://qaconsultants.com/)
   - Software quality assurance solutions
   - Enterprise and startup customers

10. **Qualitest** (https://www.qualitestgroup.com/)
    - Comprehensive QA services
    - Performance testing, functional testing, test automation

### Recruitment Specialists:

11. **MindfulQA** (https://www.mindfulqa.com/qa-recruiter/)
    - Recruiters specializing in software testers
    - All levels of experience and skill sets

### Key Insights from Reddit QA Community:

- Upwork compared to "Doordash" quality in some cases - need careful vetting
- Testlio recommended by community
- Local companies hard to find for QA-specific roles
- Freelancing platforms vary greatly in quality
