# Playwright Documentation Research - Events

**Page:** Events  
**URL:** https://playwright.dev/docs/events  
**Research Date:** December 14, 2025

## Introduction

**Capability:** Playwright allows listening to various types of events happening on web page, such as:
- Network requests
- Creation of child pages
- Dedicated workers
- etc.

**Subscription methods:** Several ways to subscribe to such events:
- Waiting for events
- Adding or removing event listeners

## Waiting for Event

**Most common pattern:** Most of time, scripts will need to wait for particular event to happen.

### Wait for Request

**Pattern:**
```typescript
// Start waiting for request before goto. Note no await.
const requestPromise = page.waitForRequest('**/*logo*.png');
await page.goto('https://wikipedia.org');
const request = await requestPromise;
console.log(request.url());
```

**Key point:** Start waiting for request **before** goto (note no await).

### Wait for Popup

**Pattern:**
```typescript
// Start waiting for popup before clicking. Note no await.
const popupPromise = page.waitForEvent('popup');
await page.getByText('open the popup').click();
const popup = await popupPromise;
await popup.goto('https://wikipedia.org');
```

**Key point:** Start waiting for popup **before** clicking (note no await).

## Adding/Removing Event Listener

**Use case:** Sometimes, events happen in random time and instead of waiting for them, they need to be handled.

**Support:** Playwright supports traditional language mechanisms for subscribing and unsubscribing from events.

### Subscribe and Unsubscribe Pattern

```typescript
page.on('request', request => console.log(`Request sent: ${request.url()}`));

const listener = request => console.log(`Request finished: ${request.url()}`);
page.on('requestfinished', listener);
await page.goto('https://wikipedia.org');

page.off('requestfinished', listener);
await page.goto('https://www.openstreetmap.org/');
```

**Methods:**
- `page.on(event, listener)` - Subscribe to event
- `page.off(event, listener)` - Unsubscribe from event

## Adding One-Off Listeners

**Use case:** If certain event needs to be handled once, there is convenience API for that.

**Pattern:**
```typescript
page.once('dialog', dialog => dialog.accept('2021'));
await page.evaluate("prompt('Enter a number:')");
```

**Method:** `page.once(event, listener)` - Handle event once

## Best Practices

### 1. Wait for Event Before Action

**✅ Good:**
```typescript
const requestPromise = page.waitForRequest('**/api/data');
await page.getByRole('button', { name: 'Load Data' }).click();
const request = await requestPromise;
```

**❌ Bad:**
```typescript
await page.getByRole('button', { name: 'Load Data' }).click();
const request = await page.waitForRequest('**/api/data'); // May miss event
```

### 2. Use Once for One-Time Events

**✅ Good:**
```typescript
page.once('dialog', dialog => dialog.accept());
await page.getByRole('button').click();
```

**Benefit:** Automatically removes listener after first event.

### 3. Remove Event Listeners When Done

**✅ Good:**
```typescript
const listener = request => console.log(request.url());
page.on('request', listener);
// ... do something
page.off('request', listener); // Clean up
```

**Benefit:** Prevents memory leaks.

### 4. Use Specific Event Patterns

**✅ Good:**
```typescript
const requestPromise = page.waitForRequest('**/api/users');
```

**❌ Bad:**
```typescript
const requestPromise = page.waitForRequest('**'); // Too broad
```

### 5. Handle Events with Timeout

**Pattern:**
```typescript
const requestPromise = page.waitForRequest('**/api/data', { timeout: 10000 });
await page.getByRole('button').click();
const request = await requestPromise;
```

## Common Use Cases

### Use Case 1: Wait for API Request

```typescript
test('wait for API request', async ({ page }) => {
  await page.goto('/');
  
  const requestPromise = page.waitForRequest('**/api/users');
  await page.getByRole('button', { name: 'Load Users' }).click();
  const request = await requestPromise;
  
  expect(request.url()).toContain('/api/users');
});
```

### Use Case 2: Wait for Response

```typescript
test('wait for API response', async ({ page }) => {
  await page.goto('/');
  
  const responsePromise = page.waitForResponse('**/api/users');
  await page.getByRole('button', { name: 'Load Users' }).click();
  const response = await responsePromise;
  
  expect(response.status()).toBe(200);
  const data = await response.json();
  expect(data.users).toHaveLength(10);
});
```

### Use Case 3: Log All Requests

```typescript
test('log all network requests', async ({ page }) => {
  const requests: string[] = [];
  
  page.on('request', request => {
    requests.push(request.url());
  });
  
  await page.goto('/');
  await page.getByRole('button', { name: 'Load Data' }).click();
  
  console.log('Requests made:', requests);
  expect(requests.length).toBeGreaterThan(0);
});
```

### Use Case 4: Handle Dialog Once

```typescript
test('handle confirmation dialog', async ({ page }) => {
  await page.goto('/');
  
  page.once('dialog', dialog => {
    expect(dialog.message()).toBe('Are you sure?');
    dialog.accept();
  });
  
  await page.getByRole('button', { name: 'Delete' }).click();
  
  await expect(page.getByText('Deleted successfully')).toBeVisible();
});
```

### Use Case 5: Wait for Multiple Events

```typescript
test('wait for multiple events', async ({ page }) => {
  await page.goto('/');
  
  const [request, response] = await Promise.all([
    page.waitForRequest('**/api/data'),
    page.waitForResponse('**/api/data'),
    page.getByRole('button', { name: 'Load' }).click(),
  ]);
  
  expect(request.method()).toBe('GET');
  expect(response.status()).toBe(200);
});
```

### Use Case 6: Wait for Console Message

```typescript
test('wait for console message', async ({ page }) => {
  await page.goto('/');
  
  const messagePromise = page.waitForEvent('console', msg => 
    msg.type() === 'log' && msg.text().includes('Data loaded')
  );
  
  await page.getByRole('button', { name: 'Load' }).click();
  const message = await messagePromise;
  
  expect(message.text()).toContain('Data loaded');
});
```

## Use Cases for Solely Art Platform

### Example 1: Wait for Booking API Request

```typescript
test('wait for booking creation request', async ({ page }) => {
  await page.goto('/book/artist/123');
  
  // Fill booking form
  await page.getByLabel('Event Date').fill('2025-01-15');
  await page.getByLabel('Event Time').fill('14:00');
  
  // Wait for booking API request
  const requestPromise = page.waitForRequest('**/api/bookings');
  await page.getByRole('button', { name: 'Confirm Booking' }).click();
  const request = await requestPromise;
  
  // Verify request payload
  const postData = request.postDataJSON();
  expect(postData.artistId).toBe(123);
  expect(postData.eventDate).toBe('2025-01-15');
});
```

### Example 2: Verify Payment API Response

```typescript
test('verify payment response', async ({ page }) => {
  await page.goto('/checkout');
  
  // Fill payment details
  await page.getByLabel('Card Number').fill('4242424242424242');
  
  // Wait for payment API response
  const responsePromise = page.waitForResponse('**/api/payments');
  await page.getByRole('button', { name: 'Pay Now' }).click();
  const response = await responsePromise;
  
  // Verify response
  expect(response.status()).toBe(200);
  const data = await response.json();
  expect(data.status).toBe('succeeded');
  expect(data.amount).toBeGreaterThan(0);
});
```

### Example 3: Log All Artist Search Requests

```typescript
test('log artist search requests', async ({ page }) => {
  const searchRequests: string[] = [];
  
  page.on('request', request => {
    if (request.url().includes('/api/artists/search')) {
      searchRequests.push(request.url());
    }
  });
  
  await page.goto('/search');
  
  // Type in search box (triggers API calls)
  await page.getByLabel('Search').fill('John');
  await page.waitForTimeout(500);
  await page.getByLabel('Search').fill('John Doe');
  
  // Verify search requests were made
  expect(searchRequests.length).toBeGreaterThan(0);
  expect(searchRequests[0]).toContain('John');
});
```

### Example 4: Handle Booking Confirmation Dialog

```typescript
test('confirm booking cancellation', async ({ page }) => {
  await page.goto('/my-bookings');
  
  // Handle confirmation dialog
  page.once('dialog', dialog => {
    expect(dialog.message()).toContain('cancel this booking');
    dialog.accept();
  });
  
  await page.getByRole('button', { name: 'Cancel Booking' }).click();
  
  await expect(page.getByText('Booking cancelled')).toBeVisible();
});
```

### Example 5: Wait for Image Upload

```typescript
test('wait for image upload request', async ({ page }) => {
  await page.goto('/artist/profile/edit');
  
  // Wait for upload request
  const requestPromise = page.waitForRequest(request =>
    request.url().includes('/api/upload') && request.method() === 'POST'
  );
  
  // Upload image
  await page.getByLabel('Profile Photo').setInputFiles('./test-image.jpg');
  const request = await requestPromise;
  
  // Verify upload
  expect(request.method()).toBe('POST');
  expect(request.headers()['content-type']).toContain('multipart/form-data');
});
```

### Example 6: Monitor Messaging WebSocket

```typescript
test('monitor messaging events', async ({ page }) => {
  const messages: string[] = [];
  
  page.on('websocket', ws => {
    ws.on('framereceived', event => {
      const payload = event.payload;
      messages.push(payload);
    });
  });
  
  await page.goto('/messages');
  
  // Send message
  await page.getByLabel('Message').fill('Hello!');
  await page.getByRole('button', { name: 'Send' }).click();
  
  // Wait for WebSocket message
  await page.waitForTimeout(1000);
  
  expect(messages.length).toBeGreaterThan(0);
});
```

### Example 7: Wait for Availability Calendar Load

```typescript
test('wait for calendar data to load', async ({ page }) => {
  await page.goto('/artist/123');
  
  // Wait for availability API response
  const responsePromise = page.waitForResponse('**/api/artists/123/availability');
  await page.getByRole('tab', { name: 'Availability' }).click();
  const response = await responsePromise;
  
  // Verify availability data
  const data = await response.json();
  expect(data.availableDates).toBeDefined();
  expect(data.availableDates.length).toBeGreaterThan(0);
});
```

## Advanced Patterns

### Pattern 1: Wait for Event with Predicate

```typescript
test('wait for specific request', async ({ page }) => {
  await page.goto('/');
  
  const requestPromise = page.waitForRequest(request =>
    request.url().includes('/api/users') && 
    request.method() === 'POST'
  );
  
  await page.getByRole('button').click();
  const request = await requestPromise;
});
```

### Pattern 2: Multiple Event Listeners

```typescript
test('listen to multiple events', async ({ page }) => {
  const events: string[] = [];
  
  page.on('request', () => events.push('request'));
  page.on('response', () => events.push('response'));
  page.on('load', () => events.push('load'));
  
  await page.goto('/');
  
  expect(events).toContain('request');
  expect(events).toContain('response');
  expect(events).toContain('load');
});
```

### Pattern 3: Conditional Event Handling

```typescript
test('conditional event handling', async ({ page }) => {
  page.on('dialog', dialog => {
    if (dialog.type() === 'confirm') {
      dialog.accept();
    } else {
      dialog.dismiss();
    }
  });
  
  await page.goto('/');
  // ... trigger dialogs
});
```

### Pattern 4: Event with Timeout

```typescript
test('wait for event with timeout', async ({ page }) => {
  await page.goto('/');
  
  try {
    const requestPromise = page.waitForRequest('**/api/data', { 
      timeout: 5000 
    });
    await page.getByRole('button').click();
    await requestPromise;
  } catch (error) {
    console.log('Request not made within 5 seconds');
  }
});
```

### Pattern 5: Remove All Listeners

```typescript
test('remove all listeners', async ({ page }) => {
  const listener1 = () => console.log('Listener 1');
  const listener2 = () => console.log('Listener 2');
  
  page.on('request', listener1);
  page.on('request', listener2);
  
  // Remove specific listener
  page.off('request', listener1);
  
  // Or remove all listeners for an event
  page.removeAllListeners('request');
});
```

### Pattern 6: Wait for Multiple Requests

```typescript
test('wait for multiple API requests', async ({ page }) => {
  await page.goto('/dashboard');
  
  const [usersReq, postsReq, commentsReq] = await Promise.all([
    page.waitForRequest('**/api/users'),
    page.waitForRequest('**/api/posts'),
    page.waitForRequest('**/api/comments'),
    page.getByRole('button', { name: 'Load All' }).click(),
  ]);
  
  expect(usersReq.url()).toContain('/users');
  expect(postsReq.url()).toContain('/posts');
  expect(commentsReq.url()).toContain('/comments');
});
```

### Pattern 7: Event Listener Cleanup

```typescript
test('cleanup event listeners', async ({ page }) => {
  const listener = request => console.log(request.url());
  
  page.on('request', listener);
  
  await page.goto('/');
  
  // Clean up
  page.off('request', listener);
  
  // Or use test.afterEach
});

test.afterEach(async ({ page }) => {
  page.removeAllListeners();
});
```

## Event Types

### Page Events

- `'console'` - Console message
- `'dialog'` - Dialog (alert, confirm, prompt)
- `'download'` - File download
- `'filechooser'` - File chooser
- `'frameattached'` - Frame attached
- `'framedetached'` - Frame detached
- `'framenavigated'` - Frame navigated
- `'load'` - Page loaded
- `'domcontentloaded'` - DOM loaded
- `'pageerror'` - Page error
- `'popup'` - Popup opened
- `'request'` - Network request
- `'requestfailed'` - Request failed
- `'requestfinished'` - Request finished
- `'response'` - Network response
- `'websocket'` - WebSocket created
- `'worker'` - Worker created

### Browser Context Events

- `'page'` - New page created
- `'backgroundpage'` - Background page created (Chrome extensions)
- `'serviceworker'` - Service worker created

### Browser Events

- `'disconnected'` - Browser disconnected

## Event Methods

### page.waitForEvent(event, optionsOrPredicate)

**Purpose:** Wait for event to fire.

```typescript
const popup = await page.waitForEvent('popup');
```

**With predicate:**
```typescript
const request = await page.waitForEvent('request', request =>
  request.url().includes('/api')
);
```

### page.waitForRequest(urlOrPredicate, options)

**Purpose:** Wait for request matching URL or predicate.

```typescript
const request = await page.waitForRequest('**/api/users');
```

### page.waitForResponse(urlOrPredicate, options)

**Purpose:** Wait for response matching URL or predicate.

```typescript
const response = await page.waitForResponse('**/api/users');
```

### page.on(event, listener)

**Purpose:** Subscribe to event.

```typescript
page.on('request', request => console.log(request.url()));
```

### page.once(event, listener)

**Purpose:** Subscribe to event once.

```typescript
page.once('dialog', dialog => dialog.accept());
```

### page.off(event, listener)

**Purpose:** Unsubscribe from event.

```typescript
page.off('request', listener);
```

### page.removeAllListeners(event)

**Purpose:** Remove all listeners for event.

```typescript
page.removeAllListeners('request');
```

## Troubleshooting

### Issue: Event Missed

**Cause:** Waiting for event after action.

**Solution:** Start waiting before action.

```typescript
// ✅ Correct
const requestPromise = page.waitForRequest('**/api/data');
await page.click('button');
const request = await requestPromise;

// ❌ Wrong
await page.click('button');
const request = await page.waitForRequest('**/api/data'); // May miss event
```

### Issue: Event Listener Not Removed

**Cause:** Forgetting to remove event listener.

**Solution:** Always remove listeners when done.

```typescript
const listener = request => console.log(request.url());
page.on('request', listener);
// ... do something
page.off('request', listener); // Clean up
```

### Issue: Event Timeout

**Cause:** Event not fired within timeout.

**Solution:** Increase timeout or verify event is actually fired.

```typescript
const requestPromise = page.waitForRequest('**/api/data', { 
  timeout: 10000 
});
```

### Issue: Wrong Event Type

**Cause:** Listening to wrong event.

**Solution:** Use correct event type.

```typescript
// For network requests
page.on('request', ...);
page.on('response', ...);

// For dialogs
page.on('dialog', ...);

// For console messages
page.on('console', ...);
```

## Summary

### Key Concepts

**1. Event types:** Network requests, dialogs, console messages, popups, etc.

**2. Waiting for events:** Use `waitForEvent()`, `waitForRequest()`, `waitForResponse()`

**3. Event listeners:** Use `on()`, `once()`, `off()`

**4. Wait before action:** Start waiting for event before triggering action

**5. Cleanup:** Remove event listeners when done

### Event Methods

- `page.waitForEvent(event)` - Wait for event
- `page.waitForRequest(url)` - Wait for request
- `page.waitForResponse(url)` - Wait for response
- `page.on(event, listener)` - Subscribe to event
- `page.once(event, listener)` - Subscribe once
- `page.off(event, listener)` - Unsubscribe
- `page.removeAllListeners(event)` - Remove all listeners

### Best Practices

1. Wait for event before action
2. Use `once()` for one-time events
3. Remove event listeners when done
4. Use specific event patterns
5. Handle events with timeout

### Common Event Types

- Network: `request`, `response`, `requestfinished`, `requestfailed`
- Page: `load`, `domcontentloaded`, `popup`
- User interaction: `dialog`, `filechooser`, `download`
- Debugging: `console`, `pageerror`

## Related Topics

- Network
- Dialogs
- Downloads
- Pages
- Popups
- WebSockets
- Console messages
- Error handling
