# Playwright Service Workers: Comprehensive Research and Analysis

**Research Date:** December 14, 2025

## 1. Introduction to Service Workers

Service Workers are a browser-native technology that provides a way to handle network requests made by a page. They can act as a network proxy, enabling features like caching, offline experiences, and background synchronization.

### 1.1. Key Characteristics

-   **Browser-Native:** Implemented directly in the browser, providing a standardized way to handle network requests.
-   **Network Proxy:** Can intercept and handle requests made by the page, including `fetch` calls and asset requests (scripts, CSS, images).
-   **Offline Experience:** Can provide an offline experience by serving cached content when the user is not connected to the network.
-   **Chromium-Only:** The documentation notes that Service Workers are currently only supported on Chromium-based browsers.

## 2. Disabling Service Workers

Playwright allows you to disable Service Workers during testing to make tests more predictable and performant. This can be done by setting the `serviceWorkers` option to `block` in your `playwright.config.ts` file.

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    serviceWorkers: 'block' // or 'allow'
  },
});
```

However, it is important to note that if your page relies on a Service Worker for its functionality, disabling it may cause the application to behave differently.

## 3. Accessing Service Workers

You can access Service Workers using the `browserContext.serviceWorkers()` method, which returns a list of all active Service Workers. You can also wait for a specific Service Worker to be registered using the `browserContext.waitForEvent('serviceworker')` method.

```typescript
const serviceWorkerPromise = context.waitForEvent('serviceworker');
await page.goto('/example-with-a-service-worker.html');
const serviceworker = await serviceWorkerPromise;
```

### 3.1. Waiting for Activation

The `browserContext.on('serviceworker')` event is fired before the Service Worker has taken control of the page. To ensure that the Service Worker is active before interacting with it, you should wait for its activation. The documentation provides an implementation-agnostic method for this:

```typescript
await page.evaluate(async () => {
  const registration = await window.navigator.serviceWorker.getRegistration();
  if (registration.active?.state === 'activated')
    return;
  await new Promise(resolve => {
    window.navigator.serviceWorker.addEventListener('controllerchange', resolve);
  });
});
```

## 4. Network Events and Routing

Any network request made by a Service Worker is reported through the `BrowserContext` object:

-   `browserContext.on('request')`
-   `browserContext.on('requestfinished')`
-   `browserContext.on('response')`
-   `browserContext.on('requestfailed')`

These requests can be intercepted and modified using `browserContext.route()`.

### 4.1. Identifying Service Worker Requests

-   `request.serviceWorker()`: Returns the Service Worker instance that made the request.
-   `response.fromServiceWorker()`: Returns `true` if the request was handled by a Service Worker.

### 4.2. Routing Service Worker Requests

You can specifically route requests made by Service Workers by checking if `route.request().serviceWorker()` is not null:

```typescript
await context.route('**', async route => {
  if (route.request().serviceWorker()) {
    // Handle Service Worker request
    await route.fulfill({
      contentType: 'text/plain',
      status: 200,
      body: 'from sw',
    });
  } else {
    // Handle other requests
    await route.continue();
  }
});
```

## 5. Known Limitations

The documentation notes a known limitation where requests for updated Service Worker main script code cannot currently be routed. This is tracked in a GitHub issue: [https://github.com/microsoft/playwright/issues/14711](https://github.com/microsoft/playwright/issues/14711)

## 6. Expert Analysis and Recommendations

### 6.1. When to Test with Service Workers

-   **Offline Functionality:** If your application has offline capabilities, you need to test them with Service Workers enabled.
-   **Caching Logic:** If you have complex caching logic implemented in a Service Worker, you should test it to ensure it works as expected.
-   **Background Sync:** If your application uses background sync, you need to test it with Service Workers enabled.

### 6.2. Best Practices

-   **Use `serviceWorkers: 'block'` for most tests:** For tests that do not rely on Service Worker functionality, disabling them can make the tests more predictable and performant.
-   **Isolate Service Worker tests:** Create a separate test suite for tests that require Service Workers to be enabled.
-   **Wait for activation:** Always wait for the Service Worker to be active before interacting with it.
-   **Use `browserContext.route()` for mocking:** Use `browserContext.route()` to mock network requests made by the Service Worker.

### 6.3. Solely Art Platform Application

For the Solely Art Platform, Service Workers could be used to:

-   **Provide an offline experience:** Allow users to browse artwork and artist profiles even when they are offline.
-   **Improve performance:** Cache frequently accessed assets to reduce load times.
-   **Enable background sync:** Allow users to upload artwork in the background, even if they lose their network connection.

When testing these features, it is crucial to have Service Workers enabled and to follow the best practices outlined in the documentation.
