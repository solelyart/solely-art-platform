# Playwright Documentation Research - Page Object Models

**Page:** Page object models  
**URL:** https://playwright.dev/docs/pom  
**Research Date:** December 13, 2025

## Introduction

### Purpose

**Goal:** Structure large test suites to optimize ease of authoring and maintenance.

**Definition:** Page object models are one approach to structure test suites.

### What is a Page Object?

**Concept:** A page object represents a part of your web application.

**Example:** E-commerce web application might have:
- Home page
- Listings page
- Checkout page

**Each can be represented by page object models.**

### Benefits

**1. Simplify authoring:**
- Create higher-level API which suits your application

**2. Simplify maintenance:**
- Capture element selectors in one place
- Create reusable code to avoid repetition

## Implementation

### Example: PlaywrightDevPage Class

**Purpose:** Encapsulate common operations on the `playwright.dev` page.

**File:** `playwright-dev-page.ts`

```typescript
import { expect, type Locator, type Page } from '@playwright/test';

export class PlaywrightDevPage {
  readonly page: Page;
  readonly getStartedLink: Locator;
  readonly gettingStartedHeader: Locator;
  readonly pomLink: Locator;
  readonly tocList: Locator;

  constructor(page: Page) {
    this.page = page;
    this.getStartedLink = page.locator('a', { hasText: 'Get started' });
    this.gettingStartedHeader = page.locator('h1', { hasText: 'Installation' });
    this.pomLink = page.locator('li', {
      hasText: 'Guides',
    }).locator('a', {
      hasText: 'Page Object Model',
    });
    this.tocList = page.locator('article div.markdown ul > li > a');
  }

  async goto() {
    await this.page.goto('https://playwright.dev');
  }

  async getStarted() {
    await this.getStartedLink.first().click();
    await expect(this.gettingStartedHeader).toBeVisible();
  }

  async pageObjectModel() {
    await this.getStarted();
    await this.pomLink.click();
  }
}
```

### Key Components

**1. Properties:**
- `readonly page: Page` - Reference to page object
- `readonly locators` - Locators for elements (defined once, reused everywhere)

**2. Constructor:**
- Takes `page` as parameter
- Initializes all locators in one place

**3. Methods:**
- Encapsulate common operations
- Provide higher-level API
- Can include assertions

### Using Page Object in Tests

**File:** `example.spec.ts`

```typescript
import { test, expect } from '@playwright/test';
import { PlaywrightDevPage } from './playwright-dev-page';

test('getting started should contain table of contents', async ({ page }) => {
  const playwrightDev = new PlaywrightDevPage(page);
  await playwrightDev.goto();
  await playwrightDev.getStarted();
  await expect(playwrightDev.tocList).toHaveText([
    `How to install Playwright`,
    `What's Installed`,
    `How to run the example test`,
    `How to open the HTML test report`,
    `Write tests using web first assertions, page fixtures and locators`,
    `Run single test, multiple tests, headed mode`,
    `Generate tests with Codegen`,
    `See a trace of your tests`
  ]);
});

test('should show Page Object Model article', async ({ page }) => {
  const playwrightDev = new PlaywrightDevPage(page);
  await playwrightDev.goto();
  await playwrightDev.pageObjectModel();
  await expect(page.locator('article')).toContainText('Page Object Model is a common pattern');
});
```

### Benefits Demonstrated

**1. Reusability:**
- `PlaywrightDevPage` instantiated in multiple tests
- Common operations (`goto()`, `getStarted()`) reused

**2. Maintainability:**
- Locators defined once in page object
- If selector changes, update in one place only

**3. Readability:**
- Test code more readable with high-level methods
- `await playwrightDev.getStarted()` vs multiple locator/click calls

**4. Abstraction:**
- Tests don't need to know implementation details
- Focus on what to test, not how to interact with page

## Best Practices

### 1. One Page Object Per Page/Component

**Structure:**
```
pages/
  ├── HomePage.ts
  ├── ArtistProfilePage.ts
  ├── BookingPage.ts
  └── CheckoutPage.ts
```

**Example:**
```typescript
export class HomePage {
  constructor(private page: Page) {}
  
  async goto() {
    await this.page.goto('/');
  }
  
  async searchArtist(name: string) {
    await this.page.getByPlaceholder('Search artists').fill(name);
    await this.page.getByRole('button', { name: 'Search' }).click();
  }
}
```

### 2. Store Locators as Properties

**✅ Good:**
```typescript
export class LoginPage {
  readonly emailInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  
  constructor(page: Page) {
    this.emailInput = page.getByLabel('Email');
    this.passwordInput = page.getByLabel('Password');
    this.loginButton = page.getByRole('button', { name: 'Login' });
  }
}
```

**❌ Bad:**
```typescript
export class LoginPage {
  constructor(private page: Page) {}
  
  async login(email: string, password: string) {
    // Locators defined inline - harder to maintain
    await this.page.getByLabel('Email').fill(email);
    await this.page.getByLabel('Password').fill(password);
    await this.page.getByRole('button', { name: 'Login' }).click();
  }
}
```

### 3. Encapsulate Actions as Methods

**✅ Good:**
```typescript
export class BookingPage {
  constructor(private page: Page) {}
  
  async selectDate(date: string) {
    await this.page.getByLabel('Date').fill(date);
  }
  
  async selectTime(time: string) {
    await this.page.getByLabel('Time').selectOption(time);
  }
  
  async completeBooking() {
    await this.page.getByRole('button', { name: 'Book Now' }).click();
  }
}
```

**Usage in test:**
```typescript
test('book artist', async ({ page }) => {
  const booking = new BookingPage(page);
  await booking.selectDate('2025-01-15');
  await booking.selectTime('14:00');
  await booking.completeBooking();
});
```

### 4. Include Assertions in Page Objects (Optional)

**Approach 1: Include assertions in page object**
```typescript
export class DashboardPage {
  constructor(private page: Page) {}
  
  async expectWelcomeMessage(name: string) {
    await expect(this.page.getByText(`Welcome, ${name}`)).toBeVisible();
  }
}
```

**Approach 2: Return data for test to assert**
```typescript
export class DashboardPage {
  constructor(private page: Page) {}
  
  async getWelcomeMessage() {
    return await this.page.getByTestId('welcome').textContent();
  }
}

// In test
test('shows welcome message', async ({ page }) => {
  const dashboard = new DashboardPage(page);
  const message = await dashboard.getWelcomeMessage();
  expect(message).toContain('Welcome');
});
```

**Recommendation:** Use approach 1 for common assertions, approach 2 for flexible assertions.

### 5. Use TypeScript for Type Safety

**Benefits:**
- Auto-completion
- Type checking
- Refactoring support

**Example:**
```typescript
export class ArtistProfilePage {
  constructor(private page: Page) {}
  
  async bookService(serviceType: 'painting' | 'sculpture' | 'photography') {
    await this.page.getByRole('button', { name: serviceType }).click();
  }
}
```

### 6. Keep Page Objects Focused

**✅ Good - Focused:**
```typescript
export class CheckoutPage {
  // Only checkout-related methods
  async enterPaymentInfo(cardNumber: string, cvv: string) {}
  async submitPayment() {}
  async getConfirmationNumber() {}
}
```

**❌ Bad - Too broad:**
```typescript
export class CheckoutPage {
  // Mixing concerns
  async enterPaymentInfo() {}
  async navigateToHome() {}  // Should be in HomePage
  async searchArtist() {}     // Should be in SearchPage
}
```

### 7. Compose Page Objects

**Pattern:** Page objects can use other page objects.

**Example:**
```typescript
export class Navigation {
  constructor(private page: Page) {}
  
  async goToProfile() {
    await this.page.getByRole('link', { name: 'Profile' }).click();
  }
}

export class DashboardPage {
  readonly navigation: Navigation;
  
  constructor(private page: Page) {
    this.navigation = new Navigation(page);
  }
  
  async navigateToProfile() {
    await this.navigation.goToProfile();
  }
}
```

### 8. Handle Waits in Page Objects

**✅ Good - Encapsulate waits:**
```typescript
export class BookingPage {
  constructor(private page: Page) {}
  
  async waitForConfirmation() {
    await this.page.waitForResponse('**/api/bookings');
    await expect(this.page.getByText('Booking confirmed')).toBeVisible();
  }
}
```

**Usage:**
```typescript
test('booking confirmation', async ({ page }) => {
  const booking = new BookingPage(page);
  await booking.completeBooking();
  await booking.waitForConfirmation();  // Wait logic encapsulated
});
```

## Advanced Patterns

### Pattern 1: Base Page Object

**Create base class with common functionality:**

```typescript
export class BasePage {
  constructor(protected page: Page) {}
  
  async goto(path: string) {
    await this.page.goto(path);
  }
  
  async waitForPageLoad() {
    await this.page.waitForLoadState('networkidle');
  }
  
  async takeScreenshot(name: string) {
    await this.page.screenshot({ path: `screenshots/${name}.png` });
  }
}

export class HomePage extends BasePage {
  constructor(page: Page) {
    super(page);
  }
  
  async goto() {
    await super.goto('/');
  }
}
```

### Pattern 2: Component Objects

**For reusable components across pages:**

```typescript
export class NavigationComponent {
  constructor(private page: Page) {}
  
  async clickLogo() {
    await this.page.getByRole('img', { name: 'Logo' }).click();
  }
  
  async openUserMenu() {
    await this.page.getByRole('button', { name: 'User menu' }).click();
  }
}

export class HomePage {
  readonly navigation: NavigationComponent;
  
  constructor(private page: Page) {
    this.navigation = new NavigationComponent(page);
  }
}

export class ArtistPage {
  readonly navigation: NavigationComponent;
  
  constructor(private page: Page) {
    this.navigation = new NavigationComponent(page);
  }
}
```

### Pattern 3: Fluent Interface

**Chain method calls for better readability:**

```typescript
export class BookingPage {
  constructor(private page: Page) {}
  
  async selectDate(date: string) {
    await this.page.getByLabel('Date').fill(date);
    return this;  // Return this for chaining
  }
  
  async selectTime(time: string) {
    await this.page.getByLabel('Time').fill(time);
    return this;
  }
  
  async submit() {
    await this.page.getByRole('button', { name: 'Submit' }).click();
    return this;
  }
}

// Usage with chaining
test('book with fluent interface', async ({ page }) => {
  const booking = new BookingPage(page);
  await booking
    .selectDate('2025-01-15')
    .then(b => b.selectTime('14:00'))
    .then(b => b.submit());
});
```

### Pattern 4: Page Object with Fixtures

**Combine page objects with Playwright fixtures:**

```typescript
// fixtures.ts
import { test as base } from '@playwright/test';
import { HomePage } from './pages/HomePage';
import { ArtistPage } from './pages/ArtistPage';

type Pages = {
  homePage: HomePage;
  artistPage: ArtistPage;
};

export const test = base.extend<Pages>({
  homePage: async ({ page }, use) => {
    await use(new HomePage(page));
  },
  artistPage: async ({ page }, use) => {
    await use(new ArtistPage(page));
  },
});

// Usage in test
test('navigate to artist', async ({ homePage, artistPage }) => {
  await homePage.goto();
  await homePage.searchArtist('John Doe');
  await artistPage.expectArtistName('John Doe');
});
```

## Use Cases for Solely Art Platform

### Example 1: Artist Profile Page Object

```typescript
export class ArtistProfilePage {
  readonly page: Page;
  readonly artistName: Locator;
  readonly artistBio: Locator;
  readonly portfolioImages: Locator;
  readonly bookButton: Locator;
  readonly availabilityCalendar: Locator;

  constructor(page: Page) {
    this.page = page;
    this.artistName = page.getByRole('heading', { level: 1 });
    this.artistBio = page.getByTestId('artist-bio');
    this.portfolioImages = page.getByTestId('portfolio-image');
    this.bookButton = page.getByRole('button', { name: 'Book Now' });
    this.availabilityCalendar = page.getByTestId('availability-calendar');
  }

  async goto(artistId: string) {
    await this.page.goto(`/artist/${artistId}`);
  }

  async viewPortfolio() {
    await this.portfolioImages.first().click();
  }

  async startBooking() {
    await this.bookButton.click();
  }

  async expectArtistName(name: string) {
    await expect(this.artistName).toHaveText(name);
  }

  async getAvailableDates() {
    const dates = await this.availabilityCalendar
      .locator('.available-date')
      .allTextContents();
    return dates;
  }
}
```

### Example 2: Booking Flow Page Object

```typescript
export class BookingFlowPage {
  readonly page: Page;
  readonly dateInput: Locator;
  readonly timeSelect: Locator;
  readonly serviceTypeSelect: Locator;
  readonly notesTextarea: Locator;
  readonly continueButton: Locator;
  readonly confirmationMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.dateInput = page.getByLabel('Select Date');
    this.timeSelect = page.getByLabel('Select Time');
    this.serviceTypeSelect = page.getByLabel('Service Type');
    this.notesTextarea = page.getByLabel('Special Requests');
    this.continueButton = page.getByRole('button', { name: 'Continue' });
    this.confirmationMessage = page.getByTestId('confirmation');
  }

  async selectDate(date: string) {
    await this.dateInput.fill(date);
  }

  async selectTime(time: string) {
    await this.timeSelect.selectOption(time);
  }

  async selectServiceType(type: string) {
    await this.serviceTypeSelect.selectOption(type);
  }

  async addNotes(notes: string) {
    await this.notesTextarea.fill(notes);
  }

  async continue() {
    await this.continueButton.click();
  }

  async completeBooking(details: {
    date: string;
    time: string;
    serviceType: string;
    notes?: string;
  }) {
    await this.selectDate(details.date);
    await this.selectTime(details.time);
    await this.selectServiceType(details.serviceType);
    if (details.notes) {
      await this.addNotes(details.notes);
    }
    await this.continue();
  }

  async expectConfirmation() {
    await expect(this.confirmationMessage).toBeVisible();
    await expect(this.confirmationMessage).toContainText('Booking confirmed');
  }
}
```

### Example 3: Messaging Page Object

```typescript
export class MessagingPage {
  readonly page: Page;
  readonly conversationList: Locator;
  readonly messageInput: Locator;
  readonly sendButton: Locator;
  readonly messages: Locator;

  constructor(page: Page) {
    this.page = page;
    this.conversationList = page.getByTestId('conversation-list');
    this.messageInput = page.getByPlaceholder('Type a message');
    this.sendButton = page.getByRole('button', { name: 'Send' });
    this.messages = page.getByTestId('message');
  }

  async goto() {
    await this.page.goto('/messages');
  }

  async selectConversation(artistName: string) {
    await this.conversationList
      .getByText(artistName)
      .click();
  }

  async sendMessage(text: string) {
    await this.messageInput.fill(text);
    await this.sendButton.click();
  }

  async expectMessageSent(text: string) {
    await expect(this.messages.last()).toContainText(text);
  }

  async getMessageCount() {
    return await this.messages.count();
  }
}
```

### Example 4: Complete Test Using Page Objects

```typescript
import { test, expect } from '@playwright/test';
import { ArtistProfilePage } from './pages/ArtistProfilePage';
import { BookingFlowPage } from './pages/BookingFlowPage';
import { MessagingPage } from './pages/MessagingPage';

test('complete booking and message artist', async ({ page }) => {
  // Step 1: View artist profile
  const artistProfile = new ArtistProfilePage(page);
  await artistProfile.goto('artist-123');
  await artistProfile.expectArtistName('John Doe');
  
  // Step 2: Start booking
  await artistProfile.startBooking();
  
  // Step 3: Complete booking flow
  const booking = new BookingFlowPage(page);
  await booking.completeBooking({
    date: '2025-01-15',
    time: '14:00',
    serviceType: 'Portrait Photography',
    notes: 'Outdoor session preferred'
  });
  await booking.expectConfirmation();
  
  // Step 4: Send message to artist
  const messaging = new MessagingPage(page);
  await messaging.goto();
  await messaging.selectConversation('John Doe');
  await messaging.sendMessage('Looking forward to the session!');
  await messaging.expectMessageSent('Looking forward to the session!');
});
```

## Summary

### Key Concepts

**1. Page Object:** Class representing part of web application

**2. Benefits:**
- Simplify authoring (higher-level API)
- Simplify maintenance (selectors in one place)
- Reusable code (avoid repetition)

**3. Structure:**
- Properties for locators
- Constructor to initialize locators
- Methods for actions
- Optional methods for assertions

### Best Practices

1. One page object per page/component
2. Store locators as properties
3. Encapsulate actions as methods
4. Use TypeScript for type safety
5. Keep page objects focused
6. Compose page objects
7. Handle waits in page objects
8. Consider base page objects for common functionality

### Advanced Patterns

1. Base page object for inheritance
2. Component objects for reusable UI components
3. Fluent interface for method chaining
4. Page object fixtures for easier test setup

### When to Use

**Use page objects when:**
- Test suite is large
- Multiple tests interact with same pages
- Need to improve maintainability
- Want to create higher-level test API

**Don't use page objects when:**
- Test suite is very small
- Pages are simple and rarely change
- Overhead outweighs benefits

## Related Topics

- Locators
- Fixtures
- Test organization
- TypeScript
- Best practices
- Test structure
- Maintainability patterns
