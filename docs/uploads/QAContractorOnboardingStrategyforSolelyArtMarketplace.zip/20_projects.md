# Playwright Documentation Research - Projects

**Page:** Projects  
**URL:** https://playwright.dev/docs/test-projects  
**Research Date:** December 13, 2025

## Overview

A **project** is a logical group of tests running with the same configuration. Projects enable:
- Running tests on different browsers and devices
- Running same tests in different configurations (e.g., logged-in vs logged-out)
- Running tests with different timeouts or retries
- Running tests against different environments (staging vs production)
- Splitting tests per package/functionality

Projects are configured in `playwright.config.ts`.

## Configure Projects for Multiple Browsers

Run tests across multiple browsers including chromium, webkit, firefox, branded browsers (Chrome, Edge), and emulated mobile devices.

```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    /* Test against mobile viewports */
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'Mobile Safari',
      use: { ...devices['iPhone 12'] },
    },
    /* Test against branded browsers */
    {
      name: 'Microsoft Edge',
      use: {
        ...devices['Desktop Edge'],
        channel: 'msedge'
      },
    },
    {
      name: 'Google Chrome',
      use: {
        ...devices['Desktop Chrome'],
        channel: 'chrome'
      },
    },
  ],
});
```

**Available browsers:**
- **Chromium** - Open-source browser engine
- **Firefox** - Mozilla Firefox
- **WebKit** - Safari browser engine
- **Google Chrome** - Branded Chrome browser (requires `channel: 'chrome'`)
- **Microsoft Edge** - Branded Edge browser (requires `channel: 'msedge'`)

**Mobile devices:**
- Pixel 5, Pixel 4, etc.
- iPhone 12, iPhone 13, etc.
- iPad Pro, iPad Mini, etc.
- Galaxy devices

See the registry of device parameters for complete list.

## Run Projects

### Run All Projects (Default)

By default, Playwright runs all configured projects:

```bash
npx playwright test
```

**Output:**
```
Running 7 tests using 5 workers
  ✓ [chromium] › example.spec.ts:3:1 › basic test (2s)
  ✓ [firefox] › example.spec.ts:3:1 › basic test (2s)
  ✓ [webkit] › example.spec.ts:3:1 › basic test (2s)
  ✓ [Mobile Chrome] › example.spec.ts:3:1 › basic test (2s)
  ✓ [Mobile Safari] › example.spec.ts:3:1 › basic test (2s)
  ✓ [Microsoft Edge] › example.spec.ts:3:1 › basic test (2s)
  ✓ [Google Chrome] › example.spec.ts:3:1 › basic test (2s)
```

### Run Specific Project

Use `--project` flag to run a single project:

```bash
npx playwright test --project=firefox
```

**Output:**
```
Running 1 test using 1 worker
  ✓ [firefox] › example.spec.ts:3:1 › basic test (2s)
```

### Run Multiple Specific Projects

```bash
npx playwright test --project=chromium --project=firefox
```

### VS Code Test Runner

The VS Code extension runs tests on the default browser (Chrome). To run on other browsers:

1. Click the play button's dropdown in the testing sidebar
2. Choose another profile
3. Or modify default profile by clicking **Select Default Profile**
4. Select browsers to run tests on

**Options:**
- Choose specific profile
- Choose various profiles
- Choose all profiles

## Configure Projects for Multiple Environments

Run tests against different environments with different configurations.

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  timeout: 60000, // Timeout is shared between all tests
  projects: [
    {
      name: 'staging',
      use: {
        baseURL: 'staging.example.com',
      },
      retries: 2,
    },
    {
      name: 'production',
      use: {
        baseURL: 'production.example.com',
      },
      retries: 0,
    },
  ],
});
```

**Use cases:**
- Different base URLs per environment
- Different retry strategies
- Different timeouts
- Different authentication states
- Different feature flags

**Run specific environment:**
```bash
npx playwright test --project=staging
npx playwright test --project=production
```

## Splitting Tests into Projects

Split tests into projects using filters to run subsets of tests.

### Example: Smoke Tests vs Full Suite

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  timeout: 60000, // Timeout is shared between all tests
  projects: [
    {
      name: 'Smoke',
      testMatch: /.*smoke.spec.ts/,
      retries: 0,
    },
    {
      name: 'Default',
      testIgnore: /.*smoke.spec.ts/,
      retries: 2,
    },
  ],
});
```

**Project configuration:**
- **Smoke project** - Runs only smoke tests (`*.smoke.spec.ts`), no retries
- **Default project** - Runs all other tests, 2 retries

**Filters available:**
- `testMatch` - Include tests matching pattern
- `testIgnore` - Exclude tests matching pattern
- `testDir` - Specify test directory
- `grep` - Include tests matching regex
- `grepInvert` - Exclude tests matching regex

### Example: Split by Feature

```typescript
projects: [
  {
    name: 'auth',
    testMatch: /.*auth.*.spec.ts/,
  },
  {
    name: 'checkout',
    testMatch: /.*checkout.*.spec.ts/,
  },
  {
    name: 'admin',
    testMatch: /.*admin.*.spec.ts/,
  },
]
```

## Dependencies

Project dependencies define projects that must run before other projects. Useful for:
- Global setup actions
- Authentication setup
- Database initialization
- Service startup

**Benefits:**
- Test reporters show setup tests
- Trace viewer records traces of setup
- Can inspect DOM snapshots of setup
- Can use fixtures in setup

### Basic Dependencies

```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'setup',
      testMatch: '**/*.setup.ts',
    },
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
      dependencies: ['setup'],
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
      dependencies: ['setup'],
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
      dependencies: ['setup'],
    },
  ],
});
```

### Running Order

**With single dependency:**
1. Tests in 'setup' project run first
2. Once all setup tests pass, dependent projects run in parallel
3. 'chromium', 'webkit', and 'firefox' projects run together (subject to worker limit)

**With multiple dependencies:**
1. All dependency projects run in parallel
2. If any dependency fails, dependent projects don't run

**Example with failure:**
1. 'Browser Login' and 'DataBase' projects run in parallel
   - 'Browser Login' passes ✓
   - 'DataBase' fails ❌
2. 'e2e tests' project is NOT run (dependency failed)

### Teardown

Add teardown to clean up after dependent projects complete:

```typescript
projects: [
  {
    name: 'setup',
    testMatch: '**/*.setup.ts',
    teardown: 'cleanup',
  },
  {
    name: 'cleanup',
    testMatch: '**/*.teardown.ts',
  },
  {
    name: 'tests',
    dependencies: ['setup'],
  },
]
```

See the teardown guide for more information.

## Running Order

Projects run in parallel by default, subject to:
- Maximum worker limit
- Project dependencies
- Available system resources

**Default behavior:**
- All projects run simultaneously
- Each project uses available workers
- Tests within project follow project configuration

**With dependencies:**
- Dependencies run first
- Dependent projects wait for dependencies to complete
- Multiple dependencies run in parallel

## Test Filtering with Dependencies

All test filtering options directly select primary tests:
- `--grep` / `--grep-invert`
- `--shard`
- Direct location in command line
- `test.only()`

**Behavior:** If selected tests belong to a project with dependencies, all tests from those dependencies also run.

### Ignore Dependencies

Use `--no-deps` to ignore all dependencies and teardowns:

```bash
npx playwright test --no-deps
```

Only directly selected projects will run.

## Custom Project Parameters

Projects can be used to parameterize tests with custom configuration.

See the separate guide on test parameterization for details.

## Best Practices

### 1. Use Descriptive Project Names

```typescript
projects: [
  { name: 'Desktop Chrome' },
  { name: 'Mobile Safari' },
  { name: 'Staging Environment' },
]
```

### 2. Group Related Configurations

```typescript
projects: [
  // Desktop browsers
  { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
  { name: 'webkit', use: { ...devices['Desktop Safari'] } },
  
  // Mobile devices
  { name: 'Mobile Chrome', use: { ...devices['Pixel 5'] } },
  { name: 'Mobile Safari', use: { ...devices['iPhone 12'] } },
]
```

### 3. Use Setup Projects for Common Tasks

```typescript
projects: [
  {
    name: 'setup',
    testMatch: '**/*.setup.ts',
  },
  {
    name: 'tests',
    dependencies: ['setup'],
  },
]
```

### 4. Separate Smoke Tests

```typescript
projects: [
  {
    name: 'smoke',
    testMatch: /.*smoke.spec.ts/,
    retries: 0,
  },
  {
    name: 'full',
    testIgnore: /.*smoke.spec.ts/,
    retries: 2,
  },
]
```

### 5. Configure Retries Per Environment

```typescript
projects: [
  {
    name: 'production',
    use: { baseURL: 'https://prod.example.com' },
    retries: 0, // No retries in production
  },
  {
    name: 'staging',
    use: { baseURL: 'https://staging.example.com' },
    retries: 2, // Allow retries in staging
  },
]
```

### 6. Use Shared Timeout

```typescript
export default defineConfig({
  timeout: 60000, // Shared across all projects
  projects: [
    { name: 'chromium' },
    { name: 'firefox' },
  ],
});
```

### 7. Override Per Project When Needed

```typescript
projects: [
  {
    name: 'slow-tests',
    testMatch: /.*slow.spec.ts/,
    timeout: 120000, // Override shared timeout
  },
]
```

### 8. Use Dependencies for Setup

```typescript
projects: [
  { name: 'auth-setup', testMatch: '**/*.auth.ts' },
  { name: 'db-setup', testMatch: '**/*.db.ts' },
  {
    name: 'tests',
    dependencies: ['auth-setup', 'db-setup'],
  },
]
```

### 9. Run Specific Projects in CI

```bash
# Run only smoke tests in PR checks
npx playwright test --project=smoke

# Run full suite in main branch
npx playwright test
```

### 10. Document Project Purpose

```typescript
projects: [
  {
    // Runs critical path tests with no retries
    name: 'smoke',
    testMatch: /.*smoke.spec.ts/,
    retries: 0,
  },
]
```

## Common Patterns

### Cross-Browser Testing

```typescript
projects: [
  { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
  { name: 'webkit', use: { ...devices['Desktop Safari'] } },
]
```

### Mobile and Desktop

```typescript
projects: [
  { name: 'Desktop', use: { ...devices['Desktop Chrome'] } },
  { name: 'Mobile', use: { ...devices['iPhone 12'] } },
  { name: 'Tablet', use: { ...devices['iPad Pro'] } },
]
```

### Multiple Environments

```typescript
projects: [
  {
    name: 'dev',
    use: { baseURL: 'http://localhost:3000' },
  },
  {
    name: 'staging',
    use: { baseURL: 'https://staging.example.com' },
  },
  {
    name: 'production',
    use: { baseURL: 'https://example.com' },
  },
]
```

### Authenticated vs Unauthenticated

```typescript
projects: [
  {
    name: 'logged-out',
    use: { storageState: { cookies: [], origins: [] } },
  },
  {
    name: 'logged-in',
    use: { storageState: 'auth.json' },
    dependencies: ['auth-setup'],
  },
]
```

### Feature-Based Split

```typescript
projects: [
  { name: 'auth', testMatch: /.*auth.*.spec.ts/ },
  { name: 'checkout', testMatch: /.*checkout.*.spec.ts/ },
  { name: 'search', testMatch: /.*search.*.spec.ts/ },
  { name: 'profile', testMatch: /.*profile.*.spec.ts/ },
]
```

### Smoke vs Regression

```typescript
projects: [
  {
    name: 'smoke',
    testMatch: /.*smoke.spec.ts/,
    retries: 0,
    timeout: 30000,
  },
  {
    name: 'regression',
    testIgnore: /.*smoke.spec.ts/,
    retries: 2,
    timeout: 60000,
  },
]
```

### Setup with Multiple Dependencies

```typescript
projects: [
  { name: 'db-setup', testMatch: '**/*.db.setup.ts' },
  { name: 'auth-setup', testMatch: '**/*.auth.setup.ts' },
  { name: 'api-setup', testMatch: '**/*.api.setup.ts' },
  {
    name: 'e2e-tests',
    dependencies: ['db-setup', 'auth-setup', 'api-setup'],
  },
]
```

## Related Topics to Explore

- Test configuration
- Device emulation
- Browser contexts
- Test dependencies
- Global setup and teardown
- Test reporters
- Trace viewer
- Fixtures
- Test parameterization
- CI/CD integration
- Test organization strategies
