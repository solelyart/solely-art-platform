# Playwright Documentation Research - Best Practices

**Page:** Best Practices  
**URL:** https://playwright.dev/docs/best-practices  
**Research Date:** December 13, 2025

## Introduction

This guide helps ensure you're following best practices and writing tests that are more resilient.

## Testing Philosophy

### Test User-Visible Behavior

**Core principle:** Automated tests should verify that application code works for end users, and avoid relying on implementation details.

**What to avoid testing:**
- Function names
- Whether something is an array
- CSS class names
- Internal implementation details

**What to test:**
- What users see on the page
- What users interact with
- Rendered output

**Rationale:** End users see/interact with rendered output, so tests should do the same.

### Make Tests as Isolated as Possible

**Core principle:** Each test should be completely isolated from another test and run independently.

**Test isolation includes:**
- Own local storage
- Own session storage
- Own data
- Own cookies

**Benefits:**
- Improves reproducibility
- Makes debugging easier
- Prevents cascading test failures

**Implementation with hooks:**

```typescript
import { test } from '@playwright/test';

test.beforeEach(async ({ page }) => {
  // Runs before each test and signs in each page
  await page.goto('https://github.com/login');
  await page.getByLabel('Username or email address').fill('username');
  await page.getByLabel('Password').fill('password');
  await page.getByRole('button', { name: 'Sign in' }).click();
});

test('first', async ({ page }) => {
  // page is signed in
});

test('second', async ({ page }) => {
  // page is signed in
});
```

**Alternative:** Reuse signed-in state with setup project to log in only once and skip login for all tests.

**Balance:** Some duplication is acceptable if it keeps tests clearer and easier to read/maintain.

### Avoid Testing Third-Party Dependencies

**Core principle:** Only test what you control.

**What NOT to test:**
- Links to external sites
- Third-party servers you don't control
- External content you can't control

**Problems with testing third parties:**
- Time consuming
- Slows down tests
- Cannot control page content
- Cookie banners may appear
- Overlay pages may interfere
- Unpredictable failures

**Solution:** Use Playwright Network API to mock responses:

```typescript
await page.route('**/api/fetch_data_third_party_dependency', route => route.fulfill({
  status: 200,
  body: testData,
}));
await page.goto('https://example.com');
```

### Testing with a Database

**Best practices:**
- Control the data
- Test against staging environment
- Ensure data doesn't change
- For visual regression: same OS and browser versions

## Best Practices

### Use Locators

**Why:** Need to find elements on webpage for end-to-end tests.

**Benefits of Playwright locators:**
- Auto-waiting
- Retry-ability
- Actionability checks (visible, enabled, etc.)

**Recommended approach:** Prioritize user-facing attributes and explicit contracts.

**Good example:**
```typescript
// 👍
page.getByRole('button', { name: 'submit' });
```

### Use Chaining and Filtering

**Chaining:** Narrow down search to particular part of page.

```typescript
const product = page.getByRole('listitem').filter({ hasText: 'Product 2' });
```

**Filtering by text and locator:**

```typescript
await page
    .getByRole('listitem')
    .filter({ hasText: 'Product 2' })
    .getByRole('button', { name: 'Add to cart' })
    .click();
```

### Prefer User-Facing Attributes to XPath or CSS Selectors

**Problem:** DOM can easily change, causing tests to fail.

**Bad example:**
```typescript
// 👎
page.locator('button.buttonIcon.episode-actions-later');
```

**Reason:** Designer changes class → test breaks.

**Good example:**
```typescript
// 👍
page.getByRole('button', { name: 'submit' });
```

### Generate Locators

**Tool:** Playwright test generator

**Capabilities:**
- Generates tests
- Picks locators automatically
- Prioritizes: role, text, test id locators
- Improves locators if multiple elements match
- Makes locators resilient and unique

#### Use Codegen to Generate Locators

**Command:**
```bash
npx playwright codegen playwright.dev
```

**Opens:**
- New browser window
- Playwright inspector

**Usage:**
1. Click 'Record' button to stop recording
2. Click 'Pick Locator' button
3. Hover over elements to see locators
4. Click element to add locator to inspector
5. Copy locator or edit in inspector

#### Use VS Code Extension to Generate Locators

**Benefits:**
- Generate locators
- Record tests
- Great developer experience
- Write, run, debug tests

### Use Web First Assertions

**Core principle:** Use assertions that wait until expected condition is met.

**Good example:**
```typescript
// 👍
await expect(page.getByText('welcome')).toBeVisible();
```

**Bad example:**
```typescript
// 👎
expect(await page.getByText('welcome').isVisible()).toBe(true);
```

**Why bad example fails:**
- `await` is inside `expect` rather than before it
- Test won't wait
- Just checks locator and returns immediately

**Behavior:** If alert message takes half second to appear, `toBeVisible()` will wait and retry.

### Don't Use Manual Assertions

**Problem:** Manual assertions don't await the expect.

**Bad:**
```typescript
// 👎
expect(await page.getByText('welcome').isVisible()).toBe(true);
```

**Good:**
```typescript
// 👍
await expect(page.getByText('welcome')).toBeVisible();
```

## Configure Debugging

### Local Debugging

**Recommended:** Debug tests live in VS Code with VS Code extension.

**Method:**
- Right-click line next to test
- Opens browser window
- Pauses at breakpoint

**Live debugging:**
- Click/edit locators in VS Code
- Highlights in browser window
- Shows matching locators on page

**Alternative:** Playwright inspector with `--debug` flag:

```bash
npx playwright test --debug
```

**Debug specific test:**
```bash
npx playwright test example.spec.ts:9 --debug
```

### Debugging on CI

**Recommended:** Use Playwright trace viewer instead of videos/screenshots.

**Benefits:**
- Full trace of tests
- Local Progressive Web App (PWA)
- Easily shared
- View timeline
- Inspect DOM snapshots with dev tools
- View network requests

**Configuration:**
- Set in Playwright config file
- Runs on CI on first retry of failed test
- Don't set to "on" for every test (performance heavy)

**Run trace locally:**
```bash
npx playwright test --trace on
```

**View traces:**
```bash
npx playwright show-report
```

## Use Playwright's Tooling

**Available tools:**

1. **VS Code extension** - Great developer experience for writing, running, debugging tests

2. **Test generator** - Generates tests and picks locators

3. **Trace viewer** - Full trace as local PWA, view timeline, DOM snapshots, network requests

4. **UI Mode** - Explore, run, debug tests with time travel and watch mode

5. **TypeScript** - Works out of box, better IDE integrations, highlights errors, just use `.ts` extension

## Test Across All Browsers

**Why:** Ensures app works for all users.

**Configuration:**

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
  ],
});
```

## Keep Playwright Dependency Up to Date

**Why:**
- Test on latest browser versions
- Catch failures before public release

**Update command:**
```bash
npm install -D @playwright/test@latest
```

**Check version:**
```bash
npx playwright --version
```

**Reference:** Check release notes for latest version and changes.

## Run Tests on CI

**Best practices:**
- Setup CI/CD
- Run tests frequently
- Ideally on each commit and pull request
- Playwright has GitHub Actions workflow (no setup required)

**Platform recommendation:**
- Use Linux on CI (cheaper)
- Developers can use any environment locally

**Performance:** Consider sharding to make CI faster.

### Optimize Browser Downloads on CI

**Recommendation:** Only install browsers you actually need.

**Example:**
```yaml
# Instead of installing all browsers
npx playwright install --with-deps

# Install only Chromium
npx playwright install chromium --with-deps
```

**Benefits:**
- Saves download time
- Saves disk space on CI machines

## Lint Your Tests

**Recommendations:**
- Use TypeScript
- Use ESLint for tests
- Catches errors early

**Specific rule:** `@typescript-eslint/no-floating-promises`
- Ensures no missing awaits before async calls to Playwright API

**CI check:**
```bash
tsc --noEmit
```
- Ensures functions called with right signature

## Use Parallelism and Sharding

### Parallelism

**Default:** Playwright runs tests in parallel.

**Behavior:** Tests in single file run in order, in same worker process.

**For many independent tests in single file:**

```typescript
import { test } from '@playwright/test';

test.describe.configure({ mode: 'parallel' });

test('runs in parallel 1', async ({ page }) => { /* ... */ });
test('runs in parallel 2', async ({ page }) => { /* ... */ });
```

### Sharding

**Purpose:** Execute test suite on multiple machines.

**Command:**
```bash
npx playwright test --shard=1/3
```

## Productivity Tips

### Use Soft Assertions

**Normal behavior:** Test fails → error message shown in VS Code, terminal, HTML report, or trace viewer.

**Soft assertions:** Don't immediately terminate test execution.

**Behavior:**
- Compile list of failed assertions
- Display after test ends

**Example:**
```typescript
// Make a few checks that will not stop the test when failed...
await expect.soft(page.getByTestId('status')).toHaveText('Success');

// ... and continue the test to check more things
await page.getByRole('link', { name: 'next page' }).click();
```

**Use case:** Check multiple things without stopping at first failure.

## Summary of Best Practices

### Testing Philosophy
1. Test user-visible behavior, not implementation details
2. Make tests isolated with own storage/data/cookies
3. Avoid testing third-party dependencies
4. Control database data in staging environment

### Locators
5. Use Playwright locators with auto-waiting
6. Use chaining and filtering
7. Prefer user-facing attributes over CSS/XPath
8. Generate locators with codegen or VS Code extension

### Assertions
9. Use web first assertions (await expect)
10. Don't use manual assertions

### Debugging
11. Debug locally with VS Code extension or --debug flag
12. Use trace viewer on CI instead of videos/screenshots

### Tooling
13. Use VS Code extension, test generator, trace viewer, UI Mode
14. Use TypeScript for better IDE integrations

### Cross-Browser Testing
15. Test across all browsers (Chromium, Firefox, WebKit)
16. Keep Playwright up to date

### CI/CD
17. Run tests on CI frequently (each commit/PR)
18. Use Linux on CI
19. Optimize browser downloads (install only what you need)
20. Lint tests with ESLint
21. Use parallelism and sharding

### Productivity
22. Use soft assertions for multiple checks

## Related Topics to Explore

- Locators
- Web first assertions
- Test generator (codegen)
- VS Code extension
- Trace viewer
- UI Mode
- TypeScript
- Browser configuration
- CI/CD setup
- Parallelism
- Sharding
- Soft assertions
- Network API
- Setup projects
- Authentication
