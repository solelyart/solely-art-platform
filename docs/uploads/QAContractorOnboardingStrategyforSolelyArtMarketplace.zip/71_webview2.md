# Playwright Documentation Research - WebView2

**Page:** WebView2
**URL:** https://playwright.dev/docs/webview2
**Research Date:** December 14, 2025

## Overview

Playwright provides support for testing WebView2 applications.

### Key Features

- **Connect to WebView2:** To automate and test WebView2 applications.
- **Use the same Playwright API:** For consistency with web testing.

## Usage

```javascript
const { _android, _electron, chromium, devices, firefox, webkit } = require("playwright");

(async () => {
  const browser = await chromium.connectOverCDP("http://localhost:9222");
  const context = browser.contexts()[0];
  const page = context.pages()[0];
  // ...
})();
```

## Summary

### Key Takeaways

- **`chromium.connectOverCDP()`:** To connect to a WebView2 application.
- **Use the same Playwright API:** To automate and test.

### Related Topics

- Browsers
- Browser Contexts
