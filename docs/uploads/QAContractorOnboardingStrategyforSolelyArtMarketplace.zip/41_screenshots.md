# Playwright Documentation Research - Screenshots

**Page:** Screenshots  
**URL:** https://playwright.dev/docs/screenshots  
**Research Date:** December 13, 2025

## Introduction

### Basic Screenshot

**Quick way to capture screenshot and save to file:**

```typescript
await page.screenshot({ path: 'screenshot.png' });
```

**Note:** Screenshots API accepts many parameters for image format, clip area, quality, etc.

## Full Page Screenshots

### Definition

**Full page screenshot:** Screenshot of full scrollable page, as if you had very tall screen and page could fit entirely.

### Usage

```typescript
await page.screenshot({ path: 'screenshot.png', fullPage: true });
```

**Benefit:** Captures entire page content, not just viewport.

## Capture into Buffer

### Purpose

Rather than writing to file, get buffer with image for:
- Post-processing
- Passing to third party pixel diff facility

### Usage

```typescript
const buffer = await page.screenshot();
console.log(buffer.toString('base64'));
```

**Returns:** Buffer containing image data.

## Element Screenshot

### Purpose

Take screenshot of single element instead of entire page.

### Usage

```typescript
await page.locator('.header').screenshot({ path: 'screenshot.png' });
```

**Use case:** Capture specific component or section.

## Screenshot API Parameters

### Common Options

**path:** File path to save screenshot
```typescript
await page.screenshot({ path: 'screenshot.png' });
```

**fullPage:** Capture full scrollable page
```typescript
await page.screenshot({ fullPage: true });
```

**type:** Image format (png, jpeg)
```typescript
await page.screenshot({ type: 'jpeg' });
```

**quality:** Image quality (0-100, only for jpeg)
```typescript
await page.screenshot({ type: 'jpeg', quality: 80 });
```

**clip:** Capture specific area
```typescript
await page.screenshot({ 
  clip: { x: 0, y: 0, width: 100, height: 100 } 
});
```

**omitBackground:** Transparent background (png only)
```typescript
await page.screenshot({ omitBackground: true });
```

**animations:** Control CSS animations
```typescript
await page.screenshot({ animations: 'disabled' });
```

**caret:** Control text caret visibility
```typescript
await page.screenshot({ caret: 'hide' });
```

**scale:** Page scale factor
```typescript
await page.screenshot({ scale: 'css' }); // or 'device'
```

## Best Practices

### 1. Use Screenshots for Visual Regression Testing

**Pattern:**
```typescript
test('homepage looks correct', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveScreenshot('homepage.png');
});
```

### 2. Capture Full Page for Documentation

**Use case:** Generate documentation screenshots.

```typescript
await page.screenshot({ 
  path: 'docs/homepage.png', 
  fullPage: true 
});
```

### 3. Capture Specific Elements

**Use case:** Test individual components.

```typescript
test('header component', async ({ page }) => {
  await page.goto('/');
  const header = page.locator('header');
  await expect(header).toHaveScreenshot('header.png');
});
```

### 4. Use Buffer for Comparison

**Use case:** Compare screenshots programmatically.

```typescript
const screenshot1 = await page.screenshot();
// ... make changes
const screenshot2 = await page.screenshot();
// Compare buffers
```

### 5. Disable Animations for Consistent Screenshots

**Problem:** Animations cause flaky visual tests.

**Solution:**
```typescript
await page.screenshot({ 
  animations: 'disabled',
  path: 'screenshot.png'
});
```

### 6. Hide Text Caret

**Problem:** Blinking cursor causes inconsistent screenshots.

**Solution:**
```typescript
await page.screenshot({ 
  caret: 'hide',
  path: 'screenshot.png'
});
```

### 7. Use JPEG for Large Screenshots

**Benefit:** Smaller file size.

```typescript
await page.screenshot({ 
  type: 'jpeg',
  quality: 90,
  fullPage: true,
  path: 'screenshot.jpg'
});
```

## Common Use Cases

### Use Case 1: Visual Regression Testing

```typescript
import { test, expect } from '@playwright/test';

test('visual regression', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveScreenshot();
});
```

**Playwright automatically:**
- Takes screenshot
- Compares with baseline
- Fails test if different

### Use Case 2: Debugging Test Failures

```typescript
test('complex interaction', async ({ page }) => {
  await page.goto('/');
  
  // Take screenshot before action
  await page.screenshot({ path: 'before.png' });
  
  await page.getByRole('button').click();
  
  // Take screenshot after action
  await page.screenshot({ path: 'after.png' });
});
```

### Use Case 3: Documentation Generation

```typescript
// Generate screenshots for documentation
async function generateDocs() {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  
  await page.goto('/');
  await page.screenshot({ 
    path: 'docs/homepage.png',
    fullPage: true
  });
  
  await page.goto('/features');
  await page.screenshot({ 
    path: 'docs/features.png',
    fullPage: true
  });
  
  await browser.close();
}
```

### Use Case 4: Component Screenshots

```typescript
test('capture all components', async ({ page }) => {
  await page.goto('/components');
  
  // Capture each component
  await page.locator('.button-component').screenshot({ 
    path: 'components/button.png' 
  });
  
  await page.locator('.card-component').screenshot({ 
    path: 'components/card.png' 
  });
  
  await page.locator('.form-component').screenshot({ 
    path: 'components/form.png' 
  });
});
```

### Use Case 5: Responsive Screenshots

```typescript
test('responsive design', async ({ page }) => {
  // Desktop
  await page.setViewportSize({ width: 1920, height: 1080 });
  await page.goto('/');
  await page.screenshot({ path: 'desktop.png' });
  
  // Tablet
  await page.setViewportSize({ width: 768, height: 1024 });
  await page.screenshot({ path: 'tablet.png' });
  
  // Mobile
  await page.setViewportSize({ width: 375, height: 667 });
  await page.screenshot({ path: 'mobile.png' });
});
```

## Use Cases for Solely Art Platform

### Example 1: Artist Profile Screenshots

```typescript
test('artist profile visual test', async ({ page }) => {
  await page.goto('/artist/123');
  
  // Full page screenshot
  await expect(page).toHaveScreenshot('artist-profile.png', {
    fullPage: true
  });
  
  // Component screenshots
  await expect(page.locator('.artist-header')).toHaveScreenshot('artist-header.png');
  await expect(page.locator('.portfolio-grid')).toHaveScreenshot('portfolio.png');
  await expect(page.locator('.booking-widget')).toHaveScreenshot('booking-widget.png');
});
```

### Example 2: Booking Flow Screenshots

```typescript
test('booking flow documentation', async ({ page }) => {
  await page.goto('/artist/123');
  
  // Step 1: Artist profile
  await page.screenshot({ 
    path: 'docs/booking-step1-profile.png',
    fullPage: true
  });
  
  // Step 2: Date selection
  await page.getByRole('button', { name: 'Book Now' }).click();
  await page.screenshot({ 
    path: 'docs/booking-step2-date.png'
  });
  
  // Step 3: Confirmation
  await page.getByLabel('Date').fill('2025-01-15');
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.screenshot({ 
    path: 'docs/booking-step3-confirm.png'
  });
});
```

### Example 3: Error State Screenshots

```typescript
test('capture error states', async ({ page }) => {
  await page.goto('/booking');
  
  // Submit empty form to trigger errors
  await page.getByRole('button', { name: 'Submit' }).click();
  
  // Capture error state
  await page.screenshot({ 
    path: 'error-states/booking-validation.png'
  });
});
```

### Example 4: Responsive Design Testing

```typescript
test('responsive artist profile', async ({ page }) => {
  await page.goto('/artist/123');
  
  // Desktop view
  await page.setViewportSize({ width: 1920, height: 1080 });
  await page.screenshot({ 
    path: 'responsive/artist-desktop.png',
    fullPage: true
  });
  
  // Tablet view
  await page.setViewportSize({ width: 768, height: 1024 });
  await page.screenshot({ 
    path: 'responsive/artist-tablet.png',
    fullPage: true
  });
  
  // Mobile view
  await page.setViewportSize({ width: 375, height: 667 });
  await page.screenshot({ 
    path: 'responsive/artist-mobile.png',
    fullPage: true
  });
});
```

### Example 5: Visual Regression for Components

```typescript
test('messaging component visual regression', async ({ page }) => {
  await page.goto('/messages');
  
  // Disable animations for consistent screenshots
  await expect(page.locator('.message-list')).toHaveScreenshot('message-list.png', {
    animations: 'disabled'
  });
  
  await expect(page.locator('.message-input')).toHaveScreenshot('message-input.png', {
    animations: 'disabled',
    caret: 'hide'
  });
});
```

### Example 6: Payment Flow Screenshots

```typescript
test('payment flow screenshots', async ({ page }) => {
  await page.goto('/checkout');
  
  // Capture payment form
  const paymentForm = page.locator('.payment-form');
  await paymentForm.screenshot({ 
    path: 'payment/payment-form.png'
  });
  
  // Capture success state
  await page.getByRole('button', { name: 'Pay' }).click();
  await page.waitForSelector('.payment-success');
  await page.screenshot({ 
    path: 'payment/payment-success.png'
  });
});
```

## Advanced Patterns

### Pattern 1: Screenshot on Test Failure

```typescript
import { test } from '@playwright/test';

test.afterEach(async ({ page }, testInfo) => {
  if (testInfo.status !== testInfo.expectedStatus) {
    // Take screenshot on failure
    const screenshot = await page.screenshot();
    await testInfo.attach('screenshot', { 
      body: screenshot, 
      contentType: 'image/png' 
    });
  }
});
```

### Pattern 2: Screenshot Comparison with Threshold

```typescript
test('visual comparison with threshold', async ({ page }) => {
  await page.goto('/');
  
  await expect(page).toHaveScreenshot('homepage.png', {
    maxDiffPixels: 100, // Allow up to 100 pixels difference
  });
});
```

### Pattern 3: Masked Screenshots

```typescript
test('screenshot with masked elements', async ({ page }) => {
  await page.goto('/');
  
  await expect(page).toHaveScreenshot({
    mask: [page.locator('.dynamic-content')], // Mask dynamic content
  });
});
```

### Pattern 4: Screenshot with Custom Name

```typescript
test('dynamic screenshot names', async ({ page }) => {
  const timestamp = Date.now();
  await page.goto('/');
  await page.screenshot({ 
    path: `screenshots/homepage-${timestamp}.png` 
  });
});
```

### Pattern 5: Screenshot Grid

```typescript
test('screenshot grid of products', async ({ page }) => {
  await page.goto('/artists');
  
  const artists = page.locator('.artist-card');
  const count = await artists.count();
  
  for (let i = 0; i < count; i++) {
    await artists.nth(i).screenshot({ 
      path: `artists/artist-${i}.png` 
    });
  }
});
```

## Configuration

### Global Screenshot Configuration

```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    screenshot: 'only-on-failure', // or 'on', 'off'
  },
});
```

### Per-Test Screenshot Configuration

```typescript
test.use({ screenshot: 'on' });

test('always take screenshot', async ({ page }) => {
  await page.goto('/');
  // Screenshot automatically taken
});
```

## Summary

### Key Concepts

**1. Basic screenshot:** `page.screenshot({ path: 'file.png' })`

**2. Full page screenshot:** `fullPage: true` option

**3. Buffer capture:** Get buffer instead of saving to file

**4. Element screenshot:** `locator.screenshot()` for specific elements

### Screenshot Options

- **path** - File path to save
- **fullPage** - Capture full scrollable page
- **type** - Image format (png, jpeg)
- **quality** - JPEG quality (0-100)
- **clip** - Capture specific area
- **omitBackground** - Transparent background
- **animations** - Control animations
- **caret** - Control text caret
- **scale** - Page scale factor

### Common Use Cases

1. Visual regression testing
2. Debugging test failures
3. Documentation generation
4. Component screenshots
5. Responsive design testing
6. Error state capture

### Best Practices

1. Use screenshots for visual regression
2. Capture full page for documentation
3. Capture specific elements for components
4. Use buffer for programmatic comparison
5. Disable animations for consistency
6. Hide text caret to avoid flakiness
7. Use JPEG for large screenshots

## Related Topics

- Visual comparisons
- Test assertions
- Debugging
- Test configuration
- Locators
- Page interactions
- Test reporters
