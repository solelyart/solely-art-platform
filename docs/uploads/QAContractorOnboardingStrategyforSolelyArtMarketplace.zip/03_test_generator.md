# Playwright Documentation Research - Test Generator (Codegen)

**Page:** Test generator  
**URL:** https://playwright.dev/docs/codegen  
**Research Date:** December 13, 2025

## Overview

Playwright includes a powerful test generator called Codegen that automatically generates tests as you perform actions in the browser. This is an excellent way to quickly get started with testing and learn Playwright's best practices for locators.

## Core Capabilities

### Intelligent Locator Generation

The test generator analyzes the page and automatically determines the best locator, prioritizing role, text, and test ID locators. When multiple elements match a locator, the generator improves it to make it resilient and uniquely identify the target element.

### Basic Usage

```bash
npx playwright codegen demo.playwright.dev/todomvc
```

The URL is optional - you can run the command without it and add the URL directly in the browser window.

## Recording Capabilities

### Actions Recording

The test generator can record user interactions automatically:
- **Click actions** - Simply click on elements
- **Fill actions** - Type into input fields
- **Navigation** - Page navigations are captured
- All interactions are converted to Playwright code in real-time

### Assertions Recording

The generator includes a toolbar with assertion options. Click an icon, then click an element to create assertions:

1. **Assert visibility** - Verify an element is visible
2. **Assert text** - Verify an element contains specific text
3. **Assert value** - Verify an element has a specific value

### Workflow

1. Run the `codegen` command
2. Perform actions in the browser window
3. Playwright generates code in the Inspector window
4. Stop recording when finished
5. Use the **copy** button to copy generated test to your editor
6. Use the **clear** button to start over if needed

## Locator Generation

The test generator can generate locators independently of full test recording:

1. Press the **Record** button to stop recording
2. The **Pick Locator** button appears
3. Click **Pick Locator** and hover over elements
4. The locator is highlighted underneath each element
5. Click an element to select its locator
6. The locator code appears in a field next to the Pick Locator button
7. Edit the locator to fine-tune it
8. Use the copy button to copy it to your code

## Emulation Options

### Viewport Size

Generate tests with specific viewport dimensions:

```bash
npx playwright codegen --viewport-size="800,600" playwright.dev
```

**Important:** Playwright opens a browser window with a fixed viewport size (not responsive) because tests need to run under consistent conditions.

### Device Emulation

Record tests while emulating mobile devices:

```bash
npx playwright codegen --device="iPhone 13" playwright.dev
```

This sets the viewport size, user agent, and other device-specific properties.

### Color Scheme

Emulate dark or light mode:

```bash
npx playwright codegen --color-scheme=dark playwright.dev
```

### Geolocation, Timezone, and Language

Record tests with specific location and locale settings:

```bash
npx playwright codegen --timezone="Europe/Rome" --geolocation="41.890221,12.492348" --lang="it-IT" bing.com/maps
```

**Usage workflow:**
1. Accept cookies
2. Click the "locate me" button to see geolocation in action

## Authentication State Preservation

### Saving Storage State

Record authentication separately and reuse it later:

```bash
npx playwright codegen github.com/microsoft/playwright --save-storage=auth.json
```

This saves:
- Cookies
- localStorage data
- IndexedDB data

**Security Note:** The `auth.json` file contains sensitive information. Add it to `.gitignore` or delete it after generating tests. Only use it locally.

### Loading Storage State

Continue generating tests from an authenticated state:

```bash
npx playwright codegen --load-storage=auth.json github.com/microsoft/playwright
```

This restores all cookies, localStorage, and IndexedDB data, bringing most web apps to an authenticated state without needing to login again.

### User Data Directory

Use a fixed browser profile with existing authentication:

```bash
npx playwright codegen --user-data-dir=/path/to/your/browser/data/ github.com/microsoft/playwright
```

**Important Warning:** As of Chrome 136, the default user data directory cannot be accessed via automated tooling like Playwright. You must create a separate user data directory for testing.

## Advanced Usage - Programmatic Codegen

For non-standard setups (e.g., using `browserContext.route()`), you can call `page.pause()` to open codegen controls programmatically:

```javascript
const { chromium } = require('@playwright/test');

(async () => {
  // Must run headed
  const browser = await chromium.launch({ headless: false });
  
  // Setup context with custom configuration
  const context = await browser.newContext({ /* pass any options */ });
  await context.route('**/*', route => route.continue());
  
  // Pause the page and start recording manually
  const page = await context.newPage();
  await page.pause();
})();
```

## VS Code Integration

The VS Code extension allows generating tests directly from the editor. The extension is available on the VS Code Marketplace.

## Key Benefits

1. **Quick Start** - Rapidly create initial test structure
2. **Best Practices** - Learn Playwright's recommended locator strategies
3. **Resilient Locators** - Automatically generates robust, maintainable locators
4. **Emulation Support** - Test across devices, viewports, and locales
5. **Authentication Handling** - Separate auth recording from test recording
6. **Real-time Code Generation** - See code as you interact with the page

## Best Practices Identified

1. Use codegen to learn proper locator patterns
2. Record authentication once, reuse across tests
3. Keep auth.json files secure and local only
4. Use device emulation to test responsive behavior
5. Fine-tune generated locators for better maintainability
6. Use viewport-specific recording for consistent test conditions
7. Create separate user data directories for testing (Chrome 136+)

## Related Topics to Explore

- Locator strategies and best practices
- Authentication patterns in tests
- Browser contexts and storage state
- Device emulation options
- VS Code extension features
