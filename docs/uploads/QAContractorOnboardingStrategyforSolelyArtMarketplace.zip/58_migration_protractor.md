# Playwright Documentation Research - Migrating from Protractor

**Page:** Migrating from Protractor  
**URL:** https://playwright.dev/docs/protractor  
**Research Date:** December 14, 2025

## Migration Principles

### Key Differences

**1. No need for "webdriver-manager" / Selenium**
- Playwright eliminates the need for Selenium WebDriver and webdriver-manager
- Playwright uses its own browser automation protocol
- Simpler setup and maintenance

**2. Protractor's ElementFinder ⇄ Playwright Test Locator**
- Element finding strategy has changed
- Playwright uses modern locator API
- More powerful and flexible element selection

**3. Protractor's `waitForAngular` ⇄ Playwright Test auto-waiting**
- Playwright has built-in auto-waiting
- No need for explicit Angular synchronization in most cases
- Smarter waiting mechanisms

**4. Don't forget to await in Playwright Test**
- Most Playwright operations are asynchronous
- Must use `await` keyword
- Test functions must be marked as `async`

## Cheat Sheet

### Element Locators

| Protractor | Playwright Test |
|------------|-----------------|
| `element(by.buttonText('...'))` | `page.locator('button, input[type="button"], input[type="submit"] >> text="..."')` |
| `element(by.css('...'))` | `page.locator('...')` |
| `element(by.cssContainingText('..1..', '..2..'))` | `page.locator('..1.. >> text=..2..')` |
| `element(by.id('...'))` | `page.locator('#...')` |
| `element(by.model('...'))` | `page.locator('[ng-model="..."]')` |
| `element(by.repeater('...'))` | `page.locator('[ng-repeat="..."]')` |
| `element(by.xpath('...'))` | `page.locator('xpath=...')` |
| `element.all` | `page.locator` |

### Browser Actions

| Protractor | Playwright Test |
|------------|-----------------|
| `browser.get(url)` | `await page.goto(url)` |
| `browser.getCurrentUrl()` | `page.url()` |

## Migration Example

### Original Protractor Test

```javascript
describe('angularjs homepage todo list', function() {
  it('should add a todo', function() {
    browser.get('https://angularjs.org');

    element(by.model('todoList.todoText')).sendKeys('first test');
    element(by.css('[value="add"]')).click();

    const todoList = element.all(by.repeater('todo in todoList.todos'));
    expect(todoList.count()).toEqual(3);
    expect(todoList.get(2).getText()).toEqual('first test');

    // You wrote your first test, cross it off the list
    todoList.get(2).element(by.css('input')).click();
    const completedAmount = element.all(by.css('.done-true'));
    expect(completedAmount.count()).toEqual(2);
  });
});
```

### Migrated Playwright Test

```javascript
const { test, expect } = require('@playwright/test'); // 1

test.describe('angularjs homepage todo list', () => {
  test('should add a todo', async ({ page }) => { // 2, 3
    await page.goto('https://angularjs.org'); // 4

    await page.locator('[ng-model="todoList.todoText"]').fill('first test');
    await page.locator('[value="add"]').click();

    const todoList = page.locator('[ng-repeat="todo in todoList.todos"]'); // 5
    await expect(todoList).toHaveCount(3);
    await expect(todoList.nth(2)).toHaveText('first test', {
      useInnerText: true,
    });

    // You wrote your first test, cross it off the list
    await todoList.nth(2).getByRole('textbox').click();
    const completedAmount = page.locator('.done-true');
    await expect(completedAmount).toHaveCount(2);
  });
});
```

### Migration Highlights

**1. Explicit imports**
- Each Playwright Test file has explicit import of the `test` and `expect` functions
- `const { test, expect } = require('@playwright/test');`

**2. Async test function**
- Test function is marked with `async`
- Enables use of `await` keyword

**3. Page fixture**
- Playwright Test is given a `page` as one of its parameters
- This is one of the many useful fixtures in Playwright Test
- Automatic setup and teardown

**4. Await prefix**
- Almost all Playwright calls are prefixed with `await`
- Ensures operations complete before proceeding

**5. Synchronous locator creation**
- Locator creation with `page.locator()` is one of the few methods that is sync
- Actual element interaction requires `await`

## Polyfilling waitForAngular

### When It's Needed

**Playwright Test has built-in auto-waiting** that makes Protractor's `waitForAngular` unneeded in general case.

However, it might come handy in some edge cases for Angular applications.

### Implementation Option 1: Using Protractor Scripts

**Prerequisites:**
- Make sure you have protractor installed in your package.json

**Polyfill function:**

```javascript
async function waitForAngular(page) {
  const clientSideScripts = require('protractor/built/clientsidescripts.js');

  async function executeScriptAsync(page, script, ...scriptArgs) {
    await page.evaluate(`
      new Promise((resolve, reject) => {
        const callback = (errMessage) => {
          if (errMessage)
            reject(new Error(errMessage));
          else
            resolve();
        };
        (function() {${script}}).apply(null, [...${JSON.stringify(scriptArgs)}, callback]);
      })
    `);
  }

  await executeScriptAsync(page, clientSideScripts.waitForAngular, '');
}
```

### Implementation Option 2: Simpler Approach (Angular 2+)

**If you don't want to keep a version of Protractor around**, you can use this simpler approach (only works for Angular 2+):

```javascript
async function waitForAngular(page) {
  await page.evaluate(async () => {
    // @ts-expect-error
    if (window.getAllAngularTestabilities) {
      // @ts-expect-error
      await Promise.all(window.getAllAngularTestabilities().map(whenStable));
      // @ts-expect-error
      async function whenStable(testability) {
        return new Promise(res => testability.whenStable(res));
      }
    }
  });
}
```

### Polyfill Usage

```javascript
const page = await context.newPage();
await page.goto('https://example.org');
await waitForAngular(page);
```

## Playwright Test Super Powers

### Core Benefits

Once you're on Playwright Test, you get a lot!

**1. Full zero-configuration TypeScript support**
- No additional setup required
- Type safety out of the box

**2. Cross-browser testing**
- Run tests across **all web engines** (Chrome, Firefox, Safari)
- On **any popular operating system** (Windows, macOS, Ubuntu)

**3. Advanced features**
- Full support for multiple origins
- (i)frames support
- Tabs and contexts
- Run tests in parallel across multiple browsers

**4. Built-in test artifact collection**
- Screenshots
- Videos
- Traces
- Test reports

### Bundled Tools

You also get all these ✨ awesome tools ✨ that come bundled with Playwright Test:

**1. Playwright Inspector**
- Interactive debugging
- Step-through test execution
- Element picker

**2. Playwright Test Code generation**
- Record user interactions
- Generate test code automatically
- Speed up test authoring

**3. Playwright Tracing**
- Post-mortem debugging
- Time-travel debugging
- Complete execution timeline
- Network activity
- Console logs
- Screenshots at every step

## Further Reading

### Recommended Topics

Learn more about Playwright Test runner:

- **Getting Started** - Installation and setup
- **Fixtures** - Test isolation and setup
- **Locators** - Element selection strategies
- **Assertions** - Web-first assertions
- **Auto-waiting** - Built-in smart waiting

## Summary

### Key Migration Steps

**1. Update Dependencies**
- Remove Protractor and Selenium dependencies
- Install Playwright Test
- Update package.json

**2. Convert Test Structure**
- Import `test` and `expect` from `@playwright/test`
- Mark test functions as `async`
- Use `page` fixture parameter

**3. Update Element Selectors**
- Convert `element(by.*)` to `page.locator()`
- Update Angular-specific selectors (`ng-model`, `ng-repeat`)
- Use modern locator strategies where possible

**4. Add Await Keywords**
- Prefix all async operations with `await`
- Ensure proper async/await flow

**5. Update Assertions**
- Convert Protractor expectations to Playwright assertions
- Use `toHaveCount()`, `toHaveText()`, etc.
- Leverage web-first assertions

**6. Remove waitForAngular**
- Rely on Playwright's auto-waiting in most cases
- Implement polyfill only if needed for edge cases

**7. Leverage New Features**
- Use Playwright Inspector for debugging
- Enable tracing for complex scenarios
- Implement parallel test execution
- Add screenshot/video capture

### Benefits of Migration

**1. Simpler Setup**
- No Selenium or WebDriver manager
- Direct browser control
- Faster installation

**2. Better Performance**
- Faster test execution
- Parallel testing out of the box
- Efficient browser management

**3. Modern Features**
- Auto-waiting
- Web-first assertions
- Better debugging tools
- Comprehensive tracing

**4. Cross-browser Support**
- Chromium, Firefox, WebKit
- Consistent API across browsers
- Mobile emulation

**5. Better Developer Experience**
- TypeScript support
- Code generation
- Interactive debugging
- Rich documentation

### Common Pitfalls

**1. Forgetting await**
- Most common migration issue
- Leads to timing problems
- Use linter to catch missing await

**2. Incorrect selector conversion**
- Angular-specific selectors need special handling
- Test selectors thoroughly after migration

**3. Over-reliance on waitForAngular**
- Usually not needed with Playwright's auto-waiting
- Only use in specific edge cases

**4. Not leveraging new features**
- Take advantage of Playwright's modern capabilities
- Don't just replicate Protractor patterns

### Migration Checklist

- [ ] Install Playwright Test dependencies
- [ ] Remove Protractor and Selenium dependencies
- [ ] Convert test file structure (imports, async/await)
- [ ] Update element locators
- [ ] Convert assertions
- [ ] Add await keywords
- [ ] Test waitForAngular polyfill if needed
- [ ] Enable parallel execution
- [ ] Configure reporters
- [ ] Set up CI/CD integration
- [ ] Enable tracing for debugging
- [ ] Update documentation
- [ ] Train team on new patterns

### Related Topics

- Writing tests
- Locators
- Assertions
- Auto-waiting
- Fixtures
- Configuration
- CI/CD integration
- Debugging
- Trace viewer
