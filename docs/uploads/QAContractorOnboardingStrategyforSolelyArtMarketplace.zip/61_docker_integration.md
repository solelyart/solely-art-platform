# Playwright Documentation Research - Docker Integration

**Page:** Docker
**URL:** https://playwright.dev/docs/docker
**Research Date:** December 14, 2025

## Overview

This guide describes how to run Playwright scripts in a Docker environment. Playwright provides official Docker images that include the necessary browsers and system dependencies.

### Key Features

- **Official Docker Image:** `mcr.microsoft.com/playwright`
- **Includes:** Playwright browsers and browser system dependencies
- **Excludes:** Playwright package/dependency (should be installed separately)
- **Based on:** Ubuntu

### Important Note

This Docker image is intended to be used for **testing and development purposes only**. It is not recommended to use this Docker image to visit untrusted websites.

## Usage

### Pulling the Image

```bash
docker pull mcr.microsoft.com/playwright:v1.57.0-noble
```

### Running the Image

By default, the Docker image will use the `root` user to run the browsers. This will disable the Chromium sandbox which is not available with root. If you run trusted code (e.g. End-to-end tests) and want to avoid the hassle of managing a separate user, then the root user may be fine.

```bash
docker run -it --rm --ipc=host mcr.microsoft.com/playwright:v1.57.0-noble /bin/bash
```

For web scraping or crawling, we recommend creating a separate user inside the Docker container and using the seccomp profile.

```bash
docker run -it --rm --ipc=host --user pwuser --security-opt seccomp=seccomp_profile.json mcr.microsoft.com/playwright:v1.57.0-noble /bin/bash
```

### seccomp Profile

`seccomp_profile.json` is needed to run Chromium with the sandbox. This is a default Docker seccomp profile with extra user namespace cloning permissions:

```json
{
  "comment": "Allow create user namespaces",
  "names": [
    "clone",
    "setns",
    "unshare"
  ],
  "action": "SCMP_ACT_ALLOW",
  "args": [],
  "includes": {},
  "excludes": {}
}
```

### Recommended Docker Configuration

1.  **`--init`:** Recommended to avoid special treatment for processes with PID=1 (prevents zombie processes).
2.  **`--ipc=host`:** Recommended when using Chromium to prevent it from running out of memory and crashing.
3.  **`--cap-add=SYS_ADMIN`:** Try this if you see weird errors when launching Chromium locally.

## Remote Connection

You can run Playwright Server in Docker while keeping your tests running on the host system or another machine.

### Starting the Playwright Server

```bash
docker run -p 3000:3000 --rm --init -it --workdir /home/pwuser --user pwuser mcr.microsoft.com/playwright:v1.57.0-noble /bin/sh -c "npx -y playwright@1.57.0 run-server --port 3000 --host 0.0.0.0"
```

### Connecting to the Server

**1. Using environment variable with `@playwright/test`:**

```bash
PW_TEST_CONNECT_WS_ENDPOINT=ws://127.0.0.1:3000/ npx playwright test
```

**2. Using the `browserType.connect()` API:**

```javascript
const browser = await playwright["chromium"].connect("ws://127.0.0.1:3000/");
```

### Accessing Local Servers

To access local servers from within the Docker container, use `--add-host`:

```bash
docker run --add-host=hostmachine:host-gateway -p 3000:3000 --rm --init -it --workdir /home/pwuser --user pwuser mcr.microsoft.com/playwright:v1.57.0-noble /bin/sh -c "npx -y playwright@1.57.0 run-server --port 3000 --host 0.0.0.0"
```

This makes `hostmachine` point to the host's localhost. Your tests should use `hostmachine` instead of `localhost` when accessing local servers.

### Important Note

When running tests remotely, ensure the Playwright version in your tests matches the version running in the Docker container.

## Image Tags

We currently publish images with the following tags:

-   `:v1.57.0`: Playwright v1.57.0 release docker image based on Ubuntu 24.04 LTS (Noble Numbat).
-   `:v1.57.0-noble`: Playwright v1.57.0 release docker image based on Ubuntu 24.04 LTS (Noble Numbat).
-   `:v1.57.0-jammy`: Playwright v1.57.0 release docker image based on Ubuntu 22.04 LTS (Jammy Jellyfish).

It is recommended to always pin your Docker image to a specific version if possible.

## Base Images

We currently publish images based on the following Ubuntu versions:

-   **Ubuntu 24.04 LTS** (Noble Numbat), image tags include `noble`
-   **Ubuntu 22.04 LTS** (Jammy Jellyfish), image tags include `jammy`

Browser builds for Firefox and WebKit are built for the `glibc` library. Alpine Linux and other distributions that are based on the `musl` standard library are not supported.

## Build your own image

To run Playwright inside Docker, you need to have Node.js, Playwright browsers, and browser system dependencies installed. See the following Dockerfile:

```dockerfile
FROM node:20-bookworm
RUN npx -y playwright@1.57.0 install --with-deps
```

## Summary

### Key Takeaways

- **Use official Docker images:** `mcr.microsoft.com/playwright`
- **Pin image versions:** Avoid breaking changes.
- **Use `--ipc=host`:** Prevents Chromium crashes.
- **Use `--init`:** Prevents zombie processes.
- **Use a separate user for untrusted sites:** Enhances security.
- **Match Playwright versions:** Ensure consistency between client and server.
- **Use `hostmachine` for local servers:** Access host from container.

### Related Topics

- Continuous Integration
- Playwright Server
- Browser System Dependencies
- Browser System Dependencies
