# Playwright Documentation Research - Trace Viewer

**Page:** Trace Viewer
**URL:** https://playwright.dev/docs/trace-viewer
**Research Date:** December 14, 2025

## Overview

Playwright provides a Trace Viewer to inspect test execution traces.

### Key Features

- **Time-travel debugging:** Step through test execution.
- **Inspect network requests:** View request and response details.
- **View console logs:** See console messages from the browser.

## Usage

```bash
npx playwright show-trace trace.zip
```

## Summary

### Key Takeaways

- **`npx playwright show-trace`:** To open the Trace Viewer.
- **Inspect and debug:** To understand test failures.

### Related Topics

- Tracing
- Debugging
