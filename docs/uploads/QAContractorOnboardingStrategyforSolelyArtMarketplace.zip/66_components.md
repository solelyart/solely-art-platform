# Playwright Documentation Research - Components (experimental)

**Page:** Components (experimental)
**URL:** https://playwright.dev/docs/test-components
**Research Date:** December 14, 2025

## Overview

Playwright provides experimental support for component testing. This allows you to test individual UI components in isolation.

### Key Features

- **Test components in isolation:** Without the need for a full application.
- **Supports React, Vue, and Svelte:** With dedicated packages for each framework.
- **Uses the same Playwright API:** For consistency with end-to-end tests.

## Usage

### Mounting a Component

```javascript
import { test, expect } from "@playwright/experimental-ct-react";
import Button from "./Button";

test("should work", async ({ mount }) => {
  const component = await mount(<Button>Click me</Button>);
  await expect(component).toContainText("Click me");
});
```

## Summary

### Key Takeaways

- **Experimental feature:** Use with caution.
- **`@playwright/experimental-ct-*` packages:** For React, Vue, and Svelte.
- **`mount` fixture:** To mount components in tests.

### Related Topics

- Fixtures
- Locators
- Assertions
