# Playwright Documentation Research - Dialogs

**Page:** Dialogs  
**URL:** https://playwright.dev/docs/dialogs  
**Research Date:** December 14, 2025

## Introduction

### Supported Dialog Types

**Playwright can interact with web page dialogs:**
- `alert` - Simple alert messages
- `confirm` - Confirmation dialogs with OK/Cancel
- `prompt` - Input dialogs requesting user text
- `beforeunload` - Confirmation when leaving page

**Print dialogs:** See separate Print section.

## alert(), confirm(), prompt() Dialogs

### Default Behavior

**Auto-dismissal:** By default, dialogs are auto-dismissed by Playwright, so you don't have to handle them.

### Manual Handling

**Register handler:** Can register dialog handler before action that triggers dialog.

**Two options:**
1. `dialog.accept()` - Accept/OK the dialog
2. `dialog.dismiss()` - Dismiss/Cancel the dialog

**Example:**
```typescript
page.on('dialog', dialog => dialog.accept());
await page.getByRole('button').click();
```

### Important Note: Must Handle Dialog

**Critical requirement:** `page.on('dialog')` listener **must handle** the dialog.

**Why:** Dialogs in Web are modals and block further page execution until handled.

**Consequence:** Otherwise action will stall (be it `locator.click()` or something else).

### Wrong Pattern (Will Hang)

**❌ WRONG - This will never resolve:**
```typescript
page.on('dialog', dialog => console.log(dialog.message()));
await page.getByRole('button').click(); // Will hang here
```

**Problem:** Dialog is logged but not handled (not accepted or dismissed).

### Auto-Dismissal

**No listener:** If there is no listener for `page.on('dialog')`, all dialogs are automatically dismissed.

## beforeunload Dialog

### Context

**When triggered:** When `page.close()` is invoked with truthy `runBeforeUnload` value.

**Behavior:** Page runs its unload handlers.

**Special case:** This is the only case when `page.close()` does not wait for page to actually close, because page might stay open at end of operation.

### Handling beforeunload

**Pattern:**
```typescript
page.on('dialog', async dialog => {
  assert(dialog.type() === 'beforeunload');
  await dialog.dismiss();
});
await page.close({ runBeforeUnload: true });
```

## Print Dialogs

### Asserting Print Dialog

**Purpose:** Assert that print dialog via `window.print` was triggered.

**Pattern:**
```typescript
await page.goto('<url>');

await page.evaluate('(() => {
  window.waitForPrintDialog = new Promise(f => window.print = f);
})()');

await page.getByText('Print it!').click();

await page.waitForFunction('window.waitForPrintDialog');
```

**Important:** Evaluate script before clicking button / after page is loaded.

## Best Practices

### 1. Always Handle Dialogs

**✅ Good:**
```typescript
page.on('dialog', dialog => dialog.accept());
await page.getByRole('button').click();
```

**❌ Bad:**
```typescript
page.on('dialog', dialog => console.log(dialog.message()));
await page.getByRole('button').click(); // Will hang!
```

### 2. Use Auto-Dismissal When Possible

**Pattern:** If you don't need to interact with dialogs, let Playwright auto-dismiss them.

```typescript
// No dialog handler needed - auto-dismissed
await page.getByRole('button').click();
```

### 3. Validate Dialog Message

**Pattern:**
```typescript
page.on('dialog', async dialog => {
  expect(dialog.message()).toBe('Are you sure you want to delete?');
  await dialog.accept();
});
await page.getByRole('button', { name: 'Delete' }).click();
```

### 4. Handle Different Dialog Types

**Pattern:**
```typescript
page.on('dialog', async dialog => {
  switch (dialog.type()) {
    case 'alert':
      await dialog.accept();
      break;
    case 'confirm':
      await dialog.accept(); // or dismiss()
      break;
    case 'prompt':
      await dialog.accept('User input text');
      break;
    case 'beforeunload':
      await dialog.dismiss();
      break;
  }
});
```

### 5. Test Both Accept and Dismiss Paths

**Pattern:**
```typescript
test('confirm dialog - accept', async ({ page }) => {
  page.on('dialog', dialog => dialog.accept());
  await page.getByRole('button', { name: 'Delete' }).click();
  await expect(page.getByText('Deleted')).toBeVisible();
});

test('confirm dialog - dismiss', async ({ page }) => {
  page.on('dialog', dialog => dialog.dismiss());
  await page.getByRole('button', { name: 'Delete' }).click();
  await expect(page.getByText('Deleted')).not.toBeVisible();
});
```

## Common Use Cases

### Use Case 1: Accept Alert Dialog

```typescript
test('accept alert', async ({ page }) => {
  page.on('dialog', dialog => dialog.accept());
  
  await page.goto('/');
  await page.getByRole('button', { name: 'Show Alert' }).click();
  
  // Alert is automatically accepted
  await expect(page.getByText('Alert shown')).toBeVisible();
});
```

### Use Case 2: Validate and Accept Confirm Dialog

```typescript
test('validate confirm dialog', async ({ page }) => {
  page.on('dialog', async dialog => {
    expect(dialog.type()).toBe('confirm');
    expect(dialog.message()).toBe('Delete this item?');
    await dialog.accept();
  });
  
  await page.goto('/items');
  await page.getByRole('button', { name: 'Delete' }).click();
  
  await expect(page.getByText('Item deleted')).toBeVisible();
});
```

### Use Case 3: Provide Input to Prompt Dialog

```typescript
test('prompt dialog with input', async ({ page }) => {
  page.on('dialog', async dialog => {
    expect(dialog.type()).toBe('prompt');
    expect(dialog.message()).toBe('Enter your name:');
    await dialog.accept('John Doe');
  });
  
  await page.goto('/');
  await page.getByRole('button', { name: 'Enter Name' }).click();
  
  await expect(page.getByText('Hello, John Doe')).toBeVisible();
});
```

### Use Case 4: Handle beforeunload Dialog

```typescript
test('handle beforeunload', async ({ page }) => {
  page.on('dialog', async dialog => {
    expect(dialog.type()).toBe('beforeunload');
    await dialog.dismiss();
  });
  
  await page.goto('/form');
  await page.getByLabel('Name').fill('Test');
  
  await page.close({ runBeforeUnload: true });
});
```

### Use Case 5: Test Print Dialog

```typescript
test('print dialog triggered', async ({ page }) => {
  await page.goto('/document');
  
  await page.evaluate('(() => {
    window.waitForPrintDialog = new Promise(f => window.print = f);
  })()');
  
  await page.getByRole('button', { name: 'Print' }).click();
  
  await page.waitForFunction('window.waitForPrintDialog');
  // Print dialog was triggered
});
```

## Use Cases for Solely Art Platform

### Example 1: Booking Cancellation Confirmation

```typescript
test('cancel booking with confirmation', async ({ page }) => {
  await page.goto('/bookings/123');
  
  // Handle confirmation dialog
  page.on('dialog', async dialog => {
    expect(dialog.type()).toBe('confirm');
    expect(dialog.message()).toContain('cancel this booking');
    await dialog.accept();
  });
  
  await page.getByRole('button', { name: 'Cancel Booking' }).click();
  
  await expect(page.getByText('Booking cancelled')).toBeVisible();
});
```

### Example 2: Delete Artist Profile Warning

```typescript
test('delete artist profile', async ({ page }) => {
  await page.goto('/artist/profile/edit');
  
  page.on('dialog', async dialog => {
    expect(dialog.message()).toBe('Are you sure you want to delete your profile? This action cannot be undone.');
    await dialog.accept();
  });
  
  await page.getByRole('button', { name: 'Delete Profile' }).click();
  
  await expect(page).toHaveURL('/');
  await expect(page.getByText('Profile deleted')).toBeVisible();
});
```

### Example 3: Unsaved Changes Warning

```typescript
test('unsaved changes warning', async ({ page }) => {
  await page.goto('/artist/profile/edit');
  
  // Make changes
  await page.getByLabel('Bio').fill('Updated bio');
  
  // Try to navigate away
  page.on('dialog', async dialog => {
    expect(dialog.type()).toBe('beforeunload');
    await dialog.dismiss(); // Stay on page
  });
  
  await page.getByRole('link', { name: 'Home' }).click();
  
  // Should still be on edit page
  await expect(page).toHaveURL('/artist/profile/edit');
});
```

### Example 4: Message Deletion Confirmation

```typescript
test('delete message confirmation', async ({ page }) => {
  await page.goto('/messages');
  
  page.on('dialog', async dialog => {
    expect(dialog.message()).toBe('Delete this message?');
    await dialog.accept();
  });
  
  await page.locator('.message').first().hover();
  await page.getByRole('button', { name: 'Delete' }).click();
  
  await expect(page.getByText('Message deleted')).toBeVisible();
});
```

### Example 5: Payment Confirmation Alert

```typescript
test('payment success alert', async ({ page }) => {
  await page.goto('/checkout');
  
  let alertMessage = '';
  page.on('dialog', async dialog => {
    alertMessage = dialog.message();
    await dialog.accept();
  });
  
  // Complete payment
  await page.getByRole('button', { name: 'Pay Now' }).click();
  
  // Wait for alert
  await page.waitForEvent('dialog');
  
  expect(alertMessage).toContain('Payment successful');
});
```

### Example 6: Test Both Accept and Dismiss Paths

```typescript
test('booking cancellation - accept', async ({ page }) => {
  await page.goto('/bookings/123');
  
  page.on('dialog', dialog => dialog.accept());
  await page.getByRole('button', { name: 'Cancel Booking' }).click();
  
  await expect(page.getByText('Booking cancelled')).toBeVisible();
});

test('booking cancellation - dismiss', async ({ page }) => {
  await page.goto('/bookings/123');
  
  page.on('dialog', dialog => dialog.dismiss());
  await page.getByRole('button', { name: 'Cancel Booking' }).click();
  
  // Booking should still exist
  await expect(page.getByText('Booking cancelled')).not.toBeVisible();
  await expect(page.getByText('Booking Details')).toBeVisible();
});
```

## Advanced Patterns

### Pattern 1: Dialog Handler with Assertions

```typescript
test('dialog with assertions', async ({ page }) => {
  let dialogHandled = false;
  
  page.on('dialog', async dialog => {
    expect(dialog.type()).toBe('confirm');
    expect(dialog.message()).toBe('Expected message');
    expect(dialog.defaultValue()).toBe(''); // For prompt dialogs
    
    await dialog.accept();
    dialogHandled = true;
  });
  
  await page.getByRole('button').click();
  
  expect(dialogHandled).toBe(true);
});
```

### Pattern 2: Conditional Dialog Handling

```typescript
test('conditional dialog handling', async ({ page }) => {
  page.on('dialog', async dialog => {
    if (dialog.message().includes('delete')) {
      await dialog.accept();
    } else {
      await dialog.dismiss();
    }
  });
  
  await page.goto('/');
  // Dialogs handled based on message content
});
```

### Pattern 3: Multiple Dialog Handlers

```typescript
test('multiple dialogs', async ({ page }) => {
  const dialogMessages: string[] = [];
  
  page.on('dialog', async dialog => {
    dialogMessages.push(dialog.message());
    await dialog.accept();
  });
  
  await page.getByRole('button', { name: 'Step 1' }).click();
  await page.getByRole('button', { name: 'Step 2' }).click();
  await page.getByRole('button', { name: 'Step 3' }).click();
  
  expect(dialogMessages).toHaveLength(3);
  expect(dialogMessages[0]).toBe('Step 1 complete');
  expect(dialogMessages[1]).toBe('Step 2 complete');
  expect(dialogMessages[2]).toBe('Step 3 complete');
});
```

### Pattern 4: Dialog with Timeout

```typescript
test('dialog with timeout', async ({ page }) => {
  const dialogPromise = page.waitForEvent('dialog', { timeout: 5000 });
  
  await page.getByRole('button').click();
  
  const dialog = await dialogPromise;
  expect(dialog.message()).toBe('Expected message');
  await dialog.accept();
});
```

### Pattern 5: Remove Dialog Handler

```typescript
test('remove dialog handler', async ({ page }) => {
  const handler = (dialog: Dialog) => dialog.accept();
  
  page.on('dialog', handler);
  await page.getByRole('button', { name: 'First' }).click();
  
  // Remove handler
  page.off('dialog', handler);
  
  // Now dialogs will be auto-dismissed
  await page.getByRole('button', { name: 'Second' }).click();
});
```

## Dialog Methods

### dialog.accept()

**Purpose:** Accept dialog (click OK).

**For prompt:** Can provide input text.

```typescript
await dialog.accept(); // For alert, confirm
await dialog.accept('input text'); // For prompt
```

### dialog.dismiss()

**Purpose:** Dismiss dialog (click Cancel).

```typescript
await dialog.dismiss();
```

### dialog.message()

**Purpose:** Get dialog message text.

```typescript
const message = dialog.message();
```

### dialog.type()

**Purpose:** Get dialog type.

**Types:** 'alert', 'confirm', 'prompt', 'beforeunload'

```typescript
const type = dialog.type();
```

### dialog.defaultValue()

**Purpose:** Get default value (for prompt dialogs).

```typescript
const defaultValue = dialog.defaultValue();
```

## Troubleshooting

### Issue: Test Hangs

**Cause:** Dialog handler registered but doesn't accept or dismiss dialog.

**Solution:** Always call `dialog.accept()` or `dialog.dismiss()`.

```typescript
// ❌ Wrong - will hang
page.on('dialog', dialog => console.log(dialog.message()));

// ✅ Correct
page.on('dialog', async dialog => {
  console.log(dialog.message());
  await dialog.accept();
});
```

### Issue: Dialog Not Detected

**Cause:** Dialog handler registered after dialog triggered.

**Solution:** Register handler before action that triggers dialog.

```typescript
// ✅ Correct order
page.on('dialog', dialog => dialog.accept());
await page.getByRole('button').click();
```

### Issue: Want to Test Dialog Not Shown

**Pattern:**
```typescript
test('no dialog shown', async ({ page }) => {
  let dialogShown = false;
  page.on('dialog', () => { dialogShown = true; });
  
  await page.getByRole('button').click();
  await page.waitForTimeout(1000);
  
  expect(dialogShown).toBe(false);
});
```

### Issue: beforeunload Not Working

**Cause:** Need to pass `runBeforeUnload: true` to `page.close()`.

**Solution:**
```typescript
await page.close({ runBeforeUnload: true });
```

## Summary

### Key Concepts

**1. Dialog types:** alert, confirm, prompt, beforeunload

**2. Default behavior:** Auto-dismissed by Playwright

**3. Manual handling:** Register handler with `page.on('dialog')`

**4. Must handle:** Dialog handler must accept or dismiss, otherwise test hangs

**5. No listener:** If no listener registered, dialogs auto-dismissed

### Dialog Methods

- `dialog.accept()` - Accept/OK dialog
- `dialog.accept('text')` - Accept prompt with input
- `dialog.dismiss()` - Dismiss/Cancel dialog
- `dialog.message()` - Get dialog message
- `dialog.type()` - Get dialog type
- `dialog.defaultValue()` - Get default value (prompt)

### Best Practices

1. Always handle dialogs (accept or dismiss)
2. Use auto-dismissal when possible
3. Validate dialog message
4. Handle different dialog types appropriately
5. Test both accept and dismiss paths
6. Register handler before triggering action

### Common Patterns

- Accept confirmation dialogs
- Validate dialog messages
- Provide input to prompts
- Handle beforeunload warnings
- Test print dialog triggers

## Related Topics

- Page events
- User interactions
- Test assertions
- Browser contexts
- Navigation
- Page lifecycle
