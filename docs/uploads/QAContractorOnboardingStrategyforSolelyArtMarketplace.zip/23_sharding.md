# Playwright Documentation Research - Sharding

**Page:** Sharding  
**URL:** https://playwright.dev/docs/test-sharding  
**Research Date:** December 13, 2025

## Overview

**Sharding** is splitting tests into smaller parts called "shards" that run independently on multiple machines simultaneously. This achieves greater parallelization beyond single-machine CPU core utilization.

**Purpose:** Divide tests to speed up test runtime by distributing work across multiple machines.

**Key concept:** By default, Playwright runs test files in parallel on a single machine. Sharding extends this to multiple machines.

## How Sharding Works

**On each shard:**
- Runs independently
- Utilizes available CPU cores
- Executes subset of tests

**In CI pipeline:**
- Each shard runs as separate job
- Makes use of CI hardware resources
- Tests complete faster through parallel execution

## Sharding Tests Between Multiple Machines

### Command Line Syntax

```bash
npx playwright test --shard=x/y
```

**Format:** `--shard=<current>/<total>`
- `x` = Current shard number (1-indexed)
- `y` = Total number of shards

### Example: Split into 4 Shards

```bash
npx playwright test --shard=1/4
npx playwright test --shard=2/4
npx playwright test --shard=3/4
npx playwright test --shard=4/4
```

**Result:** If run in parallel on different machines, test suite completes 4x faster.

### Important Note

Playwright can only shard tests that can run in parallel. By default, this means Playwright will shard test files.

## Balancing Shards

Sharding granularity depends on the `fullyParallel` option, which affects how tests are balanced across shards.

### Sharding with fullyParallel

**Configuration:**
```typescript
fullyParallel: true
```

**Behavior:**
- Tests split at **individual test level**
- Each shard receives even distribution of tests
- Test-level granularity
- Playwright optimizes based on total number of tests

**Advantages:**
- More balanced shard execution
- Preferred mode for even load distribution
- Better optimization in CI environments

### Sharding without fullyParallel

**Configuration:**
```typescript
// fullyParallel not set or false
```

**Behavior:**
- Tests split at **file level**
- Entire test files assigned to shards
- Same file may be assigned to different shards across projects
- File size greatly influences distribution

**Potential issues:**
- Unevenly sized test files cause imbalanced shards
- Some shards may run many tests, others few or none
- Requires manual file organization

### Key Takeaways

| Aspect | With fullyParallel | Without fullyParallel |
|--------|-------------------|----------------------|
| **Granularity** | Individual test level | File level |
| **Distribution** | Balanced automatically | Depends on file sizes |
| **Recommendation** | Preferred for CI | Requires even file sizes |
| **Optimization** | Playwright optimizes | Manual organization needed |

**Best practice:** Use `fullyParallel: true` for most effective sharding, especially in CI environments.

## Merging Reports from Multiple Shards

Each shard produces its own test report. Merge them for a combined report showing all results.

### Step 1: Configure Blob Reporter

```typescript
// playwright.config.ts
export default defineConfig({
  testDir: './tests',
  reporter: process.env.CI ? 'blob' : 'html',
});
```

**Blob report contains:**
- All test results
- Test attachments
- Traces
- Screenshot diffs

**Default location:** `blob-report` directory

**File naming:** Contains shard number, so files don't clash

### Step 2: Collect Blob Reports

Put all blob report files into a single directory (e.g., `all-blob-reports`).

### Step 3: Merge Reports

```bash
npx playwright merge-reports --reporter html ./all-blob-reports
```

**Output:** Standard HTML report in `playwright-report` directory

## GitHub Actions Example

GitHub Actions supports sharding using `jobs.<job_id>.strategy.matrix`.

### Complete Workflow

#### Part 1: Run Sharded Tests

```yaml
# .github/workflows/playwright.yml
name: Playwright Tests
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  playwright-tests:
    timeout-minutes: 60
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        shardIndex: [1, 2, 3, 4]
        shardTotal: [4]
    steps:
    - uses: actions/checkout@v5
    - uses: actions/setup-node@v5
      with:
        node-version: lts/*
    
    - name: Install dependencies
      run: npm ci
    
    - name: Install Playwright browsers
      run: npx playwright install --with-deps
    
    - name: Run Playwright tests
      run: npx playwright test --shard=${{ matrix.shardIndex }}/${{ matrix.shardTotal }}
    
    - name: Upload blob report to GitHub Actions Artifacts
      if: ${{ !cancelled() }}
      uses: actions/upload-artifact@v4
      with:
        name: blob-report-${{ matrix.shardIndex }}
        path: blob-report
        retention-days: 1
```

**Key elements:**
1. **Matrix strategy:** `shardIndex: [1, 2, 3, 4]` and `shardTotal: [4]`
2. **Shard execution:** `--shard=${{ matrix.shardIndex }}/${{ matrix.shardTotal }}`
3. **Upload artifacts:** Each shard uploads its blob report

#### Part 2: Merge Reports

```yaml
# .github/workflows/playwright.yml
jobs:
  # ... playwright-tests job above ...
  
  merge-reports:
    # Merge reports after playwright-tests, even if some shards have failed
    if: ${{ !cancelled() }}
    needs: [playwright-tests]
    
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v5
    - uses: actions/setup-node@v5
      with:
        node-version: lts/*
    
    - name: Install dependencies
      run: npm ci
    
    - name: Download blob reports from GitHub Actions Artifacts
      uses: actions/download-artifact@v5
      with:
        path: all-blob-reports
        pattern: blob-report-*
        merge-multiple: true
    
    - name: Merge into HTML Report
      run: npx playwright merge-reports --reporter html ./all-blob-reports
    
    - name: Upload HTML report
      uses: actions/upload-artifact@v4
      with:
        name: html-report--attempt-${{ github.run_attempt }}
        path: playwright-report
        retention-days: 14
```

**Key elements:**
1. **Dependency:** `needs: [playwright-tests]` ensures order
2. **Conditional execution:** `if: ${{ !cancelled() }}` runs even if shards fail
3. **Download artifacts:** Collects all blob reports
4. **Merge reports:** Creates combined HTML report
5. **Upload result:** Makes merged report available

**Result:** Combined HTML report available in GitHub Actions Artifacts tab.

## Merging Reports from Multiple Environments

For running same tests in multiple environments (not sharding), differentiate environments using tags.

### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: process.env.CI ? 'blob' : 'html',
  tag: process.env.CI_ENVIRONMENT_NAME,  // e.g., "@APIv2"
});
```

**Purpose:** Tag is automatically picked up by blob report and merge tool to differentiate environments.

## Merge-Reports CLI

### Basic Command

```bash
npx playwright merge-reports path/to/blob-reports-dir
```

Reads all blob reports from directory and merges into single report.

### Options

#### --reporter

Specify which report to produce. Can be multiple reporters separated by comma.

```bash
npx playwright merge-reports --reporter=html,github ./blob-reports
```

#### --config

Specify Playwright configuration file with output reporters. Use to pass additional configuration to output reporter.

```bash
npx playwright merge-reports --config=merge.config.ts ./blob-reports
```

**Example merge config:**

```typescript
// merge.config.ts
export default {
  testDir: 'e2e',
  reporter: [['html', { open: 'never' }]],
};
```

**Note:** This configuration can differ from the one used during blob report creation.

### Cross-OS Merging

When merging reports from different operating systems, provide explicit merge config to disambiguate which directory should be used as tests root.

## Best Practices

### 1. Use fullyParallel for Balanced Sharding

```typescript
export default defineConfig({
  fullyParallel: true,
});
```

### 2. Choose Appropriate Shard Count

```bash
# Too few: Not enough parallelization
npx playwright test --shard=1/2

# Good: Balance between overhead and speed
npx playwright test --shard=1/8

# Too many: Overhead outweighs benefits
npx playwright test --shard=1/100
```

**Rule of thumb:** Match number of available CI machines.

### 3. Use Blob Reporter on CI

```typescript
reporter: process.env.CI ? 'blob' : 'html'
```

### 4. Keep Test Files Small

Without `fullyParallel`, keep test files evenly sized for balanced distribution.

### 5. Set fail-fast: false

```yaml
strategy:
  fail-fast: false
```

Allows all shards to complete even if one fails.

### 6. Use Conditional Upload

```yaml
if: ${{ !cancelled() }}
```

Uploads artifacts even if tests fail.

### 7. Set Appropriate Retention

```yaml
retention-days: 1  # For blob reports (temporary)
retention-days: 14 # For HTML reports (longer term)
```

### 8. Merge Even on Failure

```yaml
if: ${{ !cancelled() }}
needs: [playwright-tests]
```

Ensures report merging happens even if some shards fail.

### 9. Tag Multi-Environment Runs

```typescript
tag: process.env.ENVIRONMENT
```

Differentiates between environments in merged reports.

### 10. Monitor Shard Balance

Check that shards have similar execution times. Adjust shard count or use `fullyParallel` if imbalanced.

## Common Patterns

### 4-Shard Configuration

```yaml
matrix:
  shardIndex: [1, 2, 3, 4]
  shardTotal: [4]
```

### 8-Shard Configuration

```yaml
matrix:
  shardIndex: [1, 2, 3, 4, 5, 6, 7, 8]
  shardTotal: [8]
```

### Dynamic Shard Count

```yaml
matrix:
  shardIndex: ${{ fromJSON(env.SHARD_INDICES) }}
  shardTotal: ${{ env.SHARD_TOTAL }}
```

### Multiple Reporters

```bash
npx playwright merge-reports --reporter=html,json,junit ./blob-reports
```

### Custom Merge Config

```typescript
// merge.config.ts
export default {
  reporter: [
    ['html', { open: 'never', outputFolder: 'merged-report' }],
    ['json', { outputFile: 'merged-results.json' }],
  ],
};
```

### Environment-Specific Sharding

```typescript
// playwright.config.ts
export default defineConfig({
  fullyParallel: true,
  reporter: process.env.CI ? 'blob' : 'html',
  tag: process.env.ENV_NAME,
});
```

## Related Topics to Explore

- Parallelism configuration
- Blob reporter options
- GitHub Actions matrix strategy
- CI/CD optimization
- Test distribution strategies
- Worker processes
- Test isolation
- Report merging
- Artifact management
- Cross-platform testing
