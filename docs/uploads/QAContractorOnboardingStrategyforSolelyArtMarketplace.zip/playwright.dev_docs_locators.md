
For example, consider the following DOM structure:

http://localhost:3000
John
Say hello
Mary
Say hello
John
Say goodbye
Mary
Say goodbye
<ul>
  <li>
    <div>John</div>
    <div><button>Say hello</button></div>
  </li>
  <li>
    <div>Mary</div>
    <div><button>Say hello</button></div>
  </li>
  <li>
    <div>John</div>
    <div><button>Say goodbye</button></div>
  </li>
  <li>
    <div>Mary</div>
    <div><button>Say goodbye</button></div>
  </li>
</ul>


To take a screenshot of the row with "Mary" and "Say goodbye":

const rowLocator = page.getByRole('listitem');

await rowLocator
    .filter({ hasText: 'Mary' })
    .filter({ has: page.getByRole('button', { name: 'Say goodbye' }) })
    .screenshot({ path: 'screenshot.png' });


You should now have a "screenshot.png" file in your project's root directory.

Rare use cases​
Do something with each element in the list​

Iterate elements:

for (const row of await page.getByRole('listitem').all())
  console.log(await row.textContent());


Iterate using regular for loop:

const rows = page.getByRole('listitem');
const count = await rows.count();
for (let i = 0; i < count; ++i)
  console.log(await rows.nth(i).textContent());

Evaluate in the page​

The code inside locator.evaluateAll() runs in the page, you can call any DOM apis there.

const rows = page.getByRole('listitem');
const texts = await rows.evaluateAll(
    list => list.map(element => element.textContent));

Strictness​

Locators are strict. This means that all operations on locators that imply some target DOM element will throw an exception if more than one element matches. For example, the following call throws if there are several buttons in the DOM:

Throws an error if more than one​
await page.getByRole('button').click();


On the other hand, Playwright understands when you perform a multiple-element operation, so the following call works perfectly fine when the locator resolves to multiple elements.

Works fine with multiple elements​
await page.getByRole('button').count();


You can explicitly opt-out from strictness check by telling Playwright which element to use when multiple elements match, through locator.first(), locator.last(), and locator.nth(). These methods are not recommended because when your page changes, Playwright may click on an element you did not intend. Instead, follow best practices above to create a locator that uniquely identifies the target element.

More Locators​

For less commonly used locators, look at the other locators guide.

Previous
Isolation
Next
Mock APIs
Introduction
Quick Guide
Locating elements
Locate by role
Locate by label
Locate by placeholder
Locate by text
Locate by alt text
Locate by title
Locate by test id
Locate by CSS or XPath
Locate in Shadow DOM
Filtering Locators
Filter by text
Filter by not having text
Filter by child/descendant
Filter by not having child/descendant
Locator operators
Matching inside a locator
Matching two locators simultaneously
Matching one of the two alternative locators
Matching only visible elements
Lists
Count items in a list
Assert all text in a list
Get a specific item
Chaining filters
Rare use cases
Strictness
More Locators
Learn
Getting started
Playwright Training
Learn Videos
Feature Videos
Community
Stack Overflow
Discord
Twitter
LinkedIn
More
GitHub
YouTube
Blog
Ambassadors
Copyright © 2025 Microsoft