# Playwright Documentation Research - Emulation

**Page:** Emulation  
**URL:** https://playwright.dev/docs/emulation  
**Research Date:** December 13, 2025

## Overview

Playwright enables comprehensive browser and device emulation, allowing you to test your app on any browser while simulating real devices such as mobile phones or tablets. You can emulate various device characteristics and user conditions including:

- Device parameters (userAgent, screenSize, viewport, hasTouch)
- Geolocation
- Locale and timezone
- Permissions (notifications, camera, microphone, etc.)
- Color scheme (light/dark mode)
- Network conditions (offline)
- JavaScript enabled/disabled

## Devices

Playwright includes a registry of device parameters using `playwright.devices` for selected desktop, tablet, and mobile devices. This registry simulates browser behavior for specific devices including user agent, screen size, viewport, and touch capabilities.

### Basic Device Emulation

**Config file:**
```typescript
import { defineConfig, devices } from '@playwright/test'; // import devices

export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
      },
    },
    {
      name: 'Mobile Safari',
      use: {
        ...devices['iPhone 13'],
      },
    },
  ],
});
```

**Key characteristics:**
- All tests run with specified device parameters
- Device presets include complete browser configuration
- Easy multi-device testing through projects

### Available Device Presets

The `playwright.devices` registry includes presets for:

**Desktop browsers:**
- Desktop Chrome
- Desktop Firefox
- Desktop Safari
- Desktop Edge

**Mobile phones:**
- iPhone 13, iPhone 13 Pro, iPhone 13 Pro Max
- iPhone 12, iPhone 12 Pro, iPhone 12 Pro Max
- iPhone 11, iPhone 11 Pro, iPhone 11 Pro Max
- iPhone SE
- Pixel 5, Pixel 4, Pixel 3
- Galaxy S9+, Galaxy S8
- And many more

**Tablets:**
- iPad Pro
- iPad Mini
- iPad (various generations)
- Galaxy Tab

**Each preset includes:**
- User agent string
- Viewport size
- Device pixel ratio
- Touch support
- Mobile flag
- Default orientation

## Viewport

The viewport defines the visible area of the web page. Device presets include viewport settings, but you can override them.

### Override Viewport in Config

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        // It is important to define the `viewport` property after destructuring `devices`,
        // since devices also define the `viewport` for that device.
        viewport: { width: 1280, height: 720 },
      },
    },
  ]
});
```

**Important:** Define `viewport` property **after** destructuring `devices` to ensure your override takes precedence.

### Override Viewport in Test File

```typescript
import { test, expect } from '@playwright/test';

test.use({
  viewport: { width: 1600, height: 1200 },
});

test('my test', async ({ page }) => {
  // Test runs with 1600x1200 viewport
});
```

### Override Viewport in Describe Block

```typescript
import { test, expect } from '@playwright/test';

test.describe('specific viewport block', () => {
  test.use({ viewport: { width: 1600, height: 1200 } });
  
  test('my test', async ({ page }) => {
    // Test runs with 1600x1200 viewport
  });
});
```

### Dynamic Viewport Changes

Use `page.setViewportSize()` to change viewport during test execution:

```typescript
await page.setViewportSize({ width: 1280, height: 720 });
```

**Use cases:**
- Testing responsive behavior
- Simulating window resizing
- Testing different screen sizes in single test

## isMobile

The `isMobile` flag determines whether the meta viewport tag is taken into account and if touch events are enabled.

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        // It is important to define the `isMobile` property after destructuring `devices`,
        // since devices also define the `isMobile` for that device.
        isMobile: false,
      },
    },
  ]
});
```

**Effects of isMobile:**
- **true:** Meta viewport tag is respected, touch events enabled
- **false:** Meta viewport tag ignored, touch events disabled

**Important:** Define `isMobile` property **after** destructuring `devices` to override device defaults.

## Locale & Timezone

Emulate browser locale and timezone, which can be set globally for all tests or overridden for specific tests.

### Global Configuration

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // Emulates the browser locale
    locale: 'en-GB',
    
    // Emulates the browser timezone
    timezoneId: 'Europe/Paris',
  },
});
```

### Test-Specific Configuration

```typescript
import { test, expect } from '@playwright/test';

test.use({
  locale: 'de-DE',
  timezoneId: 'Europe/Berlin',
});

test('my test for de lang in Berlin timezone', async ({ page }) => {
  await page.goto('https://www.bing.com');
  // Test runs with German locale and Berlin timezone
});
```

### Locale Format

**Common locale codes:**
- `'en-US'` - English (United States)
- `'en-GB'` - English (United Kingdom)
- `'de-DE'` - German (Germany)
- `'fr-FR'` - French (France)
- `'es-ES'` - Spanish (Spain)
- `'ja-JP'` - Japanese (Japan)
- `'zh-CN'` - Chinese (Simplified, China)

### Timezone Format

**IANA timezone identifiers:**
- `'America/New_York'`
- `'Europe/London'`
- `'Europe/Paris'`
- `'Europe/Berlin'`
- `'Asia/Tokyo'`
- `'Asia/Shanghai'`
- `'Australia/Sydney'`

### Important Note

**Browser vs Test Runner:**
- Locale and timezone settings only affect the **browser** context
- They do NOT affect the **test runner** timezone
- To set test runner timezone, use the `TZ` environment variable

**Example:**
```bash
TZ=America/New_York npx playwright test
```

## Permissions

Grant specific permissions to the browser context, such as notifications, geolocation, camera, microphone, etc.

### Global Permissions

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // Grants specified permissions to the browser context
    permissions: ['notifications'],
  },
});
```

### Origin-Specific Permissions

Grant permissions for a specific domain:

```typescript
import { test } from '@playwright/test';

test.beforeEach(async ({ context }) => {
  // Runs before each test and grants permissions for specific origin
  await context.grantPermissions(['notifications'], { origin: 'https://skype.com' });
});

test('first', async ({ page }) => {
  // page has notifications permission for https://skype.com
});
```

### Common Permissions

- `'geolocation'` - Access to geolocation
- `'notifications'` - Show notifications
- `'camera'` - Access to camera
- `'microphone'` - Access to microphone
- `'clipboard-read'` - Read from clipboard
- `'clipboard-write'` - Write to clipboard
- `'background-sync'` - Background sync
- `'midi'` - MIDI device access
- `'payment-handler'` - Payment handler

### Revoking Permissions

Clear all permissions using `browserContext.clearPermissions()`:

```typescript
await context.clearPermissions();
```

**Use case:** Reset permissions between tests or test scenarios.

## Geolocation

Set the browser's geolocation to simulate users in different locations.

### Global Geolocation

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    // Context geolocation
    geolocation: { longitude: 12.492507, latitude: 41.889938 },
    permissions: ['geolocation'],
  },
});
```

**Note:** You must also grant `'geolocation'` permission for the geolocation to work.

### Test-Specific Geolocation

```typescript
import { test, expect } from '@playwright/test';

test.use({
  geolocation: { longitude: 41.890221, latitude: 12.492348 },
  permissions: ['geolocation'],
});

test('my test with geolocation', async ({ page }) => {
  // Test runs with specified geolocation
});
```

### Dynamic Geolocation Changes

Change location during test execution:

```typescript
import { test, expect } from '@playwright/test';

test.use({
  geolocation: { longitude: 41.890221, latitude: 12.492348 },
  permissions: ['geolocation'],
});

test('my test with geolocation', async ({ page, context }) => {
  // Overwrite the location for this test
  await context.setGeolocation({ longitude: 48.858455, latitude: 2.294474 });
});
```

### Important Limitation

**Scope:** You can only change geolocation for **all pages** in the context, not individual pages.

**Geolocation format:**
```typescript
{
  longitude: number,  // -180 to 180
  latitude: number,   // -90 to 90
  accuracy?: number   // Optional, defaults to 0
}
```

**Example locations:**
- New York: `{ longitude: -74.006, latitude: 40.7128 }`
- London: `{ longitude: -0.1276, latitude: 51.5074 }`
- Tokyo: `{ longitude: 139.6917, latitude: 35.6895 }`
- Sydney: `{ longitude: 151.2093, latitude: -33.8688 }`

## Color Scheme and Media

Emulate the user's color scheme preference (light or dark mode) and media types.

### Color Scheme Configuration

**Global:**
```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    colorScheme: 'dark',
  },
});
```

**Test-specific:**
```typescript
import { test, expect } from '@playwright/test';

test.use({
  colorScheme: 'dark' // or 'light'
});

test('my test with dark mode', async ({ page }) => {
  // Test runs with dark color scheme
});
```

**Supported values:**
- `'light'` - Light mode
- `'dark'` - Dark mode
- `null` - No preference (system default)

### Media Type Emulation

Use `page.emulateMedia()` to emulate different media types:

```typescript
// Emulate print media
await page.emulateMedia({ media: 'print' });

// Emulate screen media
await page.emulateMedia({ media: 'screen' });

// Emulate color scheme
await page.emulateMedia({ colorScheme: 'dark' });
```

**Use cases:**
- Test print stylesheets
- Test responsive designs
- Test dark/light mode switching
- Test media queries

## User Agent

The user agent string is included in device presets, but can be overridden if needed.

```typescript
import { test, expect } from '@playwright/test';

test.use({ userAgent: 'My user agent' });

test('my user agent test', async ({ page }) => {
  // Test runs with custom user agent
});
```

**Use cases:**
- Test user agent detection
- Test browser-specific features
- Test legacy browser support
- Test bot detection

**Common user agents:**
- Chrome: `'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'`
- Firefox: `'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0'`
- Safari: `'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15'`

**Note:** Device presets already include appropriate user agents, so manual override is rarely needed.

## Offline

Emulate the network being offline to test offline functionality and error handling.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    offline: true
  },
});
```

**Effects:**
- All network requests will fail
- Tests offline functionality
- Verifies error handling
- Tests service workers and caching

**Use cases:**
- Progressive Web App (PWA) testing
- Offline mode verification
- Network error handling
- Cache behavior testing

## JavaScript Enabled

Emulate scenarios where JavaScript is disabled in the browser.

```typescript
import { test, expect } from '@playwright/test';

test.use({ javaScriptEnabled: false });

test('test with no JavaScript', async ({ page }) => {
  // Test runs with JavaScript disabled
});
```

**Use cases:**
- Test graceful degradation
- Verify server-side rendering
- Test accessibility without JavaScript
- Verify progressive enhancement

**Effects:**
- No JavaScript execution
- No dynamic content updates
- No client-side interactions
- Tests baseline HTML/CSS functionality

## Configuration Hierarchy

Emulation options follow the standard Playwright configuration hierarchy:

1. **Global config** - Applies to all tests
2. **Project config** - Applies to specific project
3. **Test file** - Applies to tests in file (using `test.use()`)
4. **Describe block** - Applies to tests in block
5. **Test level** - Applies to single test

**More specific configurations override less specific ones.**

## Best Practices

1. **Use Device Presets** - Leverage built-in device registry for realistic emulation

2. **Test Multiple Devices** - Use projects to test across desktop, tablet, and mobile

3. **Override After Destructuring** - When overriding device properties, do so after spreading device preset

4. **Test Dark Mode** - Use colorScheme to verify dark mode implementations

5. **Test Internationalization** - Use locale and timezone to test i18n features

6. **Grant Necessary Permissions** - Always grant required permissions (e.g., geolocation needs permission)

7. **Test Offline Scenarios** - Use offline mode to verify error handling and PWA functionality

8. **Verify Responsive Design** - Test multiple viewport sizes to ensure responsive behavior

9. **Test Without JavaScript** - Verify graceful degradation with javaScriptEnabled: false

10. **Use Origin-Specific Permissions** - Grant permissions only for specific origins when testing third-party integrations

## Common Emulation Patterns

### Mobile-First Testing

```typescript
export default defineConfig({
  projects: [
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'Mobile Safari',
      use: { ...devices['iPhone 13'] },
    },
    {
      name: 'Tablet',
      use: { ...devices['iPad Pro'] },
    },
    {
      name: 'Desktop',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
```

### Internationalization Testing

```typescript
export default defineConfig({
  projects: [
    {
      name: 'US English',
      use: {
        locale: 'en-US',
        timezoneId: 'America/New_York',
      },
    },
    {
      name: 'UK English',
      use: {
        locale: 'en-GB',
        timezoneId: 'Europe/London',
      },
    },
    {
      name: 'German',
      use: {
        locale: 'de-DE',
        timezoneId: 'Europe/Berlin',
      },
    },
  ],
});
```

### Dark Mode Testing

```typescript
export default defineConfig({
  projects: [
    {
      name: 'Light Mode',
      use: { colorScheme: 'light' },
    },
    {
      name: 'Dark Mode',
      use: { colorScheme: 'dark' },
    },
  ],
});
```

### Geolocation Testing

```typescript
test.describe('Location-based features', () => {
  test('New York user', async ({ page, context }) => {
    await context.setGeolocation({ longitude: -74.006, latitude: 40.7128 });
    await context.grantPermissions(['geolocation']);
    // Test NY-specific features
  });
  
  test('London user', async ({ page, context }) => {
    await context.setGeolocation({ longitude: -0.1276, latitude: 51.5074 });
    await context.grantPermissions(['geolocation']);
    // Test London-specific features
  });
});
```

## Related Topics to Explore

- Device registry and available devices
- Projects configuration
- Browser contexts
- Page object models for device-specific tests
- Responsive design testing strategies
- Progressive Web App testing
- Internationalization testing
- Accessibility testing
- Network mocking and offline testing
- Media query testing
