# Playwright Documentation Research - Authentication

**Page:** Authentication  
**URL:** https://playwright.dev/docs/auth  
**Research Date:** December 13, 2025

## Introduction

Playwright executes tests in **isolated environments** called **browser contexts**.

**Benefits:**
- Improves reproducibility
- Prevents cascading test failures

**Key capability:** Tests can load existing authenticated state.

**Advantages:**
- Eliminates need to authenticate in every test
- Speeds up test execution

## Core Concepts

### Storing Authenticated Browser State

Regardless of authentication strategy, you'll likely store authenticated browser state on **file system**.

### Recommended Directory Structure

Create `playwright/.auth` directory and add to `.gitignore`:

```bash
mkdir -p playwright/.auth
echo $'\nplaywright/.auth' >> .gitignore
```

**Workflow:**
1. Authentication routine produces authenticated browser state
2. Save to file in `playwright/.auth` directory
3. Tests reuse this state and start already authenticated

### Security Warning

⚠️ **DANGER:** Browser state file may contain sensitive cookies and headers that could be used to impersonate you or your test account.

**Strongly discourage** checking them into private or public repositories.

## Basic: Shared Account in All Tests

**Recommended approach** for tests **without server-side state**.

**Strategy:**
- Authenticate once in **setup project**
- Save authentication state
- Reuse to bootstrap each test already authenticated

### When to Use

When you can imagine all tests running at the same time with the same account, without affecting each other.

### When NOT to Use

- Tests modify server-side state (e.g., one test checks settings page while another changes settings)
- Authentication is browser-specific

### Implementation

#### Step 1: Create Setup File

Create `tests/auth.setup.ts`:

```typescript
import { test as setup, expect } from '@playwright/test';
import path from 'path';

const authFile = path.join(__dirname, '../playwright/.auth/user.json');

setup('authenticate', async ({ page }) => {
  // Perform authentication steps. Replace with your own.
  await page.goto('https://github.com/login');
  await page.getByLabel('Username or email address').fill('username');
  await page.getByLabel('Password').fill('password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  
  // Wait until the page receives the cookies.
  //
  // Sometimes login flow sets cookies in the process of several redirects.
  // Wait for the final URL to ensure that the cookies are actually set.
  await page.waitForURL('https://github.com/');
  
  // Alternatively, you can wait until the page reaches a state where all cookies are set.
  await expect(page.getByRole('button', { name: 'View profile and more' })).toBeVisible();

  // End of authentication steps.

  await page.context().storageState({ path: authFile });
});
```

#### Step 2: Configure Setup Project

Create setup project in `playwright.config.ts`:

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    // Setup project
    { name: 'setup', testMatch: /.*\.setup\.ts/ },

    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        // Use prepared auth state
        storageState: 'playwright/.auth/user.json',
      },
      dependencies: ['setup'],
    },

    {
      name: 'firefox',
      use: {
        ...devices['Desktop Firefox'],
        // Use prepared auth state
        storageState: 'playwright/.auth/user.json',
      },
      dependencies: ['setup'],
    },
  ],
});
```

#### Step 3: Write Tests

Tests start already authenticated:

```typescript
import { test } from '@playwright/test';

test('test', async ({ page }) => {
  // page is authenticated
});
```

### Managing State Expiration

**Note:** Delete stored state when it expires.

**Tip:** If you don't need to keep state between test runs, write browser state under `testProject.outputDir` (automatically cleaned up before every test run).

### Authenticating in UI Mode

UI mode will **not run setup project by default** to improve testing speed.

**Recommendation:** Authenticate by manually running `auth.setup.ts` from time to time, whenever existing authentication expires.

**Steps:**
1. Enable setup project in filters
2. Click triangle button next to `auth.setup.ts` file
3. Disable setup project in filters again

## Moderate: One Account Per Parallel Worker

**Recommended approach** for tests that **modify server-side state**.

**Strategy:**
- Worker processes run in parallel
- Each parallel worker is authenticated once
- All tests run by worker reuse same authentication state
- Need multiple testing accounts (one per each parallel worker)

### When to Use

Tests modify shared server-side state (e.g., one test checks settings page while another changes settings).

### When NOT to Use

Tests do not modify any shared server-side state (use single shared account instead).

### Implementation

Authenticate once per worker process, each with unique account.

#### Create Fixtures File

Create `playwright/fixtures.ts`:

```typescript
import { test as baseTest, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';

export * from '@playwright/test';
export const test = baseTest.extend<{}, { workerStorageState: string }>({
  // Use the same storage state for all tests in this worker
  storageState: ({ workerStorageState }, use) => use(workerStorageState),

  // Authenticate once per worker with a worker-scoped fixture
  workerStorageState: [async ({ browser }, use) => {
    // Use parallelIndex as a unique identifier for each worker
    const id = test.info().parallelIndex;
    const fileName = path.resolve(test.info().project.outputDir, `.auth/${id}.json`);

    if (fs.existsSync(fileName)) {
      // Reuse existing authentication state if any
      await use(fileName);
      return;
    }

    // Important: make sure we authenticate in a clean environment by unsetting storage state
    const page = await browser.newPage({ storageState: undefined });

    // Acquire a unique account, for example create a new one.
    // Alternatively, you can have a list of precreated accounts for testing.
    // Make sure that accounts are unique, so that multiple team members
    // can run tests at the same time without interference.
    const account = await acquireAccount(id);

    // Perform authentication steps. Replace with your own.
    await page.goto('https://github.com/login');
    await page.getByLabel('Username or email address').fill(account.username);
    await page.getByLabel('Password').fill(account.password);
    await page.getByRole('button', { name: 'Sign in' }).click();
    
    // Wait until the page receives the cookies
    await page.waitForURL('https://github.com/');
    await expect(page.getByRole('button', { name: 'View profile and more' })).toBeVisible();

    // End of authentication steps

    await page.context().storageState({ path: fileName });
    await page.close();
    await use(fileName);
  }, { scope: 'worker' }],
});
```

#### Use in Tests

Import `test` from fixtures file:

```typescript
// Important: import our fixtures
import { test, expect } from '../playwright/fixtures';

test('test', async ({ page }) => {
  // page is authenticated
});
```

**No changes needed in config.**

## Advanced Scenarios

### Authenticate with API Request

#### When to Use

Web application supports authenticating via API that is easier/faster than interacting with app UI.

#### In Setup Project

```typescript
import { test as setup } from '@playwright/test';

const authFile = 'playwright/.auth/user.json';

setup('authenticate', async ({ request }) => {
  // Send authentication request. Replace with your own.
  await request.post('https://github.com/login', {
    form: {
      'user': 'user',
      'password': 'password'
    }
  });
  await request.storageState({ path: authFile });
});
```

#### In Worker Fixture

```typescript
import { test as baseTest, request } from '@playwright/test';
import fs from 'fs';
import path from 'path';

export * from '@playwright/test';
export const test = baseTest.extend<{}, { workerStorageState: string }>({
  storageState: ({ workerStorageState }, use) => use(workerStorageState),

  workerStorageState: [async ({}, use) => {
    const id = test.info().parallelIndex;
    const fileName = path.resolve(test.info().project.outputDir, `.auth/${id}.json`);

    if (fs.existsSync(fileName)) {
      await use(fileName);
      return;
    }

    const context = await request.newContext({ storageState: undefined });
    const account = await acquireAccount(id);

    // Send authentication request
    await context.post('https://github.com/login', {
      form: {
        'user': 'user',
        'password': 'password'
      }
    });

    await context.storageState({ path: fileName });
    await context.dispose();
    await use(fileName);
  }, { scope: 'worker' }],
});
```

### Multiple Signed In Roles

#### When to Use

More than one role in end-to-end tests, but can reuse accounts across all tests.

#### Implementation

Authenticate multiple times in setup project:

```typescript
import { test as setup, expect } from '@playwright/test';

const adminFile = 'playwright/.auth/admin.json';

setup('authenticate as admin', async ({ page }) => {
  await page.goto('https://github.com/login');
  await page.getByLabel('Username or email address').fill('admin');
  await page.getByLabel('Password').fill('password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.waitForURL('https://github.com/');
  await expect(page.getByRole('button', { name: 'View profile and more' })).toBeVisible();
  await page.context().storageState({ path: adminFile });
});

const userFile = 'playwright/.auth/user.json';

setup('authenticate as user', async ({ page }) => {
  await page.goto('https://github.com/login');
  await page.getByLabel('Username or email address').fill('user');
  await page.getByLabel('Password').fill('password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.waitForURL('https://github.com/');
  await expect(page.getByRole('button', { name: 'View profile and more' })).toBeVisible();
  await page.context().storageState({ path: userFile });
});
```

#### Use in Tests

Specify `storageState` for each test file or test group:

```typescript
import { test } from '@playwright/test';

test.use({ storageState: 'playwright/.auth/admin.json' });

test('admin test', async ({ page }) => {
  // page is authenticated as admin
});

test.describe(() => {
  test.use({ storageState: 'playwright/.auth/user.json' });

  test('user test', async ({ page }) => {
    // page is authenticated as a user
  });
});
```

### Testing Multiple Roles Together

#### When to Use

Need to test how multiple authenticated roles interact together, in a single test.

#### Implementation

Use multiple `BrowserContexts` and `Pages` with different storage states:

```typescript
import { test } from '@playwright/test';

test('admin and user', async ({ browser }) => {
  // adminContext and all pages inside, including adminPage, are signed in as "admin"
  const adminContext = await browser.newContext({ storageState: 'playwright/.auth/admin.json' });
  const adminPage = await adminContext.newPage();

  // userContext and all pages inside, including userPage, are signed in as "user"
  const userContext = await browser.newContext({ storageState: 'playwright/.auth/user.json' });
  const userPage = await userContext.newPage();

  // ... interact with both adminPage and userPage ...

  await adminContext.close();
  await userContext.close();
});
```

### Testing Multiple Roles with POM Fixtures

#### When to Use

Need to test how multiple authenticated roles interact together, in a single test.

#### Implementation

Create fixtures that provide page authenticated as each role:

```typescript
// playwright/fixtures.ts
import { test as base, type Page, type Locator } from '@playwright/test';

class AdminPage {
  page: Page;
  greeting: Locator;

  constructor(page: Page) {
    this.page = page;
    this.greeting = page.locator('#greeting');
  }
}

class UserPage {
  page: Page;
  greeting: Locator;

  constructor(page: Page) {
    this.page = page;
    this.greeting = page.locator('#greeting');
  }
}

type MyFixtures = {
  adminPage: AdminPage;
  userPage: UserPage;
};

export * from '@playwright/test';
export const test = base.extend<MyFixtures>({
  adminPage: async ({ browser }, use) => {
    const context = await browser.newContext({ storageState: 'playwright/.auth/admin.json' });
    const adminPage = new AdminPage(await context.newPage());
    await use(adminPage);
    await context.close();
  },
  userPage: async ({ browser }, use) => {
    const context = await browser.newContext({ storageState: 'playwright/.auth/user.json' });
    const userPage = new UserPage(await context.newPage());
    await use(userPage);
    await context.close();
  },
});
```

#### Use in Tests

```typescript
import { test, expect } from '../playwright/fixtures';

test('admin and user', async ({ adminPage, userPage }) => {
  await expect(adminPage.greeting).toHaveText('Welcome, Admin');
  await expect(userPage.greeting).toHaveText('Welcome, User');
});
```

## Session Storage

### Overview

Reusing authenticated state covers:
- Cookies
- Local storage
- IndexedDB based authentication

**Rarely:** Session storage is used for storing information associated with signed-in state.

**Characteristics:**
- Specific to particular domain
- Not persisted across page loads

**Note:** Playwright does not provide API to persist session storage.

### Manual Session Storage Handling

```typescript
// Get session storage and store as env variable
const sessionStorage = await page.evaluate(() => JSON.stringify(sessionStorage));
fs.writeFileSync('playwright/.auth/session.json', sessionStorage, 'utf-8');

// Set session storage in a new context
const sessionStorage = JSON.parse(fs.readFileSync('playwright/.auth/session.json', 'utf-8'));
await context.addInitScript(storage => {
  if (window.location.hostname === 'example.com') {
    for (const [key, value] of Object.entries(storage))
      window.sessionStorage.setItem(key, value);
  }
}, sessionStorage);
```

## Avoid Authentication in Some Tests

Reset storage state in test file to avoid authentication set up for whole project:

```typescript
// not-signed-in.spec.ts
import { test } from '@playwright/test';

// Reset storage state for this file to avoid being authenticated
test.use({ storageState: { cookies: [], origins: [] } });

test('not signed in test', async ({ page }) => {
  // ...
});
```

## Best Practices

### 1. Use Setup Project for Shared Account

Authenticate once, reuse everywhere.

### 2. Store Auth State in playwright/.auth

Add to `.gitignore` for security.

### 3. Wait for Final URL After Login

Ensure cookies are actually set.

### 4. Use Worker-Scoped Fixtures for Parallel Tests

One account per worker when tests modify server state.

### 5. Authenticate via API When Possible

Faster than UI-based authentication.

### 6. Create Multiple Auth States for Different Roles

Admin, user, guest, etc.

### 7. Use Page Object Model for Multi-Role Tests

Cleaner test code with fixtures.

### 8. Handle Session Storage Manually

Use `addInitScript` to restore session storage.

### 9. Reset Storage State for Unauthenticated Tests

Use empty cookies and origins.

### 10. Manually Run Setup in UI Mode

Setup project doesn't run automatically in UI mode.

## Related Topics to Explore

- Browser contexts
- Storage state
- Test fixtures
- Setup projects
- Worker processes
- Parallel testing
- APIRequestContext
- Page Object Model
- Test dependencies
- Global setup and teardown
