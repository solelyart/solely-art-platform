# Playwright Documentation Research - Downloads

**Page:** Downloads  
**URL:** https://playwright.dev/docs/downloads  
**Research Date:** December 14, 2025

## Introduction

### Download Event

**Event emitted:** For every attachment downloaded by page, `page.on('download')` event is emitted.

**Download location:** All attachments downloaded into temporary folder.

**Access information:** Can obtain:
- Download URL
- File name
- Payload stream

**Using:** Download object from the event.

### Persist Downloaded Files

**Configuration:** Can specify where to persist downloaded files using `downloadsPath` option in `browserType.launch()`.

### Important Note

**File lifecycle:** Downloaded files are deleted when browser context that produced them is closed.

## Handling Downloads

### Simplest Way

**Pattern:**
```typescript
// Start waiting for download before clicking. Note no await.
const downloadPromise = page.waitForEvent('download');
await page.getByText('Download file').click();
const download = await downloadPromise;

// Wait for the download process to complete and save the downloaded file somewhere.
await download.saveAs('/path/to/save/at/' + download.suggestedFilename());
```

**Key points:**
1. Start waiting for download **before** clicking (no await)
2. Click to trigger download
3. Await download promise
4. Save file using `download.saveAs()`

## Variations

### Event Handler Approach

**Pattern:**
```typescript
page.on('download', download => download.path().then(console.log));
```

**Note:** Handling event forks control flow and makes script harder to follow.

**Warning:** Scenario might end while downloading file since main control flow not awaiting this operation to resolve.

## Upload Files

**Note:** For uploading files, see the uploading files section.

## Best Practices

### 1. Wait for Download Before Action

**✅ Good:**
```typescript
const downloadPromise = page.waitForEvent('download');
await page.getByRole('button', { name: 'Download' }).click();
const download = await downloadPromise;
```

**❌ Bad:**
```typescript
await page.getByRole('button', { name: 'Download' }).click();
const download = await page.waitForEvent('download'); // May miss event
```

### 2. Use suggestedFilename()

**Pattern:**
```typescript
const download = await downloadPromise;
await download.saveAs(`/downloads/${download.suggestedFilename()}`);
```

**Benefit:** Uses original filename from server.

### 3. Validate Download

**Pattern:**
```typescript
const download = await downloadPromise;

// Validate filename
expect(download.suggestedFilename()).toBe('report.pdf');

// Validate file exists
const path = await download.path();
expect(fs.existsSync(path)).toBe(true);

// Validate file size
const stats = fs.statSync(path);
expect(stats.size).toBeGreaterThan(0);
```

### 4. Configure Downloads Path

**Pattern:**
```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    downloadsPath: './test-downloads',
  },
});
```

### 5. Clean Up Downloads

**Pattern:**
```typescript
test.afterEach(async ({ context }) => {
  // Downloads automatically deleted when context closes
  await context.close();
});
```

## Common Use Cases

### Use Case 1: Download and Validate File

```typescript
test('download report', async ({ page }) => {
  await page.goto('/reports');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download Report' }).click();
  const download = await downloadPromise;
  
  // Validate filename
  expect(download.suggestedFilename()).toBe('monthly-report.pdf');
  
  // Save file
  await download.saveAs(`./downloads/${download.suggestedFilename()}`);
  
  // Validate file exists
  const path = await download.path();
  expect(fs.existsSync(path)).toBe(true);
});
```

### Use Case 2: Download Multiple Files

```typescript
test('download multiple files', async ({ page }) => {
  await page.goto('/documents');
  
  const downloads: Download[] = [];
  
  // Collect all downloads
  page.on('download', download => downloads.push(download));
  
  await page.getByRole('button', { name: 'Download All' }).click();
  
  // Wait for all downloads
  await page.waitForTimeout(2000);
  
  expect(downloads).toHaveLength(3);
  
  // Save all files
  for (const download of downloads) {
    await download.saveAs(`./downloads/${download.suggestedFilename()}`);
  }
});
```

### Use Case 3: Validate File Content

```typescript
test('validate downloaded content', async ({ page }) => {
  await page.goto('/export');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export CSV' }).click();
  const download = await downloadPromise;
  
  // Get file path
  const path = await download.path();
  
  // Read file content
  const content = fs.readFileSync(path, 'utf-8');
  
  // Validate content
  expect(content).toContain('Name,Email,Phone');
  expect(content.split('\n').length).toBeGreaterThan(1);
});
```

### Use Case 4: Download with Custom Path

```typescript
test('download to custom location', async ({ page }) => {
  await page.goto('/files');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByText('Download').click();
  const download = await downloadPromise;
  
  const timestamp = Date.now();
  const customPath = `./downloads/${timestamp}-${download.suggestedFilename()}`;
  
  await download.saveAs(customPath);
  
  expect(fs.existsSync(customPath)).toBe(true);
});
```

### Use Case 5: Download from Link

```typescript
test('download from link', async ({ page }) => {
  await page.goto('/resources');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('link', { name: 'Download PDF' }).click();
  const download = await downloadPromise;
  
  await download.saveAs(`./downloads/${download.suggestedFilename()}`);
});
```

## Use Cases for Solely Art Platform

### Example 1: Download Artist Contract

```typescript
test('download artist contract', async ({ page }) => {
  await page.goto('/artist/contracts');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download Contract' }).click();
  const download = await downloadPromise;
  
  // Validate filename
  expect(download.suggestedFilename()).toMatch(/contract.*\.pdf$/i);
  
  // Save file
  const savePath = `./downloads/contracts/${download.suggestedFilename()}`;
  await download.saveAs(savePath);
  
  // Validate file exists and has content
  expect(fs.existsSync(savePath)).toBe(true);
  const stats = fs.statSync(savePath);
  expect(stats.size).toBeGreaterThan(1000); // At least 1KB
});
```

### Example 2: Download Booking Invoice

```typescript
test('download booking invoice', async ({ page }) => {
  await page.goto('/bookings/123');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download Invoice' }).click();
  const download = await downloadPromise;
  
  // Validate filename contains booking ID
  expect(download.suggestedFilename()).toContain('booking-123');
  
  // Save invoice
  await download.saveAs(`./downloads/invoices/${download.suggestedFilename()}`);
});
```

### Example 3: Export Artist Portfolio

```typescript
test('export artist portfolio', async ({ page }) => {
  await page.goto('/artist/123/portfolio');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export Portfolio' }).click();
  const download = await downloadPromise;
  
  // Should be a ZIP file
  expect(download.suggestedFilename()).toMatch(/\.zip$/i);
  
  // Save and validate
  const savePath = `./downloads/${download.suggestedFilename()}`;
  await download.saveAs(savePath);
  
  // Validate ZIP file
  const stats = fs.statSync(savePath);
  expect(stats.size).toBeGreaterThan(10000); // At least 10KB
});
```

### Example 4: Download Booking Report (CSV)

```typescript
test('download booking report CSV', async ({ page }) => {
  await page.goto('/admin/reports');
  
  // Set date range
  await page.getByLabel('Start Date').fill('2025-01-01');
  await page.getByLabel('End Date').fill('2025-01-31');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export CSV' }).click();
  const download = await downloadPromise;
  
  // Get file path
  const path = await download.path();
  
  // Read and validate CSV content
  const content = fs.readFileSync(path, 'utf-8');
  expect(content).toContain('Booking ID,Artist,Client,Date,Amount');
  
  // Validate has data rows
  const rows = content.split('\n');
  expect(rows.length).toBeGreaterThan(1);
});
```

### Example 5: Download Multiple Artist Photos

```typescript
test('download artist photos', async ({ page }) => {
  await page.goto('/artist/123/gallery');
  
  const downloads: Download[] = [];
  page.on('download', download => downloads.push(download));
  
  // Select multiple photos
  await page.getByLabel('Select All').check();
  await page.getByRole('button', { name: 'Download Selected' }).click();
  
  // Wait for downloads to complete
  await page.waitForTimeout(3000);
  
  expect(downloads.length).toBeGreaterThan(0);
  
  // Save all photos
  for (const download of downloads) {
    const filename = download.suggestedFilename();
    expect(filename).toMatch(/\.(jpg|jpeg|png)$/i);
    await download.saveAs(`./downloads/photos/${filename}`);
  }
});
```

### Example 6: Validate Receipt Download

```typescript
test('download payment receipt', async ({ page }) => {
  await page.goto('/payments/456');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('link', { name: 'Download Receipt' }).click();
  const download = await downloadPromise;
  
  // Validate filename
  expect(download.suggestedFilename()).toContain('receipt');
  expect(download.suggestedFilename()).toContain('456');
  
  // Save receipt
  const savePath = `./downloads/receipts/${download.suggestedFilename()}`;
  await download.saveAs(savePath);
  
  // Validate PDF content (if PDF)
  if (download.suggestedFilename().endsWith('.pdf')) {
    const stats = fs.statSync(savePath);
    expect(stats.size).toBeGreaterThan(500);
  }
});
```

## Advanced Patterns

### Pattern 1: Download with Timeout

```typescript
test('download with timeout', async ({ page }) => {
  await page.goto('/files');
  
  const downloadPromise = page.waitForEvent('download', { timeout: 30000 });
  await page.getByRole('button', { name: 'Download' }).click();
  const download = await downloadPromise;
  
  await download.saveAs(`./downloads/${download.suggestedFilename()}`);
});
```

### Pattern 2: Conditional Download Handling

```typescript
test('conditional download', async ({ page }) => {
  await page.goto('/documents');
  
  page.on('download', async download => {
    const filename = download.suggestedFilename();
    
    if (filename.endsWith('.pdf')) {
      await download.saveAs(`./downloads/pdfs/${filename}`);
    } else if (filename.endsWith('.csv')) {
      await download.saveAs(`./downloads/csvs/${filename}`);
    } else {
      await download.saveAs(`./downloads/other/${filename}`);
    }
  });
  
  await page.getByRole('button', { name: 'Download All' }).click();
});
```

### Pattern 3: Download and Process

```typescript
test('download and process', async ({ page }) => {
  await page.goto('/export');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export' }).click();
  const download = await downloadPromise;
  
  // Get temporary path
  const tempPath = await download.path();
  
  // Process file
  const content = fs.readFileSync(tempPath, 'utf-8');
  const data = JSON.parse(content);
  
  // Validate processed data
  expect(data).toHaveProperty('users');
  expect(data.users.length).toBeGreaterThan(0);
  
  // Save processed file
  await download.saveAs(`./downloads/${download.suggestedFilename()}`);
});
```

### Pattern 4: Download Stream

```typescript
test('download stream', async ({ page }) => {
  await page.goto('/files');
  
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download' }).click();
  const download = await downloadPromise;
  
  // Get stream
  const stream = await download.createReadStream();
  const chunks: Buffer[] = [];
  
  stream.on('data', chunk => chunks.push(chunk));
  await new Promise((resolve, reject) => {
    stream.on('end', resolve);
    stream.on('error', reject);
  });
  
  const buffer = Buffer.concat(chunks);
  expect(buffer.length).toBeGreaterThan(0);
});
```

### Pattern 5: Configure Downloads Path Globally

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    downloadsPath: './test-downloads',
    acceptDownloads: true,
  },
});
```

## Download Methods

### download.saveAs(path)

**Purpose:** Save download to specific path.

```typescript
await download.saveAs('/path/to/save/file.pdf');
```

### download.path()

**Purpose:** Get temporary path where download is saved.

```typescript
const path = await download.path();
```

**Note:** File deleted when context closes.

### download.suggestedFilename()

**Purpose:** Get suggested filename from server.

```typescript
const filename = download.suggestedFilename();
```

### download.url()

**Purpose:** Get download URL.

```typescript
const url = download.url();
```

### download.createReadStream()

**Purpose:** Get readable stream of download.

```typescript
const stream = await download.createReadStream();
```

### download.failure()

**Purpose:** Get download failure reason (if failed).

```typescript
const error = await download.failure();
if (error) {
  console.log('Download failed:', error);
}
```

## Configuration

### downloadsPath

**Configure in playwright.config.ts:**
```typescript
export default defineConfig({
  use: {
    downloadsPath: './test-downloads',
  },
});
```

### acceptDownloads

**Enable/disable downloads:**
```typescript
export default defineConfig({
  use: {
    acceptDownloads: true, // Default is true
  },
});
```

## Troubleshooting

### Issue: Download Event Not Fired

**Cause:** Waiting for download after clicking.

**Solution:** Start waiting before clicking.

```typescript
// ✅ Correct
const downloadPromise = page.waitForEvent('download');
await page.click('button');
const download = await downloadPromise;

// ❌ Wrong
await page.click('button');
const download = await page.waitForEvent('download'); // May miss event
```

### Issue: File Not Found

**Cause:** Accessing file after context closed.

**Solution:** Save file before closing context or access within context lifecycle.

```typescript
const download = await downloadPromise;
await download.saveAs('./downloads/file.pdf'); // Save before context closes
```

### Issue: Cannot Read File

**Cause:** Download not complete.

**Solution:** Await download.path() or download.saveAs().

```typescript
const download = await downloadPromise;
const path = await download.path(); // Wait for download to complete
const content = fs.readFileSync(path);
```

### Issue: Multiple Downloads

**Cause:** Need to handle multiple download events.

**Solution:** Use array to collect downloads.

```typescript
const downloads: Download[] = [];
page.on('download', download => downloads.push(download));

await page.click('button');
await page.waitForTimeout(2000);

for (const download of downloads) {
  await download.saveAs(`./downloads/${download.suggestedFilename()}`);
}
```

## Summary

### Key Concepts

**1. Download event:** `page.on('download')` emitted for each download

**2. Temporary storage:** Downloads saved to temporary folder

**3. File lifecycle:** Files deleted when context closes

**4. Wait before action:** Start waiting for download before triggering action

**5. Save file:** Use `download.saveAs()` to persist file

### Download Methods

- `download.saveAs(path)` - Save to specific path
- `download.path()` - Get temporary path
- `download.suggestedFilename()` - Get suggested filename
- `download.url()` - Get download URL
- `download.createReadStream()` - Get readable stream
- `download.failure()` - Get failure reason

### Best Practices

1. Wait for download before action
2. Use suggestedFilename()
3. Validate download
4. Configure downloads path
5. Clean up downloads (automatic on context close)

### Common Patterns

- Download and validate file
- Download multiple files
- Validate file content
- Download with custom path
- Download from link

## Related Topics

- File uploads
- Browser contexts
- Test configuration
- File system operations
- Streams
- Event handling
