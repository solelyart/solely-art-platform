# Playwright Documentation Research - Debugging Tests

**Page:** Debugging Tests  
**URL:** https://playwright.dev/docs/debug  
**Research Date:** December 13, 2025

## Overview

**Recommendation:** Use VS Code Extension for debugging for better developer experience.

**Capabilities:**
- Debug tests right in VS Code
- See error messages
- Set breakpoints
- Step through tests

## VS Code Debugger

### Error Messages

**Feature:** If test fails, VS Code shows error messages right in editor.

**Information displayed:**
- What was expected
- What was received
- Complete call log

**Benefit:** Immediate feedback without leaving editor.

### Live Debugging

**Feature:** Debug test live in VS Code.

**Process:**
1. Run test with "Show Browser" option checked
2. Click on any locator in VS Code
3. Locator highlighted in browser window
4. Playwright shows if there are multiple matches

**Live editing:**
- Edit locators in VS Code
- Playwright shows changes live in browser window

### Picking a Locator

**Feature:** Pick locator and copy into test file.

**Process:**
1. Click "Pick locator" button from testing sidebar
2. In browser, click element you require
3. Element shows up in "Pick locator" box in VS Code
4. Press 'enter' to copy locator to clipboard
5. Paste anywhere in code
6. Press 'escape' to cancel

**Smart locator generation:**
- Playwright figures out best locator
- Prioritizes role, text, and test id locators
- If multiple elements match, improves locator to make it resilient
- Uniquely identifies target element

### Run in Debug Mode

**Setting breakpoint:**
1. Click next to line number
2. Red dot appears
3. Right click on line next to test
4. Run tests in debug mode

**Behavior:**
- Browser window opens
- Test runs and pauses at breakpoint
- Can step through tests
- Can pause test
- Can rerun tests from VS Code menu

### Debug Tests Using Chrome DevTools

**Alternative approach:** Instead of "Debug Test", choose "Run Test".

**With "Show Browser" enabled:**
- Browser session is reused
- Can open Chrome DevTools
- Continuous debugging of tests and web application

### Debug in Different Browsers

**Default:** Debugging done using Chromium profile.

**Change browser:**
1. Right click debug icon in testing sidebar
2. Click "Select Default Profile" from dropdown
3. Choose test profile for debugging

**Usage:** Each time you run test in debug mode, it uses selected profile.

**To learn more:** See "Debugging in Visual Studio Code" guide.

## Playwright Inspector

### Overview

**Definition:** GUI tool to help debug Playwright tests.

**Capabilities:**
- Step through tests
- Live edit locators
- Pick locators
- See actionability logs

### Run in Debug Mode

**Command:** Run tests with `--debug` flag to open inspector.

**Configuration when `--debug` used:**
- Browsers launch in headed mode
- Default timeout set to 0 (no timeout)

### Debug All Tests on All Browsers

**Command:**
```bash
npx playwright test --debug
```

**Behavior:** Runs tests one by one, opens inspector and browser window for each test.

### Debug One Test on All Browsers

**Command:**
```bash
npx playwright test example.spec.ts:10 --debug
```

**Behavior:** Runs single test in each browser configured in `playwright.config`, opens inspector.

### Debug on Specific Browser

**Prerequisite:** Configure projects in `playwright.config`.

**Commands:**
```bash
npx playwright test --project=chromium --debug
npx playwright test --project="Mobile Safari" --debug
npx playwright test --project="Microsoft Edge" --debug
```

**Behavior:** Debug tests on specific browser or mobile viewport.

### Debug One Test on Specific Browser

**Command:**
```bash
npx playwright test example.spec.ts:10 --project=webkit --debug
```

**Behavior:** Run one test on specific browser with debugging.

### Stepping Through Tests

**Feature:** Use toolbar at top of Inspector to control test execution.

**Controls:**
- Play
- Pause
- Step through each action

**Visual feedback:**
- Current action highlighted in test code
- Matching elements highlighted in browser window

### Run Test from Specific Breakpoint

**Method:** Add `page.pause()` to test.

**Example:**
```typescript
await page.pause();
```

**Benefit:** Speed up debugging process - won't have to step through each action.

**Usage:**
1. Add `page.pause()` call
2. Run tests in debug mode
3. Click "Resume" button in Inspector
4. Test runs and only stops on `page.pause()`

### Live Editing Locators

**Feature:** Edit locators while running in debug mode.

**Location:** Next to 'Pick Locator' button, field shows locator test is paused on.

**Process:**
1. Edit locator directly in "Pick Locator" field
2. Matching elements highlighted in browser window

### Picking Locators

**Feature:** Choose more resilient locator while debugging.

**Process:**
1. Click "Pick Locator" button
2. Hover over any element in browser window
3. See code needed to locate element highlighted below
4. Click element in browser
5. Locator added to field
6. Tweak or copy into code

**Smart generation:**
- Playwright figures out best locator
- Prioritizes role, text, and test id locators
- Improves locator if multiple elements match
- Makes locator resilient and unique

### Actionability Logs

**Feature:** See actionability checks performed by Playwright.

**Information available:**
- Element visibility
- Element enabled state
- Element stability
- Locator resolution
- Scroll into view
- Much more

**Benefit:** Understand what happened during test and what Playwright did or tried to do.

**Pending actions:** If actionability can't be reached, shows action as pending.

## Trace Viewer

**Definition:** GUI tool to explore recorded Playwright traces of tests.

**Features:**
- Go back and forward through each action (left side)
- Visually see what was happening during action
- DOM snapshot for action (middle of screen)
- Action details (right side): time, parameters, return value, log
- Explore console messages
- Explore network requests
- View source code

**To learn more:** Check out Trace Viewer guide.

## Browser Developer Tools

### Overview

**When available:** When running in Debug Mode with `PWDEBUG=console`.

**Feature:** `playwright` object available in Developer tools console.

**Capabilities:**
- Inspect DOM tree and find element selectors
- See console logs during execution
- Check network activity
- Other developer tools features

### Setup

**Step 1:** Set breakpoint using `page.pause()`.

```typescript
await page.pause();
```

**Step 2:** Run test with `PWDEBUG=console`.

```bash
# Bash
PWDEBUG=console npx playwright test

# PowerShell
$env:PWDEBUG="console"
npx playwright test

# Batch
set PWDEBUG=console
npx playwright test
```

**Step 3:** Open developer tools when Playwright launches browser.

**Result:** `playwright` object available in console panel.

### playwright.$(selector)

**Purpose:** Query Playwright selector using actual Playwright query engine.

**Example:**
```javascript
playwright.$('.auth-form >> text=Log in');
// Returns: <button>Log in</button>
```

### playwright.$$(selector)

**Purpose:** Same as `playwright.$`, but returns all matching elements.

**Example:**
```javascript
playwright.$$('li >> text=John')
// Returns: [<li>, <li>, <li>, <li>]
```

### playwright.inspect(selector)

**Purpose:** Reveal element in Elements panel.

**Example:**
```javascript
playwright.inspect('text=Log in')
```

### playwright.locator(selector)

**Purpose:** Create locator and query matching elements.

**Example:**
```javascript
playwright.locator('.auth-form', { hasText: 'Log in' });
// Returns:
// Locator ()
//   - element: button
//   - elements: [button]
```

### playwright.selector(element)

**Purpose:** Generate selector for given element.

**Example:**
```javascript
// Select element in Elements panel and pass $0
playwright.selector($0)
// Returns: "div[id="glow-ingress-block"] >> text=/.*Hello.*/"
```

## Verbose API Logs

**Feature:** Playwright supports verbose logging with DEBUG environment variable.

**Command:**
```bash
# Bash
DEBUG=pw:api npx playwright test

# PowerShell
$env:DEBUG="pw:api"
npx playwright test

# Batch
set DEBUG=pw:api
npx playwright test
```

**Note:** For WebKit, launching WebKit Inspector during execution will prevent Playwright script from executing further and will reset pre-configured user agent and device emulation.

## Headed Mode

**Default:** Playwright runs browsers in headless mode.

**Change behavior:** Use `headless: false` as launch option.

**Slow down execution:** Use `slowMo` option to slow down by N milliseconds per operation.

**Example:**
```typescript
// Chromium, Firefox, or WebKit
await chromium.launch({ headless: false, slowMo: 100 });
```

**Use case:** Follow along while debugging.

## Best Practices

### 1. Use VS Code Extension for Primary Debugging

**Recommended workflow:**
- Set breakpoints in VS Code
- Run in debug mode
- Step through tests
- Live edit locators
- See error messages inline

### 2. Use page.pause() for Strategic Breakpoints

**✅ Good:**
```typescript
test('complex workflow', async ({ page }) => {
  // ... setup code
  await page.goto('/');
  // ... many actions
  
  await page.pause();  // Pause at critical point
  
  // ... actions to debug
});
```

**Benefit:** Jump directly to area of interest without stepping through entire test.

### 3. Use Playwright Inspector for Locator Refinement

**Workflow:**
1. Run test with `--debug`
2. Use "Pick Locator" feature
3. Test different locators live
4. Copy refined locator to code

### 4. Use Browser DevTools for Deep Investigation

**When to use:**
- Need to inspect network requests
- Need to see console logs
- Need to examine DOM structure
- Need to test selectors manually

**Workflow:**
```typescript
await page.pause();  // Set breakpoint
```

```bash
PWDEBUG=console npx playwright test
```

Then use `playwright.$()` and other console methods.

### 5. Use Trace Viewer for Post-Mortem Analysis

**When to use:**
- Test failed in CI
- Need to understand what happened
- Need to share debugging information with team

**Benefit:** Visual timeline of all actions, network requests, console logs.

### 6. Debug on Multiple Browsers

**Workflow:**
```bash
# Debug on Chromium
npx playwright test --project=chromium --debug

# Debug on Firefox
npx playwright test --project=firefox --debug

# Debug on WebKit
npx playwright test --project=webkit --debug
```

**Benefit:** Catch browser-specific issues.

### 7. Use Verbose Logging for API Debugging

**When to use:**
- Need to see all API calls
- Debugging timing issues
- Understanding Playwright behavior

**Command:**
```bash
DEBUG=pw:api npx playwright test
```

## Common Debugging Scenarios

### Scenario 1: Element Not Found

**Problem:** Test fails because element not found.

**Debugging approach:**
1. Run with `--debug`
2. Use "Pick Locator" to find element
3. Check if element exists in DOM
4. Check if element is visible
5. Check actionability logs

### Scenario 2: Flaky Test

**Problem:** Test passes sometimes, fails other times.

**Debugging approach:**
1. Add `page.pause()` before flaky action
2. Run test multiple times
3. Check network timing
4. Check for race conditions
5. Use Trace Viewer to compare passing vs failing runs

### Scenario 3: Timeout Error

**Problem:** Test times out waiting for element.

**Debugging approach:**
1. Run with `--debug` (sets timeout to 0)
2. See what Playwright is waiting for
3. Check actionability logs
4. Verify element actually appears
5. Adjust wait strategy if needed

### Scenario 4: Wrong Element Clicked

**Problem:** Test clicks wrong element.

**Debugging approach:**
1. Use "Pick Locator" to verify locator
2. Check if multiple elements match
3. Refine locator to be more specific
4. Use live editing to test new locator

### Scenario 5: Network Request Issues

**Problem:** Test fails due to network issues.

**Debugging approach:**
1. Use `PWDEBUG=console`
2. Open Network tab in DevTools
3. Monitor requests and responses
4. Check for failed requests
5. Verify request timing

## Use Cases for Solely Art Platform

### Debug Booking Flow

```typescript
test('debug booking flow', async ({ page }) => {
  await page.goto('/artist/123');
  await page.getByRole('button', { name: 'Book Now' }).click();
  
  await page.pause();  // Pause to inspect booking form
  
  await page.getByLabel('Date').fill('2025-01-15');
  await page.getByLabel('Time').selectOption('14:00');
  await page.getByRole('button', { name: 'Confirm' }).click();
});
```

**Run with:**
```bash
npx playwright test booking.spec.ts --debug
```

### Debug Payment Integration

```typescript
test('debug payment', async ({ page }) => {
  // ... navigate to checkout
  
  await page.pause();  // Pause before payment
  
  // Use DevTools to inspect payment form
  // Check network requests to Stripe
  // Verify payment data
});
```

**Run with:**
```bash
PWDEBUG=console npx playwright test payment.spec.ts
```

### Debug Real-Time Messaging

```typescript
test('debug messaging', async ({ page }) => {
  await page.goto('/messages');
  
  // Monitor WebSocket in DevTools
  await page.pause();
  
  await page.getByRole('textbox').fill('Hello');
  await page.getByRole('button', { name: 'Send' }).click();
  
  // Check WebSocket frames in DevTools
});
```

### Pick Locators for New Features

**Workflow:**
1. Run test with VS Code extension
2. Enable "Show Browser"
3. Click "Pick Locator"
4. Click elements in browser
5. Copy locators to test

### Debug Cross-Browser Issues

```bash
# Test passes on Chromium but fails on WebKit
npx playwright test --project=webkit --debug

# Compare behavior between browsers
npx playwright test --project=chromium --debug
npx playwright test --project=webkit --debug
```

## Summary

### Debugging Tools

1. **VS Code Extension** - Primary debugging tool
2. **Playwright Inspector** - GUI tool for stepping through tests
3. **Browser DevTools** - Deep inspection and console access
4. **Trace Viewer** - Post-mortem analysis
5. **Verbose Logging** - API-level debugging

### Key Features

- **Breakpoints** - Pause execution at specific points
- **Live editing** - Modify locators during debugging
- **Pick locator** - Generate locators from browser
- **Actionability logs** - See what Playwright checked
- **Step through** - Execute one action at a time
- **Console access** - Query selectors manually

### Debug Modes

- **VS Code debug mode** - Integrated debugging
- **`--debug` flag** - Opens Inspector
- **`PWDEBUG=console`** - Console access
- **`DEBUG=pw:api`** - Verbose logging
- **Headed mode** - See browser while testing

### Best Practices

1. Use VS Code extension as primary tool
2. Add `page.pause()` for strategic breakpoints
3. Use Inspector for locator refinement
4. Use DevTools for deep investigation
5. Use Trace Viewer for post-mortem
6. Debug on multiple browsers
7. Use verbose logging for API issues

## Related Topics

- VS Code Extension
- Playwright Inspector
- Trace Viewer
- Locators
- Actionability
- Browser contexts
- Test configuration
- Error handling
