# Playwright Documentation Research - Locators

**Page:** Locators  
**URL:** https://playwright.dev/docs/locators  
**Research Date:** December 13, 2025

## Introduction

**Definition:** Locators are the central piece of Playwright's auto-waiting and retry-ability. In a nutshell, locators represent a way to find element(s) on the page at any moment.

## Quick Guide - Recommended Built-in Locators

1. **`page.getByRole()`** - Locate by explicit and implicit accessibility attributes
2. **`page.getByText()`** - Locate by text content
3. **`page.getByLabel()`** - Locate form control by associated label's text
4. **`page.getByPlaceholder()`** - Locate input by placeholder
5. **`page.getByAltText()`** - Locate element (usually image) by text alternative
6. **`page.getByTitle()`** - Locate element by title attribute
7. **`page.getByTestId()`** - Locate element by `data-testid` attribute (configurable)

**Example workflow:**
```typescript
await page.getByLabel('User Name').fill('John');
await page.getByLabel('Password').fill('secret-password');
await page.getByRole('button', { name: 'Sign in' }).click();
await expect(page.getByText('Welcome, John!')).toBeVisible();
```

## Locating Elements

### Core Principle

**Recommendation:** Prioritize user-facing attributes and explicit contracts such as `page.getByRole()`.

**Example:**
```typescript
await page.getByRole('button', { name: 'Sign in' }).click();
```

### Dynamic Element Location

**Key behavior:** Every time a locator is used for an action, an up-to-date DOM element is located in the page.

**Example:**
```typescript
const locator = page.getByRole('button', { name: 'Sign in' });
await locator.hover();  // Element located here
await locator.click();  // Element located again here
```

**Benefit:** If DOM changes between calls due to re-render, the new element corresponding to the locator will be used.

### Chaining Locators

**Capability:** All locator methods are available on `Locator` and `FrameLocator` classes, allowing chaining.

**Example:**
```typescript
const locator = page
    .frameLocator('#my-frame')
    .getByRole('button', { name: 'Sign in' });
await locator.click();
```

## Locate by Role

### Overview

**Purpose:** Reflects how users and assistive technology perceive the page.

**Best practice:** Pass accessible name to pinpoint exact element.

**Example:**
```typescript
await expect(page.getByRole('heading', { name: 'Sign up' })).toBeVisible();
await page.getByRole('checkbox', { name: 'Subscribe' }).check();
await page.getByRole('button', { name: /submit/i }).click();
```

### Supported Roles

**Includes:** buttons, checkboxes, headings, links, lists, tables, and many more

**Standards:** Follows W3C specifications for:
- ARIA role
- ARIA attributes
- Accessible name

**Note:** Many HTML elements like `<button>` have implicitly defined role recognized by role locator.

### Important Note

Role locators **do not replace** accessibility audits and conformance tests, but give early feedback about ARIA guidelines.

### When to Use

**Recommendation:** Prioritize role locators as it's the closest way to how users and assistive technology perceive the page.

## Locate by Label

### Overview

**Use case:** Most form controls have dedicated labels for interaction.

**Example:**
```typescript
await page.getByLabel('Password').fill('secret');
```

### When to Use

Use this locator when locating form fields.

## Locate by Placeholder

### Overview

**Use case:** Inputs with placeholder attribute hinting at expected value.

**Example:**
```typescript
await page
    .getByPlaceholder('name@example.com')
    .fill('playwright@microsoft.com');
```

### When to Use

Use when locating form elements that do not have labels but do have placeholder texts.

## Locate by Text

### Overview

**Capability:** Find element by text it contains. Can match by:
- Substring
- Exact string
- Regular expression

**Examples:**
```typescript
// Substring match
await expect(page.getByText('Welcome, John')).toBeVisible();

// Exact match
await expect(page.getByText('Welcome, John', { exact: true })).toBeVisible();

// Regular expression
await expect(page.getByText(/welcome, [A-Za-z]+$/i)).toBeVisible();
```

### Important Note

**Whitespace normalization:** Matching by text always normalizes whitespace, even with exact match:
- Turns multiple spaces into one
- Turns line breaks into spaces
- Ignores leading and trailing whitespace

### When to Use

**Recommendation:** Use text locators for non-interactive elements like `div`, `span`, `p`, etc.

**For interactive elements:** Use role locators for `button`, `a`, `input`, etc.

**Additional use:** Filter by text when finding particular item in list.

## Locate by Alt Text

### Overview

**Use case:** All images should have `alt` attribute describing the image.

**Example:**
```typescript
await page.getByAltText('playwright logo').click();
```

### When to Use

Use when element supports alt text such as `img` and `area` elements.

## Locate by Title

### Overview

**Use case:** Locate element with matching `title` attribute.

**Example:**
```typescript
await expect(page.getByTitle('Issues count')).toHaveText('25 issues');
```

### When to Use

Use when element has the `title` attribute.

## Locate by Test ID

### Overview

**Resilience:** Most resilient way of testing - test passes even if text or role changes.

**Best practice:** QAs and developers should define explicit test ids.

**Trade-off:** Not user-facing. If role or text value is important, consider user-facing locators.

**Example:**
```typescript
await page.getByTestId('directions').click();
```

### When to Use

Use when:
- Using test id methodology
- Can't locate by role or text

### Custom Test ID Attribute

**Default:** `data-testid`

**Configuration:**
```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    testIdAttribute: 'data-pw'
  }
});
```

**Usage:**
```html
<button data-pw="directions">Itinéraire</button>
```

```typescript
await page.getByTestId('directions').click();
```

## Locate by CSS or XPath

### Overview

**Capability:** Use `page.locator()` with CSS or XPath selectors.

**Auto-detection:** Playwright auto-detects if you omit `css=` or `xpath=` prefix.

**Examples:**
```typescript
await page.locator('css=button').click();
await page.locator('xpath=//button').click();

await page.locator('button').click();
await page.locator('//button').click();
```

### Problems

**Instability:** XPath and CSS selectors can be tied to DOM structure or implementation.

**Breaking changes:** Selectors break when DOM structure changes.

**Bad practice example:**
```typescript
await page.locator(
    '#tsf > div:nth-child(2) > div.A8SBwf > div.RNNXgb > div > div.a4bIc > input'
).click();
```

### When to Use

**Not recommended:** CSS and XPath not recommended as DOM can often change leading to non-resilient tests.

**Better alternatives:**
- Role locators (close to user perception)
- Test ids (explicit testing contract)

## Locate in Shadow DOM

### Overview

**Support:** All locators in Playwright by default work with elements in Shadow DOM.

**Exceptions:**
- Locating by XPath does not pierce shadow roots
- Closed-mode shadow roots not supported

**Example:**
```typescript
// Works seamlessly with Shadow DOM
await page.getByText('Details').click();
await page.locator('x-details', { hasText: 'Details' }).click();
await expect(page.locator('x-details')).toContainText('Details');
```

## Filtering Locators

### Filter by Text

**Method:** `locator.filter({ hasText: 'text' })`

**Behavior:** Searches for string somewhere inside element, possibly in descendant, case-insensitively.

**Example:**
```typescript
await page
    .getByRole('listitem')
    .filter({ hasText: 'Product 2' })
    .getByRole('button', { name: 'Add to cart' })
    .click();
```

**Regular expression:**
```typescript
await page
    .getByRole('listitem')
    .filter({ hasText: /Product 2/ })
    .getByRole('button', { name: 'Add to cart' })
    .click();
```

### Filter by Not Having Text

**Method:** `locator.filter({ hasNotText: 'text' })`

**Example:**
```typescript
// 5 in-stock items
await expect(page.getByRole('listitem').filter({ hasNotText: 'Out of stock' })).toHaveCount(5);
```

### Filter by Child/Descendant

**Method:** `locator.filter({ has: locator })`

**Capability:** Select elements that have or have not a descendant matching another locator.

**Example:**
```typescript
await page
    .getByRole('listitem')
    .filter({ has: page.getByRole('heading', { name: 'Product 2' }) })
    .getByRole('button', { name: 'Add to cart' })
    .click();
```

**Assertion:**
```typescript
await expect(page
    .getByRole('listitem')
    .filter({ has: page.getByRole('heading', { name: 'Product 2' }) }))
    .toHaveCount(1);
```

**Important:** Filtering locator must be relative to original locator and is queried starting with original locator match, not document root.

### Filter by Not Having Child/Descendant

**Method:** `locator.filter({ hasNot: locator })`

**Example:**
```typescript
await expect(page
    .getByRole('listitem')
    .filter({ hasNot: page.getByText('Product 2') }))
    .toHaveCount(1);
```

## Locator Operators

### Matching Inside a Locator

**Capability:** Chain methods to narrow down search to particular part of page.

**Example:**
```typescript
const product = page.getByRole('listitem').filter({ hasText: 'Product 2' });
await product.getByRole('button', { name: 'Add to cart' }).click();
await expect(product).toHaveCount(1);
```

**Chaining two locators:**
```typescript
const saveButton = page.getByRole('button', { name: 'Save' });
const dialog = page.getByTestId('settings-dialog');
await dialog.locator(saveButton).click();
```

### Matching Two Locators Simultaneously

**Method:** `locator.and(locator)`

**Purpose:** Narrow down existing locator by matching additional locator.

**Example:**
```typescript
const button = page.getByRole('button').and(page.getByTitle('Subscribe'));
```

### Matching One of Two Alternative Locators

**Method:** `locator.or(locator)`

**Purpose:** Create locator that matches any one or both of alternatives.

**Use case:** Target one of two or more elements when you don't know which one it will be.

**Example:**
```typescript
const newEmail = page.getByRole('button', { name: 'New' });
const dialog = page.getByText('Confirm security settings');
await expect(newEmail.or(dialog).first()).toBeVisible();
if (await dialog.isVisible())
  await page.getByRole('button', { name: 'Dismiss' }).click();
await newEmail.click();
```

**Note:** If both elements appear, "or" locator matches both, possibly throwing strictness violation. Use `locator.first()` to match only one.

### Matching Only Visible Elements

**Method:** `locator.filter({ visible: true })`

**Note:** Usually better to find more reliable way to uniquely identify element instead of checking visibility.

**Example:**
```typescript
// Finds only visible button
await page.locator('button').filter({ visible: true }).click();
```

## Lists

### Count Items in List

**Method:** `expect(locator).toHaveCount(number)`

**Example:**
```typescript
await expect(page.getByRole('listitem')).toHaveCount(3);
```

### Assert All Text in List

**Method:** `expect(locator).toHaveText(array)`

**Example:**
```typescript
await expect(page
    .getByRole('listitem'))
    .toHaveText(['apple', 'banana', 'orange']);
```

### Get Specific Item

#### Get by Text

```typescript
await page.getByText('orange').click();
```

#### Filter by Text

```typescript
await page
    .getByRole('listitem')
    .filter({ hasText: 'orange' })
    .click();
```

#### Get by Test ID

```typescript
await page.getByTestId('orange').click();
```

#### Get by Nth Item

**Methods:** `locator.first()`, `locator.last()`, `locator.nth(index)`

**Example:**
```typescript
const banana = await page.getByRole('listitem').nth(1);
```

**Caution:** Use with caution. Page might change, and locator will point to different element. Try to come up with unique locator that passes strictness criteria.

### Chaining Filters

**Purpose:** Select right element when elements have various similarities.

**Example:**
```typescript
const rowLocator = page.getByRole('listitem');

await rowLocator
    .filter({ hasText: 'Mary' })
    .filter({ has: page.getByRole('button', { name: 'Say goodbye' }) })
    .screenshot({ path: 'screenshot.png' });
```

## Rare Use Cases

### Do Something with Each Element in List

**Iterate with for...of:**
```typescript
for (const row of await page.getByRole('listitem').all())
  console.log(await row.textContent());
```

**Iterate with regular for loop:**
```typescript
const rows = page.getByRole('listitem');
const count = await rows.count();
for (let i = 0; i < count; ++i)
  console.log(await rows.nth(i).textContent());
```

### Evaluate in the Page

**Method:** `locator.evaluateAll()`

**Note:** Code runs in page, can call any DOM APIs.

**Example:**
```typescript
const rows = page.getByRole('listitem');
const texts = await rows.evaluateAll(
    list => list.map(element => element.textContent));
```

## Strictness

### Core Principle

**Locators are strict:** All operations on locators that imply some target DOM element will throw exception if more than one element matches.

**Example that throws:**
```typescript
// Throws error if more than one button
await page.getByRole('button').click();
```

**Example that works:**
```typescript
// Works fine with multiple elements
await page.getByRole('button').count();
```

### Opt-out from Strictness

**Methods:** `locator.first()`, `locator.last()`, `locator.nth()`

**Not recommended:** When page changes, Playwright may click on element you did not intend.

**Better approach:** Follow best practices to create locator that uniquely identifies target element.

## Summary of Key Concepts

### Locator Priority (Recommended Order)

1. **Role locators** - Most user-facing, reflects accessibility
2. **Label locators** - For form fields
3. **Placeholder locators** - For inputs without labels
4. **Text locators** - For non-interactive elements
5. **Test ID locators** - Most resilient, but not user-facing
6. **CSS/XPath** - Not recommended, breaks easily

### Key Behaviors

- **Auto-waiting** - Locators wait for elements to be actionable
- **Retry-ability** - Locators retry if elements not found
- **Dynamic location** - Elements located fresh for each action
- **Strictness** - Throws error if multiple elements match
- **Shadow DOM support** - Works with Shadow DOM by default

### Filtering Strategies

- Filter by text (has/hasNot)
- Filter by child/descendant (has/hasNot)
- Filter by visibility
- Chain multiple filters

### Locator Operators

- **`.and()`** - Match both conditions
- **`.or()`** - Match either condition
- **`.filter()`** - Narrow down selection
- **Chaining** - Combine multiple locators

### Best Practices

1. Use code generator to generate locators
2. Prioritize user-facing attributes
3. Avoid CSS/XPath when possible
4. Use test IDs when role/text not suitable
5. Create unique locators that pass strictness
6. Avoid `.nth()`, `.first()`, `.last()` when possible

## Related Topics to Explore

- Code generator
- Auto-waiting
- Assertions
- Actions
- Frames
- Shadow DOM
- Test IDs
- Accessibility
- Other locators
- Page object models
