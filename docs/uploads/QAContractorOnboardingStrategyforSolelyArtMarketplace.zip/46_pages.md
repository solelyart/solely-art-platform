# Playwright Documentation Research - Pages

**Page:** Pages  
**URL:** https://playwright.dev/docs/pages  
**Research Date:** December 14, 2025

## Pages

### Definition

**BrowserContext:** Each BrowserContext can have multiple pages.

**Page:** A Page refers to single tab or popup window within browser context.

**Purpose:** Should be used to navigate to URLs and interact with page content.

### Basic Usage

```typescript
// Create a page.
const page = await context.newPage();

// Navigate explicitly, similar to entering a URL in the browser.
await page.goto('http://example.com');

// Fill an input.
await page.locator('#search').fill('query');

// Navigate implicitly by clicking a link.
await page.locator('#submit').click();

// Expect a new url.
console.log(page.url());
```

## Multiple Pages

### Context Can Host Multiple Pages

**Capability:** Each browser context can host multiple pages (tabs).

### Page Behavior

**1. Active behavior:** Each page behaves like focused, active page.

**2. No need to bring to front:** Bringing page to front is not required.

**3. Context-level emulation:** Pages inside context respect context-level emulation, like:
- Viewport sizes
- Custom network routes
- Browser locale

### Creating Multiple Pages

```typescript
// Create two pages
const pageOne = await context.newPage();
const pageTwo = await context.newPage();

// Get pages of a browser context
const allPages = context.pages();
```

## Handling New Pages

### Page Event on Browser Context

**Purpose:** `page` event on browser contexts can be used to get new pages created in context.

**Use case:** Handle new pages opened by `target="_blank"` links.

### Wait for New Page Pattern

**Pattern:**
```typescript
// Start waiting for new page before clicking. Note no await.
const pagePromise = context.waitForEvent('page');
await page.getByText('open new tab').click();
const newPage = await pagePromise;

// Interact with the new page normally.
await newPage.getByRole('button').click();
console.log(await newPage.title());
```

**Key point:** Start waiting for new page **before** clicking (note no await).

### Unknown Trigger Pattern

**If action that triggers new page is unknown:**
```typescript
// Get all new pages (including popups) in the context
context.on('page', async page => {
  await page.waitForLoadState();
  console.log(await page.title());
});
```

## Handling Popups

### Popup Event

**Purpose:** If page opens pop-up (e.g. pages opened by `target="_blank"` links), can get reference by listening to `popup` event on page.

**Note:** Event emitted in addition to `browserContext.on('page')` event, but only for popups relevant to this page.

### Wait for Popup Pattern

**Pattern:**
```typescript
// Start waiting for popup before clicking. Note no await.
const popupPromise = page.waitForEvent('popup');
await page.getByText('open the popup').click();
const popup = await popupPromise;

// Interact with the new popup normally.
await popup.getByRole('button').click();
console.log(await popup.title());
```

**Key point:** Start waiting for popup **before** clicking (note no await).

### Unknown Trigger Pattern

**If action that triggers popup is unknown:**
```typescript
// Get all popups when they open
page.on('popup', async popup => {
  await popup.waitForLoadState();
  console.log(await popup.title());
});
```

## Best Practices

### 1. Wait for New Page Before Action

**✅ Good:**
```typescript
const pagePromise = context.waitForEvent('page');
await page.click('a[target="_blank"]');
const newPage = await pagePromise;
```

**❌ Bad:**
```typescript
await page.click('a[target="_blank"]');
const newPage = await context.waitForEvent('page'); // May miss event
```

### 2. Wait for Load State

**Pattern:**
```typescript
const newPage = await pagePromise;
await newPage.waitForLoadState('domcontentloaded');
// Now interact with page
```

### 3. Close Pages When Done

**Pattern:**
```typescript
const newPage = await pagePromise;
// ... interact with page
await newPage.close();
```

### 4. Use Popup Event for Popups

**Pattern:**
```typescript
// Use popup event instead of page event for popups
const popup = await page.waitForEvent('popup');
```

**Benefit:** Only captures popups relevant to this page.

### 5. Get All Pages

**Pattern:**
```typescript
const allPages = context.pages();
console.log(`Total pages: ${allPages.length}`);
```

## Common Use Cases

### Use Case 1: Handle New Tab

```typescript
test('open link in new tab', async ({ page, context }) => {
  await page.goto('/');
  
  const pagePromise = context.waitForEvent('page');
  await page.getByRole('link', { name: 'Open in New Tab' }).click();
  const newPage = await pagePromise;
  
  await newPage.waitForLoadState();
  expect(await newPage.title()).toBe('New Tab Page');
  
  await newPage.close();
});
```

### Use Case 2: Handle Popup Window

```typescript
test('handle popup window', async ({ page }) => {
  await page.goto('/');
  
  const popupPromise = page.waitForEvent('popup');
  await page.getByRole('button', { name: 'Open Popup' }).click();
  const popup = await popupPromise;
  
  await popup.waitForLoadState();
  await popup.getByRole('button', { name: 'Accept' }).click();
  
  await popup.close();
});
```

### Use Case 3: Multiple Pages Interaction

```typescript
test('work with multiple pages', async ({ context }) => {
  const page1 = await context.newPage();
  const page2 = await context.newPage();
  
  await page1.goto('/page1');
  await page2.goto('/page2');
  
  // Interact with page1
  await page1.getByRole('button').click();
  
  // Interact with page2
  await page2.getByRole('button').click();
  
  // Get all pages
  const allPages = context.pages();
  expect(allPages).toHaveLength(2);
  
  await page1.close();
  await page2.close();
});
```

### Use Case 4: Handle Unknown New Page Trigger

```typescript
test('handle any new page', async ({ page, context }) => {
  const newPages: Page[] = [];
  
  context.on('page', async newPage => {
    await newPage.waitForLoadState();
    newPages.push(newPage);
  });
  
  await page.goto('/');
  // Some action that might open new pages
  await page.evaluate(() => {
    window.open('/page1');
    window.open('/page2');
  });
  
  await page.waitForTimeout(1000);
  expect(newPages).toHaveLength(2);
});
```

### Use Case 5: Switch Between Pages

```typescript
test('switch between pages', async ({ context }) => {
  const page1 = await context.newPage();
  const page2 = await context.newPage();
  
  await page1.goto('/dashboard');
  await page2.goto('/settings');
  
  // Work on page1
  await page1.getByLabel('Name').fill('Test');
  
  // Switch to page2
  await page2.getByRole('button', { name: 'Save' }).click();
  
  // Back to page1
  await page1.getByRole('button', { name: 'Submit' }).click();
  
  await page1.close();
  await page2.close();
});
```

## Use Cases for Solely Art Platform

### Example 1: Artist Profile Opens in New Tab

```typescript
test('open artist profile in new tab', async ({ page, context }) => {
  await page.goto('/artists');
  
  const pagePromise = context.waitForEvent('page');
  await page.getByRole('link', { name: 'View Profile' }).click({ 
    modifiers: ['Meta'] // Cmd/Ctrl+Click
  });
  const artistPage = await pagePromise;
  
  await artistPage.waitForLoadState();
  expect(await artistPage.title()).toContain('Artist Profile');
  
  // Interact with artist page
  await artistPage.getByRole('button', { name: 'Book Now' }).click();
  
  await artistPage.close();
});
```

### Example 2: Payment Popup Window

```typescript
test('handle payment popup', async ({ page }) => {
  await page.goto('/checkout');
  
  const popupPromise = page.waitForEvent('popup');
  await page.getByRole('button', { name: 'Pay with Card' }).click();
  const paymentPopup = await popupPromise;
  
  await paymentPopup.waitForLoadState();
  
  // Fill payment details in popup
  await paymentPopup.getByLabel('Card Number').fill('4242424242424242');
  await paymentPopup.getByLabel('Expiry').fill('12/25');
  await paymentPopup.getByLabel('CVC').fill('123');
  await paymentPopup.getByRole('button', { name: 'Submit' }).click();
  
  // Wait for popup to close
  await paymentPopup.waitForEvent('close');
  
  // Verify payment success on main page
  await expect(page.getByText('Payment successful')).toBeVisible();
});
```

### Example 3: Compare Multiple Artists

```typescript
test('compare artists in multiple tabs', async ({ context }) => {
  const artist1Page = await context.newPage();
  const artist2Page = await context.newPage();
  
  await artist1Page.goto('/artist/123');
  await artist2Page.goto('/artist/456');
  
  // Get info from artist 1
  const artist1Name = await artist1Page.getByRole('heading').textContent();
  const artist1Price = await artist1Page.locator('.price').textContent();
  
  // Get info from artist 2
  const artist2Name = await artist2Page.getByRole('heading').textContent();
  const artist2Price = await artist2Page.locator('.price').textContent();
  
  // Compare
  console.log(`Artist 1: ${artist1Name} - ${artist1Price}`);
  console.log(`Artist 2: ${artist2Name} - ${artist2Price}`);
  
  await artist1Page.close();
  await artist2Page.close();
});
```

### Example 4: Terms and Conditions Popup

```typescript
test('accept terms in popup', async ({ page }) => {
  await page.goto('/signup');
  
  const popupPromise = page.waitForEvent('popup');
  await page.getByRole('link', { name: 'View Terms' }).click();
  const termsPopup = await popupPromise;
  
  await termsPopup.waitForLoadState();
  
  // Read terms
  const termsText = await termsPopup.locator('.terms-content').textContent();
  expect(termsText).toContain('Terms and Conditions');
  
  await termsPopup.close();
  
  // Accept terms on main page
  await page.getByLabel('I accept the terms').check();
  await page.getByRole('button', { name: 'Sign Up' }).click();
});
```

### Example 5: Share Artist Profile

```typescript
test('share artist profile opens new window', async ({ page, context }) => {
  await page.goto('/artist/123');
  
  const pagePromise = context.waitForEvent('page');
  await page.getByRole('button', { name: 'Share on Twitter' }).click();
  const twitterPage = await pagePromise;
  
  await twitterPage.waitForLoadState();
  expect(twitterPage.url()).toContain('twitter.com');
  
  // Verify share text
  const shareText = await twitterPage.locator('textarea').inputValue();
  expect(shareText).toContain('Check out this artist');
  
  await twitterPage.close();
});
```

### Example 6: Multi-Page Booking Flow

```typescript
test('booking flow across multiple pages', async ({ context }) => {
  const searchPage = await context.newPage();
  const artistPage = await context.newPage();
  const checkoutPage = await context.newPage();
  
  // Search for artists
  await searchPage.goto('/search');
  await searchPage.getByLabel('Location').fill('New York');
  await searchPage.getByRole('button', { name: 'Search' }).click();
  
  // View artist details
  const artistId = await searchPage.locator('.artist-card').first().getAttribute('data-id');
  await artistPage.goto(`/artist/${artistId}`);
  await artistPage.getByRole('button', { name: 'Book Now' }).click();
  
  // Complete checkout
  await checkoutPage.goto('/checkout');
  await checkoutPage.getByLabel('Date').fill('2025-01-15');
  await checkoutPage.getByRole('button', { name: 'Confirm' }).click();
  
  // Verify booking on search page
  await searchPage.goto('/my-bookings');
  await expect(searchPage.getByText('Booking confirmed')).toBeVisible();
  
  await searchPage.close();
  await artistPage.close();
  await checkoutPage.close();
});
```

## Advanced Patterns

### Pattern 1: Handle Multiple Popups

```typescript
test('handle multiple popups', async ({ page }) => {
  const popups: Page[] = [];
  
  page.on('popup', async popup => {
    await popup.waitForLoadState();
    popups.push(popup);
  });
  
  await page.goto('/');
  await page.getByRole('button', { name: 'Open Popups' }).click();
  
  await page.waitForTimeout(1000);
  expect(popups).toHaveLength(2);
  
  // Interact with each popup
  for (const popup of popups) {
    await popup.getByRole('button', { name: 'Close' }).click();
  }
});
```

### Pattern 2: Page Factory Pattern

```typescript
class PageFactory {
  constructor(private context: BrowserContext) {}
  
  async createPage(url: string): Promise<Page> {
    const page = await this.context.newPage();
    await page.goto(url);
    await page.waitForLoadState('domcontentloaded');
    return page;
  }
  
  async closeAllPages(): Promise<void> {
    const pages = this.context.pages();
    await Promise.all(pages.map(page => page.close()));
  }
}

test('use page factory', async ({ context }) => {
  const factory = new PageFactory(context);
  
  const page1 = await factory.createPage('/page1');
  const page2 = await factory.createPage('/page2');
  
  // ... interact with pages
  
  await factory.closeAllPages();
});
```

### Pattern 3: Page Manager

```typescript
class PageManager {
  private pages: Map<string, Page> = new Map();
  
  async openPage(name: string, url: string, context: BrowserContext): Promise<Page> {
    const page = await context.newPage();
    await page.goto(url);
    this.pages.set(name, page);
    return page;
  }
  
  getPage(name: string): Page | undefined {
    return this.pages.get(name);
  }
  
  async closeAll(): Promise<void> {
    for (const page of this.pages.values()) {
      await page.close();
    }
    this.pages.clear();
  }
}

test('use page manager', async ({ context }) => {
  const manager = new PageManager();
  
  await manager.openPage('search', '/search', context);
  await manager.openPage('artist', '/artist/123', context);
  
  const searchPage = manager.getPage('search');
  const artistPage = manager.getPage('artist');
  
  // ... interact with pages
  
  await manager.closeAll();
});
```

### Pattern 4: Wait for All Pages

```typescript
test('wait for all pages to load', async ({ context }) => {
  const page1 = await context.newPage();
  const page2 = await context.newPage();
  const page3 = await context.newPage();
  
  await Promise.all([
    page1.goto('/page1'),
    page2.goto('/page2'),
    page3.goto('/page3'),
  ]);
  
  await Promise.all([
    page1.waitForLoadState('networkidle'),
    page2.waitForLoadState('networkidle'),
    page3.waitForLoadState('networkidle'),
  ]);
  
  // All pages loaded
});
```

### Pattern 5: Conditional Popup Handling

```typescript
test('conditional popup handling', async ({ page }) => {
  let popupHandled = false;
  
  page.on('popup', async popup => {
    const url = popup.url();
    
    if (url.includes('payment')) {
      // Handle payment popup
      await popup.getByRole('button', { name: 'Pay' }).click();
    } else if (url.includes('terms')) {
      // Handle terms popup
      await popup.getByRole('button', { name: 'Accept' }).click();
    }
    
    popupHandled = true;
  });
  
  await page.goto('/');
  // ... trigger popup
  
  await page.waitForTimeout(1000);
  expect(popupHandled).toBe(true);
});
```

## Page Methods

### context.newPage()

**Purpose:** Create new page in context.

```typescript
const page = await context.newPage();
```

### context.pages()

**Purpose:** Get all pages in context.

```typescript
const allPages = context.pages();
```

### context.waitForEvent('page')

**Purpose:** Wait for new page to be created.

```typescript
const pagePromise = context.waitForEvent('page');
const newPage = await pagePromise;
```

### page.waitForEvent('popup')

**Purpose:** Wait for popup to be opened.

```typescript
const popupPromise = page.waitForEvent('popup');
const popup = await popupPromise;
```

### page.close()

**Purpose:** Close page.

```typescript
await page.close();
```

### page.url()

**Purpose:** Get current page URL.

```typescript
const url = page.url();
```

### page.title()

**Purpose:** Get page title.

```typescript
const title = await page.title();
```

## Troubleshooting

### Issue: New Page Event Missed

**Cause:** Waiting for page event after action.

**Solution:** Start waiting before action.

```typescript
// ✅ Correct
const pagePromise = context.waitForEvent('page');
await page.click('a[target="_blank"]');
const newPage = await pagePromise;

// ❌ Wrong
await page.click('a[target="_blank"]');
const newPage = await context.waitForEvent('page'); // May miss event
```

### Issue: Popup vs Page Event

**Question:** When to use `page.waitForEvent('popup')` vs `context.waitForEvent('page')`?

**Answer:**
- Use `popup` event for popups relevant to specific page
- Use `page` event for all new pages in context

### Issue: Page Not Loaded

**Cause:** Interacting with page before it's loaded.

**Solution:** Wait for load state.

```typescript
const newPage = await pagePromise;
await newPage.waitForLoadState('domcontentloaded');
// Now interact with page
```

### Issue: Too Many Pages Open

**Cause:** Not closing pages after use.

**Solution:** Close pages when done.

```typescript
const newPage = await pagePromise;
// ... interact with page
await newPage.close();
```

## Summary

### Key Concepts

**1. Page:** Single tab or popup window within browser context

**2. Multiple pages:** Context can host multiple pages

**3. Active behavior:** Each page behaves like focused, active page

**4. Context emulation:** Pages respect context-level emulation

**5. New page event:** `context.on('page')` for new pages

**6. Popup event:** `page.on('popup')` for popups

### Page Methods

- `context.newPage()` - Create new page
- `context.pages()` - Get all pages
- `context.waitForEvent('page')` - Wait for new page
- `page.waitForEvent('popup')` - Wait for popup
- `page.close()` - Close page
- `page.url()` - Get URL
- `page.title()` - Get title

### Best Practices

1. Wait for new page/popup before action
2. Wait for load state before interacting
3. Close pages when done
4. Use popup event for popups
5. Get all pages with context.pages()

### Common Patterns

- Handle new tab
- Handle popup window
- Multiple pages interaction
- Handle unknown new page trigger
- Switch between pages

## Related Topics

- Browser contexts
- Navigation
- Events
- Popups
- Tabs
- Page lifecycle
- Load states
