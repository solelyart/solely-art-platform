# Playwright Documentation Research - Continuous Integration

**Page:** Continuous Integration  
**URL:** https://playwright.dev/docs/ci  
**Research Date:** December 13, 2025

## Overview

Playwright tests can be executed in CI environments with comprehensive support for common CI providers. The documentation provides sample configurations and best practices for integrating Playwright into automated pipelines.

## Three-Step CI Setup Process

The fundamental setup for running Playwright tests in CI follows three essential steps:

**Step 1: Ensure CI agent can run browsers** - Use Playwright's Docker image for Linux agents or install dependencies using the CLI.

**Step 2: Install Playwright** - Install NPM packages and Playwright browsers with dependencies using `npm ci` followed by `npx playwright install --with-deps`.

**Step 3: Run tests** - Execute tests using `npx playwright test`.

## Workers Configuration for CI

Playwright recommends setting workers to "1" in CI environments to prioritize stability and reproducibility. Running tests sequentially ensures each test receives full system resources, avoiding potential conflicts. However, for powerful self-hosted CI systems, parallel tests can be enabled. For wider parallelization, sharding distributes tests across multiple CI jobs.

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  // Opt out of parallel tests on CI
  workers: process.env.CI ? 1 : undefined,
});
```

## GitHub Actions Integration

### Basic Push/Pull Request Configuration

Tests run on push or pull request events on main/master branches. The workflow installs dependencies, installs Playwright, runs tests, and creates HTML reports.

**Key workflow features:**
- Triggers on push and pull_request events
- Uses ubuntu-latest runner
- 60-minute timeout
- Installs Node.js LTS version
- Uploads playwright-report as artifact with 30-day retention
- Uses `actions/checkout@v5` and `actions/setup-node@v6`

### Sharded Execution

GitHub Actions supports distributing tests across multiple jobs for parallel execution. This involves configuring multiple jobs that each run a portion of the test suite, then merging HTML reports.

### Container-Based Execution

GitHub Actions supports running jobs in containers using the `jobs.<job_id>.container` option. This approach provides several benefits:

**Advantages:**
- Avoids polluting host environment with dependencies
- Ensures consistent environment across operating systems
- Ideal for screenshots and visual regression testing
- Uses official Playwright Docker image: `mcr.microsoft.com/playwright:v1.57.0-noble`

**Configuration note:** Container runs with `--user 1001` option for proper permissions.

### Deployment-Triggered Tests

Tests can be triggered after GitHub Deployment reaches success state. This pattern is used by services like Vercel to run end-to-end tests on deployed environments.

**Key features:**
- Listens for `deployment_status` events
- Checks if deployment state equals 'success'
- Sets `PLAYWRIGHT_TEST_BASE_URL` from deployment target URL
- Enables testing against actual deployed environment

### Fail-Fast Strategy

Large test suites can execute preliminary runs using the `--only-changed` flag to run likely-to-fail test files first. This provides faster feedback loops and reduces CI consumption during pull requests.

**Implementation details:**
- Uses `--only-changed=$GITHUB_BASE_REF` flag
- Analyzes suite dependency graph to detect affected test files
- Requires non-shallow checkout with `fetch-depth: 0`
- Runs changed tests first, then full suite
- Heuristic approach that might miss tests, so full suite must still run

## Docker Integration

Playwright provides a pre-built Docker image that can be used directly or as a reference for custom Docker definitions. The recommended Docker configuration ensures optimal performance.

## Azure Pipelines

### Platform-Specific Configuration

**Windows/macOS agents:** No additional configuration required beyond installing Playwright and running tests.

**Linux agents:** Can use Playwright Docker container with containerized job support, or use command line tools to install dependencies.

### Basic Pipeline Configuration

Uses `UseNode@1` task to install Node.js version 22, followed by dependency installation, Playwright browser installation, and test execution with `CI: 'true'` environment variable.

### Test Results Integration

Azure DevOps integration uses `PublishTestResults@2` task to publish JUnit format results. Configuration requires:
- JUnit reporter configured in playwright.config.ts
- Output file: `test-results/e2e-junit-results.xml`
- `PublishPipelineArtifact@1` task for uploading playwright-report
- Tasks run on `succeededOrFailed()` condition

### Sharded Execution

Azure Pipelines supports sharding through strategy matrix configuration. Tests can be distributed across multiple browsers (chromium, firefox, webkit) and multiple shards per browser (e.g., 1/3, 2/3, 3/3).

**Execution:** Uses `--project=$(project) --shard=$(shard)` flags to run specific test subsets.

### Containerized Execution

Azure Pipelines can run tests in Playwright Docker container by specifying container image in pool configuration.

## CircleCI

### Docker Executor Configuration

CircleCI uses docker executor definition to specify Playwright Docker image. Tests run similarly to GitHub Actions.

**Important note:** CircleCI medium tier has 2 cores. Playwright defaults to detected core count for workers. Overriding to higher numbers causes unnecessary timeouts and failures.

### Sharding Implementation

CircleCI sharding is zero-indexed, requiring adjustment to Playwright's one-indexed sharding. The configuration adds 1 to `CIRCLE_NODE_INDEX` before passing to `--shard` argument.

**Example:** With parallelism of 4, uses `SHARD="$((${CIRCLE_NODE_INDEX}+1))"` to calculate correct shard number.

## Jenkins

Jenkins supports Docker agents for pipelines. Configuration uses Playwright Docker image with standard pipeline stages for installing dependencies and running tests.

## Bitbucket Pipelines

Bitbucket Pipelines can use public Docker images as build environments. Configuration simply specifies Playwright Docker image at the pipeline level.

## GitLab CI

### Basic Configuration

GitLab CI uses stages with Playwright Docker image specified at the job level.

### Sharding with Parallel Keyword

GitLab supports the `parallel` keyword to split test jobs into multiple smaller jobs running in parallel. Jobs are named sequentially from `job_name 1/N` to `job_name N/N`.

**Implementation:** Uses `--shard=$CI_NODE_INDEX/$CI_NODE_TOTAL` to distribute tests.

### Matrix-Based Sharding

GitLab's `parallel:matrix` option enables running multiple jobs with different variable values. This allows combining multiple dimensions (e.g., 2 projects × 10 shards = 20 total jobs).

**Example configuration:** Tests can run across multiple browsers and multiple shards simultaneously using matrix variables for PROJECT and SHARD.

## Google Cloud Build

Google Cloud Build uses Playwright Docker image with `CI=true` environment variable set for proper CI behavior.

## Drone

Drone CI uses Docker pipeline type with Playwright image specified in the step configuration.

## Browser Caching

**Recommendation:** Caching browser binaries is NOT recommended. Cache restoration time is comparable to download time. Linux systems require installing OS dependencies that are not cacheable.

**If caching is still desired:** Cache browser binary directories against a hash of the Playwright version.

## Debugging in CI

### Browser Launch Debugging

The `DEBUG` environment variable outputs debug logs during execution. Setting `DEBUG=pw:browser` helps debug "Failed to launch browser" errors.

```bash
DEBUG=pw:browser npx playwright test
```

### Headed Mode Execution

By default, Playwright launches browsers in headless mode. On Linux agents, headed execution requires Xvfb (X Virtual Framebuffer).

**Xvfb availability:**
- Pre-installed in Playwright Docker image
- Pre-installed in GitHub Action
- Required for headed mode on Linux

**Usage:** Prefix command with `xvfb-run`:
```bash
xvfb-run npx playwright test
```

## Best Practices Identified

1. **Use Sequential Execution in CI** - Set workers to 1 for stability unless using powerful self-hosted systems
2. **Leverage Docker Images** - Use official Playwright Docker images for consistency
3. **Implement Sharding for Large Suites** - Distribute tests across multiple jobs for faster execution
4. **Use Container-Based Execution** - Isolate dependencies and ensure consistent environments
5. **Upload Test Artifacts** - Always upload reports and traces for debugging failed tests
6. **Set Appropriate Timeouts** - Use 60-minute timeout as baseline for test jobs
7. **Use Fail-Fast Strategies** - Run likely-to-fail tests first with --only-changed flag
8. **Avoid Browser Caching** - Download time is comparable to cache restoration
9. **Enable Debug Logging When Needed** - Use DEBUG environment variable for troubleshooting
10. **Test on Deployment** - Trigger tests after successful deployments to verify production-like environments

## CI Provider Support Summary

Playwright provides comprehensive support for major CI providers with detailed configuration examples for GitHub Actions, Azure Pipelines, CircleCI, Jenkins, Bitbucket Pipelines, GitLab CI, Google Cloud Build, and Drone.

## Related Topics to Explore

- Sharding documentation
- Docker image configuration
- Command line tools for dependency installation
- Reporter configuration for CI
- Parallelization strategies
- GitHub Actions workflow customization
- Test result publishing
- Artifact management
