# Playwright Documentation Research - Release Notes Summary

**Page:** Release notes  
**URL:** https://playwright.dev/docs/release-notes  
**Research Date:** December 13, 2025

## Overview

The release notes page provides comprehensive version history for Playwright, documenting new features, breaking changes, browser version updates, and deprecations. The page is extensive with detailed information about each release.

## Latest Version: 1.57

### Speedboard Feature

A new tab in the HTML reporter called "Speedboard" shows all executed tests sorted by slowness. This helps identify tests taking longer than expected and optimize test suite performance.

### Chrome for Testing Switch

Starting with version 1.57, Playwright switches from Chromium to using Chrome for Testing builds. This affects both headed and headless browsers. Key points:
- No functional changes expected from this switch
- New icon and title appear in the toolbar
- Arm64 Linux continues to use Chromium
- Users should file issues if unexpected behavior changes occur

### WebServer Wait Field

`testConfig.webServer` added a `wait` field that accepts a regular expression. Playwright waits until webserver logs match the pattern.

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  webServer: {
    command: 'npm run start',
    wait: {
      stdout: '/Listening on port (?<my_server_port>\\d+)/'
    },
  },
});
```

Named capture groups in the expression are provided as environment variables, useful for:
- Capturing varying ports of dev servers
- Waiting for service readiness without HTTP checks
- Using readiness messages from stdout or stderr

### Breaking Change: Page Accessibility Removal

After 3 years of deprecation, `Page#accessibility` was removed from the API. Users should use other libraries such as Axe for accessibility testing.

### Other Version 1.57 Features

- New property `testConfig.tag` adds tags to all tests in a run
- `worker.on('console')` event for JavaScript console API calls
- `locator.description()` returns locator description
- New `steps` option in `locator.click()` and `locator.dragTo()` for configuring mousemove events
- Service Worker network requests now reported and routable (Chromium only)
- Service Worker console messages dispatched through `worker.on('console')`

### Browser Versions (1.57)
- Chromium 143.0.7499.4
- Mozilla Firefox 142.0.1
- WebKit 26.0

## Version 1.56 - Playwright Test Agents

### Agent Definitions

Three custom agent definitions for guiding LLMs through Playwright test building:
- **planner** - Explores app and produces Markdown test plan
- **generator** - Transforms Markdown plan into Playwright Test files
- **healer** - Executes test suite and automatically repairs failing tests

```bash
# Generate agent files for each agentic loop
npx playwright init-agents --loop=vscode
npx playwright init-agents --loop=claude
npx playwright init-agents --loop=opencode
```

### New Methods and Features

- `page.consoleMessages()` and `page.pageErrors()` for retrieving recent console messages
- `page.requests()` for retrieving recent network requests
- `--test-list` and `--test-list-invert` for manual test specification
- HTML reporter option to disable "Copy prompt" button
- HTML reporter and UI Mode option to merge files
- UI Mode option for `--update-snapshots`
- UI Mode option to run only single worker

### Deprecations

`browserContext.on('backgroundpage')` event deprecated and will not be emitted. `browserContext.backgroundPages()` returns empty list.

### Other Features

- Aria snapshots render and compare input placeholder
- `PLAYWRIGHT_TEST` environment variable in worker processes

### Browser Versions (1.56)
- Chromium 141.0.7390.37
- Mozilla Firefox 142.0.1
- WebKit 26.0

## Version 1.55

### Key Features

- New property `testStepInfo.titlePath` returns full title path from test file
- Automatic `toBeVisible()` assertions in Codegen (configurable in settings)
- Dropped support for Chromium extension manifest v2
- Added support for Debian 13 "Trixie"

### Browser Versions (1.55)
- Chromium 140.0.7339.16
- Mozilla Firefox 141.0
- WebKit 26.0
- Tested against Google Chrome 139 and Microsoft Edge 139

## Version 1.54

### Cookie Partitioning

New cookie property `partitionKey` in `browserContext.cookies()` and `browserContext.addCookies()` for saving and restoring partitioned cookies (CHIPS support).

### HTML Reporter Enhancements

- New option `noSnippets` to disable code snippets
- New property `location` in test annotations showing where annotations were added

### Codegen Improvements

- New option `--user-data-dir` to reuse browsing state between sessions
- Removed `-gv` option (use `--grep-invert` instead)
- `npx playwright open` no longer opens test recorder (use `npx playwright codegen`)

### Node.js Support Changes

- Node.js 16 support removed
- Node.js 18 deprecated (will be removed in future)

### Browser Versions (1.54)
- Chromium 139.0.7258.5
- Mozilla Firefox 140.0.2
- WebKit 26.0
- Tested against Google Chrome 140 and Microsoft Edge 140

## Version 1.53

### Trace Viewer and Reporter Improvements

- New steps visualization in Trace Viewer and HTML reporter
- HTML reporter option to set custom test run title

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['html', { title: 'Custom test run #1028' }]]
});
```

### Snapshot and Locator Features

- New option `kind` in `testInfo.snapshotPath()` controls snapshot path template
- New method `locator.describe()` to describe locators for trace viewer and reports

```typescript
const button = page.getByTestId('btn-sub').describe('Subscribe button');
await button.click();
```

### CLI Enhancement

`npx playwright install --list` now lists all installed browsers, versions, and locations.

### Browser Versions (1.53)
- Chromium 138.0.7204.4
- Mozilla Firefox 139.0
- WebKit 18.5
- Tested against Google Chrome 137 and Microsoft Edge 137

## Key Patterns Across Releases

### Regular Browser Updates

Playwright consistently updates browser versions across Chromium, Firefox, and WebKit with each release, ensuring compatibility with latest web standards.

### Reporter Enhancements

Continuous improvements to HTML reporter and trace viewer with new visualization options, customization capabilities, and debugging features.

### Developer Experience Focus

Regular additions of convenience methods, better debugging tools, and workflow improvements (agents, codegen, UI mode enhancements).

### Breaking Changes Management

Deprecation warnings provided well in advance (e.g., 3 years for Page#accessibility), with clear migration paths.

### CI/CD Considerations

Features like sharding, parallel execution, and environment-specific configurations receive ongoing attention.

## Related Topics to Explore

- Canary releases for bleeding-edge features
- Migration guides for version upgrades
- Browser compatibility matrix
- Deprecation timeline
- Feature request process
- Breaking changes policy
