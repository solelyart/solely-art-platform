# Playwright Documentation Research - Actions

**Page:** Actions  
**URL:** https://playwright.dev/docs/input  
**Research Date:** December 13, 2025

## Overview

Playwright can interact with HTML Input elements including:
- Text inputs
- Checkboxes
- Radio buttons
- Select options
- Mouse clicks
- Type characters
- Keys and shortcuts
- Upload files
- Focus elements

## Text Input

### Using locator.fill()

**Easiest way** to fill out form fields.

**What it does:**
- Focuses the element
- Triggers `input` event with entered text

**Works with:**
- `<input>` elements
- `<textarea>` elements
- `[contenteditable]` elements

### Examples

```typescript
// Text input
await page.getByRole('textbox').fill('Peter');

// Date input
await page.getByLabel('Birth date').fill('2020-02-02');

// Time input
await page.getByLabel('Appointment time').fill('13:15');

// Local datetime input
await page.getByLabel('Local time').fill('2020-03-02T05:15');
```

## Checkboxes and Radio Buttons

### Using locator.setChecked()

**Easiest way** to check and uncheck checkboxes or radio buttons.

**Works with:**
- `input[type=checkbox]`
- `input[type=radio]`
- `[role=checkbox]` elements

### Examples

```typescript
// Check the checkbox
await page.getByLabel('I agree to the terms above').check();

// Assert the checked state
expect(page.getByLabel('Subscribe to newsletter')).toBeChecked();

// Select the radio button
await page.getByLabel('XL').check();
```

## Select Options

### Using locator.selectOption()

Selects one or multiple options in `<select>` element.

**Can specify:**
- Option `value`
- Option `label`
- Multiple options (array)

### Examples

```typescript
// Single selection matching the value or label
await page.getByLabel('Choose a color').selectOption('blue');

// Single selection matching the label
await page.getByLabel('Choose a color').selectOption({ label: 'Blue' });

// Multiple selected items
await page.getByLabel('Choose multiple colors').selectOption(['red', 'green', 'blue']);
```

## Mouse Click

Performs a simple human click.

### Click Variations

```typescript
// Generic click
await page.getByRole('button').click();

// Double click
await page.getByText('Item').dblclick();

// Right click
await page.getByText('Item').click({ button: 'right' });

// Shift + click
await page.getByText('Item').click({ modifiers: ['Shift'] });

// Ctrl + click on Windows and Linux
// Meta + click on macOS
await page.getByText('Item').click({ modifiers: ['ControlOrMeta'] });

// Hover over element
await page.getByText('Item').hover();

// Click the top left corner
await page.getByText('Item').click({ position: { x: 0, y: 0 } });
```

### Under the Hood

Pointer-related methods automatically:
1. Wait for element to be in DOM
2. Wait for it to become displayed (not empty, no `display:none`, no `visibility:hidden`)
3. Wait for it to stop moving (e.g., CSS transition finishes)
4. Scroll element into view
5. Wait for it to receive pointer events at action point (non-obscured)
6. Retry if element is detached during checks

### Forcing the Click

Sometimes apps use logic where hovering overlays element with another that intercepts click.

**Bypass actionability checks:**
```typescript
await page.getByRole('button').click({ force: true });
```

### Programmatic Click

If not interested in testing under real conditions, dispatch click event directly:

```typescript
await page.getByRole('button').dispatchEvent('click');
```

**Note:** Triggers `HTMLElement.click()` behavior via `locator.dispatchEvent()`.

## Type Characters

⚠️ **CAUTION:** Most of the time, use `locator.fill()`. Only type characters if there is **special keyboard handling** on the page.

### Using locator.pressSequentially()

Type character by character, like a real user with keyboard.

```typescript
// Press keys one by one
await page.locator('#area').pressSequentially('Hello World!');
```

**Emits all necessary keyboard events:**
- `keydown`
- `keyup`
- `keypress`

**Optional delay:** Simulate real user behavior with delay between key presses.

## Keys and Shortcuts

### Using locator.press()

Focuses selected element and produces single keystroke.

```typescript
// Hit Enter
await page.getByText('Submit').press('Enter');

// Dispatch Control+Right
await page.getByRole('textbox').press('Control+ArrowRight');

// Press $ sign on keyboard
await page.getByRole('textbox').press('$');
```

### Supported Key Names

Accepts logical key names from `keyboardEvent.key`:

```
Backquote, Minus, Equal, Backslash, Backspace, Tab, Delete, Escape,
ArrowDown, End, Enter, Home, Insert, PageDown, PageUp, ArrowRight,
ArrowUp, F1 - F12, Digit0 - Digit9, KeyA - KeyZ, etc.
```

**Alternative:** Specify single character like `"a"` or `"#"`

**Modification shortcuts supported:** `Shift, Control, Alt, Meta`

### Character Case Sensitivity

Single character is **case-sensitive**: `"a"` and `"A"` produce different results.

```typescript
// <input id=name>
await page.locator('#name').press('Shift+A');

// <input id=name>
await page.locator('#name').press('Shift+ArrowLeft');
```

### Shortcuts with Modifiers

```typescript
// Shortcuts like "Control+o" or "Control+Shift+T"
// Modifier is pressed and held while subsequent key is pressed
```

**Note:** Still need to specify capital `A` in `Shift-A` to produce capital character. `Shift-a` produces lowercase (as if `CapsLock` toggled).

## Upload Files

### Using locator.setInputFiles()

Select input files for upload.

**Requirements:**
- First argument points to `input` element with type `"file"`
- Multiple files can be passed in array
- Relative paths resolved relative to current working directory
- Empty array clears selected files

### Examples

```typescript
// Select one file
await page.getByLabel('Upload file').setInputFiles(path.join(__dirname, 'myfile.pdf'));

// Select multiple files
await page.getByLabel('Upload files').setInputFiles([
  path.join(__dirname, 'file1.txt'),
  path.join(__dirname, 'file2.txt'),
]);

// Select a directory
await page.getByLabel('Upload directory').setInputFiles(path.join(__dirname, 'mydir'));

// Remove all the selected files
await page.getByLabel('Upload file').setInputFiles([]);

// Upload buffer from memory
await page.getByLabel('Upload file').setInputFiles({
  name: 'file.txt',
  mimeType: 'text/plain',
  buffer: Buffer.from('this is test')
});
```

### Dynamic File Input

If input element is created dynamically, handle `page.on('filechooser')` event:

```typescript
// Start waiting for file chooser before clicking. Note no await.
const fileChooserPromise = page.waitForEvent('filechooser');
await page.getByLabel('Upload file').click();
const fileChooser = await fileChooserPromise;
await fileChooser.setFiles(path.join(__dirname, 'myfile.pdf'));
```

## Focus Element

### Using locator.focus()

For dynamic pages that handle focus events.

```typescript
await page.getByLabel('Password').focus();
```

## Drag and Drop

### Using locator.dragTo()

Performs drag & drop operation automatically.

**What it does:**
1. Hover element that will be dragged
2. Press left mouse button
3. Move mouse to element that will receive drop
4. Release left mouse button

```typescript
await page.locator('#item-to-be-dragged').dragTo(page.locator('#item-to-drop-at'));
```

### Dragging Manually

For precise control, use lower-level methods:

```typescript
await page.locator('#item-to-be-dragged').hover();
await page.mouse.down();
await page.locator('#item-to-drop-at').hover();
await page.mouse.up();
```

**Note:** If page relies on `dragover` event, need **at least two mouse moves** to trigger it in all browsers.

**Sequence for reliable dragover:**
1. Hover drag element
2. Mouse down
3. Hover drop element
4. Hover drop element second time
5. Mouse up

## Scrolling

### Automatic Scrolling

**Most of the time, Playwright automatically scrolls** before actions.

```typescript
// Scrolls automatically so that button is visible
await page.getByRole('button').click();
```

**No explicit scrolling needed.**

### Manual Scrolling

Rare cases where manual scrolling needed:
- Force "infinite list" to load more elements
- Position page for specific screenshot

**Most reliable way:** Find element to make visible and scroll into view.

```typescript
// Scroll the footer into view, forcing an "infinite list" to load more content
await page.getByText('Footer text').scrollIntoViewIfNeeded();
```

### Precise Scroll Control

Use `mouse.wheel()` or `locator.evaluate()`:

```typescript
// Position the mouse and scroll with the mouse wheel
await page.getByTestId('scrolling-container').hover();
await page.mouse.wheel(0, 10);

// Alternatively, programmatically scroll a specific element
await page.getByTestId('scrolling-container').evaluate(e => e.scrollTop += 100);
```

## Best Practices

### 1. Use locator.fill() for Text Input

Preferred over typing character by character.

### 2. Use Semantic Locators

```typescript
page.getByRole('button')
page.getByLabel('Email')
```

### 3. Let Playwright Auto-Scroll

Don't manually scroll unless necessary.

### 4. Use Actionability Checks

Don't force clicks unless you have a specific reason.

### 5. Handle Dynamic File Inputs

Use `waitForEvent('filechooser')` for dynamic inputs.

### 6. Use Appropriate Click Methods

- `click()` for single click
- `dblclick()` for double click
- `click({ button: 'right' })` for right click

### 7. Use Modifiers for Keyboard Shortcuts

```typescript
click({ modifiers: ['Shift'] })
press('Control+ArrowRight')
```

### 8. Upload from Memory When Needed

```typescript
setInputFiles({ name, mimeType, buffer })
```

### 9. Use dragTo() for Simple Drag & Drop

Only use manual methods when precise control needed.

### 10. Specify Position for Precise Clicks

```typescript
click({ position: { x: 0, y: 0 } })
```

## Related Topics to Explore

- Locators
- Auto-waiting
- Actionability
- Assertions
- Keyboard events
- Mouse events
- File uploads
- Drag and drop
- Scrolling behavior
- Focus management
