# Playwright Documentation Research - Trace Viewer

**Page:** Trace viewer  
**URL:** https://playwright.dev/docs/trace-viewer-intro  
**Research Date:** December 13, 2025

## Overview

Playwright Trace Viewer is a GUI tool that enables exploration of recorded Playwright traces from test executions. It provides the ability to navigate back and forward through each action of a test and visually observe what occurred during each action.

## Core Concept

A trace is a complete recording of a test execution that captures:
- Every action performed
- Page state before and after each action
- Network activity
- Console logs
- Errors
- DOM snapshots
- Screenshots

## Recording Traces

### Default Configuration

By default, the `playwright.config` file includes configuration to create a `trace.zip` file for each test:

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  retries: process.env.CI ? 2 : 0, // set to 2 when running on CI
  use: {
    trace: 'on-first-retry', // record traces on first retry of each test
  },
});
```

### Trace Recording Strategy

**Default Behavior:**
- Traces run `on-first-retry` - recorded on the first retry of a failed test
- Retries are set to 2 when running on CI
- Retries are set to 0 locally
- This means traces are recorded on the first retry but not on the initial run or second retry

**Rationale:**
- Optimizes for CI environments where debugging failed tests is critical
- Avoids overhead of recording traces for passing tests
- Provides debugging information exactly when needed

### Local Trace Recording

Traces are normally run in Continuous Integration (CI) environments. For local development, UI Mode is recommended. However, traces can be forced locally:

```bash
npx playwright test --trace on
```

## Accessing Traces

### Via HTML Report

The HTML report provides multiple ways to access traces:

```bash
npx playwright show-report
```

**Access Methods:**

1. **Direct Access:** Click the trace icon next to the test file name
2. **Detailed View:** 
   - Click to open detailed test view
   - Scroll to the 'Traces' tab
   - Click the trace screenshot to open

### HTML Report Features

The HTML report displays:
- All tests that have been run
- Browser information for each test
- Test execution duration
- Filtering options: passed, failed, flaky, or skipped tests
- Search functionality for specific tests
- Detailed view with errors, test steps, and traces

## Trace Viewer Capabilities

### Navigation Features

**Timeline Navigation:**
- Click through each action sequentially
- Hover over the timeline to preview actions
- See page state before and after each action

### Inspection Tools

**Available Information:**
- **Log:** Complete action log
- **Source:** Test source code
- **Network:** Network requests and responses
- **Errors:** Error messages and stack traces
- **Console:** Console output during test execution

### DOM Snapshot

The trace viewer creates a full DOM snapshot enabling:
- Complete interaction with the recorded page state
- Browser DevTools access for inspection
- HTML, CSS, and JavaScript examination
- Element inspection at any point in the test

### Visual Analysis

- Screenshots at each step
- Visual representation of page state
- Ability to see exactly what the test "saw"
- Timeline visualization of test execution

## Use Cases

### CI/CD Debugging
- Primary use case for trace recording
- Automatically captures failed test information
- Enables post-mortem analysis without reproducing failures
- Provides complete context for debugging

### Test Failure Investigation
- Understand why a test failed
- See exact page state at failure point
- Review network activity leading to failure
- Examine console errors and logs

### Test Development
- While UI Mode is preferred for local development
- Traces can supplement development workflow
- Useful for sharing test behavior with team members

## Integration with Other Tools

### UI Mode
- UI Mode is recommended for local development instead of traces
- Provides live debugging experience
- Traces are better suited for post-execution analysis

### HTML Reporter
- Traces are accessed through HTML Reporter
- Seamless integration between test results and trace viewing
- Filtering and search capabilities help locate relevant traces

## Best Practices Identified

1. **Use Default Configuration for CI** - `on-first-retry` balances debugging needs with performance
2. **Prefer UI Mode Locally** - Better developer experience for active development
3. **Review Traces for Flaky Tests** - Traces help identify timing and state issues
4. **Share Traces for Collaboration** - trace.zip files can be shared with team members
5. **Inspect Network Activity** - Network tab reveals API and resource loading issues
6. **Use DOM Snapshots** - Interact with page state to understand test behavior
7. **Leverage Timeline** - Visual timeline helps identify where tests diverge from expectations

## Performance Considerations

### Recording Overhead
- Traces add overhead to test execution
- `on-first-retry` minimizes impact on passing tests
- Only failed tests incur trace recording cost

### Storage
- Traces are saved as trace.zip files
- Can accumulate in CI environments
- Consider retention policies for trace artifacts

## Related Topics to Explore

- Detailed Trace Viewer guide
- HTML Reporter configuration
- UI Mode features
- CI/CD integration
- Trace recording options
- Reporter customization
- Debugging strategies
