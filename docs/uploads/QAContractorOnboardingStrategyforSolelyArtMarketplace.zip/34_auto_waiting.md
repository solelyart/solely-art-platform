# Playwright Documentation Research - Auto-waiting

**Page:** Auto-waiting  
**URL:** https://playwright.dev/docs/actionability  
**Research Date:** December 13, 2025

## Introduction

Playwright performs a range of **actionability checks** on elements before making actions to ensure these actions behave as expected.

**Key mechanism:** It **auto-waits** for all relevant checks to pass and only then performs the requested action.

**Failure handling:** If required checks do not pass within the given `timeout`, action fails with `TimeoutError`.

## Example: locator.click()

For `locator.click()`, Playwright will ensure that:

1. Locator resolves to **exactly one element**
2. Element is **Visible**
3. Element is **Stable** (not animating or completed animation)
4. Element **Receives Events** (not obscured by other elements)
5. Element is **Enabled**

## Complete List of Actionability Checks

### Actionability Checks Matrix

| Action | Visible | Stable | Receives Events | Enabled | Editable |
|--------|---------|--------|-----------------|---------|----------|
| `locator.check()` | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes | - |
| `locator.click()` | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes | - |
| `locator.dblclick()` | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes | - |
| `locator.setChecked()` | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes | - |
| `locator.tap()` | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes | - |
| `locator.uncheck()` | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes | - |
| `locator.hover()` | ✅ Yes | ✅ Yes | ✅ Yes | - | - |
| `locator.dragTo()` | ✅ Yes | ✅ Yes | ✅ Yes | - | - |
| `locator.screenshot()` | ✅ Yes | ✅ Yes | - | - | - |
| `locator.fill()` | ✅ Yes | - | - | ✅ Yes | ✅ Yes |
| `locator.clear()` | ✅ Yes | - | - | ✅ Yes | ✅ Yes |
| `locator.selectOption()` | ✅ Yes | - | - | ✅ Yes | - |
| `locator.selectText()` | ✅ Yes | - | - | - | - |
| `locator.scrollIntoViewIfNeeded()` | - | ✅ Yes | - | - | - |
| `locator.blur()` | - | - | - | - | - |
| `locator.dispatchEvent()` | - | - | - | - | - |
| `locator.focus()` | - | - | - | - | - |
| `locator.press()` | - | - | - | - | - |
| `locator.pressSequentially()` | - | - | - | - | - |
| `locator.setInputFiles()` | - | - | - | - | - |

### Key Observations

**Most strict checks:** `locator.check()`, `locator.click()`, `locator.dblclick()`, `locator.setChecked()`, `locator.tap()`, `locator.uncheck()`
- All 4 checks: Visible, Stable, Receives Events, Enabled

**Moderate checks:** `locator.hover()`, `locator.dragTo()`
- 3 checks: Visible, Stable, Receives Events

**Input-specific checks:** `locator.fill()`, `locator.clear()`
- Checks: Visible, Enabled, Editable (no Stable or Receives Events)

**Minimal checks:** `locator.blur()`, `locator.dispatchEvent()`, `locator.focus()`, `locator.press()`, `locator.pressSequentially()`, `locator.setInputFiles()`
- No actionability checks

## Forcing Actions

Some actions like `locator.click()` support **`force` option** that disables non-essential actionability checks.

**Example:** Passing truthy `force` to `locator.click()` method will **not check** that the target element actually receives click events.

```typescript
// Force click without checking if element receives events
await locator.click({ force: true });
```

**Use case:** When you know the element is clickable but Playwright's checks are too strict.

**Warning:** Use sparingly, as it bypasses safety checks.

## Assertions

Playwright includes **auto-retrying assertions** that remove flakiness by waiting until the condition is met, similarly to auto-waiting before actions.

### Complete List of Auto-Retrying Assertions

| Assertion | Description |
|-----------|-------------|
| `expect(locator).toBeAttached()` | Element is attached |
| `expect(locator).toBeChecked()` | Checkbox is checked |
| `expect(locator).toBeDisabled()` | Element is disabled |
| `expect(locator).toBeEditable()` | Element is editable |
| `expect(locator).toBeEmpty()` | Container is empty |
| `expect(locator).toBeEnabled()` | Element is enabled |
| `expect(locator).toBeFocused()` | Element is focused |
| `expect(locator).toBeHidden()` | Element is not visible |
| `expect(locator).toBeInViewport()` | Element intersects viewport |
| `expect(locator).toBeVisible()` | Element is visible |
| `expect(locator).toContainText()` | Element contains text |
| `expect(locator).toHaveAttribute()` | Element has a DOM attribute |
| `expect(locator).toHaveClass()` | Element has a class property |
| `expect(locator).toHaveCount()` | List has exact number of children |
| `expect(locator).toHaveCSS()` | Element has CSS property |
| `expect(locator).toHaveId()` | Element has an ID |
| `expect(locator).toHaveJSProperty()` | Element has a JavaScript property |
| `expect(locator).toHaveText()` | Element matches text |
| `expect(locator).toHaveValue()` | Input has a value |
| `expect(locator).toHaveValues()` | Select has options selected |
| `expect(page).toHaveTitle()` | Page has a title |
| `expect(page).toHaveURL()` | Page has a URL |
| `expect(response).toBeOK()` | Response has an OK status |

**Key benefit:** These assertions automatically retry until the condition is met or timeout is reached, eliminating flaky tests.

## Actionability Check Definitions

### Visible

**Definition:** Element is considered **visible** when it has **non-empty bounding box** and does not have `visibility:hidden` computed style.

**Important notes:**

1. **Elements of zero size are NOT considered visible**
   - Even if they exist in DOM, zero-size elements fail visibility check

2. **Elements with `display:none` are NOT considered visible**
   - Hidden elements cannot be interacted with

3. **Elements with `opacity:0` ARE considered visible**
   - Transparent elements are still considered visible for actionability

**Example:**
```typescript
// This will wait until element has non-zero size and is not visibility:hidden
await page.locator('.button').click();
```

### Stable

**Definition:** Element is considered **stable** when it has maintained the **same bounding box** for at least **two consecutive animation frames**.

**Purpose:** Ensures element is not animating or has completed animation before interaction.

**Why it matters:** Clicking on a moving element can result in missed clicks or clicks on wrong elements.

**Example:**
```typescript
// Playwright waits for button to stop animating before clicking
await page.locator('.animated-button').click();
```

### Enabled

**Definition:** Element is considered **enabled** when it is **not disabled**.

**Element is disabled when:**

1. It is a `<button>`, `<select>`, `<input>`, `<textarea>`, `<option>` or `<optgroup>` with a `[disabled]` attribute

2. It is a `<button>`, `<select>`, `<input>`, `<textarea>`, `<option>` or `<optgroup>` that is a part of a `<fieldset>` with a `[disabled]` attribute

3. It is a descendant of an element with `[aria-disabled=true]` attribute

**Example:**
```typescript
// Playwright waits until button is enabled before clicking
await page.locator('button[type="submit"]').click();
```

### Editable

**Definition:** Element is considered **editable** when it is **enabled** and is **not readonly**.

**Element is readonly when:**

1. It is a `<select>`, `<input>` or `<textarea>` with a `[readonly]` attribute

2. It has an `[aria-readonly=true]` attribute and an aria role that supports it

**Example:**
```typescript
// Playwright waits until input is both enabled and not readonly before filling
await page.locator('input[name="username"]').fill('testuser');
```

### Receives Events

**Definition:** Element is considered **receiving pointer events** when it is the **hit target** of the pointer event at the action point.

**Purpose:** Checks whether some other element (usually an overlay) will instead capture the click.

**Example scenario:** When clicking at point `(10, 10)`, Playwright checks whether some other element will capture the click at that exact position.

**Real-world example:**

Consider a scenario where Playwright will click "Sign Up" button regardless of when the `locator.click()` call was made:

1. Page is checking that user name is unique and "Sign Up" button is disabled
2. After checking with server, the disabled "Sign Up" button is replaced with another one that is now enabled

Playwright automatically waits for the button to be enabled and receive events before clicking.

## Best Practices

### 1. Trust Auto-Waiting

Don't add manual waits (`sleep`) before actions. Playwright's auto-waiting is more reliable.

**Bad:**
```typescript
await page.waitForTimeout(1000);
await page.locator('.button').click();
```

**Good:**
```typescript
await page.locator('.button').click();
```

### 2. Use Auto-Retrying Assertions

Use Playwright's built-in assertions instead of manual checks.

**Bad:**
```typescript
const text = await page.locator('.status').textContent();
expect(text).toBe('Success');
```

**Good:**
```typescript
await expect(page.locator('.status')).toHaveText('Success');
```

### 3. Increase Timeout for Slow Operations

If an operation legitimately takes longer, increase timeout instead of adding waits.

```typescript
await page.locator('.slow-button').click({ timeout: 60000 });
```

### 4. Use Force Option Sparingly

Only use `force: true` when you're certain the element is actionable but Playwright's checks are too strict.

```typescript
// Use only when necessary
await page.locator('.special-button').click({ force: true });
```

### 5. Understand Which Checks Apply

Know which actionability checks apply to each action to debug issues effectively.

### 6. Wait for Animations to Complete

Let Playwright's stability check handle animations automatically.

### 7. Check for Overlays

If clicks are not working, check if an overlay is blocking the element (Receives Events check).

### 8. Verify Element State

Use assertions to verify element state before and after actions.

```typescript
await expect(page.locator('.button')).toBeEnabled();
await page.locator('.button').click();
await expect(page.locator('.status')).toHaveText('Clicked');
```

### 9. Handle Dynamic Content

Trust auto-waiting for dynamically loaded content.

```typescript
// Playwright waits for element to appear and be actionable
await page.locator('.dynamic-button').click();
```

### 10. Debug with Trace Viewer

Use trace viewer to see exactly which actionability checks failed.

```typescript
// Run with trace
npx playwright test --trace on
```

## Common Patterns

### Waiting for Element to Be Visible and Clickable

```typescript
// Playwright automatically waits for all checks
await page.locator('.submit-button').click();
```

### Waiting for Element to Be Enabled

```typescript
// Waits until button is enabled
await page.locator('button[type="submit"]').click();
```

### Waiting for Animation to Complete

```typescript
// Waits for element to be stable (animation complete)
await page.locator('.animated-element').click();
```

### Filling Input After It Becomes Editable

```typescript
// Waits for input to be visible, enabled, and editable
await page.locator('input[name="email"]').fill('test@example.com');
```

### Checking Checkbox After It Appears

```typescript
// Waits for checkbox to be visible, stable, receives events, and enabled
await page.locator('input[type="checkbox"]').check();
```

### Hovering Over Element

```typescript
// Waits for element to be visible, stable, and receive events
await page.locator('.menu-item').hover();
```

### Taking Screenshot of Stable Element

```typescript
// Waits for element to be visible and stable
await page.locator('.chart').screenshot({ path: 'chart.png' });
```

## Timeout Handling

### Default Timeout

Default timeout for actions is **30 seconds**.

### Setting Custom Timeout

```typescript
// Per action
await page.locator('.button').click({ timeout: 60000 });

// Per test
test.setTimeout(120000);

// Globally in config
export default defineConfig({
  timeout: 60000,
});
```

### Timeout Error

When actionability checks don't pass within timeout:

```
TimeoutError: locator.click: Timeout 30000ms exceeded.
=========================== logs ===========================
waiting for locator('.button')
  locator resolved to <button>...</button>
  attempting click action
  waiting for element to be visible, enabled and stable
  element is not visible - waiting...
```

## Related Topics to Explore

- Locators
- Assertions
- Timeouts
- Actions
- Test debugging
- Trace viewer
- Force option
- Element state
- Animation handling
- Overlay detection
