# Playwright Documentation Research - Service Workers

**Page:** Service Workers  
**URL:** https://playwright.dev/docs/service-workers-experimental  
**Research Date:** December 14, 2025  
**Status:** ✅ Complete (Previously 404, now documented from provided content)

## Overview

Service Workers are a browser-native technology that provides a way to handle network requests made by a page. They can act as a network proxy, enabling features like caching, offline experiences, and background synchronization. Playwright provides comprehensive support for testing applications that use Service Workers.

## Browser Support

⚠️ **Warning:** Service Workers are only supported on Chromium-based browsers in Playwright.

## Introduction to Service Workers

### What are Service Workers?

Service Workers provide a browser-native method of handling requests made by a page with the native Fetch API (`fetch`) along with other network-requested assets (like scripts, CSS, and images).

### Key Capabilities

- **Network Proxy:** Act as a network proxy between the page and the external network
- **Caching Logic:** Perform caching logic to improve performance
- **Offline Experience:** Provide users with an offline experience if the Service Worker adds a FetchEvent listener
- **Background Operations:** Handle background sync and push notifications

### Transparency

Many sites that use Service Workers simply use them as a transparent optimization technique. While users might notice a faster experience, the app's implementation is unaware of their existence. Running the app with or without Service Workers enabled appears functionally equivalent.

## General Network Mocking

📝 **Note:** If you're looking to do general network mocking, routing, and interception, please see the Network Guide first. Playwright provides built-in APIs for this use case that don't require Service Worker-specific knowledge. However, if you're interested in requests made by Service Workers themselves, the information below is relevant.

## Disabling Service Workers

Playwright allows you to disable Service Workers during testing to make tests more predictable and performant. However, if your actual page uses a Service Worker, the behavior might be different.

### Configuration

To disable Service Workers, set `testOptions.serviceWorkers` to `'block'` in your `playwright.config.ts`:

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    serviceWorkers: 'block' // or 'allow'
  },
});
```

### When to Disable

- **Most tests:** For tests that do not rely on Service Worker functionality
- **Predictability:** To make tests more predictable and deterministic
- **Performance:** To improve test execution speed
- **Isolation:** To isolate the application logic from caching behavior

### When to Enable

- **Offline functionality:** If your application has offline capabilities
- **Caching logic:** If you have complex caching logic to test
- **Background sync:** If your application uses background sync
- **Service Worker-specific features:** When testing features that depend on Service Workers

## Accessing Service Workers

### Listing Service Workers

You can use `browserContext.serviceWorkers()` to list the Service Workers currently active in the browser context.

### Waiting for Service Worker Registration

You can specifically watch for a Service Worker if you anticipate a page will trigger its registration:

```typescript
const serviceWorkerPromise = context.waitForEvent('serviceworker');
await page.goto('/example-with-a-service-worker.html');
const serviceworker = await serviceWorkerPromise;
```

## Waiting for Activation

The `browserContext.on('serviceworker')` event is fired **before** the Service Worker has taken control over the page. Therefore, before evaluating in the worker with `worker.evaluate()`, you should wait for its activation.

### Implementation-Agnostic Method

There are more idiomatic methods of waiting for a Service Worker to be activated, but the following is an implementation-agnostic method:

```typescript
await page.evaluate(async () => {
  const registration = await window.navigator.serviceWorker.getRegistration();
  if (registration.active?.state === 'activated')
    return;
  await new Promise(resolve => {
    window.navigator.serviceWorker.addEventListener('controllerchange', resolve);
  });
});
```

This code:
1. Gets the Service Worker registration
2. Checks if it's already activated
3. If not, waits for the `controllerchange` event

## Network Events and Routing

Any network request made by the Service Worker is reported through the `BrowserContext` object.

### Events Fired

The following events are fired for Service Worker requests:
- `browserContext.on('request')`
- `browserContext.on('requestfinished')`
- `browserContext.on('response')`
- `browserContext.on('requestfailed')`

### Routing

- `browserContext.route()` can intercept and route Service Worker requests
- `request.serviceWorker()` will be set to the Service Worker instance
- `request.frame()` will throw an exception for Service Worker requests

### Response Identification

For any network request made by the Page, method `response.fromServiceWorker()` returns `true` when the request was handled by a Service Worker's fetch handler.

## Example: Transparent Service Worker

Consider a simple Service Worker that fetches every request made by the page:

```javascript
// transparent-service-worker.js
self.addEventListener('fetch', event => {
  // actually make the request
  const responsePromise = fetch(event.request);
  // send it back to the page
  event.respondWith(responsePromise);
});

self.addEventListener('activate', event => {
  event.waitUntil(clients.claim());
});
```

### Network Event Flow

If `index.html` registers this Service Worker, and then fetches `data.json`, the following Request/Response events would be emitted:

| Event | Owner | URL | Routed | response.fromServiceWorker() |
| :--- | :--- | :--- | :--- | :--- |
| `browserContext.on('request')` | Frame | index.html | Yes | - |
| `page.on('request')` | Frame | index.html | Yes | - |
| `browserContext.on('request')` | Service Worker | transparent-service-worker.js | Yes | - |
| `browserContext.on('request')` | Service Worker | data.json | Yes | - |
| `browserContext.on('request')` | Frame | data.json | No | Yes |
| `page.on('request')` | Frame | data.json | No | Yes |

### Key Observations

Since the example Service Worker acts as a basic transparent "proxy":

1. **Two requests for data.json:** There are 2 `browserContext.on('request')` events for `data.json`:
   - One Frame-owned
   - One Service Worker-owned

2. **Routing behavior:** Only the Service Worker-owned request for the resource was routable via `browserContext.route()`

3. **Frame-owned requests not routable:** The Frame-owned events for `data.json` are not routeable, as they would not have even had the possibility to hit the external network since the Service Worker has a fetch handler registered

### Important Caution

⚠️ **Caution:** It's important to note that calling `request.frame()` or `response.frame()` will throw an exception if called on a Request/Response that has a non-null `request.serviceWorker()`.

## Routing Service Worker Requests Only

You can specifically route requests made by Service Workers by checking if `route.request().serviceWorker()` is not null:

```typescript
await context.route('**', async route => {
  if (route.request().serviceWorker()) {
    // NB: calling route.request().frame() here would THROW
    await route.fulfill({
      contentType: 'text/plain',
      status: 200,
      body: 'from sw',
    });
  } else {
    await route.continue();
  }
});
```

This pattern allows you to:
- Mock responses specifically for Service Worker requests
- Differentiate between page requests and Service Worker requests
- Test Service Worker behavior in isolation

## Known Limitations

### Service Worker Script Updates

Requests for updated Service Worker main script code currently cannot be routed.

**GitHub Issue:** [https://github.com/microsoft/playwright/issues/14711](https://github.com/microsoft/playwright/issues/14711)

This means:
- You cannot intercept requests for the Service Worker script itself
- Updates to the Service Worker code cannot be mocked
- Testing Service Worker updates requires actual script files

## Best Practices

### 1. Use `serviceWorkers: 'block'` for Most Tests

For tests that do not rely on Service Worker functionality, disabling them can make the tests more predictable and performant. This approach:
- Reduces complexity
- Improves test speed
- Eliminates caching-related flakiness

### 2. Isolate Service Worker Tests

Create a separate test suite for tests that require Service Workers to be enabled. This allows you to:
- Configure Service Workers only where needed
- Clearly identify which tests depend on Service Workers
- Manage different test configurations

Example:

```typescript
// playwright.config.ts
export default defineConfig({
  projects: [
    {
      name: 'chromium-no-sw',
      use: {
        ...devices['Desktop Chrome'],
        serviceWorkers: 'block',
      },
    },
    {
      name: 'chromium-with-sw',
      use: {
        ...devices['Desktop Chrome'],
        serviceWorkers: 'allow',
      },
    },
  ],
});
```

### 3. Wait for Activation

Always wait for the Service Worker to be active before interacting with it. This prevents race conditions and ensures the Service Worker is ready to handle requests.

### 4. Use `browserContext.route()` for Mocking

Use `browserContext.route()` to mock network requests made by the Service Worker. This allows you to:
- Test Service Worker behavior in isolation
- Simulate network conditions
- Validate caching logic

### 5. Check `request.serviceWorker()`

When routing requests, always check if `request.serviceWorker()` is not null to differentiate between page requests and Service Worker requests.

## Solely Art Platform Application

For the Solely Art Platform, Service Workers could be used to:

### 1. Provide an Offline Experience

Allow users to browse artwork and artist profiles even when they are offline. This could include:
- Caching artwork images
- Storing artist profiles
- Enabling offline browsing of previously viewed content

### 2. Improve Performance

Cache frequently accessed assets to reduce load times. This could include:
- Artwork thumbnails
- Artist profile images
- Static assets (CSS, JavaScript)
- API responses for frequently accessed data

### 3. Enable Background Sync

Allow users to upload artwork in the background, even if they lose their network connection. This could include:
- Queuing artwork uploads
- Syncing bookings when connection is restored
- Sending messages when back online

### Testing Strategy

When testing these features, it is crucial to:
1. **Enable Service Workers** in the test configuration
2. **Wait for activation** before running tests
3. **Test offline scenarios** by blocking network requests
4. **Validate caching logic** by inspecting cached responses
5. **Test background sync** by simulating network disconnection

## Summary

### Key Takeaways

- **Chromium-only:** Service Workers are only supported on Chromium-based browsers
- **Configuration:** Use `serviceWorkers: 'allow'` or `'block'` in playwright.config.ts
- **Wait for activation:** Always wait for Service Worker activation before interacting
- **Network events:** Service Worker requests are reported through BrowserContext
- **Routing:** Can route Service Worker requests using `browserContext.route()`
- **Identification:** Use `request.serviceWorker()` and `response.fromServiceWorker()`
- **Known limitation:** Cannot route requests for Service Worker script updates

### Related Topics

- Network Guide
- Mock APIs
- API Testing
- Browsers
- Best Practices
- Configuration

### Implementation Recommendations

1. **Default to blocking Service Workers** for most tests
2. **Create separate test suite** for Service Worker-specific tests
3. **Always wait for activation** before interacting with Service Workers
4. **Use `browserContext.route()`** for mocking Service Worker requests
5. **Test offline scenarios** by blocking network requests
6. **Validate caching logic** by inspecting cached responses
7. **Document Service Worker behavior** in test comments

### Future Considerations

- **Service Worker updates:** Monitor GitHub issue #14711 for routing script updates
- **Cross-browser testing:** Service Workers currently only work on Chromium
- **Performance testing:** Measure impact of Service Workers on test execution time
- **Caching strategies:** Test different caching strategies for optimal performance
- **Offline testing:** Develop comprehensive offline testing scenarios
