# Playwright Documentation Research - Timeouts

**Page:** Timeouts  
**URL:** https://playwright.dev/docs/test-timeouts  
**Research Date:** December 13, 2025

## Overview

Playwright Test has multiple configurable timeouts for various tasks. Understanding and properly configuring timeouts is essential for reliable test execution.

## Main Timeout Types

### Quick Reference Table

| Timeout | Default | Description |
|---------|---------|-------------|
| **Test timeout** | 30,000 ms | Timeout for each test |
| **Expect timeout** | 5,000 ms | Timeout for each assertion |

## Test Timeout

Playwright Test enforces a timeout for each test, **30 seconds by default**.

### What's Included

Time spent by:
- Test function
- Fixture setups
- `beforeEach` hooks

### Timeout Error

```
example.spec.ts:3:1 › basic test ===========================

Timeout of 30000ms exceeded.
```

### Additional Timeout for Teardown

A separate timeout (same value) is shared between:
- Fixture teardowns
- `afterEach` hooks

**Timing:** After the test function has finished.

### beforeAll/afterAll Timeout

The same timeout value applies to `beforeAll` and `afterAll` hooks, but they **do not share time** with any test.

### Set Test Timeout in Config

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  timeout: 120_000,
});
```

**API reference:** `testConfig.timeout`

### Set Timeout for a Single Test

```typescript
// example.spec.ts
import { test, expect } from '@playwright/test';

test('slow test', async ({ page }) => {
  test.slow(); // Easy way to triple the default timeout
  // ...
});

test('very slow test', async ({ page }) => {
  test.setTimeout(120_000);
  // ...
});
```

**Methods:**
- `test.slow()` - Triples the default timeout
- `test.setTimeout(ms)` - Sets specific timeout value

**API reference:** `test.setTimeout()` and `test.slow()`

### Change Timeout from a beforeEach Hook

```typescript
// example.spec.ts
import { test, expect } from '@playwright/test';

test.beforeEach(async ({ page }, testInfo) => {
  // Extend timeout for all tests running this hook by 30 seconds
  testInfo.setTimeout(testInfo.timeout + 30_000);
});
```

**API reference:** `testInfo.setTimeout()`

### Change Timeout for beforeAll/afterAll

`beforeAll` and `afterAll` hooks have a separate timeout, by default equal to test timeout. Change it for each hook individually:

```typescript
// example.spec.ts
import { test, expect } from '@playwright/test';

test.beforeAll(async () => {
  // Set timeout for this hook
  test.setTimeout(60000);
});
```

**API reference:** `testInfo.setTimeout()`

## Expect Timeout

Auto-retrying assertions like `expect(locator).toHaveText()` have a separate timeout, **5 seconds by default**.

**Important:** Assertion timeout is **unrelated** to test timeout.

### Timeout Error

```
example.spec.ts:3:1 › basic test ===========================

Error: expect(received).toHaveText(expected)

Expected string: "my text"
Received string: ""
Call log:
  - expect.toHaveText with timeout 5000ms
  - waiting for "locator('button')"
```

### Set Expect Timeout in Config

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  expect: {
    timeout: 10_000,
  },
});
```

**API reference:** `testConfig.expect`

### Specify Expect Timeout for a Single Assertion

```typescript
// example.spec.ts
import { test, expect } from '@playwright/test';

test('example', async ({ page }) => {
  await expect(locator).toHaveText('hello', { timeout: 10_000 });
});
```

## Global Timeout

Timeout for the **whole test run**. Prevents excess resource usage when everything goes wrong.

**Default:** No global timeout (runs indefinitely)

**Recommendation:** Set a reasonable timeout in config (e.g., one hour)

### Timeout Error

```
Running 1000 tests using 10 workers
  514 skipped
  486 passed
  Timed out waiting 3600s for the entire test run
```

### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  globalTimeout: 3_600_000, // 1 hour
});
```

**API reference:** `testConfig.globalTimeout`

## Advanced: Low-Level Timeouts

Pre-configured by test runner. **You should not need to change these** unless you have specific requirements.

**Note:** If tests are flaky, the solution is likely elsewhere, not in these timeouts.

### Low-Level Timeout Types

| Timeout | Default | Description |
|---------|---------|-------------|
| **Action timeout** | no timeout | Timeout for each action |
| **Navigation timeout** | no timeout | Timeout for each navigation action |
| **Global timeout** | no timeout | Global timeout for whole test run |
| **beforeAll/afterAll timeout** | 30,000 ms | Timeout for the hook |
| **Fixture timeout** | no timeout | Timeout for individual fixture |

### Set Action and Navigation Timeouts in Config

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    actionTimeout: 10 * 1000,      // 10 seconds
    navigationTimeout: 30 * 1000,  // 30 seconds
  },
});
```

**API reference:** `testOptions.actionTimeout` and `testOptions.navigationTimeout`

### Set Timeout for a Single Action

```typescript
// example.spec.ts
import { test, expect } from '@playwright/test';

test('basic test', async ({ page }) => {
  await page.goto('https://playwright.dev', { timeout: 30000 });
  await page.getByText('Get Started').click({ timeout: 10000 });
});
```

## Fixture Timeout

By default, fixtures share timeout with the test. For slow fixtures (especially worker-scoped ones), set a separate timeout.

**Benefits:**
- Keep overall test timeout small
- Give slow fixtures more time

### Example

```typescript
// example.spec.ts
import { test as base, expect } from '@playwright/test';

const test = base.extend<{ slowFixture: string }>({
  slowFixture: [async ({}, use) => {
    // ... perform a slow operation ...
    await use('hello');
  }, { timeout: 60_000 }]
});

test('example test', async ({ slowFixture }) => {
  // ...
});
```

**API reference:** `test.extend()`

## Best Practices

### 1. Use Reasonable Default Timeouts

```typescript
export default defineConfig({
  timeout: 30_000,        // 30 seconds per test
  expect: {
    timeout: 5_000,       // 5 seconds per assertion
  },
  globalTimeout: 3_600_000, // 1 hour total
});
```

### 2. Use test.slow() for Known Slow Tests

```typescript
test('slow integration test', async ({ page }) => {
  test.slow(); // Triples timeout
  // ... slow operations ...
});
```

### 3. Increase Timeout from beforeEach for Setup

```typescript
test.beforeEach(async ({ page }, testInfo) => {
  // Add extra time for expensive setup
  testInfo.setTimeout(testInfo.timeout + 30_000);
  await performExpensiveSetup();
});
```

### 4. Set Specific Timeout for Flaky Assertions

```typescript
// Instead of increasing global expect timeout
await expect(locator).toBeVisible({ timeout: 10_000 });
```

### 5. Use Separate Fixture Timeouts

```typescript
const test = base.extend<{ dbConnection: Database }>({
  dbConnection: [async ({}, use) => {
    const db = await connectToDatabase();
    await use(db);
    await db.close();
  }, { timeout: 60_000 }] // Separate timeout for slow fixture
});
```

### 6. Set Global Timeout on CI

```typescript
export default defineConfig({
  globalTimeout: process.env.CI ? 3_600_000 : undefined,
});
```

### 7. Don't Set Action/Navigation Timeouts Unless Necessary

```typescript
// Avoid setting these unless you have a specific need
use: {
  actionTimeout: 10_000,
  navigationTimeout: 30_000,
}
```

### 8. Increase Timeout for Specific Slow Tests

```typescript
test('very slow test', async ({ page }) => {
  test.setTimeout(180_000); // 3 minutes
  // ... very slow operations ...
});
```

### 9. Use Different Timeouts for Different Projects

```typescript
projects: [
  {
    name: 'fast-tests',
    testMatch: /.*fast.spec.ts/,
    timeout: 15_000,
  },
  {
    name: 'slow-tests',
    testMatch: /.*slow.spec.ts/,
    timeout: 120_000,
  },
]
```

### 10. Monitor and Adjust Based on Test Duration

Review test execution times and adjust timeouts accordingly. Avoid setting timeouts too high as they mask real issues.

## Common Patterns

### Environment-Based Timeouts

```typescript
export default defineConfig({
  timeout: process.env.CI ? 60_000 : 30_000,
  globalTimeout: process.env.CI ? 7_200_000 : undefined,
});
```

### Test-Type-Specific Timeouts

```typescript
test.describe('API tests', () => {
  test.beforeEach(async ({}, testInfo) => {
    testInfo.setTimeout(10_000); // Fast API tests
  });
  // Tests
});

test.describe('E2E tests', () => {
  test.beforeEach(async ({}, testInfo) => {
    testInfo.setTimeout(60_000); // Slower E2E tests
  });
  // Tests
});
```

### Conditional Timeout Extension

```typescript
test('conditional test', async ({ page }, testInfo) => {
  if (process.env.SLOW_MODE) {
    testInfo.setTimeout(testInfo.timeout * 2);
  }
  // Test code
});
```

### Hook-Specific Timeouts

```typescript
test.beforeAll(async () => {
  test.setTimeout(120_000); // 2 minutes for setup
  await performExpensiveGlobalSetup();
});

test.afterAll(async () => {
  test.setTimeout(60_000); // 1 minute for cleanup
  await performCleanup();
});
```

### Fixture with Timeout

```typescript
const test = base.extend<{
  authenticatedPage: Page,
  database: Database
}>({
  authenticatedPage: async ({ page }, use) => {
    await page.goto('/login');
    await login(page);
    await use(page);
  },
  
  database: [async ({}, use) => {
    const db = await connectToDatabase();
    await use(db);
    await db.close();
  }, { timeout: 60_000 }] // Only database fixture has custom timeout
});
```

## Timeout Hierarchy

Understanding how timeouts interact:

```
Global Timeout (entire test run)
  └── Test Timeout (per test)
      ├── Test function + fixture setups + beforeEach
      └── Separate timeout for fixture teardowns + afterEach
  └── beforeAll/afterAll Timeout (separate, not shared with tests)
  └── Expect Timeout (independent, for assertions)
  └── Action Timeout (low-level, per action)
  └── Navigation Timeout (low-level, per navigation)
  └── Fixture Timeout (optional, per fixture)
```

## Troubleshooting Timeouts

### Test Timeout Exceeded

**Problem:** Test takes longer than allowed time

**Solutions:**
1. Increase timeout: `test.setTimeout(60_000)`
2. Use `test.slow()` to triple timeout
3. Optimize test to run faster
4. Split into smaller tests

### Expect Timeout Exceeded

**Problem:** Assertion waiting for condition that never happens

**Solutions:**
1. Increase assertion timeout: `expect(locator).toBeVisible({ timeout: 10_000 })`
2. Check if selector is correct
3. Verify element actually appears
4. Add explicit waits before assertion

### Global Timeout Exceeded

**Problem:** Entire test suite takes too long

**Solutions:**
1. Increase global timeout in config
2. Use sharding to distribute tests
3. Optimize slow tests
4. Remove unnecessary tests

### Action Timeout Issues

**Problem:** Actions taking too long

**Solutions:**
1. Check network conditions
2. Verify page is responsive
3. Use explicit waits
4. Increase action timeout if necessary

## Related Topics to Explore

- Test configuration
- Flaky test handling
- Test optimization
- Fixtures
- Hooks (beforeEach, afterEach, beforeAll, afterAll)
- Assertions
- Test retries
- CI/CD configuration
- Performance testing
- Test debugging
