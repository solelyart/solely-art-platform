# Playwright Documentation Research - Writing Tests

**Page:** Writing tests  
**URL:** https://playwright.dev/docs/writing-tests  
**Research Date:** December 13, 2025

## Core Philosophy

Playwright tests follow a simple two-part structure: **perform actions** and **assert the state** against expectations. The framework is designed around automatic waiting and resilient assertions that eliminate flaky tests.

## Key Concepts

### Automatic Waiting and Actionability

Playwright automatically waits for actionability checks to pass before performing each action. This eliminates the need for manual waits or dealing with race conditions. The framework checks that elements are:
- Attached to the DOM
- Visible
- Stable (not animating)
- Enabled
- Not obscured by other elements

### Async Matchers

Playwright assertions are designed to describe expectations that will eventually be met. Async matchers wait until the expected condition is met, eliminating flaky timeouts and racy checks.

## Test Structure

### Basic Test Example

```typescript
import { test, expect } from '@playwright/test';

test('has title', async ({ page }) => {
  await page.goto('https://playwright.dev/');
  await expect(page).toHaveTitle(/Playwright/);
});

test('get started link', async ({ page }) => {
  await page.goto('https://playwright.dev/');
  await page.getByRole('link', { name: 'Get started' }).click();
  await expect(page.getByRole('heading', { name: 'Installation' })).toBeVisible();
});
```

### Navigation

Most tests start by navigating to a URL using `page.goto()`. Playwright waits for the page to reach the load state before continuing.

```typescript
await page.goto('https://playwright.dev/');
```

## Actions

### Locating Elements

Playwright uses the Locators API to find elements on the page at any moment. Locators represent a way to find element(s) dynamically.

```typescript
// Create a locator
const getStarted = page.getByRole('link', { name: 'Get started' });
// Click it
await getStarted.click();

// Or in one line
await page.getByRole('link', { name: 'Get started' }).click();
```

### Common Actions

| Action | Description |
|--------|-------------|
| `locator.check()` | Check the input checkbox |
| `locator.click()` | Click the element |
| `locator.uncheck()` | Uncheck the input checkbox |
| `locator.hover()` | Hover mouse over the element |
| `locator.fill()` | Fill the form field, input text |
| `locator.focus()` | Focus the element |
| `locator.press()` | Press single key |
| `locator.setInputFiles()` | Pick files to upload |
| `locator.selectOption()` | Select option in the drop down |

## Assertions

### Async Assertions

Playwright includes test assertions using the `expect` function. Async matchers wait until the expected condition is met.

```typescript
await expect(page).toHaveTitle(/Playwright/);
```

### Common Async Assertions

| Assertion | Description |
|-----------|-------------|
| `expect(locator).toBeChecked()` | Checkbox is checked |
| `expect(locator).toBeEnabled()` | Control is enabled |
| `expect(locator).toBeVisible()` | Element is visible |
| `expect(locator).toContainText()` | Element contains text |
| `expect(locator).toHaveAttribute()` | Element has attribute |
| `expect(locator).toHaveCount()` | List of elements has given length |
| `expect(locator).toHaveText()` | Element matches text |
| `expect(locator).toHaveValue()` | Input element has value |
| `expect(page).toHaveTitle()` | Page has title |
| `expect(page).toHaveURL()` | Page has URL |

### Synchronous Assertions

Generic matchers like `toEqual`, `toContain`, `toBeTruthy` can be used for immediate synchronous checks on already available values. These do not use the `await` keyword.

```typescript
expect(success).toBeTruthy();
```

## Test Isolation

Playwright Test is based on the concept of test fixtures. The built-in `page` fixture is passed into tests. Pages are isolated between tests due to the Browser Context, which is equivalent to a brand new browser profile. Every test gets a fresh environment, even when multiple tests run in a single browser.

```typescript
test('example test', async ({ page }) => {
  // "page" belongs to an isolated BrowserContext, created for this specific test.
});

test('another test', async ({ page }) => {
  // "page" in this second test is completely isolated from the first test.
});
```

## Test Hooks

Playwright provides various test hooks for organizing and setting up tests:

- `test.describe` - Declare a group of tests
- `test.beforeEach` - Executed before each test
- `test.afterEach` - Executed after each test
- `test.beforeAll` - Executed once per worker before all tests
- `test.afterAll` - Executed once per worker after all tests

```typescript
test.describe('navigation', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://playwright.dev/');
  });

  test('main navigation', async ({ page }) => {
    await expect(page).toHaveURL('https://playwright.dev/');
  });
});
```

## Best Practices Noted

1. Add `// @ts-check` at the start of each test file when using JavaScript in VS Code for automatic type checking
2. Use locators to find elements dynamically rather than storing static selectors
3. Rely on automatic waiting instead of manual waits
4. Use async assertions that wait for conditions to be met
5. Leverage test isolation through fixtures for clean test environments

## Related Topics to Explore

- Locators API and different types of locators
- Actionability checks in detail
- Test fixtures system
- Browser Context isolation
- page.goto() options
