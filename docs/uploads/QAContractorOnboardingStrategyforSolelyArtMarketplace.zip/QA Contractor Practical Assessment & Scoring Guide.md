# QA Contractor Practical Assessment & Scoring Guide

**Document Version:** 1.0  
**Last Updated:** December 13, 2025  
**Author:** Manus AI

## 1. Introduction

This document provides the materials and scoring rubrics for the **Stage 3: Practical Work Sample Exercise** and **Stage 4: Behavioral and Technical Interview** as outlined in the main *Strategic Guide to Identifying and Evaluating QA Contractors*. Its purpose is to equip the hiring team with standardized tools to ensure a fair, consistent, and effective evaluation of all candidates.

The work sample exercise is the most critical component of the evaluation process, as it simulates a real-world challenge and provides direct evidence of a candidate's capabilities. The scoring rubrics are designed to translate that evidence into objective, comparable data points.

---

## 2. Work Sample Exercise: Materials & Instructions

This section contains the information to be provided to the candidate for the **Bug Investigation and Communication Task**.

### Candidate Briefing Document

**Exercise Title:** Bug Investigation and Communication Task

**Time Allotment:** 90 minutes (60 minutes for investigation and artifact creation, 30 minutes for presentation and feedback/revision)

**Background:**
Welcome to the practical assessment for the QA Contractor role at Solely Art Platform. This exercise is designed to simulate a real-world scenario you might encounter while working with us. We want to see how you approach a complex problem, analyze its root cause, and communicate your findings to different team members.

**The Scenario:**
We have received a high-priority report from a user about a potential double-booking issue. The Solely Art Platform's booking engine is supposed to prevent this, so it's a critical issue to investigate. 

**Initial Bug Report:**

> **Title:** Possible double-booking for artist Jane Doe
> 
> **Description:** I was trying to book a 1-hour session with Jane Doe for her last available slot today at 3:00 PM. My friend was trying to book the same slot at the same time. We both were able to get to the payment page, which shouldn't happen. I didn't complete the payment, but this seems wrong.

**Your Task:**
Your goal is to investigate this issue and communicate your findings. You have been given access to our staging environment and relevant documentation.

**Deliverables:**

1.  **Enhanced Bug Report:** Using our bug reporting format (similar to Monday.com), create a comprehensive bug report. It must include:
    *   A clear, descriptive title.
    *   Precise, step-by-step instructions on how to reliably reproduce the issue (you may need to simulate two users acting simultaneously).
    *   A detailed analysis of the potential root cause.
    *   An assessment of the business impact and user experience implications.

2.  **Technical Communication Artifact:** Write a brief, technical note for a back-end developer. This should:
    *   Explain the likely technical cause of the issue (e.g., race condition, locking issue).
    *   Suggest specific areas of the codebase or data flow (referencing the provided architecture diagram) that they should investigate.

3.  **Non-Technical Communication Artifact:** Write a concise summary for a non-technical Product Manager. This should:
    *   Explain the problem in simple, business-focused terms.
    *   Clearly articulate the risk and potential impact on users and the business.
    *   Avoid technical jargon.

**Provided Materials:**
1.  Access credentials for the Solely Art Platform staging environment.
2.  A simplified version of the `QA_MASTER_DOCUMENTATION.md`, including the platform architecture and data flow diagrams.

---

## 3. Scoring Rubric: Work Sample Exercise

Use this rubric to score the candidate's performance on each deliverable. Score each criterion on a scale of 1 (Poor) to 5 (Excellent).

| Criteria | 1 - Poor | 2 - Fair | 3 - Good | 4 - Very Good | 5 - Excellent |
|---|---|---|---|---|---|
| **Bug Reproduction & Analysis** | Unable to reproduce the bug or analysis is incorrect/missing. | Reproduces the bug inconsistently; analysis is superficial. | Reliably reproduces the bug; correctly identifies the issue as a concurrency problem. | Provides precise steps to reproduce; clearly articulates the concept of a race condition. | Provides flawless reproduction steps and a deep, insightful analysis of the race condition and its potential triggers. |
| **Technical Communication** | Explanation is unclear, incorrect, or provides no useful direction for the developer. | Vaguely mentions a bug but offers no technical insight or direction. | Correctly identifies the technical issue (race condition) but provides generic advice. | Provides a clear explanation and points to the correct area of the system (e.g., booking/slot locking). | Provides a clear, concise explanation and suggests specific technical solutions (e.g., database-level locking, transactional integrity checks). |
| **Business Communication** | Fails to explain the business impact; uses technical jargon. | Explains the bug but not the business risk. | Explains the business risk but the message is not concise or is somewhat technical. | Clearly and concisely explains the business impact and user experience risk with no jargon. | Delivers a compelling, persuasive summary of the business risk that would galvanize a Product Manager to prioritize the fix. |
| **Attention to Detail** | Bug report is missing key information and has significant errors. | Bug report is mostly complete but lacks detail or has minor errors. | Bug report is complete and accurate. | Bug report is highly detailed, well-structured, and easy to follow. | Bug report is exceptionally thorough, anticipating potential questions and providing extra context beyond what was asked. |
| **Adaptability (Feedback/Revision)** | Is defensive or unable to incorporate feedback effectively. | Struggles to understand or apply the feedback. | Accepts feedback and makes a satisfactory revision. | Accepts feedback gracefully and makes a strong, effective revision. | Proactively seeks to understand the feedback deeply and makes an exceptional revision that significantly improves the original artifact. |

**Scoring:**
- **Total Score:** Sum the scores from each category (Max: 25).
- **Hiring Recommendation:**
    - **21-25:** Strong Hire. Candidate demonstrates senior-level skills.
    - **16-20:** Hireable. Candidate is competent but may need some initial guidance.
    - **11-15:** Borderline. Hire with caution; may not be ready for the complexity of the role.
    - **<11:** No Hire. Candidate does not meet the minimum requirements.

---

## 4. Interview Scorecard

Use this scorecard during the **Stage 4: Behavioral and Technical Interview** to ensure all candidates are evaluated against the same criteria. Rate each area on a scale of 1 to 5.

**Candidate Name:** ________________________

**Interviewer:** ________________________

| Category | Question / Topic | Rating (1-5) | Notes |
|---|---|---|---|
| **Strategic Thinking** | *"Based on your understanding of the Solely Art Platform, which feature would you prioritize for testing and why?"* | | |
| | *"How would you approach creating a test plan for our new messaging feature?"* | | |
| **Technical Proficiency** | *"Describe a time you had to test a complex system with multiple integrations. What was your approach?"* | | |
| | *"Walk me through how you would write a simple automated test for our login page."* | | |
| **Problem-Solving & Communication** | *"You've found a critical bug an hour before a major release. What do you do?"* | | |
| | *"Describe a situation where you had to explain a complex technical issue to a non-technical team member."* | | |
| **Cultural Fit & Collaboration** | *"How do you prefer to receive feedback on your work?"* | | |
| | *"Describe your ideal collaboration process with developers."* | | |
| **Overall Impression** | Candidate's questions, enthusiasm, and professionalism. | | |

**Overall Rating (Average):** ________

**Hiring Recommendation:** (Strong Hire / Hire / No Hire)

**Justification:**





