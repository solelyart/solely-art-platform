# Playwright Documentation Research - Web Server

**Page:** Web server  
**URL:** https://playwright.dev/docs/test-webserver  
**Research Date:** December 13, 2025

## Overview

Playwright provides a `webServer` option in the config file to **launch a local dev server before running tests**.

**Use cases:**
- Writing tests during development
- No staging or production URL available
- Testing against local development server

## Introduction

The `webServer` property launches a development web server during tests automatically.

**Benefits:**
- Automatic server startup
- Server management handled by Playwright
- Automatic cleanup after tests

## Configuring a Web Server

### Basic Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Run your local dev server before starting the tests
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
    stdout: 'ignore',
    stderr: 'pipe',
  },
});
```

## webServer Configuration Options

### Complete Property Reference

| Property | Description |
|----------|-------------|
| `command` | Shell command to start the local dev server |
| `url` | URL expected to return 2xx, 3xx, 400, 401, 402, or 403 status when ready |
| `reuseExistingServer` | Reuse existing server if available |
| `timeout` | How long to wait for server to start (default: 60000ms) |
| `cwd` | Current working directory of spawned process |
| `env` | Environment variables for the command |
| `stdout` | Pipe or ignore stdout (default: "ignore") |
| `stderr` | Pipe or ignore stderr (default: "pipe") |
| `ignoreHTTPSErrors` | Ignore HTTPS errors when fetching URL (default: false) |
| `name` | Custom name for web server in logs (default: "[WebServer]") |
| `gracefulShutdown` | How to shut down the process |
| `wait` | Wait for specific output before considering server started |
| `port` | **Deprecated** - Use `url` instead |

### command

**Type:** `string`

Shell command to start the local dev server.

```typescript
command: 'npm run start'
```

**Examples:**
- `'npm run dev'`
- `'yarn start'`
- `'node server.js'`
- `'python -m http.server 8000'`

### url

**Type:** `string`

URL of your HTTP server that returns a 2xx, 3xx, 400, 401, 402, or 403 status code when ready.

```typescript
url: 'http://localhost:3000'
```

**Purpose:** Playwright waits for this URL to be accessible before running tests.

**Note:** Either `port` or `url` should be specified (prefer `url`).

### reuseExistingServer

**Type:** `boolean`

**Behavior:**
- `true`: Re-use existing server on the port/URL if available
- `false`: Throw error if server already running

```typescript
reuseExistingServer: !process.env.CI
```

**Common pattern:** Allow reuse locally, but not in CI.

**Rationale:**
- Local: Faster development (don't restart server)
- CI: Ensure clean environment

### timeout

**Type:** `number` (milliseconds)

**Default:** 60000 (60 seconds)

How long to wait for the server to start and be available.

```typescript
timeout: 120 * 1000  // 120 seconds
```

### cwd

**Type:** `string`

Current working directory of the spawned process.

**Default:** Directory of the configuration file

```typescript
cwd: './backend'
```

### env

**Type:** `object`

Environment variables for the command.

**Default:** Inherits `process.env` with `PLAYWRIGHT_TEST=1` added

```typescript
env: {
  NODE_ENV: 'test',
  PORT: '3000'
}
```

### stdout

**Type:** `'pipe' | 'ignore'`

**Default:** `'ignore'`

**Options:**
- `'pipe'`: Pipe stdout to process stdout
- `'ignore'`: Ignore stdout

```typescript
stdout: 'ignore'
```

### stderr

**Type:** `'pipe' | 'ignore'`

**Default:** `'pipe'`

**Options:**
- `'pipe'`: Pipe stderr to process stderr
- `'ignore'`: Ignore stderr

```typescript
stderr: 'pipe'
```

### ignoreHTTPSErrors

**Type:** `boolean`

**Default:** `false`

Whether to ignore HTTPS errors when fetching the URL.

```typescript
ignoreHTTPSErrors: true
```

### name

**Type:** `string`

**Default:** `'[WebServer]'`

Custom name for the web server (prefixed to log messages).

```typescript
name: 'Frontend Server'
```

### gracefulShutdown

**Type:** `object`

How to shut down the process.

**Default:** Process group is forcefully `SIGKILL`ed

**Options:**
```typescript
gracefulShutdown: {
  signal: 'SIGTERM',  // or 'SIGINT'
  timeout: 500        // milliseconds
}
```

**Behavior:**
1. Send specified signal (SIGTERM or SIGINT)
2. Wait for timeout
3. Send SIGKILL if process hasn't exited

**Special cases:**
- `timeout: 0` means no SIGKILL will be sent
- Windows doesn't support SIGTERM and SIGINT (option ignored)
- Docker containers require SIGTERM

### wait

**Type:** `object`

Consider command started only when given output has been produced.

```typescript
wait: {
  stdout: /Listening on port (?<my_server_port>\\d+)/,
  stderr: /Server error: (?<error_message>.*)/
}
```

**Named capture groups:** Stored in environment variables (uppercase with underscores).

**Example:** `/Listening on port (?<my_server_port>\\d+)/` stores port in `process.env['MY_SERVER_PORT']`

### port (Deprecated)

**Type:** `number`

**Status:** Deprecated - Use `url` instead

The port your HTTP server is expected to appear on.

```typescript
port: 3000  // Deprecated, use url instead
```

## Adding a Server Timeout

Webservers can sometimes take longer to boot up. Increase the timeout if needed.

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Rest of your config...
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
    timeout: 120 * 1000,  // 120 seconds
  },
});
```

**Use case:** Slow-starting servers (e.g., large applications, cold starts).

## Adding a baseURL

**Recommendation:** Specify `baseURL` in the `use: {}` section for relative URLs in tests.

### Benefits

- Use relative URLs in tests
- Avoid repeating full URL
- Easier to change environment

### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  // Rest of your config...
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
  use: {
    baseURL: 'http://localhost:3000',
  },
});
```

### How baseURL Works

When using these methods, baseURL is considered:
- `page.goto()`
- `page.route()`
- `page.waitForURL()`
- `page.waitForRequest()`
- `page.waitForResponse()`

**Implementation:** Uses `URL()` constructor to build corresponding URL.

### Example Usage

```typescript
// test.spec.ts
import { test } from '@playwright/test';

test('test', async ({ page }) => {
  // This will navigate to http://localhost:3000/login
  await page.goto('./login');
});
```

**Result:** `baseURL` + relative path = full URL

## Multiple Web Servers

Launch multiple web servers (or background processes) simultaneously by providing an array.

### Configuration

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  webServer: [
    {
      command: 'npm run start',
      url: 'http://localhost:3000',
      name: 'Frontend',
      timeout: 120 * 1000,
      reuseExistingServer: !process.env.CI,
    },
    {
      command: 'npm run backend',
      url: 'http://localhost:3333',
      name: 'Backend',
      timeout: 120 * 1000,
      reuseExistingServer: !process.env.CI,
    }
  ],
  use: {
    baseURL: 'http://localhost:3000',
  },
});
```

**Use cases:**
- Frontend + Backend servers
- Multiple microservices
- Database + API server
- Mock services

## Best Practices

### 1. Use reuseExistingServer Based on Environment

```typescript
reuseExistingServer: !process.env.CI
```

**Rationale:**
- Local: Reuse for faster development
- CI: Fresh start for clean environment

### 2. Set Appropriate Timeout

```typescript
timeout: 120 * 1000  // Increase for slow-starting servers
```

### 3. Always Specify baseURL

```typescript
use: {
  baseURL: 'http://localhost:3000',
}
```

**Benefit:** Use relative URLs in tests.

### 4. Pipe stderr, Ignore stdout

```typescript
stdout: 'ignore',
stderr: 'pipe',
```

**Rationale:**
- stdout: Often noisy, ignore
- stderr: Important errors, pipe

### 5. Name Multiple Servers

```typescript
webServer: [
  { name: 'Frontend', ... },
  { name: 'Backend', ... },
]
```

**Benefit:** Clear log messages.

### 6. Use Graceful Shutdown for Docker

```typescript
gracefulShutdown: {
  signal: 'SIGTERM',
  timeout: 5000
}
```

### 7. Set Environment Variables

```typescript
env: {
  NODE_ENV: 'test',
  PORT: '3000'
}
```

### 8. Use wait for Specific Output

```typescript
wait: {
  stdout: /Server listening on port \d+/
}
```

### 9. Ignore HTTPS Errors for Self-Signed Certs

```typescript
ignoreHTTPSErrors: true
```

### 10. Set Working Directory for Monorepos

```typescript
cwd: './packages/frontend'
```

## Common Patterns

### Basic Development Server

```typescript
webServer: {
  command: 'npm run dev',
  url: 'http://localhost:3000',
  reuseExistingServer: !process.env.CI,
}
```

### Production Build Testing

```typescript
webServer: {
  command: 'npm run build && npm run start',
  url: 'http://localhost:3000',
  timeout: 120 * 1000,
  reuseExistingServer: false,
}
```

### Full-Stack Application

```typescript
webServer: [
  {
    command: 'npm run frontend',
    url: 'http://localhost:3000',
    name: 'Frontend',
  },
  {
    command: 'npm run backend',
    url: 'http://localhost:4000',
    name: 'Backend',
  },
  {
    command: 'npm run db',
    url: 'http://localhost:5432',
    name: 'Database',
  },
]
```

### Environment-Specific Configuration

```typescript
webServer: {
  command: process.env.CI ? 'npm run start:ci' : 'npm run dev',
  url: process.env.BASE_URL || 'http://localhost:3000',
  reuseExistingServer: !process.env.CI,
}
```

### With Environment Variables

```typescript
webServer: {
  command: 'npm run start',
  url: 'http://localhost:3000',
  env: {
    NODE_ENV: 'test',
    DATABASE_URL: 'postgresql://localhost:5432/test',
    API_KEY: process.env.TEST_API_KEY,
  },
}
```

### Graceful Shutdown for Docker

```typescript
webServer: {
  command: 'docker-compose up',
  url: 'http://localhost:3000',
  gracefulShutdown: {
    signal: 'SIGTERM',
    timeout: 10000,
  },
}
```

### Wait for Specific Output

```typescript
webServer: {
  command: 'npm run start',
  url: 'http://localhost:3000',
  wait: {
    stdout: /Listening on port (?<server_port>\\d+)/,
  },
}
```

### Python Development Server

```typescript
webServer: {
  command: 'python -m http.server 8000',
  url: 'http://localhost:8000',
  cwd: './dist',
}
```

### Monorepo Setup

```typescript
webServer: [
  {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    cwd: './apps/web',
    name: 'Web App',
  },
  {
    command: 'npm run dev',
    url: 'http://localhost:4000',
    cwd: './apps/api',
    name: 'API',
  },
]
```

## Troubleshooting

### Server Takes Too Long to Start

**Problem:** Tests fail because server isn't ready

**Solution:** Increase timeout
```typescript
timeout: 180 * 1000  // 3 minutes
```

### Port Already in Use

**Problem:** Error when server port is already occupied

**Solution:** Use `reuseExistingServer`
```typescript
reuseExistingServer: true
```

### Server Doesn't Shut Down Cleanly

**Problem:** Server process remains after tests

**Solution:** Configure graceful shutdown
```typescript
gracefulShutdown: {
  signal: 'SIGTERM',
  timeout: 5000
}
```

### Wrong Working Directory

**Problem:** Server can't find files

**Solution:** Set `cwd`
```typescript
cwd: './backend'
```

### Environment Variables Not Set

**Problem:** Server missing required env vars

**Solution:** Specify `env`
```typescript
env: {
  NODE_ENV: 'test',
  API_KEY: process.env.TEST_API_KEY
}
```

## Related Topics to Explore

- Test configuration
- baseURL usage
- Environment variables
- CI/CD setup
- Docker integration
- Monorepo testing
- API testing
- Global setup and teardown
- Test isolation
- Development workflows
