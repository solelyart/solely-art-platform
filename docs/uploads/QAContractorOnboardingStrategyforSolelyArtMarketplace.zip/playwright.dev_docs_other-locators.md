XPath locator​
WARNING

We recommend prioritizing user-visible locators like text or accessible role instead of using XPath that is tied to the implementation and easily break when the page changes.

XPath locators are equivalent to calling Document.evaluate.

await page.locator('xpath=//button').click();

NOTE

Any selector string starting with // or .. are assumed to be an xpath selector. For example, Playwright converts '//html/body' to 'xpath=//html/body'.

NOTE

XPath does not pierce shadow roots.

XPath union​

Pipe operator (|) can be used to specify multiple selectors in XPath. It will match all elements that can be selected by one of the selectors in that list.

// Waits for either confirmation dialog or load spinner.
await page.locator(
    `//span[contains(@class, 'spinner__loading')]|//div[@id='confirmation']`
).waitFor();

Label to form control retargeting​
WARNING

We recommend locating by label text instead of relying to label-to-control retargeting.

Targeted input actions in Playwright automatically distinguish between labels and controls, so you can target the label to perform an action on the associated control.

For example, consider the following DOM structure: <label for="password">Password:</label><input id="password" type="password">. You can target the label by its "Password" text using page.getByText(). However, the following actions will be performed on the input instead of the label:

locator.click() will click the label and automatically focus the input field;
locator.fill() will fill the input field;
locator.inputValue() will return the value of the input field;
locator.selectText() will select text in the input field;
locator.setInputFiles() will set files for the input field with type=file;
locator.selectOption() will select an option from the select box.
// Fill the input by targeting the label.
await page.getByText('Password').fill('secret');


However, other methods will target the label itself, for example expect(locator).toHaveText() will assert the text content of the label, not the input field.

// Fill the input by targeting the label.
await expect(page.locator('label')).toHaveText('Password');

Legacy text locator​
WARNING

We recommend the modern text locator instead.

Legacy text locator matches elements that contain passed text.

await page.locator('text=Log in').click();


Legacy text locator has a few variations:

text=Log in - default matching is case-insensitive, trims whitespace and searches for a substring. For example, text=Log matches <button>Log in</button>.

await page.locator('text=Log in').click();


text="Log in" - text body can be escaped with single or double quotes to search for a text node with exact content after trimming whitespace.

For example, text="Log" does not match <button>Log in</button> because <button> contains a single text node "Log in" that is not equal to "Log". However, text="Log" matches <button> Log <span>in</span></button>, because <button> contains a text node " Log ". This exact mode implies case-sensitive matching, so text="Download" will not match <button>download</button>.

Quoted body follows the usual escaping rules, e.g. use \" to escape double quote in a double-quoted string: text="foo\"bar".

await page.locator('text="Log in"').click();


/Log\s*in/i - body can be a JavaScript-like regex wrapped in / symbols. For example, text=/Log\s*in/i matches <button>Login</button> and <button>log IN</button>.

await page.locator('text=/Log\\s*in/i').click();

NOTE

String selectors starting and ending with a quote (either " or ') are assumed to be a legacy text locators. For example, "Log in" is converted to text="Log in" internally.

NOTE

Matching always normalizes whitespace. For example, it turns multiple spaces into one, turns line breaks into spaces and ignores leading and trailing whitespace.

NOTE

Input elements of the type button and submit are matched by their value instead of text content. For example, text=Log in matches <input type=button value="Log in">.

id, data-testid, data-test-id, data-test selectors​
WARNING

We recommend locating by test id instead.

Playwright supports shorthand for selecting elements using certain attributes. Currently, only the following attributes are supported:

id
data-testid
data-test-id
data-test
// Fill an input with the id "username"
await page.locator('id=username').fill('value');

// Click an element with data-test-id "submit"
await page.locator('data-test-id=submit').click();

NOTE

Attribute selectors are not CSS selectors, so anything CSS-specific like :enabled is not supported. For more features, use a proper css selector, e.g. css=[data-test="login"]:enabled.

Chaining selectors​
WARNING

We recommend chaining locators instead.

Selectors defined as engine=body or in short-form can be combined with the >> token, e.g. selector1 >> selector2 >> selectors3. When selectors are chained, the next one is queried relative to the previous one's result.

For example,

css=article >> css=.bar > .baz >> css=span[attr=value]


is equivalent to

document
    .querySelector('article')
    .querySelector('.bar > .baz')
    .querySelector('span[attr=value]');


If a selector needs to include >> in the body, it should be escaped inside a string to not be confused with chaining separator, e.g. text="some >> text".

Intermediate matches​
WARNING

We recommend filtering by another locator to locate elements that contain other elements.

By default, chained selectors resolve to an element queried by the last selector. A selector can be prefixed with * to capture elements that are queried by an intermediate selector.

For example, css=article >> text=Hello captures the element with the text Hello, and *css=article >> text=Hello (note the *) captures the article element that contains some element with the text Hello.

Previous
Network
Next
Pages
Introduction
CSS locator
CSS: matching by text
CSS: matching only visible elements
CSS: elements that contain other elements
CSS: elements matching one of the conditions
CSS: matching elements based on layout
CSS: pick n-th match from the query result
N-th element locator
Parent element locator
React locator
Vue locator
XPath locator
XPath union
Label to form control retargeting
Legacy text locator
id, data-testid, data-test-id, data-test selectors
Chaining selectors
Intermediate matches
Learn
Getting started
Playwright Training
Learn Videos
Feature Videos
Community
Stack Overflow
Discord
Twitter
LinkedIn
More
GitHub
YouTube
Blog
Ambassadors
Copyright © 2025 Microsoft