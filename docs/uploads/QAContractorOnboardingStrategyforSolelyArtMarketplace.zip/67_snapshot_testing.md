# Playwright Documentation Research - Snapshot Testing

**Page:** Snapshot Testing
**URL:** https://playwright.dev/docs/test-snapshots
**Research Date:** December 14, 2025

## Overview

Playwright provides support for snapshot testing. This allows you to compare screenshots or other data against a baseline to detect unexpected changes.

### Key Features

- **Visual regression testing:** Compare screenshots to detect visual changes.
- **Data snapshotting:** Compare any serializable data against a baseline.
- **Update snapshots:** Easily update snapshots when changes are expected.

## Usage

### Screenshot Snapshot

```javascript
await expect(page).toHaveScreenshot();
```

### Data Snapshot

```javascript
const data = await page.evaluate(() => window.someData);
expect(data).toMatchSnapshot("my-data.json");
```

## Summary

### Key Takeaways

- **`toHaveScreenshot()`:** For visual regression testing.
- **`toMatchSnapshot()`:** For data snapshotting.
- **`--update-snapshots`:** To update snapshots.

### Related Topics

- Assertions
- Screenshots
