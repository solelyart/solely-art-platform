# Playwright Documentation Research - Handles

**Page:** Handles  
**URL:** https://playwright.dev/docs/handles  
**Research Date:** December 14, 2025

## Introduction

**Capability:** Playwright can create handles to:
- Page DOM elements
- Any other objects inside the page

**Location:** These handles live in **Playwright process**, whereas actual objects live in **browser**.

### Two Types of Handles

**1. JSHandle** - To reference any JavaScript objects in the page

**2. ElementHandle** - To reference DOM elements in the page
- Has extra methods that allow performing actions on elements
- Allows asserting element properties

**Relationship:** Since any DOM element in page is also JavaScript object, any **ElementHandle** is a **JSHandle** as well.

### Handle Operations

**Uses:** Handles are used to perform operations on those actual objects in page:
- Evaluate on handle
- Get handle properties
- Pass handle as evaluation parameter
- Serialize page object into JSON
- etc.

**API:** See JSHandle class API for these methods.

## API Reference

- **JSHandle**
- **ElementHandle**

### Obtaining JSHandle

**Easiest way:**
```typescript
const jsHandle = await page.evaluateHandle('window');
//  Use jsHandle for evaluations.
```

## Element Handles

### ⚠️ DISCOURAGED

**Recommendation:** The use of **ElementHandle is discouraged**, use **Locator** objects and web-first assertions instead.

### When ElementHandle is Required

**Recommended approach:** Fetch it with:
- `page.waitForSelector()`
- `frame.waitForSelector()`

**Benefit:** These APIs wait for element to be:
- Attached
- Visible

### Example Usage

```typescript
// Get the element handle
const elementHandle = page.waitForSelector('#box');

// Assert bounding box for the element
const boundingBox = await elementHandle.boundingBox();
expect(boundingBox.width).toBe(100);

// Assert attribute for the element
const classNames = await elementHandle.getAttribute('class');
expect(classNames.includes('highlighted')).toBeTruthy();
```

## Handles as Parameters

**Capability:** Handles can be passed into `page.evaluate()` and similar methods.

### Example: Array Handle

**Pattern:** Creates new array in page, initializes it with data, returns handle to array into Playwright, then uses handle in subsequent evaluations:

```typescript
// Create new array in page.
const myArrayHandle = await page.evaluateHandle(() => {
  window.myArray = [1];
  return myArray;
});

// Get the length of the array.
const length = await page.evaluate(a => a.length, myArrayHandle);

// Add one more element to the array using the handle
await page.evaluate(arg => arg.myArray.push(arg.newElement), {
  myArray: myArrayHandle,
  newElement: 2
});

// Release the object when it's no longer needed.
await myArrayHandle.dispose();
```

## Handle Lifecycle

### Acquiring Handles

**Methods:** Handles can be acquired using page methods such as:
- `page.evaluateHandle()`
- `page.$()`
- `page.$$()`

**Frame counterparts:**
- `frame.evaluateHandle()`
- `frame.$()`
- `frame.$$()`

### Garbage Collection

**Retention:** Once created, handles will retain object from **garbage collection** unless:
- Page navigates, or
- Handle is manually disposed via `jsHandle.dispose()` method

### API Reference

- JSHandle
- ElementHandle
- `elementHandle.boundingBox()`
- `elementHandle.getAttribute()`
- `elementHandle.innerText()`
- `elementHandle.innerHTML()`
- `elementHandle.textContent()`
- `jsHandle.evaluate()`
- `page.evaluateHandle()`
- `page.$()`
- `page.$$()`

## Locator vs ElementHandle

### ⚠️ CAUTION

**Recommendation:** We only recommend using **ElementHandle** in rare cases when you need to perform extensive DOM traversal on static page.

**For all user actions and assertions:** Use **locator** instead.

### Key Difference

**ElementHandle:** Points to particular element

**Locator:** Captures logic of how to retrieve that element

### ElementHandle Problem - Stale Reference

**Issue:** Handle points to particular DOM element on page. If that element changes text or is used by React to render entirely different component, handle is still pointing to that very **stale DOM element**. This can lead to **unexpected behaviors**.

**Example:**
```typescript
const handle = await page.$('text=Submit');
// ...
await handle.hover();
await handle.click();
```

**Problem:** If element changes between hover and click, handle still points to old element.

### Locator Solution - Always Fresh

**Benefit:** With locator, every time locator is used, **up-to-date DOM element** is located in page using selector.

**Example:**
```typescript
const locator = page.getByText('Submit');
// ...
await locator.hover();
await locator.click();
```

**Behavior:** Underlying DOM element is going to be located twice (once for hover, once for click), ensuring it's always fresh.

## Best Practices

### 1. Prefer Locators Over ElementHandles

**✅ Good:**
```typescript
const button = page.getByRole('button', { name: 'Submit' });
await button.click();
```

**❌ Discouraged:**
```typescript
const handle = await page.$('button');
await handle.click();
```

### 2. Dispose Handles When Done

**✅ Good:**
```typescript
const handle = await page.evaluateHandle(() => window.myObject);
// Use handle
await handle.dispose(); // Clean up
```

### 3. Use waitForSelector for ElementHandles

**✅ Good:**
```typescript
const handle = await page.waitForSelector('.element');
// Element is guaranteed to be attached and visible
```

**❌ Bad:**
```typescript
const handle = await page.$('.element');
// Element might not be ready
```

### 4. Pass Handles as Evaluation Parameters

**✅ Good:**
```typescript
const handle = await page.evaluateHandle(() => window.myObject);
const result = await page.evaluate(obj => obj.property, handle);
```

### 5. Avoid Long-Lived Handles

**✅ Good:**
```typescript
const handle = await page.evaluateHandle(() => window.data);
const value = await handle.jsonValue();
await handle.dispose();
// Use value
```

**❌ Bad:**
```typescript
const handle = await page.evaluateHandle(() => window.data);
// Keep handle for long time - risk of stale reference
```

## Common Use Cases

### Use Case 1: Get Window Object

```typescript
test('get window object', async ({ page }) => {
  await page.goto('/');
  
  const windowHandle = await page.evaluateHandle(() => window);
  const userAgent = await windowHandle.evaluate(win => win.navigator.userAgent);
  
  expect(userAgent).toContain('Chrome');
  
  await windowHandle.dispose();
});
```

### Use Case 2: Get Element Bounding Box

```typescript
test('get element bounding box', async ({ page }) => {
  await page.goto('/');
  
  const handle = await page.waitForSelector('.box');
  const box = await handle.boundingBox();
  
  expect(box.width).toBe(100);
  expect(box.height).toBe(100);
  
  await handle.dispose();
});
```

### Use Case 3: Pass Handle to Evaluate

```typescript
test('pass handle to evaluate', async ({ page }) => {
  await page.goto('/');
  
  const dataHandle = await page.evaluateHandle(() => ({
    users: ['Alice', 'Bob'],
    count: 2,
  }));
  
  const count = await page.evaluate(data => data.count, dataHandle);
  expect(count).toBe(2);
  
  await dataHandle.dispose();
});
```

### Use Case 4: Get JSON Value from Handle

```typescript
test('get JSON value from handle', async ({ page }) => {
  await page.goto('/');
  
  const dataHandle = await page.evaluateHandle(() => ({
    name: 'John',
    age: 30,
  }));
  
  const data = await dataHandle.jsonValue();
  
  expect(data.name).toBe('John');
  expect(data.age).toBe(30);
  
  await dataHandle.dispose();
});
```

### Use Case 5: Manipulate Array via Handle

```typescript
test('manipulate array via handle', async ({ page }) => {
  await page.goto('/');
  
  const arrayHandle = await page.evaluateHandle(() => {
    window.myArray = [1, 2, 3];
    return window.myArray;
  });
  
  await page.evaluate(arr => arr.push(4), arrayHandle);
  
  const length = await page.evaluate(arr => arr.length, arrayHandle);
  expect(length).toBe(4);
  
  await arrayHandle.dispose();
});
```

## Use Cases for Solely Art Platform

### Example 1: Get Booking Data Object

```typescript
test('get booking data object', async ({ page }) => {
  await page.goto('/booking/123');
  
  const bookingHandle = await page.evaluateHandle(() => window.bookingData);
  
  const booking = await bookingHandle.jsonValue();
  
  expect(booking.artistId).toBe(123);
  expect(booking.status).toBe('confirmed');
  
  await bookingHandle.dispose();
});
```

### Example 2: Get Artist Profile Element Properties

```typescript
test('get artist profile properties', async ({ page }) => {
  await page.goto('/artist/123');
  
  const profileHandle = await page.waitForSelector('.artist-profile');
  
  const innerHTML = await profileHandle.innerHTML();
  const innerText = await profileHandle.innerText();
  const className = await profileHandle.getAttribute('class');
  
  expect(innerHTML).toContain('John Doe');
  expect(innerText).toContain('Music Artist');
  expect(className).toContain('verified');
  
  await profileHandle.dispose();
});
```

### Example 3: Manipulate Search Results Array

```typescript
test('manipulate search results', async ({ page }) => {
  await page.goto('/search');
  
  const resultsHandle = await page.evaluateHandle(() => {
    window.searchResults = [
      { id: 1, name: 'Artist 1' },
      { id: 2, name: 'Artist 2' },
    ];
    return window.searchResults;
  });
  
  // Add new result
  await page.evaluate(results => {
    results.push({ id: 3, name: 'Artist 3' });
  }, resultsHandle);
  
  const count = await page.evaluate(results => results.length, resultsHandle);
  expect(count).toBe(3);
  
  await resultsHandle.dispose();
});
```

### Example 4: Get Calendar Element Bounding Box

```typescript
test('get calendar bounding box', async ({ page }) => {
  await page.goto('/artist/123/book');
  
  const calendarHandle = await page.waitForSelector('.booking-calendar');
  const box = await calendarHandle.boundingBox();
  
  expect(box.width).toBeGreaterThan(300);
  expect(box.height).toBeGreaterThan(400);
  
  await calendarHandle.dispose();
});
```

### Example 5: Access Global App State

```typescript
test('access global app state', async ({ page }) => {
  await page.goto('/');
  
  const appStateHandle = await page.evaluateHandle(() => window.appState);
  
  const state = await appStateHandle.jsonValue();
  
  expect(state.isAuthenticated).toBe(true);
  expect(state.currentUser).toBeDefined();
  
  await appStateHandle.dispose();
});
```

## Advanced Patterns

### Pattern 1: Chain Handle Operations

```typescript
test('chain handle operations', async ({ page }) => {
  await page.goto('/');
  
  const handle = await page.evaluateHandle(() => window.data);
  
  const value1 = await handle.evaluate(d => d.property1);
  const value2 = await handle.evaluate(d => d.property2);
  
  expect(value1).toBeDefined();
  expect(value2).toBeDefined();
  
  await handle.dispose();
});
```

### Pattern 2: Multiple Handles

```typescript
test('use multiple handles', async ({ page }) => {
  await page.goto('/');
  
  const handle1 = await page.evaluateHandle(() => window.obj1);
  const handle2 = await page.evaluateHandle(() => window.obj2);
  
  const result = await page.evaluate(
    ({ obj1, obj2 }) => obj1.value + obj2.value,
    { obj1: handle1, obj2: handle2 }
  );
  
  expect(result).toBeDefined();
  
  await handle1.dispose();
  await handle2.dispose();
});
```

### Pattern 3: Handle Properties

```typescript
test('get handle properties', async ({ page }) => {
  await page.goto('/');
  
  const handle = await page.evaluateHandle(() => ({
    name: 'Test',
    count: 42,
  }));
  
  const properties = await handle.getProperties();
  const nameHandle = properties.get('name');
  const name = await nameHandle.jsonValue();
  
  expect(name).toBe('Test');
  
  await handle.dispose();
});
```

### Pattern 4: Element Handle Methods

```typescript
test('use element handle methods', async ({ page }) => {
  await page.goto('/');
  
  const handle = await page.waitForSelector('button');
  
  const text = await handle.textContent();
  const isVisible = await handle.isVisible();
  const isEnabled = await handle.isEnabled();
  
  expect(text).toBe('Click me');
  expect(isVisible).toBe(true);
  expect(isEnabled).toBe(true);
  
  await handle.dispose();
});
```

### Pattern 5: Query Selector on Handle

```typescript
test('query selector on handle', async ({ page }) => {
  await page.goto('/');
  
  const containerHandle = await page.waitForSelector('.container');
  const buttonHandle = await containerHandle.$('button');
  
  await buttonHandle.click();
  
  await containerHandle.dispose();
  await buttonHandle.dispose();
});
```

## Handle Methods

### page.evaluateHandle(pageFunction, arg)

**Purpose:** Execute function in page and return JSHandle.

```typescript
const handle = await page.evaluateHandle(() => window);
```

### page.$(selector)

**Purpose:** Query selector and return ElementHandle.

```typescript
const handle = await page.$('button');
```

**Note:** Discouraged, use locators instead.

### page.$$(selector)

**Purpose:** Query selector all and return array of ElementHandles.

```typescript
const handles = await page.$$('button');
```

**Note:** Discouraged, use locators instead.

### page.waitForSelector(selector)

**Purpose:** Wait for element and return ElementHandle.

```typescript
const handle = await page.waitForSelector('.element');
```

### jsHandle.evaluate(pageFunction, arg)

**Purpose:** Evaluate function on handle.

```typescript
const value = await handle.evaluate(obj => obj.property);
```

### jsHandle.jsonValue()

**Purpose:** Get JSON representation of handle.

```typescript
const data = await handle.jsonValue();
```

### jsHandle.dispose()

**Purpose:** Dispose handle and release from garbage collection.

```typescript
await handle.dispose();
```

### jsHandle.getProperties()

**Purpose:** Get handle properties as map.

```typescript
const properties = await handle.getProperties();
```

### elementHandle.boundingBox()

**Purpose:** Get element bounding box.

```typescript
const box = await handle.boundingBox();
```

### elementHandle.getAttribute(name)

**Purpose:** Get element attribute.

```typescript
const className = await handle.getAttribute('class');
```

### elementHandle.innerHTML()

**Purpose:** Get element innerHTML.

```typescript
const html = await handle.innerHTML();
```

### elementHandle.innerText()

**Purpose:** Get element innerText.

```typescript
const text = await handle.innerText();
```

### elementHandle.textContent()

**Purpose:** Get element textContent.

```typescript
const text = await handle.textContent();
```

### elementHandle.$(selector)

**Purpose:** Query selector within element.

```typescript
const childHandle = await handle.$('.child');
```

### elementHandle.$$(selector)

**Purpose:** Query selector all within element.

```typescript
const childHandles = await handle.$$('.child');
```

## Troubleshooting

### Issue: Stale Element Reference

**Cause:** Using ElementHandle after element has changed.

**Solution:** Use Locators instead of ElementHandles.

```typescript
// ✅ Correct - Use Locator
const button = page.getByRole('button');
await button.click();

// ❌ Wrong - ElementHandle can become stale
const handle = await page.$('button');
await handle.click(); // May fail if element changed
```

### Issue: Handle Not Disposed

**Cause:** Forgetting to dispose handle.

**Solution:** Always dispose handles when done.

```typescript
// ✅ Correct
const handle = await page.evaluateHandle(() => window.data);
const value = await handle.jsonValue();
await handle.dispose();

// ❌ Wrong
const handle = await page.evaluateHandle(() => window.data);
const value = await handle.jsonValue();
// Forgot to dispose - memory leak
```

### Issue: Element Not Found

**Cause:** Using `page.$()` on element that doesn't exist yet.

**Solution:** Use `page.waitForSelector()` instead.

```typescript
// ✅ Correct
const handle = await page.waitForSelector('.element');

// ❌ Wrong
const handle = await page.$('.element'); // May return null
```

### Issue: Cannot Serialize Handle

**Cause:** Trying to return handle from evaluate.

**Solution:** Use `evaluateHandle()` instead of `evaluate()`.

```typescript
// ✅ Correct
const handle = await page.evaluateHandle(() => document.body);

// ❌ Wrong
const element = await page.evaluate(() => document.body); // Error
```

## Summary

### Key Concepts

**1. Two types:** JSHandle (any JS object), ElementHandle (DOM elements)

**2. Discouraged:** ElementHandle is discouraged, use Locators instead

**3. Handles live in Playwright:** Actual objects live in browser

**4. Stale references:** ElementHandles can become stale, Locators always fresh

**5. Dispose handles:** Always dispose handles to prevent memory leaks

### Handle Types

- **JSHandle** - Reference to JavaScript object in page
- **ElementHandle** - Reference to DOM element in page (discouraged)

### Locator vs ElementHandle

- **ElementHandle** - Points to particular element (can become stale)
- **Locator** - Captures logic to retrieve element (always fresh)

### Best Practices

1. Prefer Locators over ElementHandles
2. Dispose handles when done
3. Use `waitForSelector()` for ElementHandles
4. Pass handles as evaluation parameters
5. Avoid long-lived handles

### Common Methods

- `page.evaluateHandle()` - Get JSHandle
- `page.waitForSelector()` - Get ElementHandle (discouraged)
- `jsHandle.evaluate()` - Evaluate on handle
- `jsHandle.jsonValue()` - Get JSON value
- `jsHandle.dispose()` - Dispose handle
- `elementHandle.boundingBox()` - Get bounding box
- `elementHandle.getAttribute()` - Get attribute

## Related Topics

- Locators
- Evaluating JavaScript
- Pages
- Frames
- Isolation
- Garbage collection
- Web-first assertions
