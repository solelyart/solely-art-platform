# Videos | Playwright

**URL:** https://playwright.dev/docs/videos

---

Skip to main content
Playwright
Docs
API
Node.js
Community
Search
⌘
K
Getting Started
Installation
Writing tests
Generating tests
Running and debugging tests
Trace viewer
Setting up CI
Getting started - VS Code
Release notes
Canary releases
Playwright Test
Agents
Annotations
Command line
Configuration
Configuration (use)
Emulation
Fixtures
Global setup and teardown
Parallelism
Parameterize tests
Projects
Reporters
Retries
Sharding
Timeouts
TypeScript
UI Mode
Web server
Guides
Library
Accessibility testing
Actions
Assertions
API testing
Authentication
Auto-waiting
Best Practices
Browsers
Chrome extensions
Clock
Components (experimental)
Debugging Tests
Dialogs
Downloads
Evaluating JavaScript
Events
Extensibility
Frames
Handles
Isolation
Locators
Mock APIs
Mock browser APIs
Navigations
Network
Other locators
Pages
Page object models
Screenshots
Service Workers
Snapshot testing
Test generator
Touch events (legacy)
Trace viewer
Videos
Visual comparisons
WebView2
Migration
Integrations
Supported languages
GuidesVideos
Videos
Introduction​

With Playwright you can record videos for your tests.

Record video​

Playwright Test can record videos for your tests, controlled by the video option in your Playwright config. By default videos are off.

'off' - Do not record video.
'on' - Record video for each test.
'retain-on-failure' - Record video for each test, but remove all videos from successful test runs.
'on-first-retry' - Record video only when retrying a test for the first time.

Video files will appear in the test output directory, typically test-results. See testOptions.video for advanced video configuration.

Videos are saved upon browser context closure at the end of a test. If you create a browser context manually, make sure to await browserContext.close().

Test
Library
playwright.config.ts
import { defineConfig } from '@playwright/test';
export default defineConfig({
  use: {
    video: 'on-first-retry',
  },
});


You can also specify video size. The video size defaults to the viewport size scaled down to fit 800x800. The video of the viewport is placed in the top-left corner of the output video, scaled down to fit if necessary. You may need to set the viewport size to match your desired video size.

Test
Library
playwright.config.ts
import { defineConfig } from '@playwright/test';
export default defineConfig({
  use: {
    video: {
      mode: 'on-first-retry',
      size: { width: 640, height: 480 }
    }
  },
});


For multi-page scenarios, you can access the video file associated with the page via the page.video().

const path = await page.video().path();

NOTE

Note that the video is only available after the page or browser context is closed.

Previous
Trace viewer
Next
Visual comparisons
Introduction
Record video
Learn
Getting started
Playwright Training
Learn Videos
Feature Videos
Community
Stack Overflow
Discord
Twitter
LinkedIn
More
GitHub
YouTube
Blog
Ambassadors
Copyright © 2025 Microsoft