# Playwright Documentation Research - Mock APIs

**Page:** Mock APIs  
**URL:** https://playwright.dev/docs/mock  
**Research Date:** December 13, 2025

## Introduction

**Overview:** Web APIs are usually implemented as HTTP endpoints. Playwright provides APIs to **mock** and **modify** network traffic, both HTTP and HTTPS.

**Capabilities:**
- Track requests (XHRs and fetch)
- Modify requests
- Mock requests
- Mock using HAR files (containing multiple network requests)

## Mock API Requests

### Complete Request Mocking

**Purpose:** Intercept API calls and return custom response without making actual API request.

**Example:**
```typescript
test("mocks a fruit and doesn't call api", async ({ page }) => {
  // Mock the api call before navigating
  await page.route('*/**/api/v1/fruits', async route => {
    const json = [{ name: 'Strawberry', id: 21 }];
    await route.fulfill({ json });
  });
  
  // Go to the page
  await page.goto('https://demo.playwright.dev/api-mocking');

  // Assert that the Strawberry fruit is visible
  await expect(page.getByText('Strawberry')).toBeVisible();
});
```

**Key points:**
- No actual API requests made
- Custom mock data returned
- Trace shows API fulfilled with mock data, never called

**Use case:** Test UI behavior without depending on external APIs.

## Modify API Responses

### Request-Modify-Fulfill Pattern

**Purpose:** Make actual API request but patch response for reproducible testing.

**Example:**
```typescript
test('gets the json from api and adds a new fruit', async ({ page }) => {
  // Get the response and add to it
  await page.route('*/**/api/v1/fruits', async route => {
    const response = await route.fetch();
    const json = await response.json();
    json.push({ name: 'Loquat', id: 100 });
    
    // Fulfill using the original response, while patching the response body
    // with the given JSON object.
    await route.fulfill({ response, json });
  });

  // Go to the page
  await page.goto('https://demo.playwright.dev/api-mocking');

  // Assert that the new fruit is visible
  await expect(page.getByText('Loquat', { exact: true })).toBeVisible();
});
```

**Key points:**
- Actual API called
- Response modified before fulfillment
- Trace shows API was called and response modified

**Use case:** Test with real API data but ensure specific test conditions.

## Mocking with HAR Files

### What is HAR?

**Definition:** HAR (HTTP Archive) file contains record of all network requests made when page is loaded.

**Contains:**
- Request and response headers
- Cookies
- Content
- Timings
- More

### HAR Workflow

**Three steps:**
1. Record a HAR file
2. Commit HAR file alongside tests
3. Route requests using saved HAR files in tests

### Recording a HAR File

**Method 1: Using `routeFromHAR()` with `update: true`**

**Methods available:**
- `page.routeFromHAR()`
- `browserContext.routeFromHAR()`

**Parameters:**
- Path to HAR file
- Optional options object

**Options:**
- `url`: Glob pattern to match specific URLs (if not specified, all requests served from HAR)
- `update: true`: Creates or updates HAR file with actual network information

**Example:**
```typescript
await page.routeFromHAR('./hars/fruit.har', {
  url: '*/**/api/v1/fruits',
  update: true,  // Record mode
});
```

**Method 2: Using `recordHar` option**

**Alternative approach:**
```typescript
const context = await browser.newContext({
  recordHar: { path: './hars/example.har' }
});
```

**Benefit:** Captures all network traffic for entire context until context is closed.

### Modifying a HAR File

**Process:**
1. Open hashed `.txt` file inside `hars` folder
2. Edit the JSON manually
3. Commit to source control

**Example modification:**
```json
[
  {
    "name": "Playwright",
    "id": 100
  },
  // ... other fruits
]
```

**Note:** Running test with `update: true` will update HAR file with request from API.

### Replaying from HAR

**Process:** Turn off or remove `update` option to replay from HAR instead of hitting API.

**Example:**
```typescript
test('gets the json from HAR and checks the new fruit has been added', async ({ page }) => {
  // Replay API requests from HAR.
  // Either use a matching response from the HAR,
  // or abort the request if nothing matches.
  await page.routeFromHAR('./hars/fruit.har', {
    url: '*/**/api/v1/fruits',
    update: false,  // Replay mode
  });

  // Go to the page
  await page.goto('https://demo.playwright.dev/api-mocking');

  // Assert that the Playwright fruit is visible
  await expect(page.getByText('Playwright', { exact: true })).toBeVisible();
});
```

**Key points:**
- Route fulfilled from HAR file
- API not called
- Trace shows fulfillment from HAR

### HAR Matching Rules

**Strict matching:**
- URL matched strictly
- HTTP method matched strictly
- For POST requests: POST payloads matched strictly

**Multiple matches:**
- If multiple recordings match, the one with most matching headers is picked

**Redirects:**
- Entry resulting in redirect followed automatically

### HAR Archive Format

**ZIP support:**
- If HAR file name ends with `.zip`, it's considered an archive
- Contains HAR file + network payloads as separate entries
- Can extract, edit payloads/HAR log manually
- Point to extracted HAR file
- All payloads resolved relative to extracted HAR file

### Recording HAR with CLI

**Command:**
```bash
# Save API requests from example.com as "example.har" archive
npx playwright open --save-har=example.har --save-har-glob="**/api/**" https://example.com
```

**Options:**
- `--save-har`: Produce HAR file
- `--save-har-glob`: Only save requests matching pattern (e.g., API endpoints)
- `.zip` extension: Artifacts written as separate files, compressed into single zip

**Recommendation:** Use `update` option in tests rather than CLI for recording.

## Mock WebSockets

### Complete WebSocket Mocking

**Purpose:** Intercept WebSocket connections and mock entire communication without connecting to server.

**Example:**
```typescript
await page.routeWebSocket('wss://example.com/ws', ws => {
  ws.onMessage(message => {
    if (message === 'request')
      ws.send('response');
  });
});
```

**Behavior:** Responds to "request" with "response" without server connection.

### Intercept and Modify WebSocket Messages

**Purpose:** Connect to actual server but intercept and modify messages in-between.

**Example:**
```typescript
await page.routeWebSocket('wss://example.com/ws', ws => {
  const server = ws.connectToServer();
  ws.onMessage(message => {
    if (message === 'request')
      server.send('request2');  // Modified message
    else
      server.send(message);     // Unmodified message
  });
});
```

**Behavior:** Modifies some messages, leaves rest unmodified.

**Reference:** See `WebSocketRoute` for more details.

## Best Practices

### 1. Mock Before Navigation

Always set up mocks before navigating to the page.

```typescript
// ✅ Good
await page.route('**/api/**', route => route.fulfill({ json: mockData }));
await page.goto('https://example.com');

// ❌ Bad
await page.goto('https://example.com');
await page.route('**/api/**', route => route.fulfill({ json: mockData }));
```

### 2. Use Glob Patterns

Use glob patterns to match multiple similar endpoints.

```typescript
await page.route('*/**/api/v1/**', async route => {
  // Handle all v1 API calls
});
```

### 3. Choose Right Approach

**Complete mocking:** When you don't need real API data
```typescript
await page.route('**/api/**', route => route.fulfill({ json: mockData }));
```

**Modify responses:** When you need real data with modifications
```typescript
await page.route('**/api/**', async route => {
  const response = await route.fetch();
  const json = await response.json();
  json.modified = true;
  await route.fulfill({ response, json });
});
```

**HAR files:** When you need to replay complex multi-request scenarios
```typescript
await page.routeFromHAR('./hars/scenario.har', {
  url: '**/api/**',
  update: false
});
```

### 4. HAR File Management

**Recording:**
- Use `update: true` when creating/updating HAR
- Commit HAR files to source control
- Use specific URL patterns to reduce HAR file size

**Replaying:**
- Use `update: false` or omit option for replay
- Manually edit HAR files for test-specific data
- Use `.zip` format for large HAR files

### 5. WebSocket Testing

**Complete mocking:** For unit-like tests
```typescript
await page.routeWebSocket('wss://example.com/ws', ws => {
  ws.onMessage(message => ws.send('mock response'));
});
```

**Intercept and modify:** For integration-like tests
```typescript
await page.routeWebSocket('wss://example.com/ws', ws => {
  const server = ws.connectToServer();
  ws.onMessage(message => {
    // Modify or pass through
    server.send(modifyMessage(message));
  });
});
```

## Common Patterns

### Pattern 1: Mock Multiple Endpoints

```typescript
test('mock multiple endpoints', async ({ page }) => {
  await page.route('**/api/users', route => 
    route.fulfill({ json: [{ id: 1, name: 'John' }] })
  );
  
  await page.route('**/api/products', route => 
    route.fulfill({ json: [{ id: 1, name: 'Product' }] })
  );
  
  await page.goto('https://example.com');
});
```

### Pattern 2: Conditional Mocking

```typescript
test('conditional mock based on request', async ({ page }) => {
  await page.route('**/api/**', async route => {
    const url = route.request().url();
    
    if (url.includes('/users')) {
      await route.fulfill({ json: mockUsers });
    } else if (url.includes('/products')) {
      await route.fulfill({ json: mockProducts });
    } else {
      await route.continue();  // Let other requests through
    }
  });
  
  await page.goto('https://example.com');
});
```

### Pattern 3: Error Simulation

```typescript
test('simulate API error', async ({ page }) => {
  await page.route('**/api/data', route => 
    route.fulfill({ 
      status: 500,
      body: 'Internal Server Error'
    })
  );
  
  await page.goto('https://example.com');
  await expect(page.getByText('Error loading data')).toBeVisible();
});
```

### Pattern 4: Delay Simulation

```typescript
test('simulate slow API', async ({ page }) => {
  await page.route('**/api/data', async route => {
    await new Promise(resolve => setTimeout(resolve, 3000));
    await route.fulfill({ json: mockData });
  });
  
  await page.goto('https://example.com');
  // Test loading states
});
```

### Pattern 5: HAR Recording Workflow

```typescript
// Step 1: Record HAR
test('record HAR', async ({ page }) => {
  await page.routeFromHAR('./hars/scenario.har', {
    url: '**/api/**',
    update: true  // Record mode
  });
  
  await page.goto('https://example.com');
  // Perform actions that trigger API calls
});

// Step 2: Manually edit HAR file in hars/scenario.har.txt

// Step 3: Replay from HAR
test('replay from HAR', async ({ page }) => {
  await page.routeFromHAR('./hars/scenario.har', {
    url: '**/api/**',
    update: false  // Replay mode
  });
  
  await page.goto('https://example.com');
  // Assert expected behavior
});
```

## Use Cases for Solely Art Platform

### 1. Mock Booking API

```typescript
test('mock booking availability check', async ({ page }) => {
  await page.route('**/api/bookings/availability', route => 
    route.fulfill({ 
      json: { 
        available: true,
        dates: ['2025-01-15', '2025-01-16']
      }
    })
  );
  
  await page.goto('/artist/profile');
  // Test booking flow with mocked availability
});
```

### 2. Mock Payment Processing

```typescript
test('mock successful payment', async ({ page }) => {
  await page.route('**/api/payments/process', route => 
    route.fulfill({ 
      json: { 
        success: true,
        transactionId: 'mock-txn-123'
      }
    })
  );
  
  // Test payment flow
});
```

### 3. Mock Messaging System

```typescript
test('mock real-time messaging', async ({ page }) => {
  await page.routeWebSocket('wss://api.solelyart.com/ws', ws => {
    ws.onMessage(message => {
      const data = JSON.parse(message);
      if (data.type === 'send_message') {
        ws.send(JSON.stringify({
          type: 'message_received',
          messageId: 'mock-msg-123',
          timestamp: Date.now()
        }));
      }
    });
  });
  
  await page.goto('/messages');
  // Test messaging functionality
});
```

### 4. Record Complex User Journey

```typescript
test('record complete booking journey', async ({ page }) => {
  await page.routeFromHAR('./hars/booking-journey.har', {
    url: '**/api/**',
    update: true
  });
  
  await page.goto('/');
  // Complete entire booking flow
  // HAR will capture all API interactions
});
```

## Summary

### Key Capabilities

1. **Complete mocking** - No API calls made
2. **Response modification** - Real API with modified responses
3. **HAR files** - Record and replay complex scenarios
4. **WebSocket mocking** - Mock or intercept WebSocket communication

### When to Use Each Approach

**Complete mocking:**
- Unit-like tests
- Testing UI logic without backend
- Simulating error conditions
- Fast, isolated tests

**Response modification:**
- Need real API data structure
- Test edge cases with real data
- Ensure specific test conditions

**HAR files:**
- Complex multi-request scenarios
- Regression testing
- Reproducible test environments
- Offline testing

**WebSocket mocking:**
- Real-time feature testing
- Message flow testing
- Connection handling

## Related Topics

- Advanced networking
- Network interception
- Request routing
- Response fulfillment
- HAR format
- WebSocket routing
- API testing
- Test isolation
