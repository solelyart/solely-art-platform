# Playwright Documentation Research - Accessibility Testing

**Page:** Accessibility testing  
**URL:** https://playwright.dev/docs/accessibility-testing  
**Research Date:** December 13, 2025

## Overview

Playwright can be used to test applications for many types of **accessibility issues**.

**Examples of problems detected:**
- Poor color contrast (hard to read for vision impairments)
- UI controls/form elements without screen reader labels
- Interactive elements with duplicate IDs (confuses assistive technologies)

## Required Package

Examples rely on **`@axe-core/playwright`** package which adds support for running the **axe accessibility testing engine** as part of Playwright tests.

### Installation

```bash
npm install --save-dev @axe-core/playwright
```

## Important Disclaimer

⚠️ **Automated accessibility tests can detect some common problems** (missing/invalid properties) **but many accessibility problems can only be discovered through manual testing**.

**Recommendation:** Use combination of:
1. Automated testing
2. Manual accessibility assessments
3. Inclusive user testing

**For manual assessments:** Use **Accessibility Insights for Web** (free, open source dev tool) that walks through assessing a website for **WCAG 2.1 AA** coverage.

## Example Accessibility Tests

Accessibility tests work just like any other Playwright test. You can:
- Create separate test cases for them
- Integrate accessibility scans into existing test cases

### Scanning an Entire Page

Test entire page for automatically detectable accessibility violations.

**The test:**
1. Imports `@axe-core/playwright` package
2. Uses normal Playwright Test syntax
3. Navigates to page under test
4. Awaits `AxeBuilder.analyze()` to run scan
5. Uses assertions to verify no violations

```typescript
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright'; // 1

test.describe('homepage', () => { // 2
  test('should not have any automatically detectable accessibility issues', async ({ page }) => {
    await page.goto('https://your-site.com/'); // 3

    const accessibilityScanResults = await new AxeBuilder({ page }).analyze(); // 4

    expect(accessibilityScanResults.violations).toEqual([]); // 5
  });
});
```

### Configuring axe to Scan Specific Part of Page

`@axe-core/playwright` supports many configuration options using **Builder pattern** with `AxeBuilder` class.

**Use `AxeBuilder.include()`** to constrain scan to one specific part of page.

**Important:** `AxeBuilder.analyze()` scans page **in its current state** when called. To scan parts revealed by UI interactions, use Locators to interact first.

```typescript
test('navigation menu should not have automatically detectable accessibility violations', async ({
  page,
}) => {
  await page.goto('https://your-site.com/');

  await page.getByRole('button', { name: 'Navigation Menu' }).click();

  // Important: waitFor() the page to be in desired state
  // *before* running analyze(). Otherwise, axe might not
  // find all elements your test expects it to scan.
  await page.locator('#navigation-menu-flyout').waitFor();

  const accessibilityScanResults = await new AxeBuilder({ page })
      .include('#navigation-menu-flyout')
      .analyze();

  expect(accessibilityScanResults.violations).toEqual([]);
});
```

### Scanning for WCAG Violations

**Default behavior:** axe checks against wide variety of accessibility rules:
- Some correspond to WCAG success criteria
- Others are "best practice" rules (not required by WCAG)

**Use `AxeBuilder.withTags()`** to constrain scan to rules tagged as corresponding to specific WCAG success criteria.

**Example:** Match **Accessibility Insights for Web's Automated Checks** (only WCAG A and AA):

```typescript
test('should not have any automatically detectable WCAG A or AA violations', async ({ page }) => {
  await page.goto('https://your-site.com/');

  const accessibilityScanResults = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();

  expect(accessibilityScanResults.violations).toEqual([]);
});
```

**Tags used:**
- `wcag2a` - WCAG 2.0 Level A
- `wcag2aa` - WCAG 2.0 Level AA
- `wcag21a` - WCAG 2.1 Level A
- `wcag21aa` - WCAG 2.1 Level AA

**Note:** Automated testing cannot detect all types of WCAG violations.

**Complete listing:** See "Axe-core Tags" section of axe API documentation.

## Handling Known Issues

Common question: "How do I suppress known violations?"

### Excluding Individual Elements from Scan

Use **`AxeBuilder.exclude()`** to exclude specific elements with known issues.

**Downsides:**
- Excludes specified elements **and all descendants**
- Prevents **all rules** from running (not just rules with known issues)

```typescript
test('should not have any accessibility violations outside of elements with known issues', async ({
  page,
}) => {
  await page.goto('https://your-site.com/page-with-known-issues');

  const accessibilityScanResults = await new AxeBuilder({ page })
      .exclude('#element-with-known-issue')
      .analyze();

  expect(accessibilityScanResults.violations).toEqual([]);
});
```

**Tip:** If element used repeatedly in many pages, use test fixture to reuse configuration.

### Disabling Individual Scan Rules

Use **`AxeBuilder.disableRules()`** to temporarily disable specific rules with many preexisting violations.

**Finding rule IDs:** Look in `id` property of violations you want to suppress.

```typescript
test('should not have any accessibility violations outside of rules with known issues', async ({
  page,
}) => {
  await page.goto('https://your-site.com/page-with-known-issues');

  const accessibilityScanResults = await new AxeBuilder({ page })
      .disableRules(['duplicate-id'])
      .analyze();

  expect(accessibilityScanResults.violations).toEqual([]);
});
```

### Using Snapshots to Allow Specific Known Issues

Use **Snapshots** to verify preexisting violations haven't changed. More granular than `exclude()` but slightly more complex.

**Don't do this (fragile):**
```typescript
// Don't do this! This is fragile.
expect(accessibilityScanResults.violations).toMatchSnapshot();
```

**Reason:** Contains implementation details (rendered HTML snippets) that break on unrelated changes.

**Do this instead (less fragile):**
```typescript
// This is less fragile than snapshotting the entire violations array.
expect(violationFingerprints(accessibilityScanResults)).toMatchSnapshot();

// my-test-utils.js
function violationFingerprints(accessibilityScanResults) {
  const violationFingerprints = accessibilityScanResults.violations.map(violation => ({
    rule: violation.id,
    // CSS selectors which uniquely identify each element with violation
    targets: violation.nodes.map(node => node.target),
  }));

  return JSON.stringify(violationFingerprints, null, 2);
}
```

**Fingerprint contains:**
- Rule ID
- CSS selectors identifying elements with violations
- Only enough info to uniquely identify issue

## Exporting Scan Results as Test Attachment

Scan results contain more than just violations:
- Rules which passed
- Elements with inconclusive results
- Useful for debugging

**Use `testInfo.attach()`** to include full scan results:

```typescript
test('example with attachment', async ({ page }, testInfo) => {
  await page.goto('https://your-site.com/');

  const accessibilityScanResults = await new AxeBuilder({ page }).analyze();

  await testInfo.attach('accessibility-scan-results', {
    body: JSON.stringify(accessibilityScanResults, null, 2),
    contentType: 'application/json'
  });

  expect(accessibilityScanResults.violations).toEqual([]);
});
```

**Benefit:** Reporters can embed or link full results in test output.

## Using Test Fixture for Common Configuration

**Test fixtures** share common `AxeBuilder` configuration across tests.

**Use cases:**
- Common set of rules among all tests
- Suppress known violation in common element across many pages
- Common configuration patterns

### Creating Fixture

```typescript
// fixtures.ts
import { test as base } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

export const test = base.extend({
  makeAxeBuilder: async ({ page }, use) => {
    const makeAxeBuilder = () => new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('#known-issue-element');
    await use(makeAxeBuilder);
  }
});

export { expect } from '@playwright/test';
```

### Using Fixture

```typescript
import { test, expect } from './fixtures';

test('should not have accessibility violations', async ({ page, makeAxeBuilder }) => {
  await page.goto('https://your-site.com/');
  
  const accessibilityScanResults = await makeAxeBuilder().analyze();
  
  expect(accessibilityScanResults.violations).toEqual([]);
});
```

## Best Practices

### 1. Combine Automated and Manual Testing

Automated tests catch common issues, but manual testing is essential.

### 2. Use WCAG Tags for Compliance Testing

```typescript
.withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
```

### 3. Wait for Page State Before Scanning

```typescript
await page.locator('#dynamic-content').waitFor();
const results = await new AxeBuilder({ page }).analyze();
```

### 4. Create Violation Fingerprints for Snapshots

Don't snapshot entire violations array (fragile).

### 5. Use Test Fixtures for Shared Configuration

Reuse common `AxeBuilder` configuration across tests.

### 6. Attach Full Scan Results for Debugging

```typescript
await testInfo.attach('accessibility-scan-results', {
  body: JSON.stringify(accessibilityScanResults, null, 2),
  contentType: 'application/json'
});
```

### 7. Exclude Elements Sparingly

`exclude()` affects all descendants and all rules.

### 8. Disable Rules Temporarily

Use `disableRules()` as temporary measure while fixing issues.

### 9. Scan Specific Components

Use `include()` to focus on specific parts of page.

### 10. Document Known Issues

When suppressing violations, document why and when they'll be fixed.

## Common Patterns

### Full Page Scan

```typescript
test('full page accessibility', async ({ page }) => {
  await page.goto('https://your-site.com/');
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations).toEqual([]);
});
```

### Component-Specific Scan

```typescript
test('modal accessibility', async ({ page }) => {
  await page.goto('https://your-site.com/');
  await page.click('[data-testid="open-modal"]');
  await page.locator('[role="dialog"]').waitFor();
  
  const results = await new AxeBuilder({ page })
    .include('[role="dialog"]')
    .analyze();
  
  expect(results.violations).toEqual([]);
});
```

### WCAG Compliance Testing

```typescript
test('WCAG 2.1 AA compliance', async ({ page }) => {
  await page.goto('https://your-site.com/');
  
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  
  expect(results.violations).toEqual([]);
});
```

### With Known Issues Excluded

```typescript
test('accessibility with known issues', async ({ page }) => {
  await page.goto('https://your-site.com/');
  
  const results = await new AxeBuilder({ page })
    .exclude('#legacy-component')
    .disableRules(['color-contrast'])
    .analyze();
  
  expect(results.violations).toEqual([]);
});
```

### Using Fixture

```typescript
// fixtures.ts
export const test = base.extend({
  makeAxeBuilder: async ({ page }, use) => {
    await use(() => new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']));
  }
});

// test.spec.ts
test('using fixture', async ({ page, makeAxeBuilder }) => {
  await page.goto('https://your-site.com/');
  const results = await makeAxeBuilder().analyze();
  expect(results.violations).toEqual([]);
});
```

## Related Topics to Explore

- WCAG guidelines
- Axe-core rules
- Test fixtures
- Snapshots
- Locators
- Test attachments
- Manual accessibility testing
- Screen reader testing
- Keyboard navigation testing
- Color contrast testing
