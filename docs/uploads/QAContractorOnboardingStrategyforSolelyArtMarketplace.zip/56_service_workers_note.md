# Playwright Documentation Research - Service Workers

**Page:** Service Workers  
**URL:** https://playwright.dev/docs/service-workers-experimental  
**Research Date:** December 14, 2025  
**Status:** 404 - Page Not Found

## Note

The Service Workers documentation page is currently unavailable (404 error). The URL attempted was:
- https://playwright.dev/docs/service-workers-experimental

This page may have been:
- Removed from the documentation
- Moved to a different URL
- Still in experimental status and not yet published

## Alternative Resources

Based on the Playwright API documentation and general knowledge:

### Service Worker Support in Playwright

Playwright has support for Service Workers through the browser context and page APIs:

**Key APIs:**
- `browserContext.serviceWorkers()` - Returns all service workers
- `page.workers()` - Returns all workers including service workers
- `worker.url()` - Get worker URL
- `worker.evaluate()` - Evaluate code in worker context

**Basic Example:**
```typescript
// Wait for service worker
const [worker] = await Promise.all([
  context.waitForEvent('serviceworker'),
  page.goto('/')
]);

console.log(worker.url());

// Evaluate in service worker context
const result = await worker.evaluate(() => {
  return self.registration.scope;
});
```

### Testing Service Workers

**Common testing scenarios:**
1. Verify service worker registration
2. Test caching strategies
3. Test offline functionality
4. Test push notifications
5. Test background sync

**Example: Verify Service Worker Registration**
```typescript
test('service worker registers', async ({ page, context }) => {
  const workerPromise = context.waitForEvent('serviceworker');
  await page.goto('/');
  const worker = await workerPromise;
  
  expect(worker.url()).toContain('service-worker.js');
});
```

**Example: Test Offline Functionality**
```typescript
test('works offline', async ({ page, context }) => {
  // Load page with service worker
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  
  // Go offline
  await context.setOffline(true);
  
  // Navigate to cached page
  await page.goto('/cached-page');
  
  // Verify page loaded from cache
  await expect(page.locator('h1')).toHaveText('Cached Page');
});
```

## Related Topics

- Workers
- Browser contexts
- Network interception
- Offline testing
- Caching strategies

## Status

This page requires further investigation or may be documented in a different section of the Playwright documentation.
